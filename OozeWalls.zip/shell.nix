{ pkgs ? import <nixpkgs> { } }:
pkgs.mkShell {
  nativeBuildInputs = [ pkgs.pkg-config pkgs.cargo pkgs.rustc ];
  buildInputs = with pkgs; [
    mpv-unwrapped
    libGL
    wayland
    libxkbcommon
    libX11
    libXcursor
    libXrandr
    libXi
    fontconfig
    freetype
  ];
  LD_LIBRARY_PATH = pkgs.lib.makeLibraryPath (with pkgs; [
    mpv-unwrapped libGL wayland libxkbcommon libX11 libXcursor libXrandr libXi fontconfig freetype
  ]);
}
