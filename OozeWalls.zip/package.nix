# SECCION: PACKAGE NIXOS
# IPC: build install
{
  lib,
  rustPlatform,
  pkg-config,
  mpv-unwrapped,
  mpv,
  mpvpaper,
  ffmpeg,
  socat,
  matugen,
  fontconfig,
  freetype,
  libGL,
  wayland,
  libxkbcommon,
  libX11,
  libXcursor,
  libXrandr,
  libXi,
  makeWrapper,
}:
let
  baseLibs = [
    libGL
    wayland
    libxkbcommon
    libX11
    libXcursor
    libXrandr
    libXi
    fontconfig
    freetype
  ];
  liveLibs = baseLibs ++ [ mpv-unwrapped ];
  tools = [ mpvpaper mpv ffmpeg socat matugen ];
in
rec {
  oozewalls-live = rustPlatform.buildRustPackage {
    pname = "oozewalls-live";
    version = "0.1.0";
    src = ./.;
    cargoLock.lockFile = ./Cargo.lock;
    cargoBuildFlags = [ "-p" "oozewalls-live" ];
    cargoTestFlags = [ "-p" "oozewalls-live" ];
    nativeBuildInputs = [ pkg-config makeWrapper ];
    buildInputs = liveLibs ++ [ ffmpeg ];
    postInstall = ''
      wrapProgram $out/bin/oozewalls-live \
        --prefix LD_LIBRARY_PATH : ${lib.makeLibraryPath liveLibs} \
        --suffix PATH : ${lib.makeBinPath tools}
    '';
    meta = with lib; {
      description = "Live wallpaper motor via mpv + wayland-egl";
      license = licenses.gpl3Plus;
      platforms = platforms.linux;
      mainProgram = "oozewalls-live";
    };
  };

  oozewalls = rustPlatform.buildRustPackage {
    pname = "oozewalls";
    version = "0.1.0";
    src = ./.;
    cargoLock.lockFile = ./Cargo.lock;
    cargoBuildFlags = [ "-p" "oozewalls" ];
    cargoTestFlags = [ "-p" "oozewalls" ];
    nativeBuildInputs = [ pkg-config makeWrapper ];
    buildInputs = baseLibs;
    postInstall = ''
      mkdir -p $out/share/icons/hicolor/scalable/apps
      mkdir -p $out/share/applications
      cp $src/oozewalls-gui.desktop $out/share/applications/
      cp $src/oozewalls.svg $out/share/icons/hicolor/scalable/apps/oozewalls.svg
      wrapProgram $out/bin/oozewalls-gui \
        --prefix LD_LIBRARY_PATH : ${lib.makeLibraryPath baseLibs} \
        --suffix PATH : ${lib.makeBinPath (tools ++ [ oozewalls-live ])}
      wrapProgram $out/bin/oozewalls \
        --prefix LD_LIBRARY_PATH : ${lib.makeLibraryPath baseLibs} \
        --suffix PATH : ${lib.makeBinPath (tools ++ [ oozewalls-live ])}
    '';
    meta = with lib; {
      description = "Motor minimo de wallpapers live/static via mpvpaper controlable desde Quickshell";
      license = licenses.gpl3Plus;
      platforms = platforms.linux;
      mainProgram = "oozewalls-gui";
    };
  };
}
