// SECCION: TRANSITION CATALOGO FRAMES AWWW MPV
// IPC: --transition --transition-duration --no-transition transitions set_property
use std::path::Path;
use std::time::{Duration, Instant};

// ---------------------------------------------------------------- CATALOGO

pub const KINDS: &[(&str, &str)] = &[
    ("wave-left", "Ola desde la izquierda"),
    ("wave-right", "Ola desde la derecha"),
    ("wave-up", "Ola desde arriba"),
    ("wave-down", "Ola desde abajo"),
    ("slime", "Slime Flow"),
    ("blob", "Sticky Blob"),
    ("drip", "Goteo"),
    ("rings", "Anillos"),
    ("bars-left", "Barras desde la izquierda"),
    ("bars-right", "Barras desde la derecha"),
    ("diagonal-left", "Diagonales desde la izquierda"),
    ("diagonal-right", "Diagonales desde la derecha"),
    ("fade", "Desvanecer"),
    ("slide-left", "Deslizar desde la izquierda"),
    ("slide-right", "Deslizar desde la derecha"),
    ("slide-up", "Deslizar desde arriba"),
    ("slide-down", "Deslizar desde abajo"),
    ("zoom", "Zoom con desvanecido"),
    ("wipe-left", "Barrido desde la izquierda"),
    ("wipe-right", "Barrido desde la derecha"),
    ("wipe-up", "Barrido desde arriba"),
    ("wipe-down", "Barrido desde abajo"),
    ("circle", "Círculo desde el centro"),
    ("blinds", "Persianas"),
    ("none", "Sin animación"),
    ("random", "Aleatoria"),
];

pub const CUSTOM_KINDS: [&str; 12] = [
    "wave-left",
    "wave-right",
    "wave-up",
    "wave-down",
    "slime",
    "blob",
    "drip",
    "rings",
    "bars-left",
    "bars-right",
    "diagonal-left",
    "diagonal-right",
];

pub fn is_custom(kind: &str) -> bool {
    CUSTOM_KINDS.contains(&kind)
}

pub const DEFAULT_KIND: &str = "fade";
pub const DEFAULT_MS: u32 = 600;
pub const MIN_MS: u32 = 100;
pub const MAX_MS: u32 = 3000;

pub fn is_valid(kind: &str) -> bool {
    KINDS.iter().any(|(k, _)| *k == kind)
}

pub fn clamp_ms(ms: u32) -> u32 {
    ms.clamp(MIN_MS, MAX_MS)
}

pub fn label_of(kind: &str) -> &'static str {
    KINDS
        .iter()
        .find(|(k, _)| *k == kind)
        .map(|(_, l)| *l)
        .unwrap_or("Desvanecer")
}

pub fn label_of_lang(kind: &str, en: bool) -> &'static str {
    if !en {
        return label_of(kind);
    }
    match kind {
        "wave-left" => "Wave from left",
        "wave-right" => "Wave from right",
        "wave-up" => "Wave from top",
        "wave-down" => "Wave from bottom",
        "slime" => "Slime Flow",
        "blob" => "Sticky Blob",
        "drip" => "Drip",
        "rings" => "Rings",
        "bars-left" => "Bars from left",
        "bars-right" => "Bars from right",
        "diagonal-left" => "Diagonals from left",
        "diagonal-right" => "Diagonals from right",
        "fade" => "Fade",
        "slide-left" => "Slide from left",
        "slide-right" => "Slide from right",
        "slide-up" => "Slide from top",
        "slide-down" => "Slide from bottom",
        "zoom" => "Zoom with fade",
        "wipe-left" => "Wipe from left",
        "wipe-right" => "Wipe from right",
        "wipe-up" => "Wipe from top",
        "wipe-down" => "Wipe from bottom",
        "circle" => "Circle from center",
        "blinds" => "Blinds",
        "none" => "No animation",
        "random" => "Random",
        _ => "Fade",
    }
}

fn concrete_kinds(allow_custom: bool) -> Vec<&'static str> {
    KINDS
        .iter()
        .map(|(k, _)| *k)
        .filter(|k| *k != "none" && *k != "random")
        .filter(|k| allow_custom || !is_custom(k))
        .collect()
}

// -------------------------------------------------------------- TRANSITION

#[derive(Debug, Clone)]
pub struct Transition {
    pub kind: String,
    pub ms: u32,
}

impl Transition {
    pub fn none() -> Self {
        Self {
            kind: String::from("none"),
            ms: DEFAULT_MS,
        }
    }

    pub fn from_config(cfg: &crate::config::Config) -> Self {
        Self {
            kind: cfg.transition.clone(),
            ms: clamp_ms(cfg.transition_ms),
        }
    }

    pub fn with_overrides(mut self, kind: Option<&str>, ms: Option<u32>) -> Self {
        if let Some(k) = kind {
            if is_valid(k) {
                self.kind = k.to_string();
            }
        }
        if let Some(m) = ms {
            self.ms = clamp_ms(m);
        }
        self
    }

    pub fn enabled(&self) -> bool {
        self.kind != "none" && self.ms > 0
    }

    pub fn needs_builtin(&self) -> bool {
        self.enabled() && is_custom(&self.kind)
    }

    pub fn resolved(&self) -> Self {
        self.resolved_with(true)
    }

    fn resolved_with(&self, allow_custom: bool) -> Self {
        if self.kind != "random" {
            return self.clone();
        }
        let pool = concrete_kinds(allow_custom);
        let seed = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .map(|d| d.subsec_nanos() as usize)
            .unwrap_or(0);
        Self {
            kind: pool[seed % pool.len()].to_string(),
            ms: self.ms,
        }
    }

    pub fn awww_args(&self) -> Vec<String> {
        let r = self.resolved_with(false);
        let ty = match r.kind.as_str() {
            "none" => "none",
            "fade" => "fade",
            "slide-left" | "wipe-left" => "left",
            "slide-right" | "wipe-right" => "right",
            "slide-up" | "wipe-up" => "top",
            "slide-down" | "wipe-down" => "bottom",
            "circle" => "center",
            "zoom" => "grow",
            "blinds" => "wave",
            _ => "fade",
        };
        let mut v = vec![String::from("--transition-type"), ty.to_string()];
        if ty != "none" {
            v.push(String::from("--transition-duration"));
            v.push(format!("{:.2}", r.ms as f32 / 1000.0));
            v.push(String::from("--transition-fps"));
            v.push(String::from("60"));
        }
        v
    }
}

// ------------------------------------------------------------------ EASING

pub fn ease(t: f32) -> f32 {
    let t = t.clamp(0.0, 1.0);
    if t < 0.5 {
        4.0 * t * t * t
    } else {
        let u = -2.0 * t + 2.0;
        1.0 - u * u * u / 2.0
    }
}

// ------------------------------------------------------------------ FRAMES

fn copy_cols(dst: &mut [u8], src: &[u8], w: usize, h: usize, d0: usize, s0: usize, n: usize) {
    if n == 0 {
        return;
    }
    for y in 0..h {
        let row = y * w * 4;
        let d = row + d0 * 4;
        let s = row + s0 * 4;
        dst[d..d + n * 4].copy_from_slice(&src[s..s + n * 4]);
    }
}

fn copy_rows(dst: &mut [u8], src: &[u8], w: usize, d0: usize, s0: usize, n: usize) {
    if n == 0 {
        return;
    }
    let stride = w * 4;
    dst[d0 * stride..(d0 + n) * stride].copy_from_slice(&src[s0 * stride..(s0 + n) * stride]);
}

fn mix_weight(e: f32) -> u32 {
    (e * 256.0).round().clamp(0.0, 256.0) as u32
}

fn mix(a: u8, b: u8, k: u32) -> u8 {
    ((a as u32 * (256 - k) + b as u32 * k) >> 8) as u8
}

fn frame_fade(dst: &mut [u8], old: &[u8], new: &[u8], e: f32) {
    let k = mix_weight(e);
    for ((d, o), n) in dst.iter_mut().zip(old.iter()).zip(new.iter()) {
        *d = mix(*o, *n, k);
    }
}

fn frame_circle(dst: &mut [u8], new: &[u8], w: usize, h: usize, e: f32) {
    let cx = w as f32 / 2.0;
    let cy = h as f32 / 2.0;
    let max_r = (cx * cx + cy * cy).sqrt();
    let r = e * max_r;
    if r <= 0.0 {
        return;
    }
    for y in 0..h {
        let dy = y as f32 + 0.5 - cy;
        if dy.abs() >= r {
            continue;
        }
        let half = (r * r - dy * dy).sqrt();
        let x0 = (cx - half).round().max(0.0) as usize;
        let x1 = ((cx + half).round() as usize).min(w);
        if x1 > x0 {
            let row = y * w * 4;
            dst[row + x0 * 4..row + x1 * 4].copy_from_slice(&new[row + x0 * 4..row + x1 * 4]);
        }
    }
}

fn frame_blinds(dst: &mut [u8], new: &[u8], w: usize, h: usize, e: f32) {
    let bands = 12usize;
    let bw = (w + bands - 1) / bands;
    let shown = (e * bw as f32).round() as usize;
    if shown == 0 {
        return;
    }
    for k in 0..bands {
        let x0 = k * bw;
        if x0 >= w {
            break;
        }
        let n = shown.min(w - x0);
        copy_cols(dst, new, w, h, x0, x0, n);
    }
}

fn frame_zoom(dst: &mut [u8], old: &[u8], new: &[u8], w: usize, h: usize, e: f32) {
    let s = 1.0 + 0.15 * (1.0 - e);
    let k = mix_weight(e);
    let cx = w as f32 / 2.0;
    let cy = h as f32 / 2.0;
    let xs: Vec<usize> = (0..w)
        .map(|x| {
            let sx = cx + (x as f32 + 0.5 - cx) / s;
            (sx as usize).min(w - 1)
        })
        .collect();
    for y in 0..h {
        let sy = cy + (y as f32 + 0.5 - cy) / s;
        let sy = (sy as usize).min(h - 1);
        let srow = sy * w * 4;
        let drow = y * w * 4;
        for x in 0..w {
            let si = srow + xs[x] * 4;
            let di = drow + x * 4;
            dst[di] = mix(old[di], new[si], k);
            dst[di + 1] = mix(old[di + 1], new[si + 1], k);
            dst[di + 2] = mix(old[di + 2], new[si + 2], k);
            dst[di + 3] = 255;
        }
    }
}

// ----------------------------------------------------- FRAMES CAPAS ORGANICAS

pub const LUT_SIZE: usize = LUT_N;

const LAYER_SHADES: [f32; 3] = [0.30, 0.62, 1.0];
const LUT_N: usize = 720;
const BLOB_MIN: f32 = 0.74;

#[derive(Clone, Copy)]
enum Edge {
    Left,
    Right,
    Top,
    Bottom,
}

fn orient(edge: Edge, x: usize, y: usize, w: usize, h: usize) -> (f32, usize) {
    match edge {
        Edge::Bottom => (1.0 - (y as f32 + 0.5) / h as f32, x),
        Edge::Top => ((y as f32 + 0.5) / h as f32, x),
        Edge::Left => ((x as f32 + 0.5) / w as f32, y),
        Edge::Right => (1.0 - (x as f32 + 0.5) / w as f32, y),
    }
}

fn across_len(edge: Edge, w: usize, h: usize) -> usize {
    match edge {
        Edge::Bottom | Edge::Top => w,
        Edge::Left | Edge::Right => h,
    }
}

fn par_rows<F>(dst: &mut [u8], w: usize, h: usize, f: F)
where
    F: Fn(usize, &mut [u8]) + Sync,
{
    let stride = w * 4;
    let threads = std::thread::available_parallelism()
        .map(|n| n.get())
        .unwrap_or(1)
        .clamp(1, 8);
    if threads == 1 || h < 64 {
        for (y, row) in dst.chunks_exact_mut(stride).enumerate() {
            f(y, row);
        }
        return;
    }
    let rows_per = (h + threads - 1) / threads;
    std::thread::scope(|sc| {
        for (ci, chunk) in dst.chunks_mut(rows_per * stride).enumerate() {
            let f = &f;
            sc.spawn(move || {
                for (ry, row) in chunk.chunks_exact_mut(stride).enumerate() {
                    f(ci * rows_per + ry, row);
                }
            });
        }
    });
}

fn blend3(c: [u8; 3], t: [u8; 3], k: u32) -> [u8; 3] {
    [mix(c[0], t[0], k), mix(c[1], t[1], k), mix(c[2], t[2], k)]
}

pub fn accent_layers(new: &[u8], w: usize, h: usize) -> [[u8; 3]; 3] {
    let gx = 32usize.min(w).max(1);
    let gy = 18usize.min(h).max(1);
    let mut sum = [0u64; 3];
    let mut n = 0u64;
    for j in 0..gy {
        let y = (j * 2 + 1) * h / (gy * 2);
        for i in 0..gx {
            let x = (i * 2 + 1) * w / (gx * 2);
            let p = (y * w + x) * 4;
            sum[0] += new[p] as u64;
            sum[1] += new[p + 1] as u64;
            sum[2] += new[p + 2] as u64;
            n += 1;
        }
    }
    let nf = n.max(1) as f32;
    let avg = [sum[0] as f32 / nf, sum[1] as f32 / nf, sum[2] as f32 / nf];
    let mean = (avg[0] + avg[1] + avg[2]) / 3.0;
    let mut c = [0f32; 3];
    for k in 0..3 {
        c[k] = (mean + (avg[k] - mean) * 2.0).clamp(0.0, 255.0);
    }
    let peak = c[0].max(c[1]).max(c[2]).max(1.0);
    let scale = 235.0 / peak;
    let mut out = [[0u8; 3]; 3];
    for (i, shade) in LAYER_SHADES.iter().enumerate() {
        for k in 0..3 {
            out[i][k] = (c[k] * scale * shade).round().clamp(0.0, 255.0) as u8;
        }
    }
    out
}

fn frame_layers<S>(
    dst: &mut [u8],
    old: &[u8],
    new: &[u8],
    w: usize,
    h: usize,
    e: f32,
    gap: f32,
    soft: f32,
    field: S,
) where
    S: Fn(usize, usize) -> f32 + Sync,
{
    dst.copy_from_slice(old);
    if e <= 0.0 {
        return;
    }
    let cols = accent_layers(new, w, h);
    let f0 = e * (1.0 + 3.0 * gap + soft);
    let fronts = [f0, f0 - gap, f0 - 2.0 * gap, f0 - 3.0 * gap];
    let inv = 256.0 / soft;
    let stride = w * 4;
    par_rows(dst, w, h, |y, row| {
        let nrow = &new[y * stride..(y + 1) * stride];
        for x in 0..w {
            let s = field(x, y).clamp(0.0, 0.998);
            let d = fronts[0] - s;
            if d <= 0.0 {
                continue;
            }
            let i = x * 4;
            let mut c = [row[i], row[i + 1], row[i + 2]];
            c = blend3(c, cols[0], ((d * inv) as u32).min(256));
            for l in 1..3 {
                let d = fronts[l] - s;
                if d > 0.0 {
                    c = blend3(c, cols[l], ((d * inv) as u32).min(256));
                }
            }
            let d = fronts[3] - s;
            if d > 0.0 {
                let n = [nrow[i], nrow[i + 1], nrow[i + 2]];
                c = blend3(c, n, ((d * inv) as u32).min(256));
            }
            row[i] = c[0];
            row[i + 1] = c[1];
            row[i + 2] = c[2];
        }
    });
}

fn frame_rise(
    dst: &mut [u8],
    old: &[u8],
    new: &[u8],
    w: usize,
    h: usize,
    e: f32,
    edge: Edge,
    amp: f32,
    off: &[f32],
    gap: f32,
    soft: f32,
) {
    let span = 1.0 - 2.0 * amp;
    frame_layers(dst, old, new, w, h, e, gap, soft, |x, y| {
        let (a, c) = orient(edge, x, y, w, h);
        amp + span * a + off[c]
    });
}

pub const WAVE_AMP: f32 = 0.07;
pub const SLIME_AMP: f32 = 0.13;
pub const DRIP_REACH: f32 = 0.5;

pub fn wave_offsets(e: f32, n: usize) -> Vec<f32> {
    let amp = WAVE_AMP;
    let phase = e * 5.0;
    (0..n)
        .map(|i| {
            let u = (i as f32 + 0.5) / n as f32 * std::f32::consts::TAU;
            amp * (0.6 * (u * 1.5 + phase).sin() + 0.4 * (u * 2.5 - phase * 0.7 + 1.3).sin())
        })
        .collect()
}

fn frame_waves(dst: &mut [u8], old: &[u8], new: &[u8], w: usize, h: usize, e: f32, edge: Edge) {
    let n = across_len(edge, w, h);
    let off = wave_offsets(e, n);
    frame_rise(dst, old, new, w, h, e, edge, WAVE_AMP, &off, 0.14, 0.01);
}

pub fn slime_offsets(e: f32, w: usize) -> Vec<f32> {
    let amp = SLIME_AMP;
    let centers = [0.1f32, 0.3, 0.5, 0.7, 0.9];
    let widths = [0.07f32, 0.09, 0.06, 0.09, 0.07];
    let bumps: Vec<(f32, f32, f32)> = centers
        .iter()
        .zip(widths.iter())
        .enumerate()
        .map(|(i, (c, wd))| {
            let k = i as f32;
            let hgt = 0.55 + 0.45 * ((e * 5.0 + k * 1.9).sin() * 0.5 + 0.5);
            let ctr = *c + 0.03 * (e * 6.0 + k * 2.3).sin();
            (ctr, *wd, hgt)
        })
        .collect();
    (0..w)
        .map(|x| {
            let fx = (x as f32 + 0.5) / w as f32;
            let mut raw = 0.0f32;
            for &(c, wd, hg) in &bumps {
                let d = (fx - c) / wd;
                raw += hg * (-d * d).exp();
            }
            amp * (2.0 * raw.min(1.0) - 1.0)
        })
        .collect()
}

fn frame_slime(dst: &mut [u8], old: &[u8], new: &[u8], w: usize, h: usize, e: f32) {
    let off = slime_offsets(e, w);
    frame_rise(dst, old, new, w, h, e, Edge::Bottom, SLIME_AMP, &off, 0.1, 0.012);
}

pub fn drip_drape(w: usize) -> Vec<f32> {
    let n = 9usize;
    let drips: Vec<(f32, f32, f32)> = (0..n)
        .map(|i| {
            let k = i as f32 + 1.0;
            let a = (k * 12.9898).sin() * 43758.547;
            let b = (k * 78.233).sin() * 12345.679;
            let r1 = a - a.floor();
            let r2 = b - b.floor();
            (
                (i as f32 + 0.2 + 0.6 * r1) / n as f32,
                0.018 + 0.015 * r2,
                0.45 + 0.55 * r2,
            )
        })
        .collect();
    (0..w)
        .map(|x| {
            let fx = (x as f32 + 0.5) / w as f32;
            let mut g = 0.18 + 0.08 * (fx * std::f32::consts::TAU * 3.0).sin();
            for &(c, wd, hg) in &drips {
                let d = (fx - c).abs() / wd;
                if d < 1.0 {
                    g = g.max(hg * (1.0 - d * d).sqrt());
                }
            }
            g.clamp(0.0, 1.0)
        })
        .collect()
}

fn frame_drip(dst: &mut [u8], old: &[u8], new: &[u8], w: usize, h: usize, e: f32) {
    let reach = DRIP_REACH;
    let drape = drip_drape(w);
    frame_layers(dst, old, new, w, h, e, 0.1, 0.01, |x, y| {
        let fy = (y as f32 + 0.5) / h as f32;
        fy * (1.0 - reach) + reach * (1.0 - drape[x])
    });
}

fn frame_bars(dst: &mut [u8], old: &[u8], new: &[u8], w: usize, h: usize, e: f32, from_right: bool) {
    let n = 12usize;
    let cols: Vec<(f32, bool)> = (0..w)
        .map(|x| {
            let xx = if from_right { w - 1 - x } else { x };
            let i = (xx * n / w).min(n - 1);
            (i as f32 / n as f32, i % 2 == 1)
        })
        .collect();
    let inv_n = 1.0 / n as f32;
    frame_layers(dst, old, new, w, h, e, 0.1, 0.008, |x, y| {
        let fy = (y as f32 + 0.5) / h as f32;
        let (base, odd) = cols[x];
        base + (if odd { 1.0 - fy } else { fy }) * inv_n
    });
}

fn frame_diagonals(dst: &mut [u8], old: &[u8], new: &[u8], w: usize, h: usize, e: f32, from_right: bool) {
    let n = 7.0f32;
    let span = (w + h) as f32;
    frame_layers(dst, old, new, w, h, e, 0.1, 0.008, |x, y| {
        let x = if from_right { w - 1 - x } else { x };
        let d = (x + y) as f32 / span;
        let q = (d * n).floor();
        let u = (x as f32 - y as f32 + h as f32) / span;
        let t = if (q as u32) % 2 == 1 { 1.0 - u } else { u };
        (q + t) / n
    });
}

fn frame_rings(dst: &mut [u8], old: &[u8], new: &[u8], w: usize, h: usize, e: f32) {
    let cx = w as f32 / 2.0;
    let cy = h as f32 / 2.0;
    let rmax = (cx * cx + cy * cy).sqrt();
    frame_layers(dst, old, new, w, h, e, 0.12, 0.012, |x, y| {
        let dx = x as f32 + 0.5 - cx;
        let dy = y as f32 + 0.5 - cy;
        (dx * dx + dy * dy).sqrt() / rmax
    });
}

fn fast_atan2(y: f32, x: f32) -> f32 {
    let ax = x.abs();
    let ay = y.abs();
    let mx = ax.max(ay);
    if mx == 0.0 {
        return 0.0;
    }
    let mn = ax.min(ay);
    let a = mn / mx;
    let s = a * a;
    let mut r = ((-0.046_496_475 * s + 0.159_314_22) * s - 0.327_622_77) * s * a + a;
    if ay > ax {
        r = std::f32::consts::FRAC_PI_2 - r;
    }
    if x < 0.0 {
        r = std::f32::consts::PI - r;
    }
    if y < 0.0 {
        r = -r;
    }
    r
}

pub fn blob_lut(e: f32) -> Vec<f32> {
    let tau = std::f32::consts::TAU;
    (0..LUT_N)
        .map(|i| {
            let a = i as f32 / LUT_N as f32 * tau;
            1.0 + 0.16 * ((5.0 * a + e * 3.0).sin() + 0.6 * (3.0 * a - e * 2.0).sin())
        })
        .collect()
}

pub fn blob_sats(w: usize, h: usize) -> [(f32, f32, f32); 6] {
    let cx = w as f32 / 2.0;
    let cy = h as f32 / 2.0;
    let rmax = (cx * cx + cy * cy).sqrt();
    let seeds = [
        (0.5f32, 0.42f32, 1.0f32),
        (1.7, 0.55, 0.7),
        (2.9, 0.38, 0.9),
        (4.0, 0.60, 0.6),
        (5.1, 0.47, 0.8),
        (5.9, 0.33, 0.5),
    ];
    let mut out = [(0.0f32, 0.0f32, 0.0f32); 6];
    for (o, &(a, d, sz)) in out.iter_mut().zip(seeds.iter()) {
        *o = (cx + a.cos() * d * rmax, cy + a.sin() * d * rmax, 0.05 * rmax * sz);
    }
    out
}

fn frame_blob(dst: &mut [u8], old: &[u8], new: &[u8], w: usize, h: usize, e: f32) {
    let cx = w as f32 / 2.0;
    let cy = h as f32 / 2.0;
    let rmax = (cx * cx + cy * cy).sqrt();
    let tau = std::f32::consts::TAU;
    let lut = blob_lut(e);
    let sats = blob_sats(w, h);
    let to_idx = LUT_N as f32 / tau;
    frame_layers(dst, old, new, w, h, e, 0.1, 0.012, |x, y| {
        let px = x as f32 + 0.5;
        let py = y as f32 + 0.5;
        let dx = px - cx;
        let dy = py - cy;
        let ang = fast_atan2(dy, dx);
        let idx = (((ang + std::f32::consts::PI) * to_idx) as usize).min(LUT_N - 1);
        let mut s = (dx * dx + dy * dy).sqrt() / rmax * BLOB_MIN / lut[idx];
        for &(sx, sy, sr) in &sats {
            let ex = px - sx;
            let ey = py - sy;
            let d2 = ex * ex + ey * ey;
            let lim = sr * 1.5;
            if d2 < lim * lim {
                let v = d2.sqrt() / sr;
                if v < s {
                    s = v;
                }
            }
        }
        s
    });
}

pub fn frame_into(
    dst: &mut [u8],
    old: &[u8],
    new: &[u8],
    w: usize,
    h: usize,
    kind: &str,
    t: f32,
) {
    let total = w * h * 4;
    if w == 0 || h == 0 || dst.len() < total || old.len() < total || new.len() < total {
        return;
    }
    let e = ease(t);
    match kind {
        "fade" => return frame_fade(&mut dst[..total], &old[..total], &new[..total], e),
        "zoom" => return frame_zoom(&mut dst[..total], &old[..total], &new[..total], w, h, e),
        "wave-left" => {
            return frame_waves(&mut dst[..total], &old[..total], &new[..total], w, h, e, Edge::Left)
        }
        "wave-right" => {
            return frame_waves(&mut dst[..total], &old[..total], &new[..total], w, h, e, Edge::Right)
        }
        "wave-up" => {
            return frame_waves(&mut dst[..total], &old[..total], &new[..total], w, h, e, Edge::Top)
        }
        "wave-down" => {
            return frame_waves(&mut dst[..total], &old[..total], &new[..total], w, h, e, Edge::Bottom)
        }
        "slime" => return frame_slime(&mut dst[..total], &old[..total], &new[..total], w, h, e),
        "blob" => return frame_blob(&mut dst[..total], &old[..total], &new[..total], w, h, e),
        "drip" => return frame_drip(&mut dst[..total], &old[..total], &new[..total], w, h, e),
        "rings" => return frame_rings(&mut dst[..total], &old[..total], &new[..total], w, h, e),
        "bars-left" => {
            return frame_bars(&mut dst[..total], &old[..total], &new[..total], w, h, e, false)
        }
        "bars-right" => {
            return frame_bars(&mut dst[..total], &old[..total], &new[..total], w, h, e, true)
        }
        "diagonal-left" => {
            return frame_diagonals(&mut dst[..total], &old[..total], &new[..total], w, h, e, false)
        }
        "diagonal-right" => {
            return frame_diagonals(&mut dst[..total], &old[..total], &new[..total], w, h, e, true)
        }
        _ => {}
    }
    dst[..total].copy_from_slice(&old[..total]);
    match kind {
        "slide-left" => {
            let off = ((1.0 - e) * w as f32).round() as usize;
            copy_cols(dst, new, w, h, 0, off.min(w), w.saturating_sub(off));
        }
        "slide-right" => {
            let off = ((1.0 - e) * w as f32).round() as usize;
            copy_cols(dst, new, w, h, off.min(w), 0, w.saturating_sub(off));
        }
        "slide-up" => {
            let off = ((1.0 - e) * h as f32).round() as usize;
            copy_rows(dst, new, w, 0, off.min(h), h.saturating_sub(off));
        }
        "slide-down" => {
            let off = ((1.0 - e) * h as f32).round() as usize;
            copy_rows(dst, new, w, off.min(h), 0, h.saturating_sub(off));
        }
        "wipe-left" => {
            let n = ((e * w as f32).round() as usize).min(w);
            copy_cols(dst, new, w, h, 0, 0, n);
        }
        "wipe-right" => {
            let n = ((e * w as f32).round() as usize).min(w);
            copy_cols(dst, new, w, h, w - n, w - n, n);
        }
        "wipe-up" => {
            let n = ((e * h as f32).round() as usize).min(h);
            copy_rows(dst, new, w, 0, 0, n);
        }
        "wipe-down" => {
            let n = ((e * h as f32).round() as usize).min(h);
            copy_rows(dst, new, w, h - n, h - n, n);
        }
        "circle" => frame_circle(dst, new, w, h, e),
        "blinds" => frame_blinds(dst, new, w, h, e),
        _ => frame_fade(dst, old, new, e),
    }
}

// --------------------------------------------------------------- VIDEO MPV

const PAN_AWAY: f64 = 1.5;
const ZOOM_IN: f64 = 0.2;

fn lerp(a: f64, b: f64, t: f64) -> f64 {
    a + (b - a) * t
}

fn ramp(sock: &Path, props: &[(&str, f64, f64)], ms: u32) {
    let total = Duration::from_millis(ms as u64);
    let step = Duration::from_millis(16);
    let start = Instant::now();
    loop {
        let el = start.elapsed();
        let t = if el >= total {
            1.0
        } else {
            ease(el.as_secs_f32() / total.as_secs_f32()) as f64
        };
        for (p, a, b) in props {
            let _ = crate::ipc::set_prop(sock, p, lerp(*a, *b, t));
        }
        if el >= total {
            break;
        }
        let spent = start.elapsed() - el;
        if spent < step {
            std::thread::sleep(step - spent);
        }
    }
}

fn slide_axis(kind: &str) -> Option<(&'static str, f64)> {
    match kind {
        "slide-left" => Some(("video-pan-x", -1.0)),
        "slide-right" => Some(("video-pan-x", 1.0)),
        "slide-up" => Some(("video-pan-y", -1.0)),
        "slide-down" => Some(("video-pan-y", 1.0)),
        _ => None,
    }
}

pub fn video_reset(sock: &Path) {
    let _ = crate::ipc::set_prop(sock, "brightness", 0.0f64);
    let _ = crate::ipc::set_prop(sock, "video-pan-x", 0.0f64);
    let _ = crate::ipc::set_prop(sock, "video-pan-y", 0.0f64);
    let _ = crate::ipc::set_prop(sock, "video-zoom", 0.0f64);
}

pub fn video_out(sock: &Path, tr: &Transition) {
    if !tr.enabled() {
        return;
    }
    let r = tr.resolved();
    let half = (r.ms / 2).max(50);
    match slide_axis(&r.kind) {
        Some((prop, dir)) => {
            ramp(sock, &[(prop, 0.0, -dir * PAN_AWAY)], half);
            let _ = crate::ipc::set_prop(sock, prop, dir * PAN_AWAY);
        }
        None => {
            ramp(sock, &[("brightness", 0.0, -100.0)], half);
        }
    }
}

pub fn video_in(sock: &Path, tr: &Transition) {
    if !tr.enabled() {
        return;
    }
    let r = tr.resolved();
    let half = (r.ms / 2).max(50);
    match slide_axis(&r.kind) {
        Some((prop, dir)) => {
            ramp(sock, &[(prop, dir * PAN_AWAY, 0.0)], half);
        }
        None if r.kind == "zoom" => {
            ramp(
                sock,
                &[("brightness", -100.0, 0.0), ("video-zoom", ZOOM_IN, 0.0)],
                half,
            );
        }
        None => {
            ramp(sock, &[("brightness", -100.0, 0.0)], half);
        }
    }
    video_reset(sock);
}

pub fn video_intro_opts(tr: &Transition) -> String {
    if !tr.enabled() {
        return String::new();
    }
    let r = tr.resolved();
    match slide_axis(&r.kind) {
        Some((prop, dir)) => format!(" --{}={}", prop, dir * PAN_AWAY),
        None if r.kind == "zoom" => format!(" --brightness=-100 --video-zoom={}", ZOOM_IN),
        None => String::from(" --brightness=-100"),
    }
}

pub fn wait_socket(sock: &Path, max_ms: u64) -> bool {
    let start = Instant::now();
    while start.elapsed() < Duration::from_millis(max_ms) {
        if crate::ipc::is_alive(sock) {
            return true;
        }
        std::thread::sleep(Duration::from_millis(40));
    }
    false
}

// ------------------------------------------------------------------- TESTS

#[cfg(test)]
mod tests {
    use super::*;

    fn pattern(w: usize, h: usize, flip: bool) -> Vec<u8> {
        let mut v = vec![0u8; w * h * 4];
        for (i, px) in v.chunks_exact_mut(4).enumerate() {
            let mut c = [
                (i % 251) as u8 + 1,
                ((i / 3) % 251) as u8 + 1,
                ((i / 7) % 251) as u8 + 1,
            ];
            if flip {
                for ch in c.iter_mut() {
                    *ch ^= 0x55;
                }
            }
            px[0] = c[0];
            px[1] = c[1];
            px[2] = c[2];
            px[3] = 255;
        }
        v
    }

    fn render(kind: &str, t: f32, w: usize, h: usize, old: &[u8], new: &[u8]) -> Vec<u8> {
        let mut dst = vec![0u8; w * h * 4];
        frame_into(&mut dst, old, new, w, h, kind, t);
        dst
    }

    fn px(buf: &[u8], w: usize, x: usize, y: usize) -> [u8; 4] {
        let i = (y * w + x) * 4;
        [buf[i], buf[i + 1], buf[i + 2], buf[i + 3]]
    }

    #[test]
    fn every_kind_starts_as_old_and_ends_as_new() {
        let (w, h) = (48, 30);
        let old = pattern(w, h, false);
        let new = pattern(w, h, true);
        for (k, _) in KINDS {
            if *k == "none" || *k == "random" {
                continue;
            }
            assert_eq!(render(k, 0.0, w, h, &old, &new), old, "{} inicio", k);
            assert_eq!(render(k, 1.0, w, h, &old, &new), new, "{} final", k);
        }
    }

    #[test]
    fn region_kinds_are_partial_at_midpoint() {
        let (w, h) = (48, 30);
        let old = pattern(w, h, false);
        let new = pattern(w, h, true);
        for k in ["slide-left", "slide-right", "slide-up", "slide-down"] {
            let mid = render(k, 0.5, w, h, &old, &new);
            assert_ne!(mid, old, "{} igual al inicio", k);
            assert_ne!(mid, new, "{} igual al final", k);
        }
        for k in [
            "wipe-left", "wipe-right", "wipe-up", "wipe-down", "circle", "blinds",
        ] {
            let mid = render(k, 0.5, w, h, &old, &new);
            let from_new = (0..w * h).filter(|i| mid[i * 4..i * 4 + 4] == new[i * 4..i * 4 + 4]).count();
            let from_old = (0..w * h).filter(|i| mid[i * 4..i * 4 + 4] == old[i * 4..i * 4 + 4]).count();
            assert!(from_new > 0 && from_old > 0, "{} no mezcla", k);
            assert_eq!(from_new + from_old, w * h, "{} pixel ajeno", k);
        }
    }

    #[test]
    fn custom_kinds_mix_layers_at_midpoint() {
        let (w, h) = (96, 80);
        let old = pattern(w, h, false);
        let new = pattern(w, h, true);
        for k in CUSTOM_KINDS {
            let mid = render(k, 0.5, w, h, &old, &new);
            let from_new = (0..w * h).filter(|i| mid[i * 4..i * 4 + 4] == new[i * 4..i * 4 + 4]).count();
            let from_old = (0..w * h).filter(|i| mid[i * 4..i * 4 + 4] == old[i * 4..i * 4 + 4]).count();
            assert!(from_new > 0 && from_old > 0, "{} no mezcla", k);
            assert!(from_new + from_old < w * h, "{} sin capas de color", k);
            assert!(mid.chunks_exact(4).all(|p| p[3] == 255), "{} alfa", k);
        }
    }

    #[test]
    fn custom_kinds_progress_and_use_threads() {
        let (w, h) = (64, 96);
        let old = pattern(w, h, false);
        let new = pattern(w, h, true);
        for k in CUSTOM_KINDS {
            assert_eq!(render(k, 0.0, w, h, &old, &new), old, "{} inicio", k);
            assert_eq!(render(k, 1.0, w, h, &old, &new), new, "{} final", k);
            let count = |t: f32| {
                let m = render(k, t, w, h, &old, &new);
                (0..w * h).filter(|i| m[i * 4..i * 4 + 4] == new[i * 4..i * 4 + 4]).count()
            };
            assert!(count(0.25) < count(0.9), "{} no avanza", k);
        }
    }

    #[test]
    fn wave_directions_enter_from_their_edge() {
        let (w, h) = (96, 80);
        let old = pattern(w, h, false);
        let new = pattern(w, h, true);
        let cases = [
            ("wave-left", (0, h / 2), (w - 1, h / 2)),
            ("wave-right", (w - 1, h / 2), (0, h / 2)),
            ("wave-up", (w / 2, 0), (w / 2, h - 1)),
            ("wave-down", (w / 2, h - 1), (w / 2, 0)),
        ];
        for (k, near, far) in cases {
            let mid = render(k, 0.5, w, h, &old, &new);
            assert_eq!(px(&mid, w, near.0, near.1), px(&new, w, near.0, near.1), "{} borde de entrada", k);
            assert_eq!(px(&mid, w, far.0, far.1), px(&old, w, far.0, far.1), "{} borde lejano", k);
        }
    }

    #[test]
    fn display_order_groups_new_then_video_then_rest() {
        let ids: Vec<&str> = KINDS.iter().map(|(k, _)| *k).collect();
        let pos = |k: &str| ids.iter().position(|x| *x == k).unwrap();
        assert!(CUSTOM_KINDS.iter().all(|k| pos(k) < pos("fade")));
        for k in ["slide-left", "slide-right", "slide-up", "slide-down", "zoom"] {
            assert!(pos("fade") <= pos(k) && pos(k) < pos("wipe-left"), "{}", k);
        }
        assert!(pos("blinds") < pos("none") && pos("none") < pos("random"));
    }

    #[test]
    fn custom_kinds_route_to_builtin_layer() {
        let t = Transition {
            kind: String::from("drip"),
            ms: 600,
        };
        assert!(t.needs_builtin());
        assert!(!Transition::none().needs_builtin());
        let r = Transition {
            kind: String::from("random"),
            ms: 600,
        };
        for _ in 0..20 {
            let a = r.awww_args();
            assert!(["fade", "left", "right", "top", "bottom", "center", "grow", "wave"].contains(&a[1].as_str()));
        }
    }

    #[test]
    fn fade_and_zoom_blend_between_old_and_new() {
        let (w, h) = (32, 20);
        let old = pattern(w, h, false);
        let new = pattern(w, h, true);
        let mid = render("fade", 0.5, w, h, &old, &new);
        for i in 0..w * h * 4 {
            let (lo, hi) = (old[i].min(new[i]), old[i].max(new[i]));
            assert!(mid[i] >= lo && mid[i] <= hi);
        }
        let z = render("zoom", 0.5, w, h, &old, &new);
        assert!(z.chunks_exact(4).all(|p| p[3] == 255));
        assert_ne!(z, old);
        assert_ne!(z, new);
    }

    #[test]
    fn slide_left_enters_from_left_edge() {
        let (w, h) = (40, 4);
        let old = pattern(w, h, false);
        let new = pattern(w, h, true);
        let mid = render("slide-left", 0.5, w, h, &old, &new);
        assert_eq!(px(&mid, w, 0, 0), px(&new, w, 20, 0));
        assert_eq!(px(&mid, w, w - 1, 0), px(&old, w, w - 1, 0));
    }

    #[test]
    fn slide_right_enters_from_right_edge() {
        let (w, h) = (40, 4);
        let old = pattern(w, h, false);
        let new = pattern(w, h, true);
        let mid = render("slide-right", 0.5, w, h, &old, &new);
        assert_eq!(px(&mid, w, 0, 0), px(&old, w, 0, 0));
        assert_eq!(px(&mid, w, w - 1, 0), px(&new, w, 19, 0));
    }

    #[test]
    fn validation_and_clamp() {
        assert!(is_valid("fade"));
        assert!(!is_valid("spin"));
        assert_eq!(clamp_ms(5), MIN_MS);
        assert_eq!(clamp_ms(99999), MAX_MS);
    }

    #[test]
    fn random_resolves_to_concrete() {
        let t = Transition {
            kind: String::from("random"),
            ms: 500,
        };
        let r = t.resolved();
        assert!(r.kind != "random" && r.kind != "none" && is_valid(&r.kind));
    }

    #[test]
    fn awww_mapping() {
        let t = Transition {
            kind: String::from("wipe-up"),
            ms: 800,
        };
        let a = t.awww_args();
        assert_eq!(a[1], "top");
        assert!(a.contains(&String::from("0.80")));
        let n = Transition::none().awww_args();
        assert_eq!(n, vec!["--transition-type", "none"]);
    }
}
