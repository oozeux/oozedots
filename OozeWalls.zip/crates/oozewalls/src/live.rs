//! Live - lado padre: pidfiles, spawn, switch y stop del proceso oozewalls-live

use std::io::{BufRead, BufReader};
use std::os::unix::process::CommandExt;
use std::path::PathBuf;
use std::process::{Command, Stdio};
use std::time::{Duration, Instant};

pub fn live_bin() -> std::ffi::OsString {
    if let Ok(exe) = std::env::current_exe() {
        if let Some(sib) = exe.parent().map(|d| d.join("oozewalls-live")) {
            if sib.is_file() {
                return sib.into_os_string();
            }
        }
    }
    if let Some(home) = std::env::var_os("HOME") {
        let p = PathBuf::from(home).join(".local/bin/oozewalls-live");
        if p.is_file() {
            return p.into_os_string();
        }
    }
    std::ffi::OsString::from("oozewalls-live")
}

pub fn pidfile_for(output: &str) -> PathBuf {
    let clean: String = output
        .chars()
        .filter(|c| c.is_alphanumeric() || *c == '-' || *c == '_')
        .collect();
    let name = if output == "*" || clean.is_empty() {
        String::from("all")
    } else {
        clean
    };
    crate::ipc::socket_dir().join(format!("live_{}.livepid", name))
}

pub fn read_pid(p: &std::path::Path) -> Option<u32> {
    std::fs::read_to_string(p).ok()?.trim().parse().ok()
}

fn is_live_process(pid: u32) -> bool {
    std::fs::read(format!("/proc/{}/cmdline", pid))
        .map(|b| b.split(|c| *c == 0).any(|a| a == &b"__live"[..]))
        .unwrap_or(false)
}

pub fn pids() -> Vec<u32> {
    let mut v = Vec::new();
    if let Ok(rd) = std::fs::read_dir(crate::ipc::socket_dir()) {
        for e in rd.filter_map(|x| x.ok()) {
            let p = e.path();
            if p.extension().and_then(|x| x.to_str()) != Some("livepid") {
                continue;
            }
            match read_pid(&p) {
                Some(pid) if is_live_process(pid) => v.push(pid),
                _ => {
                    let _ = std::fs::remove_file(&p);
                }
            }
        }
    }
    v
}

fn kill_pidfile(p: &std::path::Path, except: Option<u32>) {
    let Some(pid) = read_pid(p) else {
        let _ = std::fs::remove_file(p);
        return;
    };
    if Some(pid) == except {
        return;
    }
    if is_live_process(pid) {
        unsafe {
            libc::kill(pid as i32, libc::SIGTERM);
        }
        let deadline = Instant::now() + Duration::from_millis(1500);
        while Instant::now() < deadline && is_live_process(pid) {
            std::thread::sleep(Duration::from_millis(20));
        }
        if is_live_process(pid) {
            unsafe {
                libc::kill(pid as i32, libc::SIGKILL);
            }
        }
    }
    let _ = std::fs::remove_file(p);
}

pub fn stop_output(output: &str) {
    if output == "*" {
        stop_all();
        return;
    }
    kill_pidfile(&pidfile_for(output), None);
}

pub fn stop_all() {
    if let Ok(rd) = std::fs::read_dir(crate::ipc::socket_dir()) {
        for e in rd.filter_map(|x| x.ok()) {
            let p = e.path();
            if p.extension().and_then(|x| x.to_str()) == Some("livepid") {
                kill_pidfile(&p, None);
            }
        }
    }
}

pub fn pid_for(output: &str) -> Option<u32> {
    read_pid(&pidfile_for(output)).filter(|p| is_live_process(*p))
}

pub fn switch(
    sock: &std::path::Path,
    file: &str,
    scaling: &str,
    tr: &crate::transition::Transition,
) -> Result<(), String> {
    let r = tr.resolved();
    let kind = if r.enabled() { r.kind.clone() } else { String::from("none") };
    let cmd = serde_json::json!({
        "command": ["script-message", "oozewalls-switch", kind, r.ms.to_string(), scaling, file]
    });
    let text = serde_json::to_string(&cmd).map_err(|e| e.to_string())?;
    let resp = crate::ipc::send(&std::path::PathBuf::from(sock), &text)?;
    if resp.contains("\"error\":\"success\"") {
        Ok(())
    } else {
        Err(format!("switch {}", resp.trim()))
    }
}

pub fn snapshot_path(sock: &std::path::Path) -> PathBuf {
    let name = sock
        .file_stem()
        .and_then(|n| n.to_str())
        .unwrap_or("all")
        .to_string();
    crate::ipc::socket_dir().join(format!("snap_{}.png", name))
}

pub fn write_snapshot(path: &std::path::Path, rgba_bottom_up: &[u8], w: u32, h: u32) -> Result<(), String> {
    use image::codecs::png::{CompressionType, FilterType, PngEncoder};
    use image::{ExtendedColorType, ImageEncoder};
    let (wu, hu) = (w as usize, h as usize);
    if rgba_bottom_up.len() < wu * hu * 4 {
        return Err(String::from("instantanea incompleta"));
    }
    let mut rgb = Vec::with_capacity(wu * hu * 3);
    for y in (0..hu).rev() {
        for px in rgba_bottom_up[y * wu * 4..(y + 1) * wu * 4].chunks_exact(4) {
            rgb.extend_from_slice(&px[..3]);
        }
    }
    let tmp = path.with_extension("tmp");
    let file = std::fs::File::create(&tmp).map_err(|e| e.to_string())?;
    PngEncoder::new_with_quality(std::io::BufWriter::new(file), CompressionType::Fast, FilterType::NoFilter)
        .write_image(&rgb, w, h, ExtendedColorType::Rgb8)
        .map_err(|e| e.to_string())?;
    std::fs::rename(&tmp, path).map_err(|e| e.to_string())
}

pub fn snapshot(sock: &std::path::Path) -> Option<String> {
    if !crate::ipc::is_alive(sock) {
        return None;
    }
    let path = snapshot_path(sock);
    let _ = std::fs::remove_file(&path);
    let cmd = serde_json::json!({
        "command": ["script-message", "oozewalls-snap", path.to_string_lossy()]
    });
    let text = serde_json::to_string(&cmd).ok()?;
    crate::ipc::send(&std::path::PathBuf::from(sock), &text).ok()?;
    let deadline = Instant::now() + Duration::from_millis(1500);
    while Instant::now() < deadline {
        if path.is_file() {
            let _ = crate::ipc::set_prop(sock, "pause", true);
            return Some(path.to_string_lossy().to_string());
        }
        std::thread::sleep(Duration::from_millis(15));
    }
    None
}

pub fn snapshot_for(output: &str) -> Option<String> {
    let direct = crate::ipc::socket_for(output);
    if let Some(s) = snapshot(&direct) {
        return Some(s);
    }
    let wild = crate::ipc::socket_for("*");
    if output != "*" && wild != direct {
        if let Some(s) = snapshot(&wild) {
            return Some(s);
        }
    }
    if output == "*" {
        for sock in crate::ipc::discover() {
            if sock != direct {
                if let Some(s) = snapshot(&sock) {
                    return Some(s);
                }
            }
        }
    }
    None
}

pub fn resume_output(output: &str) {
    for sock in [crate::ipc::socket_for(output), crate::ipc::socket_for("*")] {
        if crate::ipc::is_alive(&sock) {
            let _ = crate::ipc::set_prop(&sock, "pause", false);
        }
    }
}

pub fn spawn(
    output: &str,
    file: &str,
    scaling: &str,
    mute: bool,
    volume: u8,
    hwdec: &str,
    layer: &str,
    tr: &crate::transition::Transition,
    old_image: Option<&str>,
) -> Result<u32, String> {
    if output.is_empty() {
        return Err(String::from("motor live: falta salida"));
    }
    let pf = pidfile_for(output);
    kill_pidfile(&pf, None);
    let sock = crate::ipc::socket_for(output);
    let _ = std::fs::remove_file(&sock);

    let mut cmd = Command::new(live_bin());
    cmd.arg("__live")
        .arg(output)
        .arg(file)
        .arg(scaling)
        .arg(if mute { "1" } else { "0" })
        .arg(volume.min(100).to_string())
        .arg(hwdec)
        .arg(layer)
        .arg(if tr.enabled() && old_image.is_some() { tr.kind.as_str() } else { "none" })
        .arg(tr.ms.to_string())
        .arg(old_image.unwrap_or("-"))
        .stdin(Stdio::null())
        .stdout(Stdio::piped())
        .stderr(Stdio::inherit());

    unsafe {
        cmd.pre_exec(|| {
            libc::setsid();
            libc::signal(libc::SIGHUP, libc::SIG_IGN);
            Ok(())
        });
    }

    let mut child = cmd
        .spawn()
        .map_err(|e| {
            if e.kind() == std::io::ErrorKind::NotFound {
                String::from("falta oozewalls-live, instalar ambos binarios juntos")
            } else {
                format!("spawn motor live: {}", e)
            }
        })?;
    let pid = child.id();
    let out = child.stdout.take();
    let (tx, rx) = std::sync::mpsc::channel();
    if let Some(out) = out {
        std::thread::spawn(move || {
            let mut line = String::new();
            let _ = BufReader::new(out).read_line(&mut line);
            let _ = tx.send(line);
        });
    }
    let line = rx.recv_timeout(Duration::from_secs(20)).unwrap_or_default();
    if !line.trim().starts_with("ready") {
        let _ = child.kill();
        let _ = child.wait();
        let _ = std::fs::remove_file(&sock);
        let msg = line.trim().trim_start_matches("err").trim().to_string();
        return Err(if msg.is_empty() {
            String::from("motor live salio sin pintar")
        } else {
            format!("motor live: {}", msg)
        });
    }
    std::thread::spawn(move || {
        let _ = child.wait();
    });
    let _ = std::fs::write(&pf, pid.to_string());
    Ok(pid)
}
