// SECCION: LIVE MPV WRAPPER LIBMPV RENDER API OPENGL
// IPC: interno del proceso __live (no usa socket de control)
use std::ffi::{CStr, CString};
use std::os::raw::{c_char, c_int, c_void};
use std::ptr;
use std::sync::atomic::{AtomicI32, Ordering};
use std::time::{Duration, Instant};

use rsmpv_sys as mpv;

static WAKE_FD: AtomicI32 = AtomicI32::new(-1);

pub enum CoreEvent {
    None,
    StartFile,
    FileLoaded,
    Restart,
    EndFile { error: Option<String> },
    Message(Vec<String>),
    Shutdown,
    Other,
}

pub const UPDATE_FRAME: u64 = 1;

fn error_string(code: c_int) -> String {
    unsafe {
        let p = mpv::mpv_error_string(code);
        if p.is_null() {
            format!("error {}", code)
        } else {
            CStr::from_ptr(p).to_string_lossy().to_string()
        }
    }
}

unsafe extern "C" fn wrap_gl_fence_sync(_condition: u32, _flags: u32) -> *mut c_void {
    ptr::null_mut()
}

unsafe extern "C" fn get_proc_address(_ctx: *mut c_void, name: *const c_char) -> *mut c_void {
    if name.is_null() {
        return ptr::null_mut();
    }
    if CStr::from_ptr(name).to_bytes() == b"glFenceSync" {
        return wrap_gl_fence_sync as *mut c_void;
    }
    crate::egl::get_proc_address(name)
}

unsafe extern "C" fn update_cb(_ctx: *mut c_void) {
    let fd = WAKE_FD.load(Ordering::SeqCst);
    if fd >= 0 {
        let one: u64 = 1;
        let _ = libc::write(
            fd,
            &one as *const u64 as *const c_void,
            std::mem::size_of::<u64>(),
        );
    }
}

fn set_option(ctx: *mut mpv::mpv_handle, name: &str, value: &str) {
    let Ok(name) = CString::new(name) else { return };
    let Ok(value) = CString::new(value) else { return };
    unsafe {
        let _ = mpv::mpv_set_option_string(ctx, name.as_ptr(), value.as_ptr());
    }
}

pub struct Player {
    ctx: *mut mpv::mpv_handle,
    render: *mut mpv::mpv_render_context,
    frame_flag: bool,
}

impl Player {
    pub fn new(opts: &[(&str, String)], wake_fd: i32) -> Result<Self, String> {
        unsafe {
            let ctx = mpv::mpv_create();
            if ctx.is_null() {
                return Err(String::from("mpv_create fallo"));
            }
            for (k, v) in opts {
                set_option(ctx, k, v);
            }
            let rc = mpv::mpv_initialize(ctx);
            if rc < 0 {
                mpv::mpv_destroy(ctx);
                return Err(format!("mpv_initialize: {}", error_string(rc)));
            }
            // mpvpaper reaplica las opciones tras initialize para pisar config.
            for (k, v) in opts {
                set_option(ctx, k, v);
            }
            set_option(ctx, "vo", "libmpv");
            set_option(ctx, "gpu-api", "opengl");
            WAKE_FD.store(wake_fd, Ordering::SeqCst);
            Ok(Self {
                ctx,
                render: ptr::null_mut(),
                frame_flag: false,
            })
        }
    }

    pub fn create_render_context(&mut self, wl_display: *mut c_void) -> Result<(), String> {
        if !self.render.is_null() {
            return Ok(());
        }
        unsafe {
            let mut init = mpv::mpv_opengl_init_params {
                get_proc_address: Some(get_proc_address),
                get_proc_address_ctx: ptr::null_mut(),
            };
            let mut params = [
                mpv::mpv_render_param {
                    type_: mpv::MPV_RENDER_PARAM_API_TYPE,
                    data: mpv::MPV_RENDER_API_TYPE_OPENGL.as_ptr() as *mut c_void,
                },
                mpv::mpv_render_param {
                    type_: mpv::MPV_RENDER_PARAM_OPENGL_INIT_PARAMS,
                    data: &mut init as *mut _ as *mut c_void,
                },
                mpv::mpv_render_param {
                    type_: mpv::MPV_RENDER_PARAM_WL_DISPLAY,
                    data: wl_display,
                },
                mpv::mpv_render_param {
                    type_: mpv::MPV_RENDER_PARAM_INVALID,
                    data: ptr::null_mut(),
                },
            ];
            let mut render: *mut mpv::mpv_render_context = ptr::null_mut();
            let rc =
                mpv::mpv_render_context_create(&mut render, self.ctx, params.as_mut_ptr());
            if rc < 0 {
                return Err(format!("mpv_render_context_create: {}", error_string(rc)));
            }
            self.render = render;
            Ok(())
        }
    }

    pub fn set_update_callback(&mut self) {
        if self.render.is_null() {
            return;
        }
        unsafe {
            mpv::mpv_render_context_set_update_callback(
                self.render,
                Some(update_cb),
                ptr::null_mut(),
            );
        }
    }

    pub fn set_property(&mut self, name: &str, value: &str) {
        let Ok(name) = CString::new(name) else { return };
        let Ok(value) = CString::new(value) else { return };
        unsafe {
            let _ = mpv::mpv_set_property_string(self.ctx, name.as_ptr(), value.as_ptr());
        }
    }

    pub fn loadfile(&mut self, file: &str) -> Result<(), String> {
        let Ok(cmd) = CString::new("loadfile") else {
            return Err(String::from("ruta con byte nulo"));
        };
        let Ok(arg) = CString::new(file) else {
            return Err(String::from("ruta con byte nulo"));
        };
        let mut args = [cmd.as_ptr(), arg.as_ptr(), ptr::null()];
        let rc = unsafe { mpv::mpv_command(self.ctx, args.as_mut_ptr()) };
        if rc < 0 {
            Err(format!("loadfile: {}", error_string(rc)))
        } else {
            Ok(())
        }
    }

    pub fn wait_event(&mut self, timeout: f64) -> CoreEvent {
        unsafe {
            let ev = mpv::mpv_wait_event(self.ctx, timeout);
            if ev.is_null() {
                return CoreEvent::None;
            }
            match (*ev).event_id {
                mpv::MPV_EVENT_NONE => CoreEvent::None,
                mpv::MPV_EVENT_START_FILE => CoreEvent::StartFile,
                mpv::MPV_EVENT_FILE_LOADED => CoreEvent::FileLoaded,
                mpv::MPV_EVENT_PLAYBACK_RESTART => CoreEvent::Restart,
                mpv::MPV_EVENT_CLIENT_MESSAGE => {
                    let data = (*ev).data as *mut mpv::mpv_event_client_message;
                    if data.is_null() {
                        CoreEvent::Other
                    } else {
                        let d = &*data;
                        let mut args = Vec::new();
                        for i in 0..d.num_args.max(0) as usize {
                            let p = *d.args.add(i);
                            if !p.is_null() {
                                args.push(CStr::from_ptr(p).to_string_lossy().to_string());
                            }
                        }
                        CoreEvent::Message(args)
                    }
                }
                mpv::MPV_EVENT_SHUTDOWN => CoreEvent::Shutdown,
                mpv::MPV_EVENT_END_FILE => {
                    let data = (*ev).data as *mut mpv::mpv_event_end_file;
                    if data.is_null() {
                        CoreEvent::EndFile { error: None }
                    } else {
                        let d = &*data;
                        if d.reason == mpv::MPV_END_FILE_REASON_ERROR {
                            CoreEvent::EndFile {
                                error: Some(error_string(d.error)),
                            }
                        } else {
                            CoreEvent::EndFile { error: None }
                        }
                    }
                }
                _ => CoreEvent::Other,
            }
        }
    }

    pub fn poll_events(&mut self) -> Vec<CoreEvent> {
        let mut out = Vec::new();
        loop {
            match self.wait_event(0.0) {
                CoreEvent::None => return out,
                CoreEvent::Other => {}
                ev => out.push(ev),
            }
        }
    }

    pub fn wait_loaded(&mut self, timeout: Duration) -> Result<(), String> {
        let deadline = Instant::now() + timeout;
        loop {
            match self.wait_event(0.1) {
                CoreEvent::FileLoaded => return Ok(()),
                CoreEvent::EndFile { error } => {
                    return Err(error.unwrap_or_else(|| {
                        String::from("el archivo termino antes de cargar")
                    }));
                }
                CoreEvent::Shutdown => return Err(String::from("mpv se cerro al cargar")),
                _ => {}
            }
            if Instant::now() >= deadline {
                return Err(String::from("tiempo de carga de mpv agotado"));
            }
        }
    }

    pub fn update(&mut self) -> u64 {
        if self.render.is_null() {
            return 0;
        }
        let flags = unsafe { mpv::mpv_render_context_update(self.render) };
        if flags & UPDATE_FRAME != 0 {
            self.frame_flag = true;
        }
        flags
    }

    pub fn frame_pending(&self) -> bool {
        self.frame_flag
    }

    pub fn clear_frame_flag(&mut self) {
        self.frame_flag = false;
    }

    pub fn render(&mut self, w: i32, h: i32) -> Result<(), String> {
        self.render_to(0, w, h, 0)
    }

    pub fn render_to(&mut self, fbo_id: u32, w: i32, h: i32, internal: u32) -> Result<(), String> {
        if self.render.is_null() {
            return Err(String::from("render context de mpv nulo"));
        }
        let mut fbo = mpv::mpv_opengl_fbo {
            fbo: fbo_id as c_int,
            w,
            h,
            internal_format: internal as c_int,
        };
        let mut flip: c_int = 1;
        let mut block: c_int = 0;
        let mut params = [
            mpv::mpv_render_param {
                type_: mpv::MPV_RENDER_PARAM_OPENGL_FBO,
                data: &mut fbo as *mut _ as *mut c_void,
            },
            mpv::mpv_render_param {
                type_: mpv::MPV_RENDER_PARAM_FLIP_Y,
                data: &mut flip as *mut _ as *mut c_void,
            },
            mpv::mpv_render_param {
                type_: mpv::MPV_RENDER_PARAM_BLOCK_FOR_TARGET_TIME,
                data: &mut block as *mut _ as *mut c_void,
            },
            mpv::mpv_render_param {
                type_: mpv::MPV_RENDER_PARAM_INVALID,
                data: ptr::null_mut(),
            },
        ];
        let rc = unsafe { mpv::mpv_render_context_render(self.render, params.as_mut_ptr()) };
        if rc < 0 {
            Err(format!("mpv render: {}", error_string(rc)))
        } else {
            Ok(())
        }
    }

    pub fn report_swap(&mut self) {
        if !self.render.is_null() {
            unsafe { mpv::mpv_render_context_report_swap(self.render) };
        }
    }

    /// Debe llamarse con el contexto GL actual (aunque no haya surface).
    pub fn shutdown(&mut self) {
        unsafe {
            if !self.render.is_null() {
                mpv::mpv_render_context_set_update_callback(
                    self.render,
                    None,
                    ptr::null_mut(),
                );
                mpv::mpv_render_context_free(self.render);
                self.render = ptr::null_mut();
            }
            if !self.ctx.is_null() {
                mpv::mpv_terminate_destroy(self.ctx);
                self.ctx = ptr::null_mut();
            }
        }
        WAKE_FD.store(-1, Ordering::SeqCst);
    }
}

impl Drop for Player {
    fn drop(&mut self) {
        // Sin un contexto GL actual no es seguro liberar el render context.
        // El camino normal pasa por shutdown(); esto solo evita dejar vivo
        // el core si el render nunca se creó.
        if self.ctx.is_null() {
            return;
        }
        if self.render.is_null() {
            unsafe {
                mpv::mpv_terminate_destroy(self.ctx);
            }
            self.ctx = ptr::null_mut();
            WAKE_FD.store(-1, Ordering::SeqCst);
        }
    }
}
