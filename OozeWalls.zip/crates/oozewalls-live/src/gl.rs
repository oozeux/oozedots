// SECCION: LIVE GL FUNCIONES SHADERS TEXTURAS
// IPC: interno del proceso __live
use std::ffi::{c_void, CString};
use std::os::raw::c_char;

pub const TEXTURE_2D: u32 = 0x0DE1;
pub const RGBA8: u32 = 0x8058;
pub const RGBA: u32 = 0x1908;
pub const RED: u32 = 0x1903;
pub const R32F: u32 = 0x822E;
pub const UNSIGNED_BYTE: u32 = 0x1401;
pub const FLOAT: u32 = 0x1406;
pub const TEXTURE_MIN_FILTER: u32 = 0x2801;
pub const TEXTURE_MAG_FILTER: u32 = 0x2800;
pub const TEXTURE_WRAP_S: u32 = 0x2802;
pub const TEXTURE_WRAP_T: u32 = 0x2803;
pub const NEAREST: i32 = 0x2600;
pub const CLAMP_TO_EDGE: i32 = 0x812F;
pub const FRAMEBUFFER: u32 = 0x8D40;
pub const COLOR_ATTACHMENT0: u32 = 0x8CE0;
pub const FRAMEBUFFER_COMPLETE: u32 = 0x8CD5;
pub const TRIANGLES: u32 = 0x0004;
pub const VERTEX_SHADER: u32 = 0x8B31;
pub const FRAGMENT_SHADER: u32 = 0x8B30;
pub const COMPILE_STATUS: u32 = 0x8B81;
pub const LINK_STATUS: u32 = 0x8B82;
pub const INFO_LOG_LENGTH: u32 = 0x8B84;
pub const TEXTURE0: u32 = 0x84C0;
pub const UNPACK_ALIGNMENT: u32 = 0x0CF5;
pub const PACK_ALIGNMENT: u32 = 0x0D05;
pub const BLEND: u32 = 0x0BE2;
pub const SCISSOR_TEST: u32 = 0x0C11;
pub const DEPTH_TEST: u32 = 0x0B71;
pub const CULL_FACE: u32 = 0x0B44;
pub const STENCIL_TEST: u32 = 0x0B90;

macro_rules! gl_fns {
    ($($name:ident : $sym:literal => fn($($arg:ty),*) $(-> $ret:ty)?;)*) => {
        pub struct Gl {
            $(pub $name: unsafe extern "system" fn($($arg),*) $(-> $ret)?,)*
        }

        impl Gl {
            pub fn load() -> Result<Self, String> {
                unsafe {
                    Ok(Self {
                        $($name: crate::egl::load_gl::<unsafe extern "system" fn($($arg),*) $(-> $ret)?>($sym)?,)*
                    })
                }
            }
        }
    };
}

gl_fns! {
    create_shader: c"glCreateShader" => fn(u32) -> u32;
    shader_source: c"glShaderSource" => fn(u32, i32, *const *const c_char, *const i32);
    compile_shader: c"glCompileShader" => fn(u32);
    get_shaderiv: c"glGetShaderiv" => fn(u32, u32, *mut i32);
    get_shader_info_log: c"glGetShaderInfoLog" => fn(u32, i32, *mut i32, *mut c_char);
    delete_shader: c"glDeleteShader" => fn(u32);
    create_program: c"glCreateProgram" => fn() -> u32;
    attach_shader: c"glAttachShader" => fn(u32, u32);
    link_program: c"glLinkProgram" => fn(u32);
    get_programiv: c"glGetProgramiv" => fn(u32, u32, *mut i32);
    get_program_info_log: c"glGetProgramInfoLog" => fn(u32, i32, *mut i32, *mut c_char);
    use_program: c"glUseProgram" => fn(u32);
    delete_program: c"glDeleteProgram" => fn(u32);
    get_uniform_location: c"glGetUniformLocation" => fn(u32, *const c_char) -> i32;
    uniform1i: c"glUniform1i" => fn(i32, i32);
    uniform1f: c"glUniform1f" => fn(i32, f32);
    uniform2i: c"glUniform2i" => fn(i32, i32, i32);
    uniform2f: c"glUniform2f" => fn(i32, f32, f32);
    uniform4f: c"glUniform4f" => fn(i32, f32, f32, f32, f32);
    uniform3fv: c"glUniform3fv" => fn(i32, i32, *const f32);
    gen_textures: c"glGenTextures" => fn(i32, *mut u32);
    delete_textures: c"glDeleteTextures" => fn(i32, *const u32);
    bind_texture: c"glBindTexture" => fn(u32, u32);
    active_texture: c"glActiveTexture" => fn(u32);
    tex_image_2d: c"glTexImage2D" => fn(u32, i32, i32, i32, i32, i32, u32, u32, *const c_void);
    tex_sub_image_2d: c"glTexSubImage2D" => fn(u32, i32, i32, i32, i32, i32, u32, u32, *const c_void);
    tex_parameteri: c"glTexParameteri" => fn(u32, u32, i32);
    pixel_storei: c"glPixelStorei" => fn(u32, i32);
    gen_framebuffers: c"glGenFramebuffers" => fn(i32, *mut u32);
    delete_framebuffers: c"glDeleteFramebuffers" => fn(i32, *const u32);
    bind_framebuffer: c"glBindFramebuffer" => fn(u32, u32);
    framebuffer_texture_2d: c"glFramebufferTexture2D" => fn(u32, u32, u32, u32, i32);
    check_framebuffer_status: c"glCheckFramebufferStatus" => fn(u32) -> u32;
    gen_vertex_arrays: c"glGenVertexArrays" => fn(i32, *mut u32);
    delete_vertex_arrays: c"glDeleteVertexArrays" => fn(i32, *const u32);
    bind_vertex_array: c"glBindVertexArray" => fn(u32);
    draw_arrays: c"glDrawArrays" => fn(u32, i32, i32);
    disable: c"glDisable" => fn(u32);
    viewport: c"glViewport" => fn(i32, i32, i32, i32);
    read_pixels: c"glReadPixels" => fn(i32, i32, i32, i32, u32, u32, *mut c_void);
}

impl Gl {
    fn compile(&self, kind: u32, src: &str) -> Result<u32, String> {
        let text = CString::new(src).map_err(|_| String::from("shader con byte nulo"))?;
        unsafe {
            let sh = (self.create_shader)(kind);
            let ptr = text.as_ptr();
            (self.shader_source)(sh, 1, &ptr, std::ptr::null());
            (self.compile_shader)(sh);
            let mut ok = 0i32;
            (self.get_shaderiv)(sh, COMPILE_STATUS, &mut ok);
            if ok == 0 {
                let mut len = 0i32;
                (self.get_shaderiv)(sh, INFO_LOG_LENGTH, &mut len);
                let mut buf = vec![0u8; len.max(1) as usize];
                (self.get_shader_info_log)(sh, len, std::ptr::null_mut(), buf.as_mut_ptr() as *mut c_char);
                (self.delete_shader)(sh);
                let msg = String::from_utf8_lossy(&buf).trim_end_matches('\0').trim().to_string();
                return Err(format!("shader: {}", msg));
            }
            Ok(sh)
        }
    }

    pub fn program(&self, vs: &str, fs: &str) -> Result<u32, String> {
        let v = self.compile(VERTEX_SHADER, vs)?;
        let f = match self.compile(FRAGMENT_SHADER, fs) {
            Ok(f) => f,
            Err(e) => {
                unsafe { (self.delete_shader)(v) };
                return Err(e);
            }
        };
        unsafe {
            let p = (self.create_program)();
            (self.attach_shader)(p, v);
            (self.attach_shader)(p, f);
            (self.link_program)(p);
            (self.delete_shader)(v);
            (self.delete_shader)(f);
            let mut ok = 0i32;
            (self.get_programiv)(p, LINK_STATUS, &mut ok);
            if ok == 0 {
                let mut len = 0i32;
                (self.get_programiv)(p, INFO_LOG_LENGTH, &mut len);
                let mut buf = vec![0u8; len.max(1) as usize];
                (self.get_program_info_log)(p, len, std::ptr::null_mut(), buf.as_mut_ptr() as *mut c_char);
                (self.delete_program)(p);
                let msg = String::from_utf8_lossy(&buf).trim_end_matches('\0').trim().to_string();
                return Err(format!("link: {}", msg));
            }
            Ok(p)
        }
    }

    pub fn uniform(&self, prog: u32, name: &str) -> i32 {
        match CString::new(name) {
            Ok(c) => unsafe { (self.get_uniform_location)(prog, c.as_ptr()) },
            Err(_) => -1,
        }
    }

    pub fn texture(&self, internal: u32, format: u32, kind: u32, w: i32, h: i32) -> u32 {
        unsafe {
            let mut tex = 0u32;
            (self.gen_textures)(1, &mut tex);
            (self.bind_texture)(TEXTURE_2D, tex);
            (self.tex_parameteri)(TEXTURE_2D, TEXTURE_MIN_FILTER, NEAREST);
            (self.tex_parameteri)(TEXTURE_2D, TEXTURE_MAG_FILTER, NEAREST);
            (self.tex_parameteri)(TEXTURE_2D, TEXTURE_WRAP_S, CLAMP_TO_EDGE);
            (self.tex_parameteri)(TEXTURE_2D, TEXTURE_WRAP_T, CLAMP_TO_EDGE);
            (self.pixel_storei)(UNPACK_ALIGNMENT, 1);
            (self.tex_image_2d)(
                TEXTURE_2D,
                0,
                internal as i32,
                w,
                h,
                0,
                format,
                kind,
                std::ptr::null(),
            );
            tex
        }
    }

    pub fn framebuffer(&self, tex: u32) -> Result<u32, String> {
        unsafe {
            let mut fbo = 0u32;
            (self.gen_framebuffers)(1, &mut fbo);
            (self.bind_framebuffer)(FRAMEBUFFER, fbo);
            (self.framebuffer_texture_2d)(FRAMEBUFFER, COLOR_ATTACHMENT0, TEXTURE_2D, tex, 0);
            let st = (self.check_framebuffer_status)(FRAMEBUFFER);
            (self.bind_framebuffer)(FRAMEBUFFER, 0);
            if st != FRAMEBUFFER_COMPLETE {
                (self.delete_framebuffers)(1, &fbo);
                return Err(format!("framebuffer incompleto 0x{:x}", st));
            }
            Ok(fbo)
        }
    }
}
