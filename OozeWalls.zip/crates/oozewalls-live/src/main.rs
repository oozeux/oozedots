//! main - binario oozewalls-live (se lanza como: oozewalls-live __live <args>)

fn main() {
    let args: Vec<String> = std::env::args().collect();
    if args.get(1).map(String::as_str) != Some("__live") {
        eprintln!("uso: oozewalls-live __live <salida> <archivo> <scaling> <mute> <volumen> <hwdec> <capa> <transicion> <ms> <imagen-anterior>");
        std::process::exit(2);
    }
    std::process::exit(oozewalls_live::launcher::run(&args));
}
