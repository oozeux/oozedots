// SECCION: LIVE FX TRANSICIONES NATIVAS EN GPU
// IPC: interno del proceso __live (mensaje script-message oozewalls-switch)
use std::ffi::c_void;

use crate::gl::{self, Gl};
use oozewalls::transition as tr;

pub const ID_NEW: i32 = 0;
pub const ID_FADE: i32 = 1;
pub const ID_ZOOM: i32 = 2;
pub const ID_SLIDE: i32 = 3;
pub const ID_WIPE: i32 = 4;
pub const ID_CIRCLE: i32 = 5;
pub const ID_BLINDS: i32 = 6;
pub const ID_OLD: i32 = 7;
pub const ID_RISE: i32 = 10;
pub const ID_DRIP: i32 = 11;
pub const ID_BARS: i32 = 12;
pub const ID_DIAG: i32 = 13;
pub const ID_RINGS: i32 = 14;
pub const ID_BLOB: i32 = 15;

const PROBE_W: usize = 32;
const PROBE_H: usize = 18;

const VERTEX: &str = r#"#version 330 core
void main() {
    vec2 p = vec2(float((gl_VertexID << 1) & 2), float(gl_VertexID & 2));
    gl_Position = vec4(p * 2.0 - 1.0, 0.0, 1.0);
}
"#;

const FRAGMENT: &str = r#"#version 330 core
out vec4 frag;
uniform sampler2D uOld;
uniform sampler2D uNew;
uniform sampler2D uTab;
uniform ivec2 uRes;
uniform int uId;
uniform float uE;
uniform vec4 uP;
uniform vec2 uGS;
uniform vec3 uCols[3];
uniform vec3 uSats[6];
const float PI = 3.14159265358979;
const float TAU = 6.28318530717959;
const float LUT_N = 720.0;
const float BLOB_MIN = 0.74;

vec3 sOld(int x, int y) { return texelFetch(uOld, ivec2(x, uRes.y - 1 - y), 0).rgb; }
vec3 sNew(int x, int y) { return texelFetch(uNew, ivec2(x, uRes.y - 1 - y), 0).rgb; }
float tab(int i) { return texelFetch(uTab, ivec2(i, 0), 0).r; }
vec3 bl(vec3 c, vec3 t, float v) { return mix(c, t, min(floor(v), 256.0) / 256.0); }

vec3 layers(vec3 o, vec3 n, float raw) {
    float e = uE;
    if (e <= 0.0) return o;
    float gap = uGS.x;
    float soft = uGS.y;
    float f0 = e * (1.0 + 3.0 * gap + soft);
    float s = clamp(raw, 0.0, 0.998);
    float inv = 256.0 / soft;
    float d = f0 - s;
    if (d <= 0.0) return o;
    vec3 c = bl(o, uCols[0], d * inv);
    d = f0 - gap - s;
    if (d > 0.0) c = bl(c, uCols[1], d * inv);
    d = f0 - 2.0 * gap - s;
    if (d > 0.0) c = bl(c, uCols[2], d * inv);
    d = f0 - 3.0 * gap - s;
    if (d > 0.0) c = bl(c, n, d * inv);
    return c;
}

void main() {
    int x = int(gl_FragCoord.x);
    int y = uRes.y - 1 - int(gl_FragCoord.y);
    float w = float(uRes.x);
    float h = float(uRes.y);
    float fx = float(x) + 0.5;
    float fy = float(y) + 0.5;
    vec3 o = sOld(x, y);
    vec3 n = sNew(x, y);
    vec3 c = o;
    if (uId == 0) {
        c = n;
    } else if (uId == 1) {
        c = mix(o, n, clamp(floor(uE * 256.0 + 0.5), 0.0, 256.0) / 256.0);
    } else if (uId == 2) {
        float s = 1.0 + 0.15 * (1.0 - uE);
        vec2 ctr = vec2(w, h) * 0.5;
        vec2 sp = ctr + (vec2(fx, fy) - ctr) / s;
        n = sNew(min(int(sp.x), uRes.x - 1), min(int(sp.y), uRes.y - 1));
        c = mix(o, n, clamp(floor(uE * 256.0 + 0.5), 0.0, 256.0) / 256.0);
    } else if (uId == 3) {
        int code = int(uP.x + 0.5);
        int off = int(uP.y + 0.5);
        if (code == 0 && x < uRes.x - off) c = sNew(x + off, y);
        else if (code == 1 && x >= off) c = sNew(x - off, y);
        else if (code == 2 && y < uRes.y - off) c = sNew(x, y + off);
        else if (code == 3 && y >= off) c = sNew(x, y - off);
    } else if (uId == 4) {
        int code = int(uP.x + 0.5);
        int cnt = int(uP.y + 0.5);
        bool inside = (code == 0 && x < cnt) || (code == 1 && x >= uRes.x - cnt)
            || (code == 2 && y < cnt) || (code == 3 && y >= uRes.y - cnt);
        if (inside) c = n;
    } else if (uId == 5) {
        float cx = w * 0.5;
        float cy = h * 0.5;
        float r = uE * sqrt(cx * cx + cy * cy);
        float dy = fy - cy;
        if (r > 0.0 && abs(dy) < r) {
            float hw = sqrt(r * r - dy * dy);
            float x0 = max(floor(cx - hw + 0.5), 0.0);
            float x1 = min(floor(cx + hw + 0.5), w);
            if (float(x) >= x0 && float(x) < x1) c = n;
        }
    } else if (uId == 6) {
        int bw = int(uP.x + 0.5);
        int shown = int(uP.y + 0.5);
        if (shown > 0 && (x % bw) < shown) c = n;
    } else if (uId == 7) {
        c = o;
    } else if (uId == 10) {
        int edge = int(uP.x + 0.5);
        float a;
        int idx;
        if (edge == 3) { a = 1.0 - fy / h; idx = x; }
        else if (edge == 2) { a = fy / h; idx = x; }
        else if (edge == 0) { a = fx / w; idx = y; }
        else { a = 1.0 - fx / w; idx = y; }
        c = layers(o, n, uP.y + uP.z * a + tab(idx));
    } else if (uId == 11) {
        float reach = uP.x;
        c = layers(o, n, (fy / h) * (1.0 - reach) + reach * (1.0 - tab(x)));
    } else if (uId == 12) {
        int cols = 12;
        int xx = uP.x > 0.5 ? uRes.x - 1 - x : x;
        int i = min(xx * cols / uRes.x, cols - 1);
        float base = float(i) / float(cols);
        float v = (i % 2 == 1) ? 1.0 - fy / h : fy / h;
        c = layers(o, n, base + v / float(cols));
    } else if (uId == 13) {
        float cnt = 7.0;
        int xx = uP.x > 0.5 ? uRes.x - 1 - x : x;
        float span = w + h;
        float d = float(xx + y) / span;
        float q = floor(d * cnt);
        float u = (float(xx) - float(y) + h) / span;
        float t = (int(q) % 2 == 1) ? 1.0 - u : u;
        c = layers(o, n, (q + t) / cnt);
    } else if (uId == 14) {
        float cx = w * 0.5;
        float cy = h * 0.5;
        float rmax = sqrt(cx * cx + cy * cy);
        c = layers(o, n, length(vec2(fx - cx, fy - cy)) / rmax);
    } else if (uId == 15) {
        float cx = w * 0.5;
        float cy = h * 0.5;
        float rmax = sqrt(cx * cx + cy * cy);
        vec2 dv = vec2(fx - cx, fy - cy);
        float ang = atan(dv.y, dv.x);
        int idx = min(int((ang + PI) * (LUT_N / TAU)), int(LUT_N) - 1);
        float s = length(dv) / rmax * BLOB_MIN / tab(idx);
        for (int k = 0; k < 6; k++) {
            vec2 ev = vec2(fx - uSats[k].x, fy - uSats[k].y);
            float d2 = dot(ev, ev);
            float lim = uSats[k].z * 1.5;
            if (d2 < lim * lim) {
                float v = sqrt(d2) / uSats[k].z;
                if (v < s) s = v;
            }
        }
        c = layers(o, n, s);
    }
    frag = vec4(c, 1.0);
}
"#;

pub struct Spec {
    pub id: i32,
    pub p: [f32; 4],
    pub gap: f32,
    pub soft: f32,
    pub table: Vec<f32>,
    pub sats: [[f32; 3]; 6],
}

impl Spec {
    fn simple(id: i32, p: [f32; 4]) -> Self {
        Self {
            id,
            p,
            gap: 0.1,
            soft: 0.01,
            table: Vec::new(),
            sats: [[0.0; 3]; 6],
        }
    }

    fn layered(id: i32, p: [f32; 4], gap: f32, soft: f32, table: Vec<f32>) -> Self {
        Self {
            id,
            p,
            gap,
            soft,
            table,
            sats: [[0.0; 3]; 6],
        }
    }
}

fn rise(edge: f32, amp: f32, gap: f32, soft: f32, table: Vec<f32>) -> Spec {
    Spec::layered(ID_RISE, [edge, amp, 1.0 - 2.0 * amp, 0.0], gap, soft, table)
}

pub fn spec(kind: &str, e: f32, w: usize, h: usize) -> Spec {
    let wf = w as f32;
    let hf = h as f32;
    match kind {
        "fade" => Spec::simple(ID_FADE, [0.0; 4]),
        "zoom" => Spec::simple(ID_ZOOM, [0.0; 4]),
        "slide-left" | "slide-right" => {
            let off = ((1.0 - e) * wf).round().min(wf);
            let code = if kind == "slide-left" { 0.0 } else { 1.0 };
            Spec::simple(ID_SLIDE, [code, off, 0.0, 0.0])
        }
        "slide-up" | "slide-down" => {
            let off = ((1.0 - e) * hf).round().min(hf);
            let code = if kind == "slide-up" { 2.0 } else { 3.0 };
            Spec::simple(ID_SLIDE, [code, off, 0.0, 0.0])
        }
        "wipe-left" | "wipe-right" => {
            let n = (e * wf).round().min(wf);
            let code = if kind == "wipe-left" { 0.0 } else { 1.0 };
            Spec::simple(ID_WIPE, [code, n, 0.0, 0.0])
        }
        "wipe-up" | "wipe-down" => {
            let n = (e * hf).round().min(hf);
            let code = if kind == "wipe-up" { 2.0 } else { 3.0 };
            Spec::simple(ID_WIPE, [code, n, 0.0, 0.0])
        }
        "circle" => Spec::simple(ID_CIRCLE, [0.0; 4]),
        "blinds" => {
            let bw = ((w + 11) / 12).max(1) as f32;
            let shown = (e * bw).round();
            Spec::simple(ID_BLINDS, [bw, shown, 0.0, 0.0])
        }
        "wave-left" => rise(0.0, tr::WAVE_AMP, 0.14, 0.01, tr::wave_offsets(e, h)),
        "wave-right" => rise(1.0, tr::WAVE_AMP, 0.14, 0.01, tr::wave_offsets(e, h)),
        "wave-up" => rise(2.0, tr::WAVE_AMP, 0.14, 0.01, tr::wave_offsets(e, w)),
        "wave-down" => rise(3.0, tr::WAVE_AMP, 0.14, 0.01, tr::wave_offsets(e, w)),
        "slime" => rise(3.0, tr::SLIME_AMP, 0.1, 0.012, tr::slime_offsets(e, w)),
        "drip" => Spec::layered(
            ID_DRIP,
            [tr::DRIP_REACH, 0.0, 0.0, 0.0],
            0.1,
            0.01,
            tr::drip_drape(w),
        ),
        "bars-left" => Spec::layered(ID_BARS, [0.0; 4], 0.1, 0.008, Vec::new()),
        "bars-right" => Spec::layered(ID_BARS, [1.0, 0.0, 0.0, 0.0], 0.1, 0.008, Vec::new()),
        "diagonal-left" => Spec::layered(ID_DIAG, [0.0; 4], 0.1, 0.008, Vec::new()),
        "diagonal-right" => Spec::layered(ID_DIAG, [1.0, 0.0, 0.0, 0.0], 0.1, 0.008, Vec::new()),
        "rings" => Spec::layered(ID_RINGS, [0.0; 4], 0.12, 0.012, Vec::new()),
        "blob" => {
            let mut s = Spec::layered(ID_BLOB, [0.0; 4], 0.1, 0.012, tr::blob_lut(e));
            for (dst, src) in s.sats.iter_mut().zip(tr::blob_sats(w, h).iter()) {
                *dst = [src.0, src.1, src.2];
            }
            s
        }
        _ => Spec::simple(ID_NEW, [0.0; 4]),
    }
}

pub fn old_only() -> Spec {
    Spec::simple(ID_OLD, [0.0; 4])
}

pub struct Target {
    pub w: i32,
    pub h: i32,
    pub old_tex: u32,
    pub cur_tex: u32,
    pub old_fbo: u32,
    pub cur_fbo: u32,
    pub cols: [[f32; 3]; 3],
    pub cols_ready: bool,
}

struct Locs {
    old: i32,
    new: i32,
    tab: i32,
    res: i32,
    id: i32,
    e: i32,
    p: i32,
    gs: i32,
    cols: i32,
    sats: i32,
}

pub struct Fx {
    gl: Gl,
    prog: u32,
    vao: u32,
    loc: Locs,
    tab_tex: u32,
    tab_len: usize,
}

impl Fx {
    pub fn new() -> Result<Self, String> {
        let gl = Gl::load()?;
        let prog = gl.program(VERTEX, FRAGMENT)?;
        let loc = Locs {
            old: gl.uniform(prog, "uOld"),
            new: gl.uniform(prog, "uNew"),
            tab: gl.uniform(prog, "uTab"),
            res: gl.uniform(prog, "uRes"),
            id: gl.uniform(prog, "uId"),
            e: gl.uniform(prog, "uE"),
            p: gl.uniform(prog, "uP"),
            gs: gl.uniform(prog, "uGS"),
            cols: gl.uniform(prog, "uCols"),
            sats: gl.uniform(prog, "uSats"),
        };
        let mut vao = 0u32;
        unsafe {
            (gl.gen_vertex_arrays)(1, &mut vao);
        }
        let tab_len = tr::LUT_SIZE.max(4096);
        let tab_tex = gl.texture(gl::R32F, gl::RED, gl::FLOAT, tab_len as i32, 1);
        Ok(Self {
            gl,
            prog,
            vao,
            loc,
            tab_tex,
            tab_len,
        })
    }

    pub fn target(&self, w: i32, h: i32) -> Result<Target, String> {
        let old_tex = self.gl.texture(gl::RGBA8, gl::RGBA, gl::UNSIGNED_BYTE, w, h);
        let cur_tex = self.gl.texture(gl::RGBA8, gl::RGBA, gl::UNSIGNED_BYTE, w, h);
        let old_fbo = self.gl.framebuffer(old_tex);
        let cur_fbo = self.gl.framebuffer(cur_tex);
        match (old_fbo, cur_fbo) {
            (Ok(old_fbo), Ok(cur_fbo)) => Ok(Target {
                w,
                h,
                old_tex,
                cur_tex,
                old_fbo,
                cur_fbo,
                cols: [[0.0; 3]; 3],
                cols_ready: false,
            }),
            (a, b) => {
                let msg = a.as_ref().err().or(b.as_ref().err()).cloned();
                unsafe {
                    for f in [a, b].iter().flatten() {
                        (self.gl.delete_framebuffers)(1, f);
                    }
                    (self.gl.delete_textures)(1, &old_tex);
                    (self.gl.delete_textures)(1, &cur_tex);
                }
                Err(msg.unwrap_or_else(|| String::from("target")))
            }
        }
    }

    pub fn free_target(&self, t: Target) {
        unsafe {
            (self.gl.delete_framebuffers)(1, &t.old_fbo);
            (self.gl.delete_framebuffers)(1, &t.cur_fbo);
            (self.gl.delete_textures)(1, &t.old_tex);
            (self.gl.delete_textures)(1, &t.cur_tex);
        }
    }

    pub fn destroy(&mut self) {
        unsafe {
            (self.gl.delete_textures)(1, &self.tab_tex);
            (self.gl.delete_vertex_arrays)(1, &self.vao);
            (self.gl.delete_program)(self.prog);
        }
    }

    pub fn upload_old_bgrx(&self, t: &Target, bgrx: &[u8]) {
        let (w, h) = (t.w as usize, t.h as usize);
        if bgrx.len() < w * h * 4 {
            return;
        }
        let mut rgba = vec![255u8; w * h * 4];
        for y in 0..h {
            let src = &bgrx[y * w * 4..(y + 1) * w * 4];
            let dst = &mut rgba[(h - 1 - y) * w * 4..(h - y) * w * 4];
            for (d, s) in dst.chunks_exact_mut(4).zip(src.chunks_exact(4)) {
                d[0] = s[2];
                d[1] = s[1];
                d[2] = s[0];
            }
        }
        unsafe {
            (self.gl.bind_texture)(gl::TEXTURE_2D, t.old_tex);
            (self.gl.pixel_storei)(gl::UNPACK_ALIGNMENT, 1);
            (self.gl.tex_sub_image_2d)(
                gl::TEXTURE_2D,
                0,
                0,
                0,
                t.w,
                t.h,
                gl::RGBA,
                gl::UNSIGNED_BYTE,
                rgba.as_ptr() as *const c_void,
            );
        }
    }

    pub fn sync(&self, fbo: u32) {
        let mut px = [0u8; 4];
        unsafe {
            (self.gl.bind_framebuffer)(gl::FRAMEBUFFER, fbo);
            (self.gl.pixel_storei)(gl::PACK_ALIGNMENT, 1);
            (self.gl.read_pixels)(
                0,
                0,
                1,
                1,
                gl::RGBA,
                gl::UNSIGNED_BYTE,
                px.as_mut_ptr() as *mut c_void,
            );
            (self.gl.bind_framebuffer)(gl::FRAMEBUFFER, 0);
        }
    }

    pub fn probe_colors(&self, t: &mut Target) {
        let (w, h) = (t.w as usize, t.h as usize);
        if w < PROBE_W || h < PROBE_H {
            t.cols_ready = true;
            return;
        }
        let mut mini = vec![0u8; PROBE_W * PROBE_H * 4];
        unsafe {
            (self.gl.bind_framebuffer)(gl::FRAMEBUFFER, t.cur_fbo);
            (self.gl.pixel_storei)(gl::PACK_ALIGNMENT, 1);
            for j in 0..PROBE_H {
                let y = (j * 2 + 1) * h / (PROBE_H * 2);
                for i in 0..PROBE_W {
                    let x = (i * 2 + 1) * w / (PROBE_W * 2);
                    let at = (j * PROBE_W + i) * 4;
                    (self.gl.read_pixels)(
                        x as i32,
                        (h - 1 - y) as i32,
                        1,
                        1,
                        gl::RGBA,
                        gl::UNSIGNED_BYTE,
                        mini[at..at + 4].as_mut_ptr() as *mut c_void,
                    );
                }
            }
            (self.gl.bind_framebuffer)(gl::FRAMEBUFFER, 0);
        }
        let layers = tr::accent_layers(&mini, PROBE_W, PROBE_H);
        for (dst, src) in t.cols.iter_mut().zip(layers.iter()) {
            *dst = [
                src[0] as f32 / 255.0,
                src[1] as f32 / 255.0,
                src[2] as f32 / 255.0,
            ];
        }
        t.cols_ready = true;
    }

    fn upload_table(&mut self, table: &[f32]) {
        if table.is_empty() {
            return;
        }
        unsafe {
            (self.gl.bind_texture)(gl::TEXTURE_2D, self.tab_tex);
            (self.gl.pixel_storei)(gl::UNPACK_ALIGNMENT, 1);
            if table.len() > self.tab_len {
                (self.gl.delete_textures)(1, &self.tab_tex);
                self.tab_len = table.len();
                self.tab_tex = self.gl.texture(
                    gl::R32F,
                    gl::RED,
                    gl::FLOAT,
                    self.tab_len as i32,
                    1,
                );
                (self.gl.bind_texture)(gl::TEXTURE_2D, self.tab_tex);
            }
            (self.gl.tex_sub_image_2d)(
                gl::TEXTURE_2D,
                0,
                0,
                0,
                table.len() as i32,
                1,
                gl::RED,
                gl::FLOAT,
                table.as_ptr() as *const c_void,
            );
        }
    }

    pub fn draw(&mut self, dst_fbo: u32, t: &Target, spec: &Spec, e: f32) {
        self.upload_table(&spec.table);
        let g = &self.gl;
        unsafe {
            (g.bind_framebuffer)(gl::FRAMEBUFFER, dst_fbo);
            (g.viewport)(0, 0, t.w, t.h);
            for cap in [
                gl::BLEND,
                gl::SCISSOR_TEST,
                gl::DEPTH_TEST,
                gl::CULL_FACE,
                gl::STENCIL_TEST,
            ] {
                (g.disable)(cap);
            }
            (g.use_program)(self.prog);
            (g.active_texture)(gl::TEXTURE0);
            (g.bind_texture)(gl::TEXTURE_2D, t.old_tex);
            (g.active_texture)(gl::TEXTURE0 + 1);
            (g.bind_texture)(gl::TEXTURE_2D, t.cur_tex);
            (g.active_texture)(gl::TEXTURE0 + 2);
            (g.bind_texture)(gl::TEXTURE_2D, self.tab_tex);
            (g.uniform1i)(self.loc.old, 0);
            (g.uniform1i)(self.loc.new, 1);
            (g.uniform1i)(self.loc.tab, 2);
            (g.uniform2i)(self.loc.res, t.w, t.h);
            (g.uniform1i)(self.loc.id, spec.id);
            (g.uniform1f)(self.loc.e, e);
            (g.uniform4f)(self.loc.p, spec.p[0], spec.p[1], spec.p[2], spec.p[3]);
            (g.uniform2f)(self.loc.gs, spec.gap, spec.soft);
            (g.uniform3fv)(self.loc.cols, 3, t.cols.as_ptr() as *const f32);
            (g.uniform3fv)(self.loc.sats, 6, spec.sats.as_ptr() as *const f32);
            (g.bind_vertex_array)(self.vao);
            (g.draw_arrays)(gl::TRIANGLES, 0, 3);
            (g.active_texture)(gl::TEXTURE0);
        }
    }

    pub fn read_back(&self, fbo: u32, w: i32, h: i32) -> Vec<u8> {
        let mut out = vec![0u8; (w * h * 4) as usize];
        unsafe {
            (self.gl.bind_framebuffer)(gl::FRAMEBUFFER, fbo);
            (self.gl.pixel_storei)(gl::PACK_ALIGNMENT, 1);
            (self.gl.read_pixels)(
                0,
                0,
                w,
                h,
                gl::RGBA,
                gl::UNSIGNED_BYTE,
                out.as_mut_ptr() as *mut c_void,
            );
            (self.gl.bind_framebuffer)(gl::FRAMEBUFFER, 0);
        }
        out
    }

    #[cfg(test)]
    pub fn fill(&self, tex: u32, w: i32, h: i32, rgba: &[u8]) {
        unsafe {
            (self.gl.bind_texture)(gl::TEXTURE_2D, tex);
            (self.gl.pixel_storei)(gl::UNPACK_ALIGNMENT, 1);
            (self.gl.tex_sub_image_2d)(
                gl::TEXTURE_2D,
                0,
                0,
                0,
                w,
                h,
                gl::RGBA,
                gl::UNSIGNED_BYTE,
                rgba.as_ptr() as *const c_void,
            );
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use khronos_egl as egl;

    fn pattern(w: usize, h: usize, flip: bool) -> Vec<u8> {
        let mut v = vec![255u8; w * h * 4];
        for y in 0..h {
            for x in 0..w {
                let i = (y * w + x) * 4;
                let (a, b) = if flip { (w - 1 - x, h - 1 - y) } else { (x, y) };
                v[i] = (a * 255 / w) as u8;
                v[i + 1] = (b * 255 / h) as u8;
                v[i + 2] = ((a * 7 + b * 13) % 256) as u8;
            }
        }
        v
    }

    fn flip_rows(src: &[u8], w: usize, h: usize) -> Vec<u8> {
        let mut out = vec![0u8; src.len()];
        for y in 0..h {
            out[(h - 1 - y) * w * 4..(h - y) * w * 4].copy_from_slice(&src[y * w * 4..(y + 1) * w * 4]);
        }
        out
    }

    #[test]
    fn gpu_matches_cpu_for_every_kind() {
        let inst = match unsafe { egl::DynamicInstance::<egl::EGL1_5>::load_required() } {
            Ok(i) => i,
            Err(e) => { eprintln!("skip egl: {:?}", e); return }
        };
        let display = match unsafe {
            inst.get_platform_display(0x31DD, std::ptr::null_mut(), &[egl::ATTRIB_NONE])
        } {
            Ok(d) => d,
            Err(e) => { eprintln!("skip display: {:?}", e); return }
        };
        if let Err(e) = inst.initialize(display) { eprintln!("skip init: {:?}", e); return }
        if let Err(e) = inst.bind_api(egl::OPENGL_API) { eprintln!("skip api: {:?}", e); return }
        let cfg = match inst.choose_first_config(
            display,
            &[egl::SURFACE_TYPE, egl::PBUFFER_BIT, egl::RENDERABLE_TYPE, egl::OPENGL_BIT, egl::NONE],
        ) {
            Ok(Some(c)) => c,
            o => { eprintln!("skip cfg: {:?}", o.is_ok()); return }
        };
        let ctx = match inst.create_context(
            display,
            cfg,
            None,
            &[egl::CONTEXT_MAJOR_VERSION, 3, egl::CONTEXT_MINOR_VERSION, 3, egl::NONE],
        ) {
            Ok(c) => c,
            Err(e) => { eprintln!("skip ctx: {:?}", e); return }
        };
        if let Err(e) = inst.make_current(display, None, None, Some(ctx)) { eprintln!("skip mc: {:?}", e); return }
        let mut fx = Fx::new().expect("fx");
        let (w, h) = (96usize, 54usize);
        let old = pattern(w, h, false);
        let new = pattern(w, h, true);
        let mut worst = 0.0f32;
        for (kind, _) in tr::KINDS {
            if *kind == "none" || *kind == "random" {
                continue;
            }
            for &t in &[0.0f32, 0.25, 0.5, 0.8, 1.0] {
                let mut target = fx.target(w as i32, h as i32).expect("target");
                fx.fill(target.old_tex, w as i32, h as i32, &flip_rows(&old, w, h));
                fx.fill(target.cur_tex, w as i32, h as i32, &flip_rows(&new, w, h));
                fx.probe_colors(&mut target);
                let out_tex = fx.gl.texture(gl::RGBA8, gl::RGBA, gl::UNSIGNED_BYTE, w as i32, h as i32);
                let out_fbo = fx.gl.framebuffer(out_tex).expect("fbo");
                let e = tr::ease(t);
                let spec = spec(kind, e, w, h);
                fx.draw(out_fbo, &target, &spec, e);
                let got = flip_rows(&fx.read_back(out_fbo, w as i32, h as i32), w, h);
                let mut want = vec![0u8; w * h * 4];
                tr::frame_into(&mut want, &old, &new, w, h, kind, t);
                let mut bad = 0usize;
                for (g, c) in got.chunks_exact(4).zip(want.chunks_exact(4)) {
                    if (0..3).any(|k| (g[k] as i32 - c[k] as i32).abs() > 6) {
                        bad += 1;
                    }
                }
                let frac = bad as f32 / (w * h) as f32;
                worst = worst.max(frac);
                assert!(frac < 0.03, "{} t={} difiere en {:.2}% de pixeles", kind, t, frac * 100.0);
                unsafe {
                    (fx.gl.delete_framebuffers)(1, &out_fbo);
                    (fx.gl.delete_textures)(1, &out_tex);
                }
                fx.free_target(target);
            }
        }
        eprintln!("paridad GPU/CPU: peor caso {:.3}% de pixeles fuera de tolerancia", worst * 100.0);
        fx.destroy();
    }
}
