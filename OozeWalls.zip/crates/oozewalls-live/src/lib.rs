use std::sync::atomic::{AtomicBool, Ordering};

mod egl;
mod fx;
mod gl;
pub mod launcher;
mod mpv;
mod render;

static STOP: AtomicBool = AtomicBool::new(false);

pub fn stop_requested() -> bool {
    STOP.load(Ordering::SeqCst)
}

pub fn request_stop() {
    STOP.store(true, Ordering::SeqCst);
}

pub fn clear_stop() {
    STOP.store(false, Ordering::SeqCst);
}
