// SECCION: LIVE EGL WAYLAND OPENGL
// IPC: interno del proceso __live (multi-salida, un contexto GL compartido)
use std::collections::HashMap;
use std::ffi::CStr;
use std::os::raw::{c_char, c_void};
use std::ptr;
use std::sync::atomic::{AtomicPtr, Ordering};

use khronos_egl as egl;
use wayland_client::backend::ObjectId;
use wayland_client::protocol::wl_surface::WlSurface;
use wayland_client::Proxy;
use wayland_egl::WlEglSurface;

// khronos-egl 6 no exporta PLATFORM_WAYLAND_KHR.
const PLATFORM_WAYLAND_KHR: egl::Enum = 0x31D8;
const GL_BACK: u32 = 0x0405;

static EGL_LIB: AtomicPtr<c_void> = AtomicPtr::new(ptr::null_mut());
static GL_LIB: AtomicPtr<c_void> = AtomicPtr::new(ptr::null_mut());

unsafe fn dlopen_cached(cache: &AtomicPtr<c_void>, names: &[&CStr]) -> *mut c_void {
    let mut h = cache.load(Ordering::SeqCst);
    if !h.is_null() {
        return h;
    }
    for name in names {
        h = libc::dlopen(name.as_ptr(), libc::RTLD_LAZY | libc::RTLD_LOCAL);
        if !h.is_null() {
            break;
        }
    }
    cache.store(h, Ordering::SeqCst);
    h
}

/// Resuelve una función GL/EGL con eglGetProcAddress y, si falla, con libGL.
pub unsafe fn get_proc_address(name: *const c_char) -> *mut c_void {
    if name.is_null() {
        return ptr::null_mut();
    }
    let egl_handle = dlopen_cached(&EGL_LIB, &[c"libEGL.so.1", c"libEGL.so"]);
    if !egl_handle.is_null() {
        let sym = libc::dlsym(egl_handle, c"eglGetProcAddress".as_ptr());
        if !sym.is_null() {
            let f: unsafe extern "C" fn(*const c_char) -> *mut c_void = std::mem::transmute(sym);
            let p = f(name);
            if !p.is_null() {
                return p;
            }
        }
    }
    let gl_handle = dlopen_cached(&GL_LIB, &[c"libGL.so.1", c"libGL.so"]);
    if gl_handle.is_null() {
        return ptr::null_mut();
    }
    libc::dlsym(gl_handle, name)
}

pub(super) unsafe fn load_gl<T: Copy>(name: &CStr) -> Result<T, String> {
    let p = get_proc_address(name.as_ptr());
    if p.is_null() {
        return Err(format!("no se pudo cargar {}", name.to_string_lossy()));
    }
    Ok(std::mem::transmute_copy(&p))
}

struct EglSurface {
    window: WlEglSurface,
    surface: egl::Surface,
    size: (i32, i32),
}

pub struct Egl {
    inst: egl::DynamicInstance<egl::EGL1_5>,
    display: egl::Display,
    config: egl::Config,
    context: egl::Context,
    surfaces: HashMap<ObjectId, EglSurface>,
    terminated: bool,
    gl_viewport: unsafe extern "system" fn(i32, i32, i32, i32),
    gl_draw_buffer: unsafe extern "system" fn(u32),
}

impl Egl {
    pub fn new(wl_display: *mut c_void) -> Result<Self, String> {
        let inst = unsafe { egl::DynamicInstance::<egl::EGL1_5>::load_required() }
            .map_err(|e| format!("cargar libEGL: {}", e))?;
        let display = unsafe {
            inst.get_platform_display(
                PLATFORM_WAYLAND_KHR,
                wl_display,
                &[egl::ATTRIB_NONE],
            )
        }
        .map_err(|e| format!("eglGetPlatformDisplay: {:?}", e))?;

        inst.initialize(display)
            .map_err(|e| format!("eglInitialize: {:?}", e))?;
        inst.bind_api(egl::OPENGL_API)
            .map_err(|e| format!("eglBindAPI: {:?}", e))?;

        let attribs = [
            egl::SURFACE_TYPE,
            egl::WINDOW_BIT,
            egl::RENDERABLE_TYPE,
            egl::OPENGL_BIT,
            egl::RED_SIZE,
            8,
            egl::GREEN_SIZE,
            8,
            egl::BLUE_SIZE,
            8,
            egl::ALPHA_SIZE,
            8,
            egl::NONE,
        ];
        let config = inst
            .choose_first_config(display, &attribs)
            .map_err(|e| format!("eglChooseConfig: {:?}", e))?
            .ok_or_else(|| String::from("sin config EGL para ventana OpenGL"))?;

        let mut context = None;
        for (major, minor) in [
            (4, 6),
            (4, 5),
            (4, 4),
            (4, 3),
            (4, 2),
            (4, 1),
            (4, 0),
            (3, 3),
            (3, 2),
            (3, 1),
            (3, 0),
        ] {
            let attrs = [
                egl::CONTEXT_MAJOR_VERSION,
                major,
                egl::CONTEXT_MINOR_VERSION,
                minor,
                egl::NONE,
            ];
            if let Ok(ctx) = inst.create_context(display, config, None, &attrs) {
                context = Some(ctx);
                break;
            }
        }
        let context = context.ok_or_else(|| String::from("no se pudo crear contexto OpenGL"))?;
        inst.make_current(display, None, None, Some(context))
            .map_err(|e| format!("eglMakeCurrent inicial: {:?}", e))?;

        let gl_viewport = unsafe { load_gl::<unsafe extern "system" fn(i32, i32, i32, i32)>(c"glViewport") }?;
        let gl_draw_buffer = unsafe { load_gl::<unsafe extern "system" fn(u32)>(c"glDrawBuffer") }?;

        Ok(Self {
            inst,
            display,
            config,
            context,
            surfaces: HashMap::new(),
            terminated: false,
            gl_viewport,
            gl_draw_buffer,
        })
    }

    pub fn ensure_surface(
        &mut self,
        wl_surface: &WlSurface,
        w: u32,
        h: u32,
        scale: i32,
    ) -> Result<(), String> {
        if w == 0 || h == 0 {
            return Ok(());
        }
        let scale = scale.max(1) as u32;
        let pw = (w * scale) as i32;
        let ph = (h * scale) as i32;
        let id = wl_surface.id();

        if let Some(es) = self.surfaces.get_mut(&id) {
            if es.size != (pw, ph) {
                es.window.resize(pw, ph, 0, 0);
                es.size = (pw, ph);
            }
            self.make_current_id(&id)?;
            self.viewport(pw, ph);
            return Ok(());
        }

        let window = WlEglSurface::new(id.clone(), pw, ph)
            .map_err(|e| format!("wl_egl_window: {:?}", e))?;
        let surface = unsafe {
            self.inst.create_platform_window_surface(
                self.display,
                self.config,
                window.ptr() as *mut c_void,
                &[egl::ATTRIB_NONE],
            )
        }
        .map_err(|e| format!("eglCreatePlatformWindowSurface: {:?}", e))?;

        self.surfaces.insert(
            id.clone(),
            EglSurface {
                window,
                surface,
                size: (pw, ph),
            },
        );
        self.make_current_id(&id)?;
        let _ = self.inst.swap_interval(self.display, 0);
        unsafe {
            (self.gl_draw_buffer)(GL_BACK);
        }
        self.viewport(pw, ph);
        Ok(())
    }

    pub fn make_current_id(&self, id: &ObjectId) -> Result<(), String> {
        let Some(es) = self.surfaces.get(id) else {
            return Err(String::from("sin surface EGL"));
        };
        self.inst
            .make_current(self.display, Some(es.surface), Some(es.surface), Some(self.context))
            .map_err(|e| format!("eglMakeCurrent: {:?}", e))
    }

    pub fn viewport(&self, w: i32, h: i32) {
        unsafe {
            (self.gl_viewport)(0, 0, w, h);
        }
    }

    pub fn swap(&self, id: &ObjectId) -> Result<(), String> {
        let Some(es) = self.surfaces.get(id) else {
            return Ok(());
        };
        self.inst
            .swap_buffers(self.display, es.surface)
            .map_err(|e| format!("eglSwapBuffers: {:?}", e))
    }

    /// Libera la surface EGL de una salida dejando el contexto sin surface.
    pub fn destroy_surface(&mut self, id: &ObjectId) {
        if self.terminated {
            return;
        }
        if let Some(es) = self.surfaces.remove(id) {
            let _ = self
                .inst
                .make_current(self.display, None, None, Some(self.context));
            let _ = self.inst.destroy_surface(self.display, es.surface);
            drop(es.window);
        }
    }

    pub fn destroy_all_surfaces(&mut self) {
        let ids: Vec<ObjectId> = self.surfaces.keys().cloned().collect();
        for id in ids {
            self.destroy_surface(&id);
        }
    }

    pub fn destroy_context(&mut self) {
        if self.terminated {
            return;
        }
        self.destroy_all_surfaces();
        self.terminated = true;
        let _ = self.inst.destroy_context(self.display, self.context);
        let _ = self.inst.terminate(self.display);
    }
}

impl Drop for Egl {
    fn drop(&mut self) {
        self.destroy_context();
    }
}
