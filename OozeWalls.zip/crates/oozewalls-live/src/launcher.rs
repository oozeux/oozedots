//! Launcher - argumentos de __live, señales, vigilante de arranque y limpieza

use crate::render;
use std::io::Write;
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Arc;
use std::time::Duration;

const READY_TIMEOUT: Duration = Duration::from_secs(15);

extern "C" fn on_signal(_sig: libc::c_int) {
    crate::request_stop();
}

fn install_signals() {
    let handler = on_signal as extern "C" fn(libc::c_int) as libc::sighandler_t;
    unsafe {
        libc::signal(libc::SIGTERM, handler);
        libc::signal(libc::SIGINT, handler);
        libc::signal(libc::SIGQUIT, handler);
    }
}

fn arg_or(args: &[String], idx: usize, default: &str) -> String {
    args.get(idx).cloned().unwrap_or_else(|| default.to_string())
}

fn watch_ready(ready: Arc<AtomicBool>) {
    std::thread::spawn(move || {
        std::thread::sleep(READY_TIMEOUT);
        if !ready.load(Ordering::SeqCst) {
            println!("err sin respuesta del compositor");
            let _ = std::io::stdout().flush();
            std::process::exit(1);
        }
    });
}

fn cleanup(output: &str) {
    let _ = std::fs::remove_file(oozewalls::ipc::socket_for(output));
    let pidfile = oozewalls::live::pidfile_for(output);
    if oozewalls::live::read_pid(&pidfile) == Some(std::process::id()) {
        let _ = std::fs::remove_file(pidfile);
    }
}

pub fn run(args: &[String]) -> i32 {
    let output = arg_or(args, 2, "");
    let file = arg_or(args, 3, "");
    let scaling = arg_or(args, 4, "fit");
    let mute = matches!(arg_or(args, 5, "0").as_str(), "1" | "true");
    let volume: u8 = args.get(6).and_then(|v| v.parse().ok()).unwrap_or(100);
    let hwdec = arg_or(args, 7, "auto-safe");
    let layer = arg_or(args, 8, "background");
    let tr_kind = arg_or(args, 9, "none");
    let tr_ms: u32 = args.get(10).and_then(|v| v.parse().ok()).unwrap_or(0);
    let old_image = args.get(11).cloned().filter(|v| v != "-" && !v.is_empty());
    let startup = old_image.map(|old| render::Startup {
        kind: tr_kind,
        ms: tr_ms,
        old,
    });

    if std::env::var_os("__NV_DISABLE_EXPLICIT_SYNC").is_none() {
        std::env::set_var("__NV_DISABLE_EXPLICIT_SYNC", "1");
    }

    crate::clear_stop();
    install_signals();

    let ready = Arc::new(AtomicBool::new(false));
    watch_ready(ready.clone());

    let rc = match render::run_inner(
        &output, &file, &scaling, mute, volume, &hwdec, &layer, &ready, startup,
    ) {
        Ok(()) => 0,
        Err(e) => {
            if !ready.load(Ordering::SeqCst) {
                println!("err {}", e);
                let _ = std::io::stdout().flush();
            } else {
                eprintln!("live: {}", e);
            }
            1
        }
    };
    cleanup(&output);
    rc
}
