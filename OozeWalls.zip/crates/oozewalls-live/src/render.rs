// SECCION: LIVE WAYLAND LAYER SHELL Y BUCLE DE RENDER
// IPC: interno del proceso __live (una o todas las salidas, un solo decodificador)
use std::ffi::c_void;
use std::io::Write;
use std::os::fd::AsRawFd;
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Arc;
use std::time::{Duration, Instant};

use wayland_client::globals::{registry_queue_init, GlobalList, GlobalListContents};
use wayland_client::protocol::{
    wl_callback, wl_compositor, wl_output, wl_region, wl_registry, wl_surface,
};
use wayland_client::{Connection, Dispatch, EventQueue, Proxy, QueueHandle};
use wayland_protocols_wlr::layer_shell::v1::client::{zwlr_layer_shell_v1, zwlr_layer_surface_v1};

use crate::egl::Egl;
use crate::fx::{self, Fx, Target};
use crate::gl;
use crate::mpv::{CoreEvent, Player};
use oozewalls::transition as tr;

const LOAD_TIMEOUT: Duration = Duration::from_secs(6);
const FRAME_GRACE: Duration = Duration::from_millis(120);
const FALLBACK_AFTER: Duration = Duration::from_secs(1);
const STAGE_CLOCK_PENDING: u8 = 4;
const STAGE_CLOCK_RUNNING: u8 = 5;

struct OutInfo {
    wl: wl_output::WlOutput,
    name: String,
    scale: i32,
    global: u32,
    removed: bool,
}

struct SurfInfo {
    out: usize,
    surface: wl_surface::WlSurface,
    layer: zwlr_layer_surface_v1::ZwlrLayerSurfaceV1,
    size: (u32, u32),
    scale: i32,
    configured: bool,
    frame_cb: Option<wl_callback::WlCallback>,
    redraw_needed: bool,
    closed: bool,
    drawn: bool,
    fx: Option<Target>,
    settled: bool,
    destroyed: bool,
}

struct Switch {
    kind: String,
    ms: u32,
    scaling: String,
    file: String,
}

pub struct Startup {
    pub kind: String,
    pub ms: u32,
    pub old: String,
}

#[derive(Clone, Copy, PartialEq)]
enum Phase {
    Idle,
    Loading,
    Running,
}

struct Fade {
    phase: Phase,
    kind: String,
    ms: u32,
    stage: u8,
    since: Instant,
    restart_at: Instant,
    started: Instant,
}

impl Fade {
    fn idle() -> Self {
        let now = Instant::now();
        Self {
            phase: Phase::Idle,
            kind: String::from("none"),
            ms: 0,
            stage: 0,
            since: now,
            restart_at: now,
            started: now,
        }
    }
}

struct State {
    compositor: wl_compositor::WlCompositor,
    shell: zwlr_layer_shell_v1::ZwlrLayerShellV1,
    outs: Vec<OutInfo>,
    target: String,
    wild: bool,
    surfs: Vec<SurfInfo>,
    egl: Option<Egl>,
    player: Option<Player>,
    wake_fd: i32,
    layer: zwlr_layer_shell_v1::Layer,
    ready: Arc<AtomicBool>,
    started: bool,
    quit: bool,
    error: Option<String>,
    fx: Option<Fx>,
    fade: Fade,
    pending: Option<Switch>,
    startup: Option<Startup>,
    setup_done: bool,
    cur_file: String,
    good_file: Option<String>,
    scaling: String,
}

impl State {
    fn fail(&mut self, e: String) {
        if self.error.is_none() {
            self.error = Some(e);
        }
        self.quit = true;
    }

    fn bind_output(
        &mut self,
        registry: &wl_registry::WlRegistry,
        name: u32,
        version: u32,
        qh: &QueueHandle<State>,
    ) -> usize {
        let idx = self.outs.len();
        let wl: wl_output::WlOutput = registry.bind(name, version.min(4), qh, idx);
        self.outs.push(OutInfo {
            wl,
            name: String::new(),
            scale: 1,
            global: name,
            removed: false,
        });
        idx
    }

    fn add_surface(&mut self, qh: &QueueHandle<State>, out: usize) -> usize {
        let idx = self.surfs.len();
        let surface = self.compositor.create_surface(qh, ());
        let layer = self.shell.get_layer_surface(
            &surface,
            Some(&self.outs[out].wl),
            self.layer,
            String::from("oozewalls"),
            qh,
            idx,
        );
        layer.set_anchor(
            zwlr_layer_surface_v1::Anchor::Top
                | zwlr_layer_surface_v1::Anchor::Bottom
                | zwlr_layer_surface_v1::Anchor::Left
                | zwlr_layer_surface_v1::Anchor::Right,
        );
        layer.set_size(0, 0);
        layer.set_exclusive_zone(-1);
        layer.set_keyboard_interactivity(zwlr_layer_surface_v1::KeyboardInteractivity::None);
        let region = self.compositor.create_region(qh, ());
        surface.set_input_region(Some(&region));
        region.destroy();
        surface.commit();
        self.surfs.push(SurfInfo {
            out,
            surface,
            layer,
            size: (0, 0),
            scale: self.outs[out].scale.max(1),
            configured: false,
            frame_cb: None,
            redraw_needed: false,
            closed: false,
            drawn: false,
            fx: None,
            settled: false,
            destroyed: false,
        });
        idx
    }

    fn close_surface(&mut self, idx: usize) {
        let Some(sid) = self.surfs.get(idx).map(|s| s.surface.id()) else {
            return;
        };
        if let Some(t) = self.surfs[idx].fx.take() {
            if let Some(fx) = self.fx.as_ref() {
                fx.free_target(t);
            }
        }
        if let Some(egl) = self.egl.as_mut() {
            egl.destroy_surface(&sid);
        }
        let s = &mut self.surfs[idx];
        s.closed = true;
        s.frame_cb = None;
        if !s.destroyed {
            s.destroyed = true;
            s.layer.destroy();
            s.surface.destroy();
        }
    }

    fn maybe_attach(&mut self, idx: usize, qh: &QueueHandle<State>) {
        if !self.setup_done {
            return;
        }
        let Some(o) = self.outs.get(idx) else {
            return;
        };
        if o.removed || o.name.is_empty() {
            return;
        }
        if !(self.wild || o.name == self.target) {
            return;
        }
        if self.surfs.iter().any(|s| s.out == idx && !s.closed) {
            return;
        }
        self.add_surface(qh, idx);
    }

    fn surf_ready(&self, idx: usize) -> bool {
        self.surfs
            .get(idx)
            .map(|s| s.configured && !s.closed && s.size.0 > 0 && s.size.1 > 0)
            .unwrap_or(false)
    }

    fn ensure_egl_surface(&mut self, idx: usize) -> Result<(), String> {
        if !self.surf_ready(idx) {
            return Ok(());
        }
        let s = &self.surfs[idx];
        let wl = s.surface.clone();
        let (w, h, scale) = (s.size.0, s.size.1, s.scale.max(1));
        let egl = self
            .egl
            .as_mut()
            .ok_or_else(|| String::from("EGL no inicializado"))?;
        egl.ensure_surface(&wl, w, h, scale)
    }

    fn request_render(&mut self, qh: &QueueHandle<State>, idx: usize) -> Result<(), String> {
        if !self.surf_ready(idx) {
            return Ok(());
        }
        if self.surfs[idx].frame_cb.is_some() {
            self.surfs[idx].redraw_needed = true;
            return Ok(());
        }
        self.render_frame(qh, idx)
    }

    fn request_all(&mut self, qh: &QueueHandle<State>) -> Result<(), String> {
        for idx in 0..self.surfs.len() {
            self.request_render(qh, idx)?;
        }
        Ok(())
    }

    fn render_frame(&mut self, qh: &QueueHandle<State>, idx: usize) -> Result<(), String> {
        if !self.surf_ready(idx) {
            return Ok(());
        }
        let (surface, id, pw, ph) = {
            let s = &self.surfs[idx];
            let scale = s.scale.max(1) as u32;
            (
                s.surface.clone(),
                s.surface.id(),
                (s.size.0 * scale) as i32,
                (s.size.1 * scale) as i32,
            )
        };
        if self.fade.phase == Phase::Loading && self.surfs[idx].fx.is_some() && self.surfs[idx].drawn {
            return Ok(());
        }

        {
            let egl = self
                .egl
                .as_mut()
                .ok_or_else(|| String::from("EGL no inicializado"))?;
            egl.make_current_id(&id)?;
            egl.viewport(pw, ph);
        }
        if self.startup.is_some() && !self.surfs[idx].drawn && self.surfs[idx].fx.is_none() {
            self.prepare_startup(idx, pw, ph);
        }

        let has_target = self.surfs[idx].fx.is_some();
        let holding = self.fade.phase == Phase::Loading && has_target;
        let running = self.fade.phase == Phase::Running && has_target;
        if holding {
            if let (Some(fx), Some(t)) = (self.fx.as_mut(), self.surfs[idx].fx.as_ref()) {
                fx.draw(0, t, &fx::old_only(), 0.0);
            }
        } else if running {
            self.draw_transition(idx, pw, ph)?;
        } else {
            let player = self
                .player
                .as_mut()
                .ok_or_else(|| String::from("mpv no inicializado"))?;
            let _ = player.update();
            player.render(pw, ph)?;
        }

        let cb = surface.frame(qh, idx);
        if let Some(s) = self.surfs.get_mut(idx) {
            s.frame_cb = Some(cb);
            s.redraw_needed = running && !s.settled;
            s.drawn = true;
        }

        {
            let egl = self
                .egl
                .as_mut()
                .ok_or_else(|| String::from("EGL no inicializado"))?;
            egl.swap(&id)?;
        }
        if let Some(player) = self.player.as_mut() {
            player.report_swap();
        }

        if running
            && self
                .surfs
                .iter()
                .all(|s| s.fx.is_none() || s.settled || s.closed)
        {
            self.end_fade();
        }

        if !self.started && self.surfs.iter().any(|s| s.drawn) {
            self.started = true;
            if !self.ready.load(Ordering::SeqCst) {
                self.ready.store(true, Ordering::SeqCst);
                println!("ready");
                let _ = std::io::stdout().flush();
            }
        }
        Ok(())
    }

    fn draw_transition(&mut self, idx: usize, pw: i32, ph: i32) -> Result<(), String> {
        {
            let player = self
                .player
                .as_mut()
                .ok_or_else(|| String::from("mpv no inicializado"))?;
            let fx = self
                .fx
                .as_mut()
                .ok_or_else(|| String::from("fx no inicializado"))?;
            let target = self.surfs[idx]
                .fx
                .as_mut()
                .ok_or_else(|| String::from("sin textura de transicion"))?;
            let _ = player.update();
            player.render_to(target.cur_fbo, pw, ph, gl::RGBA8)?;
            if !target.cols_ready {
                fx.probe_colors(target);
            }
        }
        if self.fade.stage == STAGE_CLOCK_PENDING {
            self.fade.started = Instant::now();
            self.fade.stage = STAGE_CLOCK_RUNNING;
        }
        let total = (self.fade.ms.max(1) as f32) / 1000.0;
        let t = (self.fade.started.elapsed().as_secs_f32() / total).clamp(0.0, 1.0);
        let e = tr::ease(t);
        let spec = fx::spec(&self.fade.kind, e, pw as usize, ph as usize);
        let fx = self
            .fx
            .as_mut()
            .ok_or_else(|| String::from("fx no inicializado"))?;
        let target = self.surfs[idx]
            .fx
            .as_ref()
            .ok_or_else(|| String::from("sin textura de transicion"))?;
        fx.draw(0, target, &spec, e);
        if t >= 1.0 {
            self.surfs[idx].settled = true;
        }
        Ok(())
    }

    fn alloc_target(&mut self, idx: usize, pw: i32, ph: i32) -> bool {
        let same = self.surfs[idx]
            .fx
            .as_ref()
            .map(|t| t.w == pw && t.h == ph)
            .unwrap_or(false);
        if same {
            return true;
        }
        let Some(fx) = self.fx.as_ref() else {
            return false;
        };
        if let Some(old) = self.surfs[idx].fx.take() {
            fx.free_target(old);
        }
        match fx.target(pw, ph) {
            Ok(t) => {
                self.surfs[idx].fx = Some(t);
                self.surfs[idx].settled = false;
                true
            }
            Err(e) => {
                eprintln!("live: transicion sin textura: {}", e);
                false
            }
        }
    }

    fn free_targets(&mut self) {
        let Some(fx) = self.fx.as_ref() else {
            return;
        };
        for s in self.surfs.iter_mut() {
            if let Some(t) = s.fx.take() {
                fx.free_target(t);
            }
            s.settled = false;
        }
    }

    fn end_fade(&mut self) {
        self.free_targets();
        self.startup = None;
        self.fade = Fade::idle();
    }

    fn prepare_startup(&mut self, idx: usize, pw: i32, ph: i32) {
        let Some(old) = self.startup.as_ref().map(|s| s.old.clone()) else {
            return;
        };
        let base = match oozewalls::layerbg::compose_base(&old, &self.scaling, pw as u32, ph as u32) {
            Ok(b) => b,
            Err(e) => {
                eprintln!("live: fondo anterior no disponible: {}", e);
                return;
            }
        };
        if !self.alloc_target(idx, pw, ph) {
            return;
        }
        if let (Some(fx), Some(t)) = (self.fx.as_ref(), self.surfs[idx].fx.as_ref()) {
            fx.upload_old_bgrx(t, &base);
        }
    }

    fn apply_scaling(&mut self, scaling: &str) {
        let Some(player) = self.player.as_mut() else {
            return;
        };
        let (pan, keep) = match scaling {
            "fill" => ("1.0", "yes"),
            "stretch" => ("0.0", "no"),
            _ => ("0.0", "yes"),
        };
        player.set_property("panscan", pan);
        player.set_property("keepaspect", keep);
        self.scaling = scaling.to_string();
    }

    fn snapshot(&mut self, idx: usize) -> bool {
        let (id, pw, ph) = {
            let s = &self.surfs[idx];
            let scale = s.scale.max(1) as u32;
            (
                s.surface.id(),
                (s.size.0 * scale) as i32,
                (s.size.1 * scale) as i32,
            )
        };
        let current = match self.egl.as_ref() {
            Some(egl) => egl.make_current_id(&id).is_ok(),
            None => false,
        };
        if !current || !self.alloc_target(idx, pw, ph) {
            return false;
        }
        let Some(player) = self.player.as_mut() else {
            return false;
        };
        let Some(target) = self.surfs[idx].fx.as_mut() else {
            return false;
        };
        let _ = player.update();
        target.cols_ready = false;
        match player.render_to(target.old_fbo, pw, ph, gl::RGBA8) {
            Ok(()) => {
                if let Some(fx) = self.fx.as_ref() {
                    fx.sync(target.old_fbo);
                }
                true
            }
            Err(e) => {
                eprintln!("live: instantanea fallida: {}", e);
                false
            }
        }
    }

    fn dump_frame(&mut self, path: &str) {
        if self.fade.phase != Phase::Idle || self.fx.is_none() {
            return;
        }
        let Some(idx) = (0..self.surfs.len()).find(|&i| self.surf_ready(i) && self.surfs[i].drawn) else {
            return;
        };
        let (id, pw, ph) = {
            let s = &self.surfs[idx];
            let scale = s.scale.max(1) as u32;
            (
                s.surface.id(),
                (s.size.0 * scale) as i32,
                (s.size.1 * scale) as i32,
            )
        };
        let current = match self.egl.as_ref() {
            Some(egl) => egl.make_current_id(&id).is_ok(),
            None => false,
        };
        if !current || !self.alloc_target(idx, pw, ph) {
            return;
        }
        let rendered = {
            let Some(player) = self.player.as_mut() else {
                return;
            };
            let Some(target) = self.surfs[idx].fx.as_ref() else {
                return;
            };
            let _ = player.update();
            player.render_to(target.cur_fbo, pw, ph, gl::RGBA8).map(|_| target.cur_fbo)
        };
        match rendered {
            Ok(fbo) => {
                if let Some(fx) = self.fx.as_ref() {
                    let px = fx.read_back(fbo, pw, ph);
                    if let Err(e) = oozewalls::live::write_snapshot(std::path::Path::new(path), &px, pw as u32, ph as u32) {
                        eprintln!("live: instantanea no guardada: {}", e);
                    }
                }
            }
            Err(e) => eprintln!("live: instantanea fallida: {}", e),
        }
        self.free_targets();
    }

    fn begin_switch(&mut self, sw: Switch) {
        if self.fade.phase != Phase::Idle {
            self.pending = Some(sw);
            return;
        }
        let wanted = sw.kind != "none" && tr::is_valid(&sw.kind) && sw.ms > 0;
        let idxs: Vec<usize> = (0..self.surfs.len())
            .filter(|&i| self.surf_ready(i) && self.surfs[i].drawn)
            .collect();
        let mut animate = wanted && self.fx.is_some() && !idxs.is_empty() && sw.file != self.cur_file;
        if animate {
            if let Some(player) = self.player.as_mut() {
                player.set_property("pause", "yes");
            }
            let mut shot = 0;
            for &i in &idxs {
                if self.snapshot(i) {
                    shot += 1;
                }
            }
            animate = shot > 0;
            if !animate {
                self.free_targets();
                if let Some(player) = self.player.as_mut() {
                    player.set_property("pause", "no");
                }
            }
        }
        self.apply_scaling(&sw.scaling);
        if let Some(player) = self.player.as_mut() {
            player.set_property("pause", "no");
            if let Err(e) = player.loadfile(&sw.file) {
                eprintln!("live: {}", e);
                self.free_targets();
                return;
            }
        }
        self.cur_file = sw.file;
        if animate {
            let now = Instant::now();
            self.fade = Fade {
                phase: Phase::Loading,
                kind: sw.kind,
                ms: tr::clamp_ms(sw.ms),
                stage: 0,
                since: now,
                restart_at: now,
                started: now,
            };
        }
    }

    fn handle_core(&mut self, ev: CoreEvent) -> Result<(), String> {
        match ev {
            CoreEvent::Shutdown => self.quit = true,
            CoreEvent::StartFile => {
                if self.fade.phase == Phase::Loading && self.fade.stage == 0 {
                    self.fade.stage = 1;
                    if let Some(p) = self.player.as_mut() {
                        p.clear_frame_flag();
                    }
                }
            }
            CoreEvent::FileLoaded => {
                self.good_file = Some(self.cur_file.clone());
                if self.fade.phase == Phase::Loading && self.fade.stage == 1 {
                    self.fade.stage = 2;
                }
            }
            CoreEvent::Restart => {
                if self.fade.phase == Phase::Loading && self.fade.stage == 2 {
                    self.fade.stage = 3;
                    self.fade.restart_at = Instant::now();
                }
            }
            CoreEvent::EndFile { error: Some(e) } => {
                eprintln!("live: {}", e);
                self.end_fade();
                match self.good_file.clone() {
                    Some(good) if good != self.cur_file => {
                        if let Some(p) = self.player.as_mut() {
                            p.loadfile(&good)?;
                        }
                        self.cur_file = good;
                    }
                    _ => return Err(format!("mpv: {}", e)),
                }
            }
            CoreEvent::Message(args) => {
                if args.len() == 2 && args[0] == "oozewalls-snap" {
                    self.dump_frame(&args[1]);
                } else if args.len() == 5 && args[0] == "oozewalls-switch" {
                    self.begin_switch(Switch {
                        kind: args[1].clone(),
                        ms: args[2].parse().unwrap_or(0),
                        scaling: args[3].clone(),
                        file: args[4].clone(),
                    });
                }
            }
            _ => {}
        }
        Ok(())
    }

    fn start_running(&mut self, qh: &QueueHandle<State>) -> Result<(), String> {
        self.fade.phase = Phase::Running;
        self.fade.stage = STAGE_CLOCK_PENDING;
        self.fade.started = Instant::now();
        for s in self.surfs.iter_mut() {
            s.settled = false;
            if let Some(t) = s.fx.as_mut() {
                t.cols_ready = false;
            }
        }
        self.startup = None;
        self.request_all(qh)
    }

    fn tick_fade(&mut self, qh: &QueueHandle<State>) -> Result<(), String> {
        match self.fade.phase {
            Phase::Loading => {
                let frame = self
                    .player
                    .as_ref()
                    .map(|p| p.frame_pending())
                    .unwrap_or(false);
                let surfaces_ready = self.startup.is_none()
                    || self.surfs.iter().any(|s| s.fx.is_some() && s.drawn);
                let loaded = (self.fade.stage >= 3
                    && (frame || self.fade.restart_at.elapsed() >= FRAME_GRACE))
                    || (self.fade.stage >= 2 && self.fade.since.elapsed() >= FALLBACK_AFTER);
                if loaded && surfaces_ready {
                    self.start_running(qh)?;
                } else if self.fade.since.elapsed() > LOAD_TIMEOUT {
                    self.end_fade();
                }
            }
            Phase::Running => {
                let limit = Duration::from_millis(self.fade.ms as u64) + Duration::from_secs(1);
                if self.fade.started.elapsed() > limit {
                    self.end_fade();
                }
            }
            Phase::Idle => {}
        }
        if self.fade.phase == Phase::Idle {
            if let Some(sw) = self.pending.take() {
                self.begin_switch(sw);
            }
        }
        Ok(())
    }
}

fn make_eventfd() -> Result<i32, String> {
    let fd = unsafe { libc::eventfd(0, libc::EFD_CLOEXEC | libc::EFD_NONBLOCK) };
    if fd < 0 {
        Err(format!(
            "eventfd: {}",
            std::io::Error::last_os_error()
        ))
    } else {
        Ok(fd)
    }
}

fn drain_eventfd(fd: i32) {
    if fd < 0 {
        return;
    }
    let mut buf = 0u64;
    unsafe {
        let _ = libc::read(fd, &mut buf as *mut u64 as *mut c_void, 8);
    }
}

fn build_options(
    output: &str,
    scaling: &str,
    mute: bool,
    volume: u8,
    hwdec: &str,
) -> Vec<(&'static str, String)> {
    let sock = oozewalls::ipc::socket_for(output);
    let mut opts = oozewalls::engine::build_opt_pairs(scaling, mute, volume, hwdec);
    opts.push(("vo", String::from("libmpv")));
    opts.push(("gpu-api", String::from("opengl")));
    opts.push(("idle", String::from("yes")));
    opts.push(("terminal", String::from("no")));
    opts.push(("input-terminal", String::from("no")));
    opts.push(("input-default-bindings", String::from("no")));
    opts.push(("msg-level", String::from("all=error")));
    opts.push(("input-ipc-server", sock.display().to_string()));
    opts
}

pub fn run_inner(
    output: &str,
    file: &str,
    scaling: &str,
    mute: bool,
    volume: u8,
    hwdec: &str,
    layer_name: &str,
    ready: &Arc<AtomicBool>,
    startup: Option<Startup>,
) -> Result<(), String> {
    if output.is_empty() {
        return Err(String::from("motor live: falta salida"));
    }
    if file.is_empty() {
        return Err(String::from("motor live: falta archivo"));
    }

    let conn = Connection::connect_to_env().map_err(|e| format!("wayland: {}", e))?;
    let (globals, mut queue) =
        registry_queue_init::<State>(&conn).map_err(|e| format!("registry: {}", e))?;
    let qh = queue.handle();

    let compositor: wl_compositor::WlCompositor = globals
        .bind(&qh, 3..=6, ())
        .map_err(|_| String::from("falta wl_compositor"))?;
    let shell: zwlr_layer_shell_v1::ZwlrLayerShellV1 = globals
        .bind(&qh, 1..=4, ())
        .map_err(|_| String::from("el compositor no ofrece wlr-layer-shell"))?;

    let layer = match layer_name {
        "bottom" => zwlr_layer_shell_v1::Layer::Bottom,
        "top" => zwlr_layer_shell_v1::Layer::Top,
        "overlay" => zwlr_layer_shell_v1::Layer::Overlay,
        _ => zwlr_layer_shell_v1::Layer::Background,
    };

    let wl_display = conn.backend().display_id().as_ptr() as *mut c_void;
    let wake_fd = make_eventfd()?;

    let mut state = State {
        compositor,
        shell,
        outs: Vec::new(),
        target: output.to_string(),
        wild: output == "*",
        surfs: Vec::new(),
        egl: None,
        player: None,
        wake_fd,
        layer,
        ready: ready.clone(),
        started: false,
        quit: false,
        error: None,
        fx: None,
        fade: Fade::idle(),
        pending: None,
        startup,
        setup_done: false,
        cur_file: file.to_string(),
        good_file: None,
        scaling: scaling.to_string(),
    };

    let result = setup(
        &mut state, &globals, &mut queue, &qh, wl_display, file, scaling, mute, volume, hwdec,
    )
    .and_then(|_| event_loop(&mut state, &conn, &mut queue, &qh));

    cleanup(&mut state);
    result
}

fn setup(
    state: &mut State,
    globals: &GlobalList,
    queue: &mut EventQueue<State>,
    qh: &QueueHandle<State>,
    wl_display: *mut c_void,
    file: &str,
    scaling: &str,
    mute: bool,
    volume: u8,
    hwdec: &str,
) -> Result<(), String> {
    let found: Vec<(u32, u32)> = globals.contents().with_list(|l| {
        l.iter()
            .filter(|g| g.interface == "wl_output")
            .map(|g| (g.name, g.version))
            .collect()
    });
    for (name, ver) in found {
        state.bind_output(globals.registry(), name, ver, qh);
    }
    queue
        .roundtrip(state)
        .map_err(|e| format!("roundtrip: {}", e))?;

    let targets: Vec<usize> = if state.wild {
        state
            .outs
            .iter()
            .enumerate()
            .filter(|(_, o)| !o.removed)
            .map(|(i, _)| i)
            .collect()
    } else {
        let idx = state
            .outs
            .iter()
            .position(|o| !o.removed && o.name == state.target)
            .ok_or_else(|| format!("salida {} no encontrada", state.target))?;
        vec![idx]
    };
    if targets.is_empty() {
        return Err(String::from("no hay salidas activas"));
    }

    let opts = build_options(&state.target, scaling, mute, volume, hwdec);
    let egl = Egl::new(wl_display)?;
    state.egl = Some(egl);
    match Fx::new() {
        Ok(fx) => state.fx = Some(fx),
        Err(e) => {
            eprintln!("live: transiciones nativas desactivadas: {}", e);
            state.startup = None;
        }
    }

    let player = Player::new(&opts, state.wake_fd)?;
    state.player = Some(player);
    if let Some(player) = state.player.as_mut() {
        player.create_render_context(wl_display)?;
        player.loadfile(file)?;
        player.wait_loaded(Duration::from_secs(10))?;
        player.set_update_callback();
    }
    state.good_file = Some(file.to_string());

    if let Some(st) = state.startup.as_ref() {
        if st.kind != "none" && st.ms > 0 && tr::is_valid(&st.kind) {
            let now = Instant::now();
            state.fade = Fade {
                phase: Phase::Loading,
                kind: st.kind.clone(),
                ms: tr::clamp_ms(st.ms),
                stage: 3,
                since: now,
                restart_at: now.checked_sub(FALLBACK_AFTER).unwrap_or(now),
                started: now,
            };
        } else {
            state.startup = None;
        }
    }

    for idx in targets {
        state.add_surface(qh, idx);
    }
    state.setup_done = true;
    Ok(())
}

fn event_loop(
    state: &mut State,
    conn: &Connection,
    queue: &mut EventQueue<State>,
    qh: &QueueHandle<State>,
) -> Result<(), String> {
    let wl_fd = conn.backend().poll_fd().as_raw_fd();
    while !state.quit {
        if crate::stop_requested() {
            break;
        }

        let guard = conn.prepare_read();
        let _ = conn.flush();

        let mut fds = [
            libc::pollfd {
                fd: wl_fd,
                events: libc::POLLIN,
                revents: 0,
            },
            libc::pollfd {
                fd: state.wake_fd,
                events: libc::POLLIN,
                revents: 0,
            },
        ];
        let rc = unsafe { libc::poll(fds.as_mut_ptr(), 2, 10) };
        if rc < 0 {
            let err = std::io::Error::last_os_error();
            if err.raw_os_error() == Some(libc::EINTR) {
                continue;
            }
            return Err(format!("poll: {}", err));
        }

        if fds[0].revents & (libc::POLLHUP | libc::POLLERR | libc::POLLNVAL) != 0 {
            drop(guard);
            return Err(String::from("conexion wayland cerrada"));
        }

        match guard {
            Some(g) => {
                if fds[0].revents & libc::POLLIN != 0 {
                    if let Err(e) = g.read() {
                        return Err(format!("wayland read: {}", e));
                    }
                } else {
                    drop(g);
                }
            }
            None => {
                let _ = conn.backend().dispatch_inner_queue();
            }
        }

        queue
            .dispatch_pending(state)
            .map_err(|e| format!("dispatch: {}", e))?;
        if let Some(e) = state.error.take() {
            return Err(e);
        }
        if state.quit {
            break;
        }

        let events = match state.player.as_mut() {
            Some(player) => player.poll_events(),
            None => Vec::new(),
        };
        for ev in events {
            state.handle_core(ev)?;
        }
        if state.quit {
            break;
        }
        state.tick_fade(qh)?;

        if fds[1].revents & libc::POLLIN != 0 {
            drain_eventfd(state.wake_fd);
            if let Some(player) = state.player.as_mut() {
                let _ = player.update();
            }
            state.request_all(qh)?;
        }
    }
    Ok(())
}

fn cleanup(state: &mut State) {
    state.free_targets();
    if let Some(egl) = state.egl.as_mut() {
        egl.destroy_all_surfaces();
    }
    if let Some(mut fx) = state.fx.take() {
        fx.destroy();
    }
    if let Some(player) = state.player.as_mut() {
        player.shutdown();
    }
    if let Some(egl) = state.egl.as_mut() {
        egl.destroy_context();
    }

    for s in state.surfs.drain(..) {
        if !s.destroyed {
            s.layer.destroy();
            s.surface.destroy();
        }
    }
    for out in &state.outs {
        if !out.removed {
            out.wl.release();
        }
    }
    if state.wake_fd >= 0 {
        unsafe {
            libc::close(state.wake_fd);
        }
        state.wake_fd = -1;
    }
}

// ---------------------------------------------------------- dispatch wayland

impl Dispatch<wl_registry::WlRegistry, GlobalListContents> for State {
    fn event(
        state: &mut Self,
        proxy: &wl_registry::WlRegistry,
        event: wl_registry::Event,
        _: &GlobalListContents,
        _: &Connection,
        qh: &QueueHandle<Self>,
    ) {
        match event {
            wl_registry::Event::Global {
                name,
                interface,
                version,
            } => {
                if interface == "wl_output" && state.setup_done {
                    state.bind_output(proxy, name, version, qh);
                }
            }
            wl_registry::Event::GlobalRemove { name } => {
                let Some(out_idx) = state
                    .outs
                    .iter()
                    .position(|o| o.global == name && !o.removed)
                else {
                    return;
                };
                state.outs[out_idx].removed = true;
                let surf_idxs: Vec<usize> = state
                    .surfs
                    .iter()
                    .enumerate()
                    .filter(|(_, s)| s.out == out_idx && !s.closed)
                    .map(|(i, _)| i)
                    .collect();
                for idx in surf_idxs {
                    state.close_surface(idx);
                }
                if state.surfs.iter().all(|s| s.closed) {
                    state.end_fade();
                }
            }
            _ => {}
        }
    }
}

impl Dispatch<wl_output::WlOutput, usize> for State {
    fn event(
        state: &mut Self,
        _: &wl_output::WlOutput,
        event: wl_output::Event,
        idx: &usize,
        _: &Connection,
        qh: &QueueHandle<Self>,
    ) {
        match event {
            wl_output::Event::Name { name } => {
                if let Some(o) = state.outs.get_mut(*idx) {
                    o.name = name;
                }
                state.maybe_attach(*idx, qh);
            }
            wl_output::Event::Scale { factor } => {
                let f = factor.max(1);
                if let Some(o) = state.outs.get_mut(*idx) {
                    o.scale = f;
                }
                let surf_idxs: Vec<usize> = state
                    .surfs
                    .iter()
                    .enumerate()
                    .filter(|(_, s)| s.out == *idx)
                    .map(|(i, _)| i)
                    .collect();
                for i in surf_idxs {
                    state.surfs[i].scale = f;
                    state.surfs[i].surface.set_buffer_scale(f);
                    if let Err(e) = state.ensure_egl_surface(i) {
                        state.fail(e);
                        return;
                    }
                    if let Err(e) = state.request_render(qh, i) {
                        state.fail(e);
                    }
                }
            }
            _ => {}
        }
    }
}

impl Dispatch<zwlr_layer_surface_v1::ZwlrLayerSurfaceV1, usize> for State {
    fn event(
        state: &mut Self,
        proxy: &zwlr_layer_surface_v1::ZwlrLayerSurfaceV1,
        event: zwlr_layer_surface_v1::Event,
        idx: &usize,
        _: &Connection,
        qh: &QueueHandle<Self>,
    ) {
        match event {
            zwlr_layer_surface_v1::Event::Configure {
                serial,
                width,
                height,
            } => {
                proxy.ack_configure(serial);
                if let Some(s) = state.surfs.get_mut(*idx) {
                    s.size = (width, height);
                    s.configured = true;
                    s.surface.set_buffer_scale(s.scale.max(1));
                }
                if let Err(e) = state.ensure_egl_surface(*idx) {
                    state.fail(e);
                    return;
                }
                if let Err(e) = state.request_render(qh, *idx) {
                    state.fail(e);
                }
            }
            zwlr_layer_surface_v1::Event::Closed => {
                state.close_surface(*idx);
            }
            _ => {}
        }
    }
}

impl Dispatch<wl_callback::WlCallback, usize> for State {
    fn event(
        state: &mut Self,
        _proxy: &wl_callback::WlCallback,
        event: wl_callback::Event,
        idx: &usize,
        _: &Connection,
        qh: &QueueHandle<Self>,
    ) {
        if let wl_callback::Event::Done { .. } = event {
            let redraw = if let Some(s) = state.surfs.get_mut(*idx) {
                let redraw = s.redraw_needed;
                s.redraw_needed = false;
                s.frame_cb = None;
                redraw
            } else {
                false
            };
            if redraw {
                if let Err(e) = state.render_frame(qh, *idx) {
                    state.fail(e);
                }
            }
        }
    }
}

impl Dispatch<wl_compositor::WlCompositor, ()> for State {
    fn event(
        _: &mut Self,
        _: &wl_compositor::WlCompositor,
        _: wl_compositor::Event,
        _: &(),
        _: &Connection,
        _: &QueueHandle<Self>,
    ) {
    }
}

impl Dispatch<wl_surface::WlSurface, ()> for State {
    fn event(
        _: &mut Self,
        _: &wl_surface::WlSurface,
        _: wl_surface::Event,
        _: &(),
        _: &Connection,
        _: &QueueHandle<Self>,
    ) {
    }
}

impl Dispatch<wl_region::WlRegion, ()> for State {
    fn event(
        _: &mut Self,
        _: &wl_region::WlRegion,
        _: wl_region::Event,
        _: &(),
        _: &Connection,
        _: &QueueHandle<Self>,
    ) {
    }
}

impl Dispatch<zwlr_layer_shell_v1::ZwlrLayerShellV1, ()> for State {
    fn event(
        _: &mut Self,
        _: &zwlr_layer_shell_v1::ZwlrLayerShellV1,
        _: zwlr_layer_shell_v1::Event,
        _: &(),
        _: &Connection,
        _: &QueueHandle<Self>,
    ) {
    }
}
