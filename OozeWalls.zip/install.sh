
# SECCION: OOZEWALLS INSTALL
# IPC: build install launcher libs
set -eu
ROOT="$(cd "$(dirname "$0")" && pwd)"
BIN_DIR="$HOME/.local/bin"
APP_DIR="$HOME/.local/share/applications"
ICON_DIR="$HOME/.local/share/icons/hicolor/scalable/apps"

IS_NIX=false
if [ -d /nix/store ]; then
  IS_NIX=true
fi

# SECCION: LIBS NIXOS
BASE_LIBS="libwayland-client.so.0 libwayland-cursor.so.0 libxkbcommon.so.0 libX11.so.6 libXcursor.so.1 libXrandr.so.2 libXi.so.6 libGL.so.1 libEGL.so.1 libfontconfig.so.1 libfreetype.so.6"
LIVE_LIBS="libwayland-client.so.0 libwayland-egl.so.1 libGL.so.1 libEGL.so.1 libmpv.so.2 libmpv.so"

lib_dirs() {
  out=""
  for lib in $1; do
    hit="$(find /nix/store -maxdepth 4 -name "$lib" 2>/dev/null | grep -v lib32 | head -1)"
    if [ -n "$hit" ]; then
      out="$out:$(dirname "$hit")"
    fi
  done
  echo "$out" | tr ':' '\n' | grep -v '^$' | sort -u | tr '\n' ':' | sed 's/:$//'
}

link_dir() {
  hit="$(find /nix/store -maxdepth 4 \( -name libmpv.so -o -name libmpv.so.2 \) 2>/dev/null | grep -v lib32 | head -1)"
  if [ -n "$hit" ]; then
    d="$ROOT/target/libmpv-link"
    mkdir -p "$d"
    ln -sf "$hit" "$d/libmpv.so"
    echo "$d"
  fi
}

write_wrapper() {
  name="$1"
  libs="$2"
  cat > "$BIN_DIR/$name" <<WRAP
#!/bin/sh
EXTRA="$libs"
if [ ! -d "\$(echo "\$EXTRA" | cut -d: -f1)" ]; then
  EXTRA=""
fi
if [ -d /run/opengl-driver/lib ]; then
  EXTRA="/run/opengl-driver/lib:\$EXTRA"
fi
LD_LIBRARY_PATH="\$EXTRA:\$LD_LIBRARY_PATH" exec "$BIN_DIR/$name-bin" "\$@"
WRAP
  chmod 755 "$BIN_DIR/$name"
}

# SECCION: COMPILACION
if $IS_NIX; then
  LINK="$(link_dir)"
  if [ -n "$LINK" ]; then
    export LIBRARY_PATH="$LINK:${LIBRARY_PATH:-}"
  fi
fi

echo "OOZEWALLS compilando release"
cargo build --release --workspace --manifest-path "$ROOT/Cargo.toml"

mkdir -p "$BIN_DIR" "$APP_DIR" "$ICON_DIR"

# SECCION: BINARIOS
if $IS_NIX; then
  install -m 755 "$ROOT/target/release/oozewalls" "$BIN_DIR/oozewalls-bin"
  install -m 755 "$ROOT/target/release/oozewalls-gui" "$BIN_DIR/oozewalls-gui-bin"
  install -m 755 "$ROOT/target/release/oozewalls-live" "$BIN_DIR/oozewalls-live-bin"

  echo "OOZEWALLS resolviendo librerias"
  BASE="$(lib_dirs "$BASE_LIBS")"
  LIVE="$(lib_dirs "$LIVE_LIBS")"

  write_wrapper oozewalls "$BASE"
  write_wrapper oozewalls-gui "$BASE"
  write_wrapper oozewalls-live "$LIVE"
else
  for name in oozewalls oozewalls-gui oozewalls-live; do
    rm -f "$BIN_DIR/$name" "$BIN_DIR/$name-bin"
    install -m 755 "$ROOT/target/release/$name" "$BIN_DIR/$name"
  done
fi

# SECCION: LANZADOR
install -m 644 "$ROOT/oozewalls.svg" "$ICON_DIR/oozewalls.svg"
sed "s|^Exec=.*|Exec=$BIN_DIR/oozewalls-gui|; s|^Icon=.*|Icon=$ICON_DIR/oozewalls.svg|" \
  "$ROOT/oozewalls-gui.desktop" > "$APP_DIR/oozewalls-gui.desktop"
update-desktop-database "$HOME/.local/share/applications" 2>/dev/null || true

echo "OOZEWALLS listo busca OozeWalls en el launcher"
