# OozeWalls

Gestor de wallpapers estáticos y en video (live) para compositores Wayland. Incluye CLI, app gráfica y un motor live propio con transiciones aceleradas por GPU.

## Características

- Wallpapers estáticos y live (video) por monitor o en todos a la vez (`*`).
- Motor live propio basado en `libmpv`, EGL y `wlr-layer-shell`; `mpvpaper` queda solo como respaldo.
- 24 transiciones al cambiar de fondo, también entre videos (live → live).
- Biblioteca por carpetas con miniaturas, favoritos y selector de interfaz (español / inglés).
- Paleta de colores automática con `matugen`.
- Sin demonio residente: cada comando lee la configuración y habla con el proceso que pinta.
- Pausa, volumen, mute, escalado (`fit`, `fill`, `stretch`) y `hwdec` configurables.

## Requisitos

- Compositor Wayland con soporte `wlr-layer-shell` (Hyprland, Sway, niri, etc.).
- Rust (edición 2021), `libmpv`, `libEGL`, `libGL` y `libwayland-egl`.
- Opcionales: `matugen` (paleta), `awww`/`swww` (estáticos), `mpvpaper` (respaldo).

## Instalación

### Arch Linux

No hace falta Nix. Instala lo necesario para compilar y ejecutar:

```sh
sudo pacman -S --needed rust pkgconf mpv wayland libxkbcommon mesa libglvnd \
  fontconfig freetype2 libx11 libxcursor libxrandr libxi \
  xdg-desktop-portal xdg-desktop-portal-gtk
./install.sh
```

Compila el workspace, instala los binarios en `~/.local/bin` y registra la app en el launcher. Los binarios se instalan directos, sin envoltorios.

### NixOS

Para `cargo build` manual, entra antes con `nix-shell` (usa `shell.nix`). `install.sh` detecta `/nix/store`, resuelve las librerías ahí e instala envoltorios (`oozewalls`, `oozewalls-gui`, `oozewalls-live`) que fijan `LD_LIBRARY_PATH`. También hay `package.nix` y `hm-module.nix` para Home Manager (`programs.oozewalls.autostart = true` reaplica el fondo al iniciar sesión).

### Con los dotfiles de OozeDots

Este código viaja como `OozeWalls.zip` en la raíz de los dotfiles. `install-oozedots.sh` y `update-oozedots.sh` lo extraen en `~/.local/share/oozewalls/src` y ejecutan `install.sh` desde ahí.

## Uso

```sh
oozewalls apply ~/Videos/wall.mp4 --output "*"
oozewalls next | prev | stop
oozewalls pause | resume | toggle
oozewalls status --json
oozewalls list --json
oozewalls browse --path ~/Videos/Wallpapers --json
oozewalls dirs-add ~/Pictures/Wallpapers
oozewalls set transition wave-left
oozewalls set transition_ms 600
oozewalls restore
oozewalls-gui
```

`oozewalls --help` muestra todos los comandos. Las transiciones disponibles se listan con `oozewalls transitions`.

La configuración se guarda en `~/.config/oozewalls/config.json`.

## Cómo funciona

| Tipo de fondo | Quién pinta | Detalle |
|---|---|---|
| Video | `oozewalls-live` | Un proceso por salida (o uno para `*`). Cambiar de video reutiliza el mismo proceso por IPC. |
| Imagen | Capa propia (`__bg`) o `awww` | Proceso residente con superficie fija; sin parpadeo al cambiar. |

- **Transiciones:** viven dentro del proceso que pinta. En live se calculan en GPU mezclando una instantánea del frame anterior con el video nuevo.
- **IPC:** socket JSON estilo mpv en `$XDG_RUNTIME_DIR/oozewalls/` (`mpv_<salida>.sock`).
- **Respaldo:** si `oozewalls-live` falla o no está, se usa `mpvpaper`.

## Estructura

Workspace de Cargo con dos crates:

| Crate | Binarios | Rol |
|---|---|---|
| `crates/oozewalls` | `oozewalls`, `oozewalls-gui` | CLI, GUI (egui), capa estática, IPC y gestión de procesos |
| `crates/oozewalls-live` | `oozewalls-live` | Motor live: libmpv + EGL + layer-shell + transiciones GPU |

`oozewalls-live` depende de `oozewalls`, nunca al revés. Ambos binarios deben instalarse juntos.

## Documentación

- `docs/ARCH.md`: arquitectura general.
- `docs/ESTRUCTURA.md`: módulos, flujo de `apply` y contrato entre binarios.
- `docs/LIVE-ENGINE.md`: motor live y su máquina de fases.
- `docs/TRANSICIONES.md`: catálogo y funcionamiento de las transiciones.

## Licencia

GPL-3.0-or-later.