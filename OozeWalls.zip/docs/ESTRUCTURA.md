# Estructura del proyecto

Workspace de Cargo con dos crates y un solo `Cargo.lock`.

| Crate | Binarios | Rol | Render |
|---|---|---|---|
| `crates/oozewalls` | `oozewalls`, `oozewalls-gui` | CLI, GUI, estáticos (`__bg`), IPC, gestión de procesos live | sin `libmpv` ni EGL |
| `crates/oozewalls-live` | `oozewalls-live` | motor live: libmpv + wayland-egl + layer-shell | `rsmpv-sys`, `wayland-egl`, `khronos-egl` |

`oozewalls-live` depende de `oozewalls` como biblioteca. Nunca al revés. Los dos binarios se instalan y actualizan juntos; si falta `oozewalls-live`, `live::spawn` falla y `engine` cae a `mpvpaper`.

## Flujo de un `apply` de video

1. `cli::run` → `actions::apply_file_opts` → `engine::apply_video`.
2. Con proceso live vivo para la salida: `live::switch` envía `oozewalls-switch` por el socket (mismo PID).
3. Con `mpvpaper` vivo: rampas de `transition` + `ipc::loadfile`.
4. Sin nada: `live::spawn` lanza `oozewalls-live __live ...` y espera `ready`. Si falla, `mpvpaper`.

## Contrato entre binarios

Argumentos (`argv[1] = __live`): 2 salida (`*` = todas), 3 archivo, 4 scaling, 5 mute `1|0`, 6 volumen, 7 hwdec, 8 capa, 9 transición, 10 ms, 11 imagen anterior o `-`.

Respuesta por stdout, una línea: `ready` o `err <motivo>`.

Runtime en `$XDG_RUNTIME_DIR/oozewalls`: `<salida>.sock` (lo crea el motor) y `live_<salida>.livepid` (lo crea el padre; `live::pids` lo valida contra `/proc/<pid>/cmdline`).

## Crate `oozewalls`

| Archivo | Bloque |
|---|---|
| `cli.rs`, `main.rs` | comandos y flags |
| `engine.rs` | enrutado video/estático, mpvpaper (fallback), pausa/volumen, awww/swww |
| `live.rs` | lado padre: `live_bin`, `pids`, `spawn`, `switch`, `stop_*` |
| `layerbg.rs` | capa propia estática (`__bg`); `compose_base` también lo usa el motor live |
| `transition.rs` | catálogo, rampas de video y frames por CPU; helpers públicos que usa `fx.rs` |
| `ipc.rs`, `config.rs`, `actions.rs`, `scan.rs`, `thumbs.rs`, `matugen.rs`, `outputs.rs` | IPC mpv, config, acciones, biblioteca, miniaturas, paleta, compositor |
| `bin/oozewalls-gui.rs` | GUI egui |

## Crate `oozewalls-live`

| Archivo | Bloque |
|---|---|
| `main.rs`, `launcher.rs` | argumentos, señales, vigilante de 15 s, limpieza de socket y pidfile |
| `render.rs` | layer-shell por salida, bucle de render, IPC estilo mpv, hotplug |
| `egl.rs`, `gl.rs` | contexto EGL y carga de funciones GL |
| `mpv.rs` | `libmpv` con API de render OpenGL |
| `fx.rs` | transiciones en GPU (test `gpu_matches_cpu_for_every_kind`) |

## Instalación

- `install.sh`: compila el workspace e instala los tres binarios; solo el wrapper de `oozewalls-live` lleva `libmpv`.
- `package.nix`: dos derivaciones (`oozewalls`, `oozewalls-live`); `hm-module.nix` usa `.oozewalls`.

## Compilar en NixOS

`oozewalls-live` enlaza `-lmpv`. Con `./install.sh` se resuelve solo (symlink `libmpv.so` en `target/libmpv-link` vía `LIBRARY_PATH`). Para `cargo build` manual, entrar antes con `nix-shell` (usa `shell.nix`).
