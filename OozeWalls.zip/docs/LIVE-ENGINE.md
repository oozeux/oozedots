# OozeWalls — motor live propio (PoC)

Estado: **PoC validado** en Hyprland 0.56 con una salida explícita, con `*` y
con varias salidas a la vez (escala 1 y 2). Objetivo: dejar de depender de
`mpvpaper` como aplicación externa, manteniendo `libmpv` como librería de
reproducción.

## Qué es

El motor live es el binario `oozewalls-live` (crate `crates/oozewalls-live`). El binario `oozewalls` no enlaza `libmpv`: cada `apply` de video lanza el hijo `oozewalls-live __live ...` que pinta con:

- Wayland `wlr-layer-shell` en la capa `background`.
- EGL + OpenGL (`libEGL`, `libGL`, `libwayland-egl`).
- `libmpv` con la API de render OpenGL.

Una salida explícita usa un proceso con una sola surface. `--output '*'` usa
**un único proceso** que crea una surface por cada `wl_output` activo, pero
mantiene un solo decodificador y un solo contexto EGL compartido. El control
sigue siendo el mismo de siempre: un socket JSON de mpv por salida
(`mpv_<salida>.sock`, y `mpv_all.sock` para `*`).

## Flujo

```
oozewalls apply video.mp4 --output HDMI-A-1
  -> engine::apply_video_inner
  -> live::spawn (hijo oculto "__live")
  -> handshake "ready" por stdout (timeout 20 s, watchdog interno 15 s)
  -> pidfile live_HDMI-A-1.livepid
```

Con `--output '*'` el pidfile es `live_all.livepid` y las salidas se enumeran
con `wl_output` del registry de Wayland (no se consulta `hyprctl` ni `niri`).

- Si el motor nativo falla, se avisa por stderr y se usa `mpvpaper` como
  **fallback temporal**.
- Cambiar de video reutiliza el mismo proceso vía IPC: `loadfile ... replace`.
  Mismo PID, sin reiniciar el motor.
- `pause` / `resume` usan `set_property pause` (y `SIGSTOP`/`SIGCONT` para los
  procesos `mpvpaper` heredados).
- `stop` envía `SIGTERM`, espera el cierre ordenado y limpia socket y pidfile.
  Si el motor recibe `SIGTERM` directamente, también limpia sus artefactos.
- Con `*` o con salida explícita, si una salida desaparece se cierra solo esa
  surface y el proceso sigue vivo. Si la salida vuelve (mismo nombre o nueva), recibe
  surface y vuelve a pintar sin reaplicar nada.

## Artefactos

| Ruta | Qué es |
|---|---|
| `$XDG_RUNTIME_DIR/oozewalls/mpv_<salida>.sock` | socket de control mpv (IPC) |
| `$XDG_RUNTIME_DIR/oozewalls/live_<salida>.livepid` | PID del motor live |
| `$XDG_RUNTIME_DIR/oozewalls/bg_<salida>.bgpid` / `.bgsock` | capa estática (sin cambios) |

No queda ningún proceso residente extra: el motor es el propio reproductor.

## Dependencias y build

Crates añadidos: `rsmpv-sys`, `wayland-egl`, `khronos-egl` (feature `dynamic`).

```sh
PKG_CONFIG_PATH=/etc/profiles/per-user/$USER/lib/pkgconfig cargo build --release
```

`package.nix` e `install.sh` ya incluyen `libmpv` en `LD_LIBRARY_PATH` y el
binario `oozewalls` queda envuelto igual que la GUI.

## Limitaciones del PoC

- Escala entera (`wl_output.scale`). La escala fraccionaria la upscala el
  compositor (se ve algo más suave, funciona).
- Con EGL de NVIDIA se desactiva el *explicit sync* solo en el proceso live
  (`__NV_DISABLE_EXPLICIT_SYNC=1`, respetando el valor si ya estaba definido):
  el backend headless de Hyprland deja la superficie en negro con explicit sync.
  Para un fondo animado el sync implícito es suficiente.
- El fallback a `mpvpaper` sigue presente. Se puede retirar cuando el motor
  cubra todas las pruebas de hardware.

## Pruebas realizadas

Hardware: Hyprland 0.56, `HDMI-A-1` 1920x1080@74.97, escala 1; salida virtual
`HEADLESS-1` 1920x1080, escala 2.

- `apply` de video: se ve correctamente (verificado con `grim`).
- `status --json` reporta `live_pids`, socket y `ram_mb`.
- `pause`, `resume`, `stop` y `stop --output '*'`.
- Cambio de video con el mismo PID vía IPC.
- `SIGTERM` directo al motor: cierra y limpia socket/pidfile.
- `hwdec=no` y `hwdec=auto-safe`.
- Ciclo video → estático → video en la misma salida.
- `*` nativo: un proceso, `mpv_all.sock`, pinta en todas las salidas.
- Multi-salida con escalas distintas (HDMI escala 1 + HEADLESS escala 2):
  ambas pintan, CPU ~14 % con dos 1080p.
- Quitar una salida con `*` corriendo: se cierra esa surface y el resto sigue.
- Casos inválidos: salida inexistente y archivo corrupto devuelven error y no
  dejan procesos, sockets ni pidfiles.
- Tras cada prueba: sin procesos `__live`/`mpvpaper` residuales.

## Diagnóstico

```sh
oozewalls status --json | jq '{live_pids, sockets, ram_mb}'
```

Para ver errores del motor en primer plano:

```sh
oozewalls __live HDMI-A-1 /ruta/video.mp4 fill 1 100 auto-safe background
```

Imprime `ready` al pintar el primer frame. Los errores de arranque salen por
stdout con prefijo `err`; los de ejecución, por stderr.

## Transiciones nativas

Las transiciones viven dentro del proceso `__live` (`crates/oozewalls-live/src/fx.rs`, `gl.rs`).
El CLI ya no anima nada: envía un único `script-message oozewalls-switch <tipo> <ms> <scaling> <archivo>`
por el socket de mpv y vuelve de inmediato.

Fases del motor al recibir el mensaje:

1. `Idle`: se re-renderiza el frame actual de mpv en una textura (`old`).
2. `Loading`: se aplica el escalado y `loadfile`. La superficie conserva el último buffer presentado.
   Se avanza con los eventos `start-file`, `file-loaded` y `playback-restart` del archivo nuevo.
3. `Running`: mpv pinta el video nuevo en otra textura (`cur`) y un shader mezcla `old`/`cur`
   con el mismo catálogo y las mismas fórmulas que `transition::frame_into`. El tiempo es de pared
   y la fase termina siempre por reloj. El reloj arranca justo después del primer render del video
   nuevo y de `probe_colors` (`STAGE_CLOCK_PENDING` → `STAGE_CLOCK_RUNNING`), porque ese primer render
   (compilación de shaders, interop de hwdec) y las lecturas de color bloquean varias decenas o
   cientos de ms; si el reloj corriera antes, esa pausa se descontaría de la animación y el frame
   anterior apenas se vería.
4. De vuelta a `Idle`: se liberan las texturas y mpv pinta directo al framebuffer (costo cero).

Si llega otro cambio durante una transición, queda uno pendiente (solo el último). Estático → live:
`__live` recibe la imagen anterior (`previous_image`) y anima desde ella.

Cuando el motor live va a ser reemplazado (live → estático, o live → live con un proceso nuevo, por ejemplo
cambio entre `*` y una salida), el padre pide antes una instantánea del frame actual:
`script-message oozewalls-snap <ruta>` (`live::snapshot`). El motor renderiza el video a una textura al tamaño
físico de la superficie y guarda un PNG en `$XDG_RUNTIME_DIR/oozewalls/snap_<socket>.png` (`dump_frame`,
`live::write_snapshot`). Esa imagen es la base "vieja" de la transición y el video se pausa para que el
último frame coincida con ella. Si el motor está en medio de otra transición, no hay GLSL 3.30 o no responde
en 1.5 s, se usa la miniatura como antes. Con `*` se toma la primera superficie dibujada.

Live → live con el mismo proceso: el video actual se pausa y se toma su frame (`begin_switch`); si no se logra ningún frame
se reanuda y el cambio es directo. El video nuevo se carga ya en reproducción (`pause no` antes de `loadfile`), así que al
terminar la transición queda en play sin salto. Si no llega `playback-restart` en 1 s tras `file-loaded`, la transición
arranca igualmente (`FALLBACK_AFTER`).

La copia del frame viejo se fuerza a terminar en la GPU (`Fx::sync`, lectura de 1 px) antes del `loadfile`; sin eso mpv
podía reciclar el frame viejo y la textura "vieja" quedaba con el contenido del video nuevo, sin cambio visible.

El video anterior queda congelado durante la animación (es una instantánea). Si el contexto GL no
ofrece GLSL 3.30, las transiciones se desactivan y el cambio es directo.

## Loop

El motor no implementa el bucle: lo hace mpv con `loop-file=inf` (`engine::build_opt_pairs`, opción fija al crear el `Player`). Al llegar al final del archivo, mpv vuelve al inicio sin emitir `end-file` de error, así que el motor no se entera ni reinicia nada. Las imágenes usan `image-display-duration=inf`.

## Bug de pantalla vacía (causas corregidas)

| Causa | Efecto | Corrección |
|---|---|---|
| Rampa de `brightness`/`video-pan` hecha desde el CLI (≈60 conexiones IPC) | Si el CLI moría o se cancelaba entre salida y entrada, el video quedaba en `-100` o fuera de cuadro: pantalla negra | La animación vive en el motor y termina por reloj. La ruta `mpvpaper` resetea al inicio |
| Archivo que falla al cargar tras `loadfile` | El motor salía y la salida quedaba sin fondo | Se recarga el último archivo bueno; solo sale si falla ese mismo |
| Baja de salida (monitor DP que duerme/despierta) | El motor terminaba y no volvía | Hotplug: la surface se cierra y se recrea cuando la salida regresa |
| Con motor nativo, `video_in` forzaba negro al arrancar | Destello a negro | Ya no se usa con el motor nativo |

## Puntos a vigilar

- `fx::spec` y el GLSL de `fx.rs` duplican las fórmulas de `transition::frame_*`. Cualquier cambio en
  una tabla o constante de `transition.rs` debe verificarse con `cargo test gpu_matches_cpu_for_every_kind`
  (compara los 24 tipos contra la versión CPU; se omite sin EGL).
- `render_frame` y `begin_switch` en `live/render.rs`: concentran la máquina de fases. Un cambio en el orden
  `surface.frame` → `swap` o en cuándo se libera el `Target` rompe el ritmo de la animación.
- `Player::render_to` usa `flip_y=1` para texturas igual que para el framebuffer de ventana; las texturas
  quedan en orientación GL (fila 0 abajo). Cambiarlo invierte la imagen en `fx.rs`.
- `LOAD_TIMEOUT` (6 s) en `render.rs`: si hardware lento tarda más en el primer frame, se aborta la animación
  (el video igual se muestra).
- Un proceso `__live` ya no termina al perder todas las salidas; `stop` sigue siendo la forma de cerrarlo.
- `live::spawn` mata el motor anterior antes de lanzar el nuevo: es intencional, el viejo borra el socket al
  salir y pisaría el del nuevo.

## Próximos pasos

1. Escala fraccionaria (`wp_fractional_scale_v1`).
2. Retirar el fallback y `mpvpaper` del packaging.
