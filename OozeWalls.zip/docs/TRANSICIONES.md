# Transiciones de fondo

Documento de referencia de las animaciones al cambiar de wallpaper.
Código: `src/transition.rs` (catálogo, frames, awww, mpv), `src/layerbg.rs` (capa propia),
`src/engine.rs` (enrutado por backend), `src/actions.rs` y `src/cli.rs` (opciones).

## Configuración

| Clave | Valores | Por defecto |
|---|---|---|
| `transition` | `wave-left` `wave-right` `wave-up` `wave-down` `slime` `blob` `drip` `rings` `bars-left` `bars-right` `diagonal-left` `diagonal-right` `fade` `slide-left` `slide-right` `slide-up` `slide-down` `zoom` `wipe-left` `wipe-right` `wipe-up` `wipe-down` `circle` `blinds` `none` `random` | `fade` |
| `transition_ms` | 100 – 3000 | 600 |

Los nombres con dirección indican el **borde por donde entra** el fondo nuevo.

Orden del catálogo (`KINDS`, también el de la GUI y `oozewalls transitions`): primero las de forma, luego las que animan en video con mpv (`fade`, `slide-*`, `zoom`), después `wipe-*`, `circle` y `blinds`, y al final `none` y `random`.

## Transiciones por capas

`wave-*`, `slime`, `blob`, `drip`, `rings`, `bars-*` y `diagonal-*` comparten el motor `frame_layers` de `src/transition.rs`.

Funcionamiento:

- Cada tipo define un campo `s(x, y)` entre 0 y 1 que indica en qué momento llega el frente a ese píxel.
- Tres capas de color con frentes escalonados (oscura, media, clara) cruzan la pantalla antes de que entre la imagen nueva. Los bordes se suavizan con un degradado corto.
- El color base sale del promedio de la imagen nueva, con la saturación aumentada.
- Cada frame se reparte entre hilos por filas (hasta 8).

| Tipo | Campo |
|---|---|
| `wave-left/right/up/down` | Ola que avanza desde ese borde, con dos senos que se desplazan |
| `slime` | Masa que sube desde abajo con protuberancias gaussianas animadas |
| `blob` | Gota de contorno ondulado (tabla por ángulo) y 6 salpicaduras |
| `drip` | Cortina superior con goteos de largo y ancho variables |
| `rings` | Distancia al centro |
| `bars-left/right` | 12 barras verticales con barrido alterno arriba/abajo, desde ese lado |
| `diagonal-left/right` | 7 franjas diagonales con deslizamiento alterno, desde ese lado |

Enrutado: solo se dibujan con la capa propia. `engine::apply_static` resuelve `random` primero y, si el tipo es por capas, omite awww; solo recurre a awww (como `fade`) si la capa propia falla. `random` en awww nunca elige estos tipos. Con mpvpaper caen al desvanecido por `brightness`; con el motor propio se dibujan completas.

## Cómo se anima según el backend

### Imágenes con la capa propia (`static_backend builtin`)

El proceso `__bg` es **residente**: mantiene la misma superficie de capa y recibe los cambios por un socket (`bg_<salida>.bgsock`, comando `SET <tipo> <ms> <scaling> <archivo>`). No se crea ni destruye ninguna superficie al cambiar de fondo. Esto evita las animaciones de apertura/cierre de capas del compositor (por ejemplo Hyprland), que se sumaban a la propia y producían parpadeo.

Cambio con proceso residente:

1. El padre (`spawn`) conecta al socket y envía `SET`.
2. El hijo decodifica en paralelo la imagen anterior (la que está mostrando) y la nueva, responde `ok` y el padre regresa.
3. El hijo anima sobre la misma superficie (`frame_into`, tiempo real, ~60 fps, easing cúbico) y deja el frame final como buffer estático.
4. Si llega otro cambio mientras anima, espera a que termine; si llegan varios, solo se aplica el último.

Primer lanzamiento (no hay proceso residente) o cuando hay un video activo:

1. El padre busca la imagen anterior en la config (`wallpapers`, `current`; si era video usa su miniatura). Sin anterior, o si es el mismo archivo, no hay animación.
2. Se lanza `__bg` con tipo, duración y ruta de la anterior.
3. El hijo pinta primero un frame idéntico al fondo actual, hace `roundtrip` con el compositor e imprime `ready`. El padre baja el proceso viejo en ese momento.
4. Luego anima. Cada frame es un buffer opaco con la mezcla completa anterior→nueva, así funciona aunque el compositor ponga la capa nueva debajo de la vieja.

Memoria: durante la animación hay dos imágenes en RAM por monitor; al terminar queda un único buffer.

### Imágenes con awww

Se pasa `--transition-type`, `--transition-duration` y `--transition-fps 60`:

| Nuestro tipo | awww |
|---|---|
| fade | fade |
| slide-* y wipe-* | left / right / top / bottom |
| circle | center |
| zoom | grow |
| blinds | wave |
| tipos por capas | no aplica: usa la capa propia |
| random | random |
| none | none |

### Video en vivo con el motor propio (`crates/oozewalls-live`)

Las 24 transiciones funcionan nativas, en GPU, dentro del proceso `__live`. Detalle y puntos a vigilar en
`docs/LIVE-ENGINE.md`. Entre videos el proceso es el mismo; desde una imagen se anima desde esa imagen. Entre videos el viejo se pausa en una instantánea y el nuevo entra ya en reproducción.

### Video en vivo con mpvpaper (fallback)

Se usan propiedades de mpv por el socket IPC, en dos mitades (salida y entrada):

- Al cambiar de video con mpv ya abierto: rampa de salida, `loadfile`, rampa de entrada.
- Al lanzar mpvpaper nuevo: arranca con las propiedades "de entrada" como opciones y luego se rampa a 0.

| Tipo | Efecto en video |
|---|---|
| slide-* | `video-pan-x/y` fuera y dentro de pantalla |
| zoom | desvanecido + `video-zoom` en la entrada |
| el resto (incluidos los tipos por capas) | desvanecido por `brightness` (pasa por negro) |

Un video sobre un fondo estático (o al revés) se superpone y luego se libera el anterior.

### Live → estático y reemplazo del motor live

La capa propia cuenta el motor live como fondo previo (antes no lo hacía y no animaba). La base vieja es una instantánea
del frame actual del video (ver `docs/LIVE-ENGINE.md`), no la miniatura. Misma lógica para live → live cuando el proceso
live se reemplaza.

## Pruebas

- Unitarias (`cargo test --lib`): cada tipo empieza igual al fondo anterior, termina igual al nuevo y mezcla a mitad de camino. Los tipos por capas además verifican que aparezcan píxeles de capa, que avancen con el tiempo, que el camino con hilos dé el mismo resultado y el enrutado hacia la capa propia.
- Manual en sway headless: capturas con `grim` durante `circle`, `slide-left` y `fade`; el PID del proceso residente no cambia entre cambios; cambios encadenados sin bajón a negro.
