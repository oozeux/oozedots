// BarIslandTint

import QtQuick
import "../../../COMMON"

Item {
  id: tint

  property string side: "left"

  readonly property real from: tint.side === "left" ? 0 : (tint.side === "center" ? 0.34 : 0.67)
  readonly property real to: tint.side === "left" ? 0.33 : (tint.side === "center" ? 0.66 : 1)

  visible: Theme.barIslandTint

  Rectangle {
    anchors.fill: parent
    visible: Theme.barMixedStyle === "islands"
    radius: Theme.islandRadius
    color: Theme.mixedFill(Theme.islandPos(tint.side))
    Behavior on color { ColorAnimation { duration: Theme.animDuration(200) } }
  }

  Rectangle {
    anchors.fill: parent
    visible: Theme.barMixedStyle === "gradient"
    radius: Theme.islandRadius
    gradient: Gradient {
      orientation: Theme.barVertical ? Gradient.Vertical : Gradient.Horizontal
      GradientStop { position: 0; color: Theme.mixedFill(tint.from) }
      GradientStop { position: 1; color: Theme.mixedFill(tint.to) }
    }
  }
}
