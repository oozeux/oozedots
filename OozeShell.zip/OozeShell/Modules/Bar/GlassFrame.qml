// GlassFrame — MODULES/BAR

import Quickshell
import Quickshell.Wayland
import QtQuick
import QtQuick.Shapes
import "../../COMMON"

Item {
    id: root

    required property var screen
    property bool active: false
    property bool suppressed: false

    // ─── GEOMETRÍA DEL ANILLO ───
    QtObject {
        id: geo

        readonly property string side: Theme.frameBarSideLayout
        readonly property real bar: Theme.barOffset
        readonly property real tv: Math.max(0, Theme.frameThicknessVis)
        readonly property real w: win.width
        readonly property real h: win.height

        readonly property real ox0: side === "left" ? bar : 0
        readonly property real oy0: side === "top" ? bar : 0
        readonly property real ox1: w - (side === "right" ? bar : 0)
        readonly property real oy1: h - (side === "bottom" ? bar : 0)

        readonly property real ix0: side === "left" ? ox0 : tv
        readonly property real iy0: side === "top" ? oy0 : tv
        readonly property real ix1: side === "right" ? ox1 : w - tv
        readonly property real iy1: side === "bottom" ? oy1 : h - tv

        readonly property real rr: Math.max(0, Math.min(Theme.frameCornerRadius,
                                                         (ix1 - ix0) / 2, (iy1 - iy0) / 2))
    }

    // ─── VENTANA DEL MARCO ───
    PanelWindow {
        id: win
        screen: root.screen
        anchors { top: true; bottom: true; left: true; right: true }
        visible: root.active
        color: "transparent"
        exclusiveZone: -1
        mask: Region {}
        WlrLayershell.layer: WM.islandLayer
        WlrLayershell.namespace: "oozeshell-frame-glass"

        // ─── REGIÓN DE BLUR (anillo = rectángulo exterior menos interior redondeado) ───
        readonly property bool blurActive: Theme.glassBlurOn && root.active && !root.suppressed

        Region {
            id: ringBlur
            x: win.blurActive ? Math.round(geo.ox0) : 0
            y: win.blurActive ? Math.round(geo.oy0) : 0
            width: win.blurActive ? Math.max(0, Math.round(geo.ox1 - geo.ox0)) : 0
            height: win.blurActive ? Math.max(0, Math.round(geo.oy1 - geo.oy0)) : 0

            Region {
                intersection: Intersection.Subtract
                x: Math.round(geo.ix0)
                y: Math.round(geo.iy0)
                width: Math.max(0, Math.round(geo.ix1 - geo.ix0))
                height: Math.max(0, Math.round(geo.iy1 - geo.iy0))
                radius: geo.rr
            }
        }

        Component.onCompleted: {
            if (WM.hasBackgroundBlur) BackgroundEffect.blurRegion = ringBlur
        }

        // ─── FORMA ÚNICA (sin solapes, el color translúcido no se duplica) ───
        Shape {
            anchors.fill: parent
            preferredRendererType: Shape.CurveRenderer
            opacity: root.suppressed ? 0 : 1
            Behavior on opacity { NumberAnimation { duration: Theme.animDuration(150); easing.type: Easing.OutCubic } }

            ShapePath {
                fillColor: Theme.glassBg
                fillRule: ShapePath.OddEvenFill
                strokeWidth: -1
                strokeColor: "transparent"

                startX: geo.ox0
                startY: geo.oy0
                PathLine { x: geo.ox1; y: geo.oy0 }
                PathLine { x: geo.ox1; y: geo.oy1 }
                PathLine { x: geo.ox0; y: geo.oy1 }
                PathLine { x: geo.ox0; y: geo.oy0 }

                PathMove { x: geo.ix0 + geo.rr; y: geo.iy0 }
                PathLine { x: geo.ix1 - geo.rr; y: geo.iy0 }
                PathArc {
                    x: geo.ix1; y: geo.iy0 + geo.rr
                    radiusX: geo.rr; radiusY: geo.rr
                    direction: PathArc.Clockwise
                }
                PathLine { x: geo.ix1; y: geo.iy1 - geo.rr }
                PathArc {
                    x: geo.ix1 - geo.rr; y: geo.iy1
                    radiusX: geo.rr; radiusY: geo.rr
                    direction: PathArc.Clockwise
                }
                PathLine { x: geo.ix0 + geo.rr; y: geo.iy1 }
                PathArc {
                    x: geo.ix0; y: geo.iy1 - geo.rr
                    radiusX: geo.rr; radiusY: geo.rr
                    direction: PathArc.Clockwise
                }
                PathLine { x: geo.ix0; y: geo.iy0 + geo.rr }
                PathArc {
                    x: geo.ix0 + geo.rr; y: geo.iy0
                    radiusX: geo.rr; radiusY: geo.rr
                    direction: PathArc.Clockwise
                }
            }
        }
    }
}
