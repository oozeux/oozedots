// MenuModule — botón con el logo de la distro (variante negra con fondo claro): abre el menú principal.

import QtQuick
import QtQuick.Layouts

import "../../../COMMON"
import "../../../Services/Lang"

BarFlow {
  id: mod

  property var host: null
  readonly property bool shown: true

  BarPillButton {
    id: menuBtn

    hoverColor: mod.hoverColor

    active: mod.host.menuOpen
    tip: Translations.t("menuButtonTip")

    onHoverEntered: mod.host.tipEnter(menuBtn)
    onHoverExited: mod.host.tipLeave(menuBtn)
    onClicked: mod.host.menuButtonClicked()

    readonly property string customIcon: {
      if (Theme.menuIconMode === "single") return Theme.menuIconFile(Theme.menuIconPath)
      if (Theme.menuIconMode === "pair")
        return Theme.menuIconFile(Theme.bgIsDark ? Theme.menuIconDarkPath : Theme.menuIconLightPath)
      return ""
    }
    readonly property bool customOk: customIcon !== "" && customImg.status !== Image.Error

    readonly property string logoFile: {
      if (customOk) return ""
      if (WM.distro === "arch")
        return Theme.bgIsDark ? "Arch_Logo/Arch_Linux.svg" : "Arch_Logo/Arch_Linux_Black.svg"
      if (WM.distro === "nixos")
        return Theme.bgIsDark ? "NixOS_Logo/NixOS.svg" : "NixOS_Logo/NixOS_Black.svg"
      return ""
    }

    Image {
      id: customImg
      visible: menuBtn.customOk
      Layout.alignment: Qt.AlignHCenter
      source: menuBtn.customIcon
      sourceSize.width: Theme.fs(19) * 2
      sourceSize.height: Theme.fs(19) * 2
      Layout.preferredWidth: Theme.fs(19)
      Layout.preferredHeight: Theme.fs(19)
      fillMode: Image.PreserveAspectFit
      asynchronous: true
      smooth: true
      mipmap: true
    }
    Image {
      visible: menuBtn.logoFile !== ""
      Layout.alignment: Qt.AlignHCenter
      source: menuBtn.logoFile !== ""
        ? Qt.resolvedUrl("../../../Assets/logos/" + menuBtn.logoFile) : ""
      sourceSize.width: Theme.fs(19)
      sourceSize.height: Theme.fs(19)
      fillMode: Image.PreserveAspectFit
      asynchronous: true
    }
    Text {
      visible: menuBtn.logoFile === "" && !menuBtn.customOk
      Layout.alignment: Qt.AlignHCenter
      text: "❄"
      color: Theme.text
      font.family: Theme.fontFamily
      font.pixelSize: Theme.fs(19)
    }
  }
}
