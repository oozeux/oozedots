// WorkspacesModule — puntos de los escritorios de esta pantalla.

import QtQuick
import QtQuick.Layouts

import "../../../COMMON"

BarFlow {
  id: mod

  property var host: null
  readonly property bool shown: true

  readonly property real faceAcross: Theme.barVertical ? 40 : 30
  readonly property real sidePad: 8

  gap: 2

  WorkspaceDots {
    workspaces: WM.dotsWorkspacesFor(mod.host.screenName ?? "")
    vertical: Theme.barVertical
    hoverColor: Theme.barMixed ? mod.hoverColor : Theme.surfaceHigh

    Layout.leftMargin: Theme.barVertical ? Math.max(0, (mod.faceAcross - width) / 2) : mod.sidePad
    Layout.rightMargin: Theme.barVertical ? Math.max(0, (mod.faceAcross - width) / 2) : mod.sidePad
    Layout.topMargin: Theme.barVertical ? mod.sidePad : Math.max(0, (mod.faceAcross - height) / 2)
    Layout.bottomMargin: Theme.barVertical ? mod.sidePad : Math.max(0, (mod.faceAcross - height) / 2)
  }
}
