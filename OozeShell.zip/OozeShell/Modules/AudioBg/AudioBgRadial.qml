// AudioBgRadial

import QtQuick
import QtQuick.Shapes
import "../../COMMON"

Item {
  id: radial

  // ─── Entrada ───
  property bool active: true

  // ─── Derivados ───
  readonly property bool hole: AudioBgConfig.style === "blackhole"
  readonly property bool core: AudioBgConfig.style === "void"
  readonly property bool on: AudioBgConfig.style === "radial" || radial.hole || radial.core
  readonly property var vals: (radial.active && radial.on) ? AudioBgService.values : []
  readonly property int n: radial.vals.length
  readonly property int count: radial.n * 2
  readonly property int groups: 16
  readonly property int capSteps: 5
  readonly property real outer: Math.min(radial.width, radial.height) / 2 * (0.25 + 0.75 * AudioBgConfig.thickness / 100)
  readonly property real inner: radial.outer * AudioBgConfig.inner / 100
  readonly property real rim: radial.inner + (radial.outer - radial.inner) * 0.66
  readonly property real arc: radial.count > 0 ? 2 * Math.PI * (radial.hole ? radial.rim : radial.inner) / radial.count : 0
  readonly property real gapFrac: Math.min(0.85, AudioBgConfig.gap / Math.max(1, radial.arc))
  readonly property real coreRoom: Math.max(0, (radial.outer - radial.inner) * 0.4)
  readonly property real coreGap: Math.max(3, radial.outer * 0.025)
  readonly property real rimWidth: Math.max(1.5, radial.outer * 0.006)
  readonly property var contour: radial.core ? radial.buildContour() : []

  // ─── Geometría base ───
  function val(i) {
    const x = radial.vals[i]
    return x === undefined ? 0 : x / 1000
  }

  function bandOf(k) {
    return k < radial.n ? k : radial.count - 1 - k
  }

  function groupOf(k) {
    return Math.floor(radial.bandOf(k) * radial.groups / radial.n)
  }

  function angleOf(k) {
    return -Math.PI / 2 + (k + 0.5) * 2 * Math.PI / radial.count
  }

  function pill(a, r0, r1, wIn, wOut) {
    const cx = radial.width / 2
    const cy = radial.height / 2
    const ux = Math.cos(a), uy = Math.sin(a)
    const tx = -uy, ty = ux
    const end = Math.max(r1, r0 + wIn + wOut)
    const ci = r0 + wIn
    const co = end - wOut
    const s = radial.capSteps
    const pts = []
    for (let i = 0; i <= s; i++) {
      const p = Math.PI * i / s
      const r = co + wOut * Math.sin(p)
      const d = wOut * Math.cos(p)
      pts.push(Qt.point(cx + r * ux + d * tx, cy + r * uy + d * ty))
    }
    for (let i = 0; i <= s; i++) {
      const p = Math.PI + Math.PI * i / s
      const r = ci + wIn * Math.sin(p)
      const d = wIn * Math.cos(p)
      pts.push(Qt.point(cx + r * ux + d * tx, cy + r * uy + d * ty))
    }
    return pts
  }

  // ─── Estilo radial ───
  function radialBars(g) {
    const total = radial.count
    const out = []
    if (total === 0) return out
    const r0 = radial.inner
    const span = radial.outer - r0
    const w = Math.min(radial.arc * (1 - radial.gapFrac), Math.max(2, radial.outer * 0.013)) / 2
    const rc = r0 + span / 2
    const rest = w * 1.5
    for (let k = 0; k < total; k++) {
      if (radial.groupOf(k) !== g) continue
      const l = radial.val(radial.bandOf(k))
      const t = Math.min(1, l * 1.4)
      const rIn = rc - Math.max(rest, l * span / 2 * 0.72)
      const rOut = rc + Math.max(rest, l * span / 2)
      const fitIn = Math.PI * rIn / total * (1 - radial.gapFrac)
      const fitOut = Math.PI * rOut / total * (1 - radial.gapFrac)
      const wIn = Math.min(fitIn, Math.max(w * 0.4, w * (1 - 0.6 * t)))
      const wOut = Math.min(fitOut, w * (1 + 0.3 * t))
      out.push(radial.pill(radial.angleOf(k), rIn, rOut, wIn, wOut))
    }
    return out
  }

  // ─── Estilo blackhole ───
  function holeBars(g) {
    const total = radial.count
    const out = []
    if (total === 0) return out
    const rim = radial.rim
    const fall = rim - radial.outer * 0.04
    const rise = radial.outer - rim
    const wMax = Math.max(4, radial.outer * 0.026)
    const w = Math.min(radial.arc * (1 - radial.gapFrac), wMax) / 2
    const rest = w * 1.6
    for (let k = 0; k < total; k++) {
      if (radial.groupOf(k) !== g) continue
      const l = radial.val(radial.bandOf(k))
      const t = Math.min(1, l * 1.6)
      const rIn = rim - Math.max(rest, l * fall)
      const rOut = rim + Math.max(rest, l * rise)
      const wo = Math.min(2 * Math.PI * rOut / total * (1 - radial.gapFrac), wMax) / 2
      const wOut = w + Math.max(0, wo - w) * t
      const wIn = w * (1 - 0.88 * t)
      out.push(radial.pill(radial.angleOf(k), rIn, rOut, wIn, wOut))
    }
    return out
  }

  // ─── Estilo void ───
  function buildContour() {
    const total = radial.count
    if (total === 0) return []
    let src = new Array(total)
    let avg = 0
    for (let k = 0; k < total; k++) {
      src[k] = radial.val(radial.bandOf(k))
      avg += src[k]
    }
    avg /= total
    for (let p = 0; p < 2; p++) {
      const dst = new Array(total)
      for (let k = 0; k < total; k++)
        dst[k] = (src[(k + total - 1) % total] + 2 * src[k] + src[(k + 1) % total]) / 4
      src = dst
    }
    const pulse = 0.25 * Math.min(1, avg * 1.8)
    const out = new Array(total)
    for (let k = 0; k < total; k++)
      out[k] = radial.inner + radial.coreRoom * (pulse + 0.75 * src[k])
    return out
  }

  function contourPoint(k) {
    const total = radial.count
    const i = ((k % total) + total) % total
    const a = radial.angleOf(i)
    const r = radial.contour[i]
    return Qt.point(radial.width / 2 + r * Math.cos(a), radial.height / 2 + r * Math.sin(a))
  }

  function coreRuns(g) {
    const runs = []
    let cur = null
    for (let k = 0; k < radial.count; k++) {
      if (radial.groupOf(k) === g) {
        if (cur) cur.e = k
        else { cur = { s: k, e: k }; runs.push(cur) }
      } else {
        cur = null
      }
    }
    return runs
  }

  function coreShape() {
    const pts = []
    if (radial.contour.length === 0) return pts
    for (let k = 0; k < radial.count; k++) pts.push(radial.contourPoint(k))
    return pts
  }

  function coreRim(g) {
    const out = []
    if (radial.contour.length === 0) return out
    const runs = radial.coreRuns(g)
    for (const r of runs) {
      const pts = []
      for (let k = r.s - 1; k <= r.e + 1; k++) pts.push(radial.contourPoint(k))
      out.push(pts)
    }
    return out
  }

  function coreBars(g) {
    const total = radial.count
    const out = []
    if (total === 0 || radial.contour.length === 0) return out
    const w = Math.min(radial.arc * (1 - radial.gapFrac), Math.max(3, radial.outer * 0.016)) / 2
    const rest = w * 4
    const avail = Math.max(0, radial.outer - radial.inner - radial.coreRoom - radial.coreGap - rest)
    for (let k = 0; k < total; k++) {
      if (radial.groupOf(k) !== g) continue
      const l = radial.val(radial.bandOf(k))
      const base = radial.contour[k] + radial.coreGap
      out.push(radial.pill(radial.angleOf(k), base, base + rest + l * avail, w, w))
    }
    return out
  }

  function quads(g) {
    if (radial.hole) return radial.holeBars(g)
    if (radial.core) return radial.coreBars(g)
    return radial.radialBars(g)
  }

  function coreColor(t) {
    return Theme.mix(AudioBgConfig.colorAt(t), "#05060a", 0.72)
  }

  function rimColor(g) {
    return Qt.lighter(AudioBgConfig.colorAt((g + 0.5) / radial.groups), 1.25)
  }

  // ─── Dibujo ───
  component Wedges: ShapePath {
    id: seg
    property var host: null
    property int g: 0
    strokeColor: "transparent"
    strokeWidth: 0
    fillColor: seg.host ? AudioBgConfig.colorAt((seg.g + 0.5) / seg.host.groups) : "transparent"
    PathMultiline { paths: seg.host ? seg.host.quads(seg.g) : [] }
  }

  component CoreFill: ShapePath {
    id: fill
    property var host: null
    readonly property real cx: fill.host ? fill.host.width / 2 : 0
    readonly property real cy: fill.host ? fill.host.height / 2 : 0
    readonly property real reach: fill.host ? fill.host.inner + fill.host.coreRoom * 0.35 : 1
    strokeColor: "transparent"
    strokeWidth: 0
    fillGradient: LinearGradient {
      x1: fill.cx; y1: fill.cy - fill.reach
      x2: fill.cx; y2: fill.cy + fill.reach
      GradientStop { position: 0.000; color: fill.host ? fill.host.coreColor(0.000) : "transparent" }
      GradientStop { position: 0.038; color: fill.host ? fill.host.coreColor(0.125) : "transparent" }
      GradientStop { position: 0.146; color: fill.host ? fill.host.coreColor(0.250) : "transparent" }
      GradientStop { position: 0.309; color: fill.host ? fill.host.coreColor(0.375) : "transparent" }
      GradientStop { position: 0.500; color: fill.host ? fill.host.coreColor(0.500) : "transparent" }
      GradientStop { position: 0.691; color: fill.host ? fill.host.coreColor(0.625) : "transparent" }
      GradientStop { position: 0.854; color: fill.host ? fill.host.coreColor(0.750) : "transparent" }
      GradientStop { position: 0.962; color: fill.host ? fill.host.coreColor(0.875) : "transparent" }
      GradientStop { position: 1.000; color: fill.host ? fill.host.coreColor(1.000) : "transparent" }
    }
    PathPolyline { path: fill.host ? fill.host.coreShape() : [] }
  }

  component CoreRim: ShapePath {
    id: line
    property var host: null
    property int g: 0
    fillColor: "transparent"
    strokeColor: line.host ? line.host.rimColor(line.g) : "transparent"
    strokeWidth: line.host ? line.host.rimWidth : 2
    capStyle: ShapePath.RoundCap
    joinStyle: ShapePath.RoundJoin
    PathMultiline { paths: line.host ? line.host.coreRim(line.g) : [] }
  }

  Loader {
    anchors.fill: parent
    active: radial.core
    sourceComponent: Shape {
      preferredRendererType: Shape.CurveRenderer
      CoreFill { host: radial }
      CoreRim { host: radial; g: 0 }
      CoreRim { host: radial; g: 1 }
      CoreRim { host: radial; g: 2 }
      CoreRim { host: radial; g: 3 }
      CoreRim { host: radial; g: 4 }
      CoreRim { host: radial; g: 5 }
      CoreRim { host: radial; g: 6 }
      CoreRim { host: radial; g: 7 }
      CoreRim { host: radial; g: 8 }
      CoreRim { host: radial; g: 9 }
      CoreRim { host: radial; g: 10 }
      CoreRim { host: radial; g: 11 }
      CoreRim { host: radial; g: 12 }
      CoreRim { host: radial; g: 13 }
      CoreRim { host: radial; g: 14 }
      CoreRim { host: radial; g: 15 }
    }
  }

  Loader {
    anchors.fill: parent
    active: radial.on
    sourceComponent: Shape {
      preferredRendererType: Shape.CurveRenderer
      Wedges { host: radial; g: 0 }
      Wedges { host: radial; g: 1 }
      Wedges { host: radial; g: 2 }
      Wedges { host: radial; g: 3 }
      Wedges { host: radial; g: 4 }
      Wedges { host: radial; g: 5 }
      Wedges { host: radial; g: 6 }
      Wedges { host: radial; g: 7 }
      Wedges { host: radial; g: 8 }
      Wedges { host: radial; g: 9 }
      Wedges { host: radial; g: 10 }
      Wedges { host: radial; g: 11 }
      Wedges { host: radial; g: 12 }
      Wedges { host: radial; g: 13 }
      Wedges { host: radial; g: 14 }
      Wedges { host: radial; g: 15 }
    }
  }
}
