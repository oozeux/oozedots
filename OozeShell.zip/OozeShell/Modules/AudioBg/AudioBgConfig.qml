// AudioBgConfig

pragma Singleton
import Quickshell
import Quickshell.Io
import QtQuick
import "../../COMMON"
import "../../Core/Toml.js" as Toml

Singleton {
  id: root

  // ─── Archivo ───
  readonly property string file: Theme.prefsDir + "/audiobg.toml"

  // ─── Catálogo ───
  readonly property var styles: ["bars", "blocks", "dots", "wave", "line", "columns", "radial", "blackhole", "void"]
  readonly property var edges: ["auto", "bottom", "top", "left", "right", "both", "sides", "center"]
  readonly property var fitModes: ["auto", "fit", "behind"]
  readonly property var layers: ["bottom", "background"]
  readonly property var colorModes: ["primary", "gradient", "rainbow", "custom"]
  readonly property var symmetricModes: ["off", "center", "edges"]

  readonly property var spec: ({
    enabled:     { type: "bool", def: false },
    demo:        { type: "bool", def: false },
    style:       { type: "enum", list: root.styles, def: "bars" },
    edge:        { type: "enum", list: root.edges, def: "auto" },
    fit:         { type: "enum", list: root.fitModes, def: "auto" },
    layer:       { type: "enum", list: root.layers, def: "bottom" },
    monitor:     { type: "string", def: "" },
    colorMode:   { type: "enum", list: root.colorModes, def: "gradient" },
    customColor: { type: "color", def: "#c8a6f2" },
    symmetric:   { type: "enum", list: root.symmetricModes, def: "off" },
    peaks:       { type: "bool", def: false },
    autosens:    { type: "bool", def: true },
    bars:        { type: "int", min: 16, max: 128, def: 64 },
    fps:         { type: "int", min: 15, max: 60, def: 60 },
    smooth:      { type: "int", min: 0, max: 100, def: 55 },
    sensitivity: { type: "int", min: 20, max: 400, def: 100 },
    thickness:   { type: "int", min: 5, max: 100, def: 35 },
    opacity:     { type: "int", min: 5, max: 100, def: 80 },
    gap:         { type: "int", min: 0, max: 24, def: 3 },
    roundness:   { type: "int", min: 0, max: 100, def: 60 },
    inner:       { type: "int", min: 10, max: 80, def: 35 },
    method:      { type: "string", def: "pulse" },
    source:      { type: "string", def: "auto" }
  })

  // ─── Estado ───
  property var values: root.defaults()
  property bool loaded: false
  property string lastWritten: ""

  signal raiseRequested()

  readonly property bool enabled: root.values.enabled
  readonly property bool demo: root.values.demo
  readonly property string style: root.values.style
  readonly property string edge: root.values.edge
  readonly property string fit: root.values.fit
  readonly property string layer: root.values.layer
  readonly property string monitor: root.values.monitor
  readonly property string colorMode: root.values.colorMode
  readonly property string customColor: root.values.customColor
  readonly property string symmetric: root.values.symmetric
  readonly property bool peaks: root.values.peaks
  readonly property bool autosens: root.values.autosens
  readonly property int bars: root.values.bars
  readonly property int fps: root.values.fps
  readonly property int smooth: root.values.smooth
  readonly property int sensitivity: root.values.sensitivity
  readonly property int thickness: root.values.thickness
  readonly property int opacity: root.values.opacity
  readonly property int gap: root.values.gap
  readonly property int roundness: root.values.roundness
  readonly property int inner: root.values.inner

  // ─── Validación ───
  function defaults() {
    const out = {}
    for (const k in root.spec) out[k] = root.spec[k].def
    return out
  }

  function coerce(key, v) {
    const s = root.spec[key]
    if (!s) return undefined
    if (s.type === "bool") {
      if (v === true || v === "true" || v === 1 || v === "1") return true
      if (v === false || v === "false" || v === 0 || v === "0") return false
      return undefined
    }
    if (s.type === "int") {
      const n = Math.round(Number(v))
      if (isNaN(n)) return undefined
      return Math.max(s.min, Math.min(s.max, n))
    }
    if (s.type === "enum") return s.list.indexOf(String(v)) >= 0 ? String(v) : undefined
    if (s.type === "color") {
      const t = String(v).trim()
      return /^#[0-9a-fA-F]{6}$/.test(t) ? t.toLowerCase() : undefined
    }
    if (s.type === "string") {
      const t = String(v ?? "").trim()
      return /^[A-Za-z0-9_.:@\-]{0,120}$/.test(t) ? t : undefined
    }
    return undefined
  }

  function normalize(raw) {
    const out = root.defaults()
    if (!raw || typeof raw !== "object") return out
    for (const k in root.spec) {
      const c = root.coerce(k, raw[k])
      if (c !== undefined) out[k] = c
    }
    return out
  }

  // ─── Operaciones ───
  function set(key, v) {
    const c = root.coerce(key, v)
    if (c === undefined) return false
    if (root.values[key] === c) return true
    const next = Object.assign({}, root.values)
    next[key] = c
    root.values = next
    root.save()
    return true
  }
  function setMany(obj) {
    const next = Object.assign({}, root.values)
    let changed = false
    for (const k in obj) {
      const c = root.coerce(k, obj[k])
      if (c !== undefined && next[k] !== c) { next[k] = c; changed = true }
    }
    if (!changed) return
    root.values = next
    root.save()
  }
  function toggleEnabled() { root.set("enabled", !root.enabled); return root.enabled }

  // ─── Color ───
  function shifted(c, d) {
    const h = c.hslHue < 0 ? 0 : c.hslHue
    return Qt.hsla((h + d + 1) % 1, Math.max(0.4, c.hslSaturation), Math.max(0.5, Math.min(0.7, c.hslLightness)), 1)
  }
  function colorAt(t) {
    const x = Math.max(0, Math.min(1, t))
    switch (root.colorMode) {
      case "custom": return Qt.color(root.customColor)
      case "rainbow": return Qt.hsla(x * 0.86, 0.72, 0.62, 1)
      case "gradient": return Theme.mix(root.shifted(Theme.primary, -0.1), root.shifted(Theme.primary, 0.14), x)
      default: return Theme.primary
    }
  }

  // ─── Lectura ───
  function load(text) {
    const raw = (text || "").trim()
    if (raw !== "" && raw === root.lastWritten) { root.loaded = true; return }
    try {
      root.values = root.normalize(raw === "" ? {} : Toml.parseAny(raw))
    } catch (e) {
      console.log("[audiobg] audiobg.toml inválido, lo ignoro:", e)
    }
    root.loaded = true
  }

  FileView {
    id: view
    path: root.file
    watchChanges: true
    onFileChanged: view.reload()
    onLoaded: root.load(view.text())
    onLoadFailed: root.loaded = true
  }

  // ─── Escritura ───
  function serialize() {
    return Toml.stringify(Object.assign({ version: 1 }, root.values, { fpsCap: Theme.shellPerf ? 24 : 0 }))
  }
  function save() { saveTimer.restart() }

  Timer {
    id: saveTimer
    interval: 350
    onTriggered: {
      const text = root.serialize()
      root.lastWritten = text.trim()
      writer.payload = text
      if (writer.running) writer.pending = true
      else writer.running = true
    }
  }

  Connections {
    target: Theme
    function onShellPerfChanged() { if (root.loaded) root.save() }
  }

  Process {
    id: writer
    property string payload: ""
    property bool pending: false
    command: ["bash", "-c", 'mkdir -p "$OOZE_DIR" && printf %s "$OOZE_DATA" > "$OOZE_FILE.tmp" && mv "$OOZE_FILE.tmp" "$OOZE_FILE"']
    environment: ({ "OOZE_DATA": writer.payload, "OOZE_DIR": Theme.prefsDir, "OOZE_FILE": root.file })
    running: false
    onRunningChanged: {
      if (running || !pending) return
      pending = false
      running = true
    }
  }
}
