// FusedClock.qml — Modules/Widgets/clock
// Estilos de reloj `pixel` y `floral` (set FusedIslands). Colores solo desde Theme.

import QtQuick
import QtQuick.Layouts
import ".."
import "../../../COMMON"

Item {
  id: root

  // ─── Entradas desde ClockWidget ───
  property bool floral: false
  property var now: new Date()
  property bool h24: true
  property bool showSeconds: false
  property bool showDate: true
  property bool showBg: true
  property real bgAlpha: 0.88
  property string family: "serif"
  property var loc: Qt.locale()

  // ─── Colores (siguen la paleta activa, manual o matugen) ───
  function mix(a, b, t) {
    return Qt.rgba(a.r + (b.r - a.r) * t, a.g + (b.g - a.g) * t, a.b + (b.b - a.b) * t, 1)
  }
  function lift(t) { return root.mix(Theme.primary, Qt.rgba(1, 1, 1, 1), t) }

  readonly property color accent: Theme.primary
  readonly property color accent2: root.mix(Theme.primary, Theme.text, 0.4)
  readonly property color dayColor: root.mix(Theme.primary, Theme.text, 0.25)
  readonly property color hairline: Qt.rgba(Theme.text.r, Theme.text.g, Theme.text.b, 0.14)

  // ─── Textos ───
  readonly property string dayName: {
    const d = root.loc.toString(root.now, "dddd")
    return d.charAt(0).toUpperCase() + d.slice(1)
  }
  readonly property string timeText: Qt.formatDateTime(root.now, (root.h24 ? "HH:mm" : "h:mm") + (root.showSeconds ? ":ss" : ""))
  readonly property string ampm: root.h24 ? "" : (root.now.getHours() >= 12 ? "PM" : "AM")
  readonly property string dateText: root.loc.toString(root.now, "d MMMM yyyy").toUpperCase()

  // ─── Geometría ───
  readonly property real side: root.width * (root.floral ? 0.12 : 0.135)
  readonly property real vm: root.height * 0.08
  readonly property real cell: Math.max(3, Math.round(root.height * 0.026))

  // ─── Resplandor ───
  Rectangle {
    visible: root.showBg && !Theme.shellPerf
    x: body.x - 3
    y: body.y - 3
    width: body.width + 6
    height: body.height + 6
    radius: body.radius
    color: "transparent"
    border.width: root.floral ? 3 : 0
    border.color: Qt.rgba(root.accent.r, root.accent.g, root.accent.b, 0.2)
  }

  // ─── Sombra pixel ───
  Rectangle {
    visible: !root.floral && root.showBg
    x: body.x + root.cell
    y: body.y + root.cell
    width: body.width
    height: body.height
    color: Qt.rgba(root.accent.r, root.accent.g, root.accent.b, 0.35)
  }

  // ─── Cuerpo ───
  Rectangle {
    id: body
    anchors {
      fill: parent
      leftMargin: root.side
      rightMargin: root.side
      topMargin: root.vm
      bottomMargin: root.vm
    }
    radius: root.floral ? root.height * 0.3 : 0
    visible: root.showBg
    border.width: root.floral ? 2 : root.cell
    border.color: root.floral ? root.accent : root.accent2
    gradient: Gradient {
      GradientStop { position: 0; color: Qt.rgba(Theme.surfaceHigh.r, Theme.surfaceHigh.g, Theme.surfaceHigh.b, root.bgAlpha) }
      GradientStop { position: 1; color: Qt.rgba(Theme.surface.r * 0.8, Theme.surface.g * 0.8, Theme.surface.b * 0.8, root.bgAlpha) }
    }

    WidgetBlur {
      anchors.fill: parent
      radius: body.radius
      allowed: root.showBg
    }

    Rectangle {
      anchors.fill: parent
      anchors.margins: 3
      radius: Math.max(0, parent.radius - 3)
      color: "transparent"
      border.width: root.floral ? 1 : 0
      border.color: root.hairline
    }
  }

  // ─── Hora ───
  ColumnLayout {
    anchors.centerIn: body
    spacing: -root.height * 0.01

    WidgetText {
      Layout.alignment: Qt.AlignHCenter
      text: root.dayName
      color: root.dayColor
      font.family: root.family
      font.italic: root.floral
      font.capitalization: root.floral ? Font.MixedCase : Font.AllUppercase
      font.letterSpacing: root.floral ? 0 : 2
      font.pixelSize: Math.round(root.height * 0.125)
    }

    Item {
      Layout.alignment: Qt.AlignHCenter
      Layout.preferredWidth: timeT.implicitWidth + (ampmT.visible ? ampmT.implicitWidth + 8 : 0)
      Layout.preferredHeight: timeT.implicitHeight

      WidgetText {
        id: timeT
        text: root.timeText
        color: Theme.text
        font.family: root.family
        font.pixelSize: Math.round(root.height * 0.31)
      }
      WidgetText {
        id: ampmT
        visible: root.ampm !== ""
        x: timeT.width + 8
        y: timeT.y + timeT.baselineOffset - ampmT.baselineOffset
        text: root.ampm
        color: Theme.text
        font.family: root.family
        font.pixelSize: Math.round(root.height * 0.115)
      }
    }

    WidgetText {
      Layout.alignment: Qt.AlignHCenter
      visible: root.showDate
      text: root.dateText
      color: Theme.subtext
      font.family: root.family
      font.letterSpacing: 2
      font.pixelSize: Math.max(9, Math.round(root.height * 0.07))
    }
  }

  // ─── Pixel ───
  Item {
    visible: !root.floral
    anchors.fill: parent

    PixelEdge {
      x: 0
      y: root.height * 0.1
      width: root.side + 12
      height: root.height * 0.8
      cell: Math.max(4, Math.round(root.height * 0.026))
      color: root.accent
      color2: root.accent2
    }
    PixelEdge {
      x: root.width - width
      y: root.height * 0.1
      width: root.side + 12
      height: root.height * 0.8
      cell: Math.max(4, Math.round(root.height * 0.026))
      mirror: true
      seed: 19
      color: root.accent
      color2: root.accent2
    }
  }

  // ─── Floral ───
  Item {
    visible: root.floral
    anchors.fill: parent

    Sakura { x: root.side * 0.05; y: root.height * 0.5; size: root.height * 0.34; color: root.lift(0.45); deep: root.accent }
    Sakura { x: root.side * 0.55; y: root.height * 0.1; size: root.height * 0.2; color: root.lift(0.6); deep: root.accent }
    Sakura { x: root.side * 0.9; y: root.height * 0.78; size: root.height * 0.13; color: root.lift(0.35); deep: root.accent }
    Sakura { x: root.width - root.side * 0.95; y: root.height * 0.08; size: root.height * 0.36; color: root.lift(0.45); deep: root.accent }
    Sakura { x: root.width - root.side * 1.0; y: root.height * 0.64; size: root.height * 0.15; color: root.lift(0.6); deep: root.accent }
    Rectangle {
      anchors.horizontalCenter: parent.horizontalCenter
      y: root.height * 0.905
      width: root.width * 0.42
      height: 1
      color: Qt.rgba(root.accent.r, root.accent.g, root.accent.b, 0.7)
    }
    Sparkle {
      anchors.horizontalCenter: parent.horizontalCenter
      y: root.height * 0.905 - height / 2
      size: root.height * 0.07
      color: root.dayColor
    }
  }
}
