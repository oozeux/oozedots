// Sparkle.qml — Modules/Widgets/clock/parts
// Destello de cuatro puntas con parpadeo opcional

import QtQuick

Canvas {
  id: sp

  property color color: "#ffffff"
  property real size: 12
  property bool twinkle: true
  property int delay: 0

  width: sp.size
  height: sp.size

  onColorChanged: sp.requestPaint()
  onWidthChanged: sp.requestPaint()

  onPaint: {
    const c = sp.getContext("2d")
    c.reset()
    const s = sp.width
    const h = s / 2
    const k = s * 0.1
    c.fillStyle = String(sp.color)
    c.beginPath()
    c.moveTo(h, 0)
    c.quadraticCurveTo(h + k, h - k, s, h)
    c.quadraticCurveTo(h + k, h + k, h, s)
    c.quadraticCurveTo(h - k, h + k, 0, h)
    c.quadraticCurveTo(h - k, h - k, h, 0)
    c.closePath()
    c.fill()
  }

  // ─── Parpadeo ───
  SequentialAnimation on opacity {
    running: sp.twinkle && sp.visible
    loops: Animation.Infinite
    PauseAnimation { duration: sp.delay }
    NumberAnimation { to: 0.3; duration: 900; easing.type: Easing.InOutSine }
    NumberAnimation { to: 1; duration: 900; easing.type: Easing.InOutSine }
  }
}
