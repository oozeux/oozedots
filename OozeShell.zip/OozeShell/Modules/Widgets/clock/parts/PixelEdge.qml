// PixelEdge.qml — Modules/Widgets/clock/parts
// Borde de píxeles dispersos para el estilo pixel

import QtQuick

Canvas {
  id: px

  property bool mirror: false
  property int cell: 5
  property int seed: 7
  property color color: "#ff7ac0"
  property color color2: "#8ea0ff"

  onColorChanged: px.requestPaint()
  onColor2Changed: px.requestPaint()
  onWidthChanged: px.requestPaint()
  onHeightChanged: px.requestPaint()

  onPaint: {
    const c = px.getContext("2d")
    c.reset()
    const cols = Math.floor(px.width / px.cell)
    const rows = Math.floor(px.height / px.cell)

    // ─── Píxeles dispersos ───
    for (let y = 0; y < rows; y++) {
      for (let x = 0; x < cols; x++) {
        const d = px.mirror ? x : cols - 1 - x
        const fall = Math.pow(1 - d / cols, 2.2)
        const mid = 1 - Math.abs(y / rows - 0.5) * 0.9
        const p = 0.92 * fall * mid
        const hsh = Math.abs(((x + 1) * 73856093) ^ ((y + 1) * 19349663) ^ (px.seed * 83492791)) % 1000 / 1000
        if (hsh >= p) continue
        c.globalAlpha = 0.35 + 0.65 * (1 - hsh / Math.max(p, 0.001)) * fall
        c.fillStyle = String(hsh * 7 % 1 < 0.55 ? px.color : px.color2)
        c.fillRect(x * px.cell, y * px.cell, px.cell - 1, px.cell - 1)
      }
    }
  }
}
