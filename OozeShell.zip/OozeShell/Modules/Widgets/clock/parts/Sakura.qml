// Sakura.qml — Modules/Widgets/clock/parts
// Flor de cinco pétalos dibujada en Canvas (color y color profundo por propiedad)

import QtQuick

Canvas {
  id: sk

  property color color: "#ffc4e2"
  property color deep: "#ff6fb5"
  property real size: 36

  width: sk.size
  height: sk.size

  onColorChanged: sk.requestPaint()
  onDeepChanged: sk.requestPaint()
  onWidthChanged: sk.requestPaint()

  onPaint: {
    const c = sk.getContext("2d")
    c.reset()
    const r = sk.width / 2
    c.translate(r, r)

    // ─── Pétalos ───
    for (let i = 0; i < 5; i++) {
      c.save()
      c.rotate(i * 2 * Math.PI / 5 - Math.PI / 2)
      const g = c.createLinearGradient(0, 0, r, 0)
      g.addColorStop(0, String(sk.deep))
      g.addColorStop(0.55, String(sk.color))
      g.addColorStop(1, String(Qt.lighter(sk.color, 1.15)))
      c.fillStyle = g
      c.beginPath()
      c.moveTo(r * 0.1, 0)
      c.bezierCurveTo(r * 0.35, -r * 0.62, r * 0.88, -r * 0.5, r * 0.98, -r * 0.17)
      c.lineTo(r * 0.85, 0)
      c.lineTo(r * 0.98, r * 0.17)
      c.bezierCurveTo(r * 0.88, r * 0.5, r * 0.35, r * 0.62, r * 0.1, 0)
      c.closePath()
      c.fill()
      c.restore()
    }

    // ─── Centro ───
    c.fillStyle = String(sk.deep)
    c.beginPath()
    c.arc(0, 0, r * 0.1, 0, 2 * Math.PI)
    c.fill()
    for (let j = 0; j < 5; j++) {
      const a = j * 2 * Math.PI / 5 + 0.3
      c.beginPath()
      c.arc(Math.cos(a) * r * 0.24, Math.sin(a) * r * 0.24, r * 0.04, 0, 2 * Math.PI)
      c.fill()
    }
  }
}
