// ClockWidget — estilos: digital · minimal · analog · hybrid · vertical · weather · weathermini · serif · serifday · serifstack · serifcal · serifshadow · pixel · floral

import Quickshell
import QtQuick
import QtQuick.Layouts
import QtQuick.Effects
import ".."
import "../../../COMMON"
import "../../../Services/Lang"

WidgetBase {
  id: w

  readonly property string sty: w.widgetStyle
  readonly property bool analog: w.sty === "analog"
  readonly property bool hybrid: w.sty === "hybrid"
  readonly property bool vertical: w.sty === "vertical"
  readonly property bool fusedStyle: w.sty === "pixel" || w.sty === "floral"
  readonly property bool serifStyle: w.sty === "serif" || w.sty === "serifday" || w.sty === "serifstack" || w.sty === "serifcal" || w.sty === "serifshadow"
  readonly property string customFont: Theme.resolveFont(String(w.opt("fontFamily", "")).trim())
  readonly property string serifFamily: w.customFont !== "" ? w.customFont : Theme.pickInstalled(["Playfair Display", "Cormorant Garamond", "Libre Baskerville", "Noto Serif", "DejaVu Serif"], "serif")
  readonly property bool h24: w.opt("hour24", true)
  readonly property var loc: Qt.locale(Translations.localeCode)

  readonly property bool showSeconds: w.opt("seconds", false) || w.analog
  readonly property bool tick: w.showSeconds || w.hybrid
  readonly property bool showDate: w.opt("date", true)
  readonly property bool showBg: w.opt("background", true)
  readonly property real bgAlpha: Math.max(0, Math.min(100, Number(w.opt("bgOpacity", 60)))) / 100

  // ── legibilidad de los estilos serif sin fondo ──
  readonly property bool darkText: w.serifStyle && !w.showBg && w.opt("darkText", false)
  readonly property bool shadowOn: w.serifStyle && !Theme.shellPerf && (w.sty === "serifshadow" || (!w.showBg && w.opt("textShadow", true)))
  readonly property color ink: w.darkText ? "#12161d" : Theme.text
  readonly property color inkSoft: w.darkText ? "#2b313b" : Theme.subtext
  readonly property color accent: w.darkText ? Qt.darker(Theme.primary, 2.4) : Theme.primary
  readonly property color rule: w.darkText ? Qt.rgba(0, 0, 0, 0.3) : Theme.divider

  // ── tarjeta ajustada al contenido (estilos serif) ──
  readonly property real padX: 22
  readonly property real padY: 10
  readonly property real fitW: w.sty === "serif" ? sfTime.implicitWidth
    : w.sty === "serifday" ? Math.max(sdDay.implicitWidth, sdTime.implicitWidth, sdDate.visible ? sdDate.implicitWidth : 0)
    : w.sty === "serifstack" ? skRow.implicitWidth
    : w.sty === "serifcal" ? scRow.implicitWidth
    : w.sty === "serifshadow" ? Math.max(ssTime.implicitWidth, ssDay.implicitWidth)
    : w.width
  readonly property real fitH: w.sty === "serif" ? sfTime.implicitHeight
    : w.sty === "serifday" ? sd.implicitHeight
    : w.sty === "serifstack" ? skRow.implicitHeight
    : w.sty === "serifcal" ? scRow.implicitHeight
    : w.sty === "serifshadow" ? ssCol.implicitHeight
    : w.height

  // ── clima ──
  readonly property bool wxStyle: w.sty === "weather" || w.sty === "weathermini"
  readonly property bool mini: w.sty === "weathermini"
  readonly property string city: String(w.opt("city", "")).trim()
  readonly property bool fahr: w.opt("fahrenheit", false)
  readonly property int refreshMin: Math.max(10, Math.round(Number(w.opt("refreshMin", 20))))

  property string _id: ""
  readonly property string sig: (w.wxStyle && w.widgetId !== "") ? (w.widgetId + "|" + w.city + "|" + w.refreshMin) : ""
  onSigChanged: {
    if (w.sig === "") {
      if (w._id !== "") { WeatherService.unwatch(w._id); w._id = "" }
      return
    }
    w._id = w.widgetId
    WeatherService.watch(w.widgetId, w.city, w.refreshMin)
  }
  Component.onDestruction: if (w._id !== "") WeatherService.unwatch(w._id)

  readonly property bool noCity: w.city === ""
  readonly property var wx: (w.wxStyle && !w.noCity) ? WeatherService.get(w.city) : null
  readonly property var cur: w.wx ? (w.wx.current ?? null) : null
  readonly property bool notFound: w.cur === null && !w.noCity && !!(w.wx && w.wx.error === "notfound")
  readonly property bool askCity: w.noCity || w.notFound

  function tmp(c) { return Math.round(w.fahr ? c * 9 / 5 + 32 : c) + "°" }

  property bool cityEditing: false
  property bool paneHover: false
  property bool warnEmpty: false
  property bool hadFocus: false

  readonly property Item inputArea: w.wxStyle ? (w.cityEditing ? editBox : wxPane) : null
  readonly property bool wantsKeyboard: w.wxStyle && (w.cityEditing || w.paneHover)

  function applyCity(t) {
    const v = String(t || "").trim()
    if (v === "") { w.warnEmpty = true; warnTimer.restart(); return }
    w.warnEmpty = false
    WidgetConfig.setOption(w.widgetId, "city", v)
    w.cityEditing = false
  }
  Timer { id: warnTimer; interval: 3500; onTriggered: w.warnEmpty = false }
  onCityEditingChanged: {
    w.warnEmpty = false
    if (w.cityEditing) {
      w.hadFocus = false
      editBox.field.text = w.city
      editBox.field.forceActiveFocus()
      editBox.field.selectAll()
    } else {
      editBox.field.focus = false
    }
  }

  SystemClock {
    id: clock
    precision: w.tick ? SystemClock.Seconds : SystemClock.Minutes
  }


  function two(n) { return n < 10 ? "0" + n : String(n) }
  readonly property int hr: clock.date.getHours()
  readonly property string hourPad: w.two(w.h24 ? w.hr : (w.hr % 12 || 12))
  readonly property string hourStr: w.h24 ? w.two(w.hr) : String(w.hr % 12 || 12)
  readonly property string minStr: w.two(clock.date.getMinutes())
  readonly property string mainStr: w.hourStr + ":" + w.minStr
  readonly property string secStr: (w.showSeconds && !w.analog) ? ":" + Qt.formatTime(clock.date, "ss") : ""
  readonly property string apStr: w.h24 ? "" : (w.hr >= 12 ? "PM" : "AM")
  readonly property string suffixStr: (w.secStr + (w.apStr !== "" ? (w.secStr !== "" ? " " : "") + w.apStr : ""))
  readonly property string dateText: w.loc.toString(clock.date, "dddd, d MMMM")

  // ── TimeText: hora grande + sufijo pequeño sobre la misma línea base ──


  component TimeText: Item {
    id: tt
    property string main: ""
    property string suffix: ""
    property real availW: 100
    property real maxH: 60
    property int weight: Font.Bold
    property color tone: Theme.text
    property real ratio: 0.42
    property string family: Theme.fontFamily
    property color suffixTone: Theme.subtext

    readonly property string mainRef: tt.main.replace(/\d/g, "8")
    readonly property string sufRef: tt.suffix.replace(/\d/g, "8").replace(/[AaPp][Mm]/, "MM")
    TextMetrics { id: mm; font.family: tt.family; font.weight: tt.weight; font.pixelSize: 100; text: tt.mainRef }
    TextMetrics { id: ms; font.family: tt.family; font.weight: tt.weight; font.pixelSize: Math.round(100 * tt.ratio); text: tt.sufRef }

    readonly property real gap: tt.suffix !== "" ? 3 : 0
    readonly property real units: Math.max(1, (mm.advanceWidth + (tt.suffix !== "" ? ms.advanceWidth : 0)) / 100)
    readonly property real px: Math.max(10, Math.min(tt.maxH, (tt.availW - tt.gap) * 0.97 / tt.units))

    implicitWidth: Math.round(tt.units * tt.px + tt.gap)
    implicitHeight: mainT.implicitHeight

    WidgetText {
      id: mainT
      text: tt.main
      color: tt.tone
      font.family: tt.family
      font.weight: tt.weight
      font.pixelSize: Math.round(tt.px)
    }
    WidgetText {
      visible: tt.suffix !== ""
      anchors { left: mainT.right; leftMargin: tt.gap; baseline: mainT.baseline }
      text: tt.suffix
      color: tt.suffixTone
      font.family: tt.family
      font.weight: tt.weight === Font.Light ? Font.Normal : Font.DemiBold
      font.pixelSize: Math.max(8, Math.round(tt.px * tt.ratio))
    }
  }

  component TextShadowFx: MultiEffect {
    property real dx: 0
    property real dy: 1
    property real strength: 0.9
    property real spread: 0.4
    shadowEnabled: true
    shadowColor: w.darkText ? Qt.rgba(1, 1, 1, 1) : Qt.rgba(0, 0, 0, 1)
    shadowOpacity: w.darkText ? 0.3 : strength
    shadowBlur: w.darkText ? 0.4 : spread
    shadowHorizontalOffset: dx
    shadowVerticalOffset: dy
  }

  // ── Hand: manecilla = Item del tamaño del reloj que gira sobre su centro ──
  component Hand: Item {
    property real size: 100
    property real angle: 0
    property real length: 0.3
    property real thick: 3
    property color tone: Theme.text
    anchors.fill: parent
    rotation: angle
    Rectangle {
      width: parent.thick
      height: parent.size * parent.length
      x: (parent.size - width) / 2
      y: parent.size / 2 - height
      radius: width / 2
      color: parent.tone
    }
  }

  // ── AnalogFace: esfera reutilizada por «analog» y «hybrid» ──
  component AnalogFace: Item {
    id: af
    property var clk: null
    property bool disc: true
    property bool secHand: true
    property bool ring: false
    property bool dateInside: false
    property real alpha: 0.6
    readonly property real s: Math.min(width, height)
    readonly property var now: af.clk ? af.clk.date : null
    readonly property real hh: af.now ? af.now.getHours() : 0
    readonly property real mm: af.now ? af.now.getMinutes() : 0
    readonly property real ss: af.now ? af.now.getSeconds() : 0


    WidgetBlur {
      allowed: af.disc
      anchors.centerIn: parent
      width: af.s; height: af.s
      radius: width / 2
    }
    MdShape {
      anchors.centerIn: parent
      width: af.s; height: af.s
      shape: "cookie12"
      color: af.disc ? Qt.rgba(Theme.bg.r, Theme.bg.g, Theme.bg.b, af.alpha) : "transparent"
      strokeColor: (af.disc && af.ring) ? Qt.alpha(Theme.primary, 0.85) : Theme.text
      strokeWidth: af.disc ? (af.ring ? 2 : 0) : 2
    }
    Item {
      anchors.centerIn: parent
      width: af.s; height: af.s


      Repeater {
        model: 12
        delegate: Item {
          required property int index
          anchors.fill: parent
          rotation: index * 30
          Rectangle {
            width: index % 3 === 0 ? 3 : 2
            height: index % 3 === 0 ? af.s * 0.07 : af.s * 0.04
            x: (af.s - width) / 2
            y: af.s * 0.05
            radius: 1
            color: index % 3 === 0 ? Theme.text : Theme.subtext
          }
        }
      }

      Hand { size: af.s; angle: ((af.hh % 12) + af.mm / 60) * 30; length: 0.26; thick: 4 }
      Hand { size: af.s; angle: (af.mm + af.ss / 60) * 6; length: 0.38; thick: 3 }
      Hand { visible: af.secHand; size: af.s; angle: af.ss * 6; length: 0.42; thick: 1.5; tone: Theme.primary }

      Rectangle {
        anchors.centerIn: parent
        width: 8; height: 8; radius: 4
        color: Theme.primary
      }

      WidgetText {
        visible: af.dateInside
        anchors { horizontalCenter: parent.horizontalCenter; bottom: parent.bottom; bottomMargin: af.s * 0.2 }
        text: af.now ? w.loc.toString(af.now, "d MMM") : ""
        color: Theme.subtext
        font.family: Theme.fontFamily
        font.pixelSize: Math.max(7, Math.round(af.s * 0.07))
      }
    }
  }

  // ── fondo (todos menos analog, que lleva su propio disco) ──
  WidgetCard {
    visible: w.showBg && !w.analog && !w.fusedStyle
    width: w.serifStyle ? Math.min(w.width, Math.ceil(w.fitW + 2 * w.padX)) : w.width
    height: w.serifStyle ? Math.min(w.height, Math.ceil(w.fitH + 2 * w.padY)) : w.height
    x: Math.round((w.width - width) / 2)
    y: Math.round((w.height - height) / 2)
    alpha: w.bgAlpha
    pill: w.mini
  }

  FusedClock {
    visible: w.fusedStyle
    anchors.fill: parent
    floral: w.sty === "floral"
    now: clock.date
    h24: w.h24
    showSeconds: w.showSeconds
    showDate: w.showDate
    showBg: w.showBg
    bgAlpha: w.bgAlpha
    family: (w.sty === "pixel" && w.customFont === "") ? Theme.pixelFamily : w.serifFamily
    loc: w.loc
  }

  Column {
    visible: w.sty === "digital" || w.sty === "minimal"
    anchors.centerIn: parent
    width: Math.max(10, w.width - 28)
    spacing: 2
    Item {
      width: parent.width
      height: dgTime.implicitHeight
      TimeText {
        id: dgTime
        anchors.horizontalCenter: parent.horizontalCenter
        main: w.mainStr
        suffix: w.suffixStr
        availW: w.width - 28
        maxH: Math.max(12, Math.round(w.height * (w.sty === "minimal" ? 0.62 : 0.5)))
        weight: w.sty === "minimal" ? Font.DemiBold : Font.Bold
      }
    }
    Rectangle {
      anchors.horizontalCenter: parent.horizontalCenter
      width: Math.min(parent.width * 0.4, 120)
      height: 3
      radius: 1.5
      color: Theme.primary
      opacity: 0.55
    }
    Item {
      visible: w.showDate && w.sty === "digital"
      width: parent.width
      height: dgDate.implicitHeight
      Row {
        anchors.horizontalCenter: parent.horizontalCenter
        spacing: 6
        WidgetText {
          anchors.verticalCenter: parent.verticalCenter
          text: OozeIcons.calendar
          color: Theme.primary
          font.family: Theme.monoFamily
          font.pixelSize: Math.max(8, Math.round(w.height * 0.14))
        }
        WidgetText {
          id: dgDate
          anchors.verticalCenter: parent.verticalCenter
          text: w.dateText
          color: Theme.subtext
          font.family: Theme.fontFamily
          font.pixelSize: Math.max(8, Math.round(w.height * 0.16))
        }
      }
    }
  }

  AnalogFace {
    visible: w.analog
    anchors.centerIn: parent
    width: Math.min(w.width, w.height); height: width
    clk: clock
    disc: w.showBg
    ring: w.showBorder
    alpha: w.bgAlpha
    secHand: true
    dateInside: w.showDate
  }


  Item {
    id: hy
    visible: w.hybrid
    anchors { fill: parent; margins: 14 }
    readonly property real faceS: Math.min(hy.height, Math.round(hy.width * 0.46))
    readonly property real gap: 18
    readonly property real textMax: Math.max(20, hy.width - hy.faceS - hy.gap)

    Row {
      anchors.centerIn: parent
      spacing: hy.gap

      AnalogFace {
        id: hyFace
        anchors.verticalCenter: parent.verticalCenter
        width: hy.faceS; height: hy.faceS
        clk: clock
        disc: false
        secHand: true
        alpha: w.bgAlpha
      }
      Column {
        anchors.verticalCenter: parent.verticalCenter
        width: Math.min(hy.textMax, Math.max(hyTime.implicitWidth,
                                             w.showDate ? hyDay.implicitWidth : 0,
                                             w.showDate ? hyWeek.implicitWidth : 0))
        spacing: 2
        TimeText {
          id: hyTime
          main: w.mainStr
          suffix: w.suffixStr
          availW: hy.textMax
          maxH: Math.max(14, Math.round(hy.height * 0.46))
          weight: Font.Light
        }
        WidgetText {
          id: hyDay
          visible: w.showDate
          width: parent.width
          elide: Text.ElideRight
          text: w.loc.toString(clock.date, "d MMMM")
          color: Theme.text
          font.family: Theme.fontFamily
          font.pixelSize: Theme.fs(Math.max(10, Math.round(hy.height * 0.12)))
        }
        WidgetText {
          id: hyWeek
          visible: w.showDate
          width: parent.width
          elide: Text.ElideRight
          text: { const t = w.loc.toString(clock.date, "dddd"); return t.charAt(0).toUpperCase() + t.slice(1) }
          color: Theme.subtext
          font.family: Theme.fontFamily
          font.pixelSize: Theme.fs(Math.max(10, Math.round(hy.height * 0.11)))
        }
      }
    }
  }


  Column {
    id: vt
    visible: w.vertical
    anchors { fill: parent; margins: 12 }
    spacing: 2
    readonly property real extras: (w.suffixStr !== "" ? 22 : 0) + (w.showDate ? 22 : 0) + 10
    readonly property real px: Math.max(14, Math.min((vt.height - vt.extras) / 2 / 1.1, vt.width * 0.97 / Math.max(0.5, vtm.advanceWidth / 100)))

    TextMetrics {
      id: vtm
      font.family: Theme.fontFamily
      font.weight: Font.Black
      font.bold: true
      font.pixelSize: 100
      text: "88"
    }

    WidgetText {
      width: parent.width; height: Math.round(vt.px * 1.05)
      horizontalAlignment: Text.AlignHCenter; verticalAlignment: Text.AlignVCenter
      text: w.hourPad
      color: Theme.primary
      font.family: Theme.fontFamily; font.weight: Font.Black; font.bold: true
      font.pixelSize: Math.round(vt.px)
    }
    Rectangle {
      anchors.horizontalCenter: parent.horizontalCenter
      width: Math.min(parent.width * 0.4, 48)
      height: 3
      radius: 1.5
      color: Theme.subtext
      opacity: 0.55
    }
    WidgetText {
      width: parent.width; height: Math.round(vt.px * 1.05)
      horizontalAlignment: Text.AlignHCenter; verticalAlignment: Text.AlignVCenter
      text: w.minStr
      color: Theme.primary
      font.family: Theme.fontFamily; font.weight: Font.Black; font.bold: true
      font.pixelSize: Math.round(vt.px)
    }
    WidgetText {
      visible: w.suffixStr !== ""
      width: parent.width; height: 22
      horizontalAlignment: Text.AlignHCenter; verticalAlignment: Text.AlignVCenter
      text: w.suffixStr
      color: Theme.subtext
      font.family: Theme.fontFamily
      font.pixelSize: Theme.fs(12)
      fontSizeMode: Text.Fit; minimumPixelSize: 8; maximumLineCount: 1
    }
    WidgetText {
      visible: w.showDate
      width: parent.width; height: 22
      horizontalAlignment: Text.AlignHCenter; verticalAlignment: Text.AlignVCenter
      text: w.loc.toString(clock.date, "ddd d MMM")
      color: Theme.subtext
      font.family: Theme.fontFamily
      font.pixelSize: Theme.fs(10)
      fontSizeMode: Text.Fit; minimumPixelSize: 7; maximumLineCount: 1
    }
  }

  Item {
    id: wxv
    visible: w.wxStyle
    anchors {
      fill: parent
      margins: w.mini ? 12 : 14
      leftMargin: w.mini ? 22 : 14
      rightMargin: w.mini ? 22 : 14
    }
    opacity: w.cityEditing ? 0.2 : 1
    Behavior on opacity { NumberAnimation { duration: Theme.animDuration(150) } }
    readonly property real paneW: Math.round(wxv.width * (w.mini ? 0.32 : 0.34))

    Row {
      id: wxRow
      anchors.centerIn: parent
      height: parent.height
      spacing: 14
      readonly property real leftMax: Math.max(20, wxv.width - wxv.paneW - 2 * wxRow.spacing - 1)

      Column {
        id: wxLeft
        anchors.verticalCenter: parent.verticalCenter
        width: Math.min(wxRow.leftMax, Math.max(wxTime.implicitWidth,
                                                wxDateA.visible ? wxDateA.implicitWidth : 0,
                                                wxDateB.visible ? wxDateB.implicitWidth : 0))
        spacing: 2
        TimeText {
          id: wxTime
          main: w.mainStr
          suffix: w.suffixStr
          availW: wxRow.leftMax
          maxH: Math.max(14, Math.round(wxv.height * (w.mini ? 0.72 : 0.5)))
          weight: Font.DemiBold
        }
        WidgetText {
          id: wxDateA
          visible: w.showDate && !w.mini
          width: parent.width
          elide: Text.ElideRight
          text: w.loc.toString(clock.date, "d MMM yyyy")
          color: Theme.subtext
          font.family: Theme.fontFamily
          font.pixelSize: Theme.fs(Math.max(10, Math.round(wxv.height * 0.12)))
        }
        WidgetText {
          id: wxDateB
          visible: w.showDate && !w.mini
          width: parent.width
          elide: Text.ElideRight
          text: { const t = w.loc.toString(clock.date, "dddd"); return t.charAt(0).toUpperCase() + t.slice(1) }
          color: Theme.text
          font.family: Theme.fontFamily
          font.pixelSize: Theme.fs(Math.max(10, Math.round(wxv.height * 0.12)))
        }
      }

      Rectangle {
        id: wxDiv
        anchors.verticalCenter: parent.verticalCenter
        height: parent.height - 8
        width: 1
        color: Theme.divider
      }

      Item {
        id: wxPane
        width: wxv.paneW
        height: parent.height

        MouseArea {
          anchors.fill: parent
          hoverEnabled: true
          cursorShape: Qt.PointingHandCursor
          onContainsMouseChanged: w.paneHover = containsMouse
          onClicked: w.cityEditing = true
        }
        ColumnLayout {
          id: wxCol
          anchors.centerIn: parent
          width: parent.width
          spacing: 2
          readonly property real ic: Math.round(Math.min(wxPane.width * 0.62, wxPane.height * (w.mini ? 0.5 : 0.46)))

          WeatherBadge {
            visible: w.cur !== null
            Layout.alignment: Qt.AlignHCenter
            Layout.preferredWidth: wxCol.ic
            Layout.preferredHeight: wxCol.ic
            code: w.cur ? w.cur.code : 0
            isDay: w.cur ? w.cur.isDay : true
          }
          WidgetText {
            visible: w.cur !== null
            Layout.alignment: Qt.AlignHCenter
            text: w.cur ? w.tmp(w.cur.temp) : ""
            color: Theme.text
            font.bold: true
            font.family: Theme.fontFamily
            font.pixelSize: Math.round(wxv.height * (w.mini ? 0.32 : 0.2))
          }
          WidgetText {
            visible: w.cur === null
            Layout.alignment: Qt.AlignHCenter
            text: "󰖐"
            color: Theme.primary
            font.family: Theme.monoFamily
            font.pixelSize: Math.round(Math.min(wxPane.width * 0.4, wxv.height * 0.34))
          }
          WidgetText {
            visible: w.cur === null
            Layout.fillWidth: true
            horizontalAlignment: Text.AlignHCenter
            wrapMode: Text.WordWrap
            text: w.askCity ? Translations.t("wgWxSetCity") : Translations.t("wgWxLoading")
            color: w.notFound ? Theme.error : Theme.subtext
            font.family: Theme.fontFamily
            font.pixelSize: Theme.fs(10)
          }
        }
      }
    }
  }

  // ── SerifClock: hora grande en serif con AM/PM sobre la línea base ──
  Item {
    id: sf
    visible: w.sty === "serif"
    anchors { fill: parent; margins: 14 }
    layer.enabled: sf.visible && w.shadowOn
    layer.effect: TextShadowFx {}
    TimeText {
      id: sfTime
      anchors.centerIn: parent
      tone: w.ink
      family: w.serifFamily
      main: w.mainStr
      suffix: w.suffixStr
      suffixTone: w.ink
      availW: sf.width
      maxH: Math.max(16, Math.round(sf.height * 0.92))
      weight: Font.Normal
      ratio: 0.3
    }
  }

  // ── SerifDayClock: día de la semana, hora grande y fecha ──
  Column {
    id: sd
    visible: w.sty === "serifday"
    anchors.centerIn: parent
    width: Math.max(10, w.width - 28)
    spacing: 0
    layer.enabled: sd.visible && w.shadowOn
    layer.effect: TextShadowFx {}
    WidgetText {
      id: sdDay
      width: parent.width
      horizontalAlignment: Text.AlignHCenter
      elide: Text.ElideRight
      text: { const t = w.loc.toString(clock.date, "dddd"); return t.charAt(0).toUpperCase() + t.slice(1) }
      color: w.accent
      font.family: w.serifFamily
      font.italic: true
      font.pixelSize: Math.max(10, Math.round(w.height * 0.17))
    }
    Item {
      width: parent.width
      height: sdTime.implicitHeight
      TimeText {
        id: sdTime
        anchors.horizontalCenter: parent.horizontalCenter
        tone: w.ink
        family: w.serifFamily
        main: w.mainStr
        suffix: w.suffixStr
        suffixTone: w.ink
        availW: w.width - 28
        maxH: Math.max(16, Math.round(w.height * 0.5))
        weight: Font.Normal
        ratio: 0.3
      }
    }
    WidgetText {
      id: sdDate
      visible: w.showDate
      width: parent.width
      horizontalAlignment: Text.AlignHCenter
      elide: Text.ElideRight
      text: w.loc.toString(clock.date, "d MMMM yyyy").toUpperCase()
      color: w.inkSoft
      font.family: w.serifFamily
      font.letterSpacing: 3
      font.pixelSize: Math.max(8, Math.round(w.height * 0.075))
    }
  }

  // ── SerifStackClock: horas y minutos apilados con el día en vertical ──
  Item {
    id: sk
    visible: w.sty === "serifstack"
    anchors { fill: parent; margins: 14 }
    readonly property real labelW: Math.round(sk.height * 0.16)
    readonly property real hCoef: 2 * skm.height / 100 - 0.14 + (w.suffixStr !== "" ? 0.1 : 0)
    readonly property real wCoef: Math.max(0.5, skm.advanceWidth / 100)
    readonly property real numPx: Math.max(16, Math.min(sk.height * 0.98 / Math.max(0.5, sk.hCoef),
                                                       (sk.width - 33 - sk.labelW) * 0.97 / sk.wCoef))
    TextMetrics { id: skm; font.family: w.serifFamily; font.weight: Font.Normal; font.pixelSize: 100; text: "88" }
    layer.enabled: sk.visible && w.shadowOn
    layer.effect: TextShadowFx {}

    Row {
      id: skRow
      anchors.centerIn: parent
      spacing: 16

      Column {
        id: skDigits
        anchors.verticalCenter: parent.verticalCenter
        spacing: -sk.numPx * 0.14
        WidgetText {
          text: w.hourPad
          color: w.ink
          font.family: w.serifFamily
          font.weight: Font.Normal
          font.pixelSize: Math.round(sk.numPx)
        }
        WidgetText {
          text: w.minStr
          color: w.accent
          font.family: w.serifFamily
          font.weight: Font.Normal
          font.pixelSize: Math.round(sk.numPx)
        }
        WidgetText {
          visible: w.suffixStr !== ""
          anchors.horizontalCenter: parent.horizontalCenter
          text: w.suffixStr.trim()
          color: w.inkSoft
          font.family: w.serifFamily
          font.letterSpacing: 2
          font.pixelSize: Math.max(8, Math.round(sk.numPx * 0.2))
        }
      }

      Rectangle {
        anchors.verticalCenter: parent.verticalCenter
        width: 1
        height: sk.height * 0.72
        color: w.rule
      }

      Item {
        anchors.verticalCenter: parent.verticalCenter
        width: sk.labelW
        height: Math.round(Math.min(sk.height * 0.98, skDigits.implicitHeight))
        WidgetText {
          anchors.centerIn: parent
          width: parent.height
          height: parent.width
          rotation: -90
          horizontalAlignment: Text.AlignHCenter
          verticalAlignment: Text.AlignVCenter
          text: w.loc.toString(clock.date, "dddd").toUpperCase() + (w.showDate ? " · " + w.loc.toString(clock.date, "d MMM").toUpperCase() : "")
          color: w.inkSoft
          font.family: w.serifFamily
          font.letterSpacing: 2
          font.pixelSize: Math.round(parent.width * 0.8)
          fontSizeMode: Text.Fit
          minimumPixelSize: 9
          maximumLineCount: 1
        }
      }
    }
  }

  // ── SerifCalendarClock: número del día grande con mes, día y hora ──
  Item {
    id: sc
    visible: w.sty === "serifcal"
    anchors { fill: parent; margins: 14 }
    layer.enabled: sc.visible && w.shadowOn
    layer.effect: TextShadowFx {}

    Row {
      id: scRow
      anchors.centerIn: parent
      spacing: 16

      WidgetText {
        id: scDay
        anchors.verticalCenter: parent.verticalCenter
        text: w.loc.toString(clock.date, "d")
        color: w.ink
        font.family: w.serifFamily
        font.weight: Font.Normal
        font.pixelSize: Math.round(sc.height * 0.8)
      }

      Column {
        anchors.verticalCenter: parent.verticalCenter
        width: Math.max(20, Math.min(sc.width - scDay.implicitWidth - 16, Math.max(scWeek.implicitWidth, scMonth.implicitWidth, scHour.implicitWidth)))
        spacing: 2
        WidgetText {
          id: scWeek
          width: parent.width
          elide: Text.ElideRight
          text: { const t = w.loc.toString(clock.date, "dddd"); return t.charAt(0).toUpperCase() + t.slice(1) }
          color: w.ink
          font.family: w.serifFamily
          font.italic: true
          font.pixelSize: Math.max(10, Math.round(sc.height * 0.2))
          fontSizeMode: Text.Fit
          minimumPixelSize: 8
          maximumLineCount: 1
        }
        WidgetText {
          id: scMonth
          width: parent.width
          elide: Text.ElideRight
          text: w.loc.toString(clock.date, "MMMM").toUpperCase()
          color: w.accent
          font.family: w.serifFamily
          font.letterSpacing: 3
          font.pixelSize: Math.max(8, Math.round(sc.height * 0.12))
        }
        WidgetText {
          id: scHour
          width: parent.width
          elide: Text.ElideRight
          text: w.mainStr + (w.suffixStr !== "" ? " " + w.suffixStr.trim() : "")
          color: w.inkSoft
          font.family: w.serifFamily
          font.pixelSize: Math.max(9, Math.round(sc.height * 0.16))
        }
      }
    }
  }

  // ── SerifShadowClock: hora serif con sombra proyectada, día y fecha ──
  Item {
    id: ss
    visible: w.sty === "serifshadow"
    anchors { fill: parent; margins: 14 }
    layer.enabled: ss.visible && w.shadowOn
    layer.effect: TextShadowFx { dx: 2; dy: 5; strength: 0.85; spread: 0.9 }

    Column {
      id: ssCol
      anchors.centerIn: parent
      width: Math.min(ss.width, Math.max(ssTime.implicitWidth, ssDay.implicitWidth))
      spacing: 4
      TimeText {
        id: ssTime
        tone: w.ink
        family: w.serifFamily
        main: w.mainStr
        suffix: w.suffixStr
        suffixTone: w.ink
        availW: ss.width
        maxH: Math.max(16, Math.round(ss.height * 0.64))
        weight: Font.DemiBold
        ratio: 0.3
      }
      Rectangle {
        width: Math.min(ss.width * 0.3, 90)
        height: 3
        radius: 1.5
        color: w.accent
      }
      WidgetText {
        id: ssDay
        width: parent.width
        elide: Text.ElideRight
        text: { const t = w.loc.toString(clock.date, "dddd"); return t.charAt(0).toUpperCase() + t.slice(1) + (w.showDate ? "  ·  " + w.loc.toString(clock.date, "d MMMM") : "") }
        color: w.ink
        font.family: w.serifFamily
        font.italic: true
        font.pixelSize: Math.max(10, Math.round(ss.height * 0.15))
      }
    }
  }

  CityBox {
    id: editBox
    visible: w.cityEditing && w.wxStyle
    z: 21
    anchors { left: parent.left; right: parent.right; verticalCenter: parent.verticalCenter; margins: 12 }
    onSubmitted: text => w.applyCity(text)
    onCancelled: w.cityEditing = false
    onFocusLost: { if (w.cityEditing && w.hadFocus) w.cityEditing = false }
    onFocusGained: w.hadFocus = true
  }
  WidgetText {
    visible: w.cityEditing && w.wxStyle && w.warnEmpty
    z: 21
    anchors { left: editBox.left; right: editBox.right; top: editBox.bottom; topMargin: 3; leftMargin: 10 }
    elide: Text.ElideRight
    color: Theme.error
    font.family: Theme.fontFamily
    font.pixelSize: Theme.fs(10)
    text: Translations.t("wgWxNoCity")
  }
}
