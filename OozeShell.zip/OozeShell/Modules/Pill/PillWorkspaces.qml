// PillWorkspaces.qml — PILL

import QtQuick
import "../../COMMON"


WorkspaceDots {
    id: root


    property string screenName: ""

    useCapsule: false

    workspaces: WM.dotsWorkspacesFor(root.screenName)
}
