// StepDock — WELCOME

import QtQuick
import QtQuick.Layouts
import "../../../Settings"
import "../../../COMMON"
import "../../../Services/Lang"

SettingsPage {
  id: page

  // ─── DOCK ───
  SettingsSection {
    titleKey: "dockSection"

    SettingsRow {
      titleKey: "dockEnable"
      SettingsSwitch {
        checked: Theme.dockEnabled
        onToggled: Theme.setDockEnabled(!Theme.dockEnabled)
      }
    }

    SettingsRow {
      titleKey: "dockAutoHide"
      enabled: Theme.dockUsable
      SettingsSwitch {
        checked: Theme.dockAutoHide
        onToggled: Theme.setDockAutoHide(!Theme.dockAutoHide)
      }
    }

    SettingsRow {
      titleKey: "advDockModeLabel"
      hintKey: "advDockModeHint"
      enabled: Theme.dockUsable
      divider: true
      SettingsChoice {
        model: [
          { value: "panel", label: Translations.t("advDockModePanel"), icon: "󰘔" },
          { value: "pill",  label: Translations.t("advDockModePill"),  icon: "󰋙" }
        ]
        current: Theme.dockMode
        onPicked: v => Theme.setDockMode(v)
      }
    }
  }

  SettingsNote {
    text: Translations.t("welMoreDock")
  }
}
