// StepTerminal — WELCOME

import QtQuick
import QtQuick.Layouts
import "../../../Settings"
import "../../../COMMON"
import "../../../Services/Lang"
import "../../../Services/Terminal"

SettingsPage {
  id: page

  readonly property var terminalChoices: {
    const all = Theme.terminals
    const inst = Theme.installedTerminals
    const list = inst.length === 0 ? all.slice() : all.filter(t => inst.indexOf(t.id) >= 0 || t.id === Theme.terminalId)
    if (!all.some(t => t.id === Theme.terminalId)) list.unshift({ id: Theme.terminalId, name: Theme.terminalId })
    return list.map(t => ({ value: t.id, label: t.name, icon: "󰆍" }))
  }

  readonly property bool scriptReady: TerminalConfig.fastfetch.scriptFound === true
  readonly property bool hookReady: TerminalConfig.fastfetch.zshrcHook === true

  Component.onCompleted: TerminalConfig.refresh()

  // ─── TERMINAL ───
  SettingsSection {
    titleKey: "settingsTerminalSection"
    hintKey: "settingsTerminalHint"

    SettingsRow {
      stacked: true
      divider: false
      SettingsChips {
        model: page.terminalChoices
        current: Theme.terminalId
        onPicked: v => Theme.setTerminal(v)
      }
    }
  }

  // ─── FASTFETCH ───
  SettingsSection {
    titleKey: "termFastfetchTitle"
    hintKey: "termFastfetchHint"

    SettingsNote {
      visible: TerminalConfig.loaded && !page.scriptReady
      kind: "warn"
      text: Translations.t("termFastfetchNoScript")
    }

    SettingsNote {
      visible: TerminalConfig.loaded && page.scriptReady && !page.hookReady
      kind: "warn"
      text: Translations.t("termFastfetchNoHook")
    }

    SettingsRow {
      titleKey: "termFastfetchEnable"
      hintKey: "termFastfetchEnableHint"
      SettingsSwitch {
        checked: TerminalConfig.fastfetchEnabled
        onToggled: TerminalConfig.setFastfetch(!TerminalConfig.fastfetchEnabled)
      }
    }

    SettingsRow {
      titleKey: "termFastfetchRandom"
      hintKey: "termFastfetchRandomHint"
      divider: true
      enabled: TerminalConfig.fastfetchEnabled
      SettingsSwitch {
        checked: TerminalConfig.fastfetchRandom
        onToggled: TerminalConfig.setRandom(!TerminalConfig.fastfetchRandom)
      }
    }
  }

  SettingsNote {
    text: Translations.t("welMoreTerminal")
  }
}
