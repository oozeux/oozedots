// StepThanks — WELCOME

import QtQuick
import QtQuick.Layouts
import "../../../Settings"
import "../../../COMMON"
import "../../../Services/Lang"
import ".."

SettingsPage {
  id: page

  readonly property string repoUrl: "https://github.com/oozeux/oozedots"

  // ─── GRACIAS ───
  SettingsSection {
    titleKey: "welThanksTitle"
    hintKey: "welThanksText"

    SettingsRow {
      stacked: true
      divider: false
      Flow {
        Layout.fillWidth: true
        spacing: 8

        SettingsBtn {
          primary: true
          icon: "󰊤"
          text: Translations.t("welThanksRepo")
          onClicked: Qt.openUrlExternally(page.repoUrl)
        }
        SettingsBtn {
          icon: "󰆏"
          text: Translations.t("welThanksCopy")
          onClicked: WelcomePackages.copy(page.repoUrl)
        }
      }
    }
  }
}
