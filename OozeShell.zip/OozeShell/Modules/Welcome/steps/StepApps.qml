// StepApps — WELCOME

import QtQuick
import QtQuick.Layouts
import "../../../Settings"
import "../../../COMMON"
import "../../../Services/Lang"
import "../../../Services/DefaultApps"

SettingsPage {
  id: page

  readonly property var roleIds: ["browser", "files", "editor"]

  Component.onCompleted: DefaultApps.refreshMime()

  // ─── APPS ESENCIALES ───
  Repeater {
    model: DefaultApps.roles.filter(r => page.roleIds.indexOf(r.id) >= 0)

    delegate: SettingsSection {
      id: sec
      required property var modelData
      readonly property var opts: DefaultApps.choicesFor(sec.modelData.id)

      titleKey: sec.modelData.nameKey

      SettingsRow {
        stacked: true
        divider: false
        SettingsChips {
          model: sec.opts.map(o => ({
            value: o.id,
            label: o.id === "system" ? Translations.t("daSystem") : (o.id === "custom" ? Translations.t("daCustom") : o.name)
          }))
          current: DefaultApps.choiceOf(sec.modelData.id)
          onPicked: v => DefaultApps.setChoice(sec.modelData.id, v)
        }
      }
    }
  }

  SettingsNote {
    text: Translations.t("welMoreApps")
  }
}
