// StepLanguage — WELCOME

import QtQuick
import QtQuick.Layouts
import "../../../Settings"
import "../../../COMMON"
import "../../../Services/Lang"

SettingsPage {
  id: page

  // ─── IDIOMA ───
  SettingsSection {
    titleKey: "settingsLanguage"
    hintKey: "welLanguageHint"

    SettingsRow {
      stacked: true
      divider: false
      SettingsChips {
        model: Translations.availableLanguages.map(l => ({ value: l.code, label: l.name, icon: "󰗊" }))
        current: Translations.current
        onPicked: v => page.host.languageChosen(v)
      }
    }
  }

  // ─── RESUMEN ───
  SettingsSection {
    titleKey: "welIncludesTitle"

    SettingsNote {
      text: Translations.t("welIncludes")
    }
  }
}
