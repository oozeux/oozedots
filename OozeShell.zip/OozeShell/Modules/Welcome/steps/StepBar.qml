// StepBar — WELCOME

import QtQuick
import QtQuick.Layouts
import "../../../Settings"
import "../../../COMMON"
import "../../../Services/Lang"

SettingsPage {
  id: page

  readonly property bool waybarReady: WM.isInstalled("waybar")

  readonly property string style: Theme.pillModePref ? "pill"
    : (Theme.barBackend === "waybar" && page.waybarReady ? "waybar"
    : (Theme.islandsPref ? "islands" : "bar"))

  // ─── LÓGICA ───
  function chooseStyle(v) {
    if (v !== "bar" && Theme.barVertical) Theme.setBarPosition("top")
    if (v === "pill") { Theme.setPillModeEnabled(true); return }
    Theme.setPillModeEnabled(false)
    if (v === "waybar") { Theme.setIslandsEnabled(false); Theme.setBarBackend("waybar"); return }
    Theme.setBarBackend("ooze")
    Theme.setIslandsEnabled(v === "islands")
  }

  // ─── ESTILO ───
  SettingsSection {
    titleKey: "welBarStyle"
    hintKey: "welBarStyleHint"

    SettingsRow {
      stacked: true
      SettingsChoice {
        model: [
          { value: "bar",     label: Translations.t("welBarStyleBar"),     icon: "▀" },
          { value: "islands", label: Translations.t("welBarStyleIslands"), icon: "󰕰" },
          { value: "pill",    label: Translations.t("welBarStylePill"),    icon: "●" },
          { value: "waybar",  label: Translations.t("barWaybar"),          icon: "▬", enabled: page.waybarReady }
        ]
        current: page.style
        onPicked: v => page.chooseStyle(v)
      }
    }

    SettingsNote {
      visible: !page.waybarReady
      kind: "info"
      text: Translations.t("barWaybarMissing")
    }
  }

  // ─── POSICIÓN ───
  SettingsSection {
    visible: page.style === "bar" || page.style === "islands"
    titleKey: "barPosition"

    SettingsRow {
      stacked: true
      divider: false
      SettingsChoice {
        model: page.style === "bar" ? [
          { value: "top",    label: Translations.t("barTop"),    icon: "▀" },
          { value: "bottom", label: Translations.t("barBottom"), icon: "▄" },
          { value: "left",   label: Translations.t("barLeft"),   icon: "▌" },
          { value: "right",  label: Translations.t("barRight"),  icon: "▐" }
        ] : [
          { value: "top",    label: Translations.t("barTop"),    icon: "▀" },
          { value: "bottom", label: Translations.t("barBottom"), icon: "▄" }
        ]
        current: Theme.barPosition
        onPicked: v => Theme.setBarPosition(v)
      }
    }
  }

  SettingsNote {
    text: Translations.t("welMoreBar")
  }
}
