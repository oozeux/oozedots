// StepAi — WELCOME

import QtQuick
import QtQuick.Layouts
import "../../../Settings"
import "../../../COMMON"
import "../../../Services/Lang"

SettingsPage {
  id: page

  // ─── DÓNDE SE AJUSTA ───
  SettingsSection {
    titleKey: "welAiTitle"
    hintKey: "welAiHint"

    SettingsNote { text: Translations.t("welAiWhere") }
    SettingsNote { text: Translations.t("welAiKey") }
    SettingsNote { text: Translations.t("welAiOpen") }
  }

  SettingsBtn {
    icon: "󰒓"
    text: Translations.t("welOpenSettings")
    onClicked: page.host.requestSettings()
  }
}
