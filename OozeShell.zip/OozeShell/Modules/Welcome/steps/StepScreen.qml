// StepScreen — WELCOME

import Quickshell
import QtQuick
import QtQuick.Layouts
import "../../../Settings"
import "../../../COMMON"
import "../../../Services/Lang"

SettingsPage {
  id: page

  readonly property string targetMonitor: page.host ? page.host.targetMonitor : "auto"
  readonly property string resolvedMonitor: page.host ? page.host.resolvedMonitor : ""

  readonly property var monitorChoices: [{ value: "auto", label: Translations.t("monitorAutoOption"), icon: "󰍹" }]
    .concat(Quickshell.screens.map(s => ({ value: s.name, label: s.name, icon: "󰍹" })))

  readonly property var levelNames: [
    Translations.t("sizeSmall"), Translations.t("sizeMedium"), Translations.t("sizeNormal"),
    Translations.t("sizeLarge"), Translations.t("sizeHuge")
  ]
  readonly property int masterLevel: Theme.barLevel === Theme.windowLevel ? Theme.barLevel : -1

  // ─── MONITOR DEL SHELL ───
  SettingsSection {
    titleKey: "settingsMonitor"
    hintKey: "welMonitorHint"

    SettingsRow {
      hint: page.targetMonitor === "auto" && page.resolvedMonitor !== ""
        ? Translations.t("monitorAutoHint") + " " + page.resolvedMonitor
        : Translations.t("monitorAutoSubtitle")
      stacked: true
      divider: false
      SettingsChips {
        model: page.monitorChoices
        current: page.targetMonitor
        onPicked: v => page.host.monitorChosen(v)
      }
    }
  }

  // ─── AJUSTE DE PANTALLA ───
  SettingsSection {
    titleKey: "welDisplayTitle"
    hintKey: "welDisplayHint"

    Repeater {
      model: Quickshell.screens
      delegate: SettingsRow {
        required property var modelData
        title: modelData.name
        hint: modelData.width + "×" + modelData.height
      }
    }

    SettingsRow {
      visible: WM.has("monitorEditor")
      titleKey: "welDisplayEditor"
      hintKey: "welDisplayEditorHint"
      divider: true
      SettingsBtn {
        primary: true
        icon: "󰍹"
        text: Translations.t("welDisplayOpen")
        onClicked: page.host.requestMonitorEditor()
      }
    }

    SettingsNote {
      visible: !WM.has("monitorEditor")
      text: Translations.t("welDisplayUnsupported")
    }
  }

  // ─── TAMAÑO DE LA INTERFAZ ───
  SettingsSection {
    titleKey: "uiSizeTitle"
    hintKey: "uiSizeHint"

    SettingsRow {
      stacked: true
      divider: false
      LevelPicker {
        level: page.masterLevel
        names: page.levelNames
        showNames: true
        onPicked: index => Theme.setInterfaceLevel(index)
      }
    }
  }

  // ─── MARCO DE PANTALLA ───
  SettingsSection {
    visible: WM.has("screenFrame")
    titleKey: "welFrameTitle"

    SettingsRow {
      titleKey: "welFrame"
      hintKey: "welFrameHint"
      divider: false
      SettingsSwitch {
        checked: page.host ? page.host.screenCorners : false
        onToggled: page.host.requestCornersToggle()
      }
    }
  }
}
