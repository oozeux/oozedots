// StepFolders — WELCOME

import QtQuick
import QtQuick.Layouts
import "../../../Settings"
import "../../../COMMON"
import "../../../Services/Lang"
import "../../../Services/Screenshot"

SettingsPage {
  id: page

  readonly property string wallRoot: Theme.wallpaperDir !== "" ? Theme.wallpaperDir : "~/Pictures/Wallpapers"

  // ─── WALLPAPERS ───
  SettingsSection {
    titleKey: "welFoldersWalls"
    hintKey: "welFoldersWallsHint"

    SettingsRow {
      titleKey: "wallsFolderStatic"
      stacked: true
      FolderField {
        placeholder: "~/Pictures/Wallpapers"
        current: Theme.wallpaperDir
        onChosen: path => Theme.setWallpaperDir(path.trim())
      }
    }

    SettingsRow {
      titleKey: "wallsFolderLive"
      stacked: true
      FolderField {
        placeholder: page.wallRoot + "/Live"
        current: Theme.liveWallpaperDir
        onChosen: path => Theme.setLiveWallpaperDir(path.trim())
      }
    }

    SettingsRow {
      titleKey: "wallsOnlineSaveDir"
      hintKey: "welFoldersDownloadsHint"
      stacked: true
      divider: true
      FolderField {
        placeholder: page.wallRoot + "/Online"
        current: Theme.onlineSaveDir
        onChosen: path => Theme.setWallsOpt("onlineSaveDir", path.trim())
      }
    }
  }

  // ─── WALLHAVEN ───
  SettingsSection {
    titleKey: "welWallhavenTitle"
    hintKey: "welWallhavenHint"

    SettingsRow {
      titleKey: "wallsOnlineApiKey"
      stacked: true
      divider: false
      SettingsField {
        secret: true
        value: Theme.onlineApiKey
        onSubmitted: text => Theme.setWallsOpt("onlineApiKey", text)
      }
    }
  }

  // ─── CAPTURAS Y GRABACIONES ───
  SettingsSection {
    titleKey: "welFoldersCapture"
    hintKey: "welFoldersCaptureHint"

    SettingsRow {
      titleKey: "capShotDir"
      stacked: true
      FolderField {
        placeholder: "~/Pictures/Screenshots"
        current: CaptureConfig.shotDir
        onChosen: path => CaptureConfig.set("shotDir", path.trim())
      }
    }

    SettingsRow {
      titleKey: "capRecDir"
      stacked: true
      divider: true
      FolderField {
        placeholder: "~/Videos/Recordings"
        current: CaptureConfig.recDir
        onChosen: path => CaptureConfig.set("recDir", path.trim())
      }
    }
  }
}
