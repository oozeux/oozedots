// StepQuickSearch — WELCOME

import QtQuick
import QtQuick.Layouts
import "../../../Settings"
import "../../../COMMON"
import "../../../Services/Lang"
import "../../../Modules/QuickBar"

SettingsPage {
  id: page

  readonly property var browserChoices: {
    const out = [{ value: "default", label: Translations.t("qbBrowserDefault"), icon: "󰖟" }]
    const inst = QuickBarConfig.installedBrowsers
    const all = QuickBarConfig.browsers
    for (let i = 0; i < all.length; i++)
      if (inst.indexOf(all[i].id) >= 0 || all[i].id === QuickBarConfig.browserId)
        out.push({ value: all[i].id, label: all[i].name, icon: "󰖟" })
    return out
  }

  // ─── APARIENCIA ───
  SettingsSection {
    titleKey: "qbLookTitle"
    hintKey: "qbLookHint"

    SettingsRow {
      titleKey: "qbPosition"
      SettingsChoice {
        model: [
          { value: "top",    label: Translations.t("qbPosTop") },
          { value: "center", label: Translations.t("qbPosCenter") },
          { value: "bottom", label: Translations.t("qbPosBottom") }
        ]
        current: QuickBarConfig.position
        onPicked: v => QuickBarConfig.set("position", v)
      }
    }

    SettingsRow {
      titleKey: "qbWidth"
      divider: true
      SettingsChoice {
        model: [
          { value: "compact", label: Translations.t("qbWidthCompact") },
          { value: "normal",  label: Translations.t("qbWidthNormal") },
          { value: "wide",    label: Translations.t("qbWidthWide") }
        ]
        current: QuickBarConfig.widthMode
        onPicked: v => QuickBarConfig.set("widthMode", v)
      }
    }
  }

  // ─── NAVEGADOR ───
  SettingsSection {
    titleKey: "qbBrowserTitle"
    hintKey: "qbBrowserHint"

    SettingsRow {
      titleKey: "qbBrowserPref"
      stacked: true
      divider: false
      SettingsChips {
        model: page.browserChoices
        current: QuickBarConfig.browserId
        onPicked: v => QuickBarConfig.set("browserId", v)
      }
    }
  }

  SettingsNote {
    text: Translations.t("welMoreQuick")
  }
}
