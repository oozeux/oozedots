// StepLock — WELCOME

import QtQuick
import QtQuick.Layouts
import "../../../Settings"
import "../../../COMMON"
import "../../../Services/Lang"
import "../../Lock"

SettingsPage {
  id: page

  // ─── FONDO ───
  SettingsSection {
    titleKey: "olBackgroundTitle"
    hintKey: "olBackgroundHint"

    SettingsRow {
      hint: Translations.t(Theme.lockWallpaperMode === "custom" ? "lockCustomHint" : "lockAutoHint")
      stacked: true
      divider: false
      SettingsChoice {
        model: [
          { value: "auto",   label: Translations.t("lockModeAuto"),   icon: "󰸉" },
          { value: "custom", label: Translations.t("lockModeCustom"), icon: "󰋩" }
        ]
        current: Theme.lockWallpaperMode
        onPicked: v => Theme.setLockWallpaperMode(v)
      }
    }

    SettingsRow {
      visible: Theme.lockWallpaperMode === "custom"
      stacked: true
      SettingsField {
        placeholder: Translations.t("lockPathPlaceholder")
        value: Theme.lockWallpaperPath
        onSubmitted: text => Theme.setLockWallpaperPath(text)
      }
    }
  }

  // ─── DISTRIBUCIÓN ───
  SettingsSection {
    titleKey: "olLayoutTitle"
    hintKey: "olLayoutHint"

    SettingsRow {
      stacked: true
      divider: false
      LockLayoutPicker {
        current: LockConfig.layout
        onPicked: v => LockConfig.setValue("layout", v)
      }
    }
  }

  // ─── RELOJ ───
  SettingsSection {
    titleKey: "olInfoTitle"

    SettingsRow {
      titleKey: "olClock24h"
      SettingsSwitch {
        checked: LockConfig.clock24h
        onToggled: LockConfig.setValue("clock24h", !LockConfig.clock24h)
      }
    }

    SettingsRow {
      titleKey: "olClockStyle"
      stacked: true
      divider: true
      SettingsChips {
        model: [
          { value: "classic", label: Translations.t("olClockStyleClassic"), icon: "󰥔" },
          { value: "stacked", label: Translations.t("olClockStyleStacked"), icon: "󰕮" },
          { value: "mono",    label: Translations.t("olClockStyleMono"),    icon: "󰇘" },
          { value: "boxed",   label: Translations.t("olClockStyleBoxed"),   icon: "󰆾" },
          { value: "analog",  label: Translations.t("olClockStyleAnalog"),  icon: "󰅐" }
        ]
        current: LockConfig.clockStyle
        onPicked: v => LockConfig.setValue("clockStyle", v)
      }
    }
  }

  SettingsNote {
    text: Translations.t("welMoreLock")
  }
}
