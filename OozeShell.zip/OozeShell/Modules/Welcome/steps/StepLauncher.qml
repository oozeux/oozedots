// StepLauncher — WELCOME

import QtQuick
import QtQuick.Layouts
import "../../../Settings"
import "../../../COMMON"
import "../../../Services/Lang"

SettingsPage {
  id: page

  readonly property bool rofiReady: WM.isInstalled("rofi")
  readonly property bool useNative: Theme.launcherBackend !== "rofi" || !page.rofiReady

  // ─── MOTOR ───
  SettingsSection {
    titleKey: "lnBackendTitle"
    hintKey: "lnBackendHint"

    SettingsRow {
      stacked: true
      divider: false
      SettingsChoice {
        model: [
          { value: "quickshell", label: Translations.t("lnQuickshell"), icon: "󰀻" },
          { value: "rofi",       label: Translations.t("lnRofi"),       icon: "󰆍", enabled: page.rofiReady }
        ]
        current: page.useNative ? "quickshell" : "rofi"
        onPicked: v => Theme.setLauncherBackend(v)
      }
    }

    SettingsNote {
      visible: !page.rofiReady
      text: Translations.t("lnRofiMissing")
    }
  }

  // ─── UBICACIÓN Y TAMAÑO ───
  SettingsSection {
    titleKey: "settingsLauncherSection"
    hintKey: "settingsLauncherHint"
    enabled: page.useNative

    SettingsRow {
      titleKey: "settingsLauncherPlacement"
      SettingsChoice {
        model: [
          { value: true,  label: Translations.t("settingsLauncherBar"),    icon: "▀" },
          { value: false, label: Translations.t("settingsLauncherCenter"), icon: "▣" }
        ]
        current: Theme.launcherAttached
        onPicked: v => Theme.setLauncherAttached(v)
      }
    }

    SettingsRow {
      titleKey: "settingsLauncherSize"
      divider: true
      SettingsChoice {
        model: [
          { value: 0, label: Translations.t("settingsSizeCompact") },
          { value: 1, label: Translations.t("settingsSizeNormal") },
          { value: 2, label: Translations.t("settingsSizeLarge") }
        ]
        current: Theme.launcherSize
        onPicked: v => Theme.setLauncherSize(v)
      }
    }
  }

  SettingsNote {
    text: Translations.t("welLauncherShortcut")
  }
}
