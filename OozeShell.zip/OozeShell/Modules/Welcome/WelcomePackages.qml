// WelcomePackages — WELCOME

pragma Singleton
import Quickshell
import Quickshell.Io
import QtQuick
import "../../COMMON"

Singleton {
  id: root

  // ─── CATÁLOGO ───
  readonly property var groups: [
    { id: "base",       titleKey: "welPkgBase",       hintKey: "welPkgBaseHint",       required: true },
    { id: "desktop",    titleKey: "welPkgDesktop",    hintKey: "welPkgDesktopHint",    required: false },
    { id: "audio",      titleKey: "welPkgAudio",      hintKey: "welPkgAudioHint",      required: false },
    { id: "capture",    titleKey: "welPkgCapture",    hintKey: "welPkgCaptureHint",    required: false },
    { id: "wallpapers", titleKey: "welPkgWallpapers", hintKey: "welPkgWallpapersHint", required: false },
    { id: "terminal",   titleKey: "welPkgTerminal",   hintKey: "welPkgTerminalHint",   required: false }
  ]

  readonly property var fixed: [
    { bin: "python3",      group: "base",       arch: "python",       nix: "python3" },
    { bin: "jq",           group: "base" },
    { bin: "curl",         group: "base" },
    { bin: "socat",        group: "base" },
    { bin: "notify-send",  group: "base",       arch: "libnotify",    nix: "libnotify" },
    { bin: "xdg-open",     group: "base",       arch: "xdg-utils",    nix: "xdg-utils" },
    { bin: "wl-copy",      group: "desktop",    arch: "wl-clipboard", nix: "wl-clipboard" },
    { bin: "cliphist",     group: "desktop" },
    { bin: "brightnessctl", group: "desktop" },
    { bin: "upower",       group: "desktop" },
    { bin: "secret-tool",  group: "desktop",    arch: "libsecret",    nix: "libsecret" },
    { bin: "fd",           group: "desktop" },
    { bin: "wpctl",        group: "audio",      arch: "wireplumber",  nix: "wireplumber" },
    { bin: "pw-dump",      group: "audio",      arch: "pipewire",     nix: "pipewire" },
    { bin: "pactl",        group: "audio",      arch: "libpulse",     nix: "pulseaudio" },
    { bin: "cava",         group: "audio" },
    { bin: "grim",         group: "capture" },
    { bin: "wf-recorder",  group: "capture" },
    { bin: "ffmpeg",       group: "capture" },
    { bin: "awww",         group: "wallpapers" },
    { bin: "mpvpaper",     group: "wallpapers" },
    { bin: "matugen",      group: "wallpapers" },
    { bin: "aria2c",       group: "wallpapers", arch: "aria2",        nix: "aria2" },
    { bin: "fastfetch",    group: "terminal" },
    { bin: "starship",     group: "terminal" }
  ]

  // ─── ENTRADAS DINÁMICAS ───
  readonly property string terminalBin: {
    const t = Theme.terminals.find(x => x.id === Theme.terminalId)
    return t ? t.exec[0] : Theme.terminalId
  }

  readonly property var entries: {
    const list = root.fixed.slice()
    list.push({ bin: root.terminalBin, group: "terminal", arch: root.terminalBin, nix: root.terminalBin })
    if (Theme.barBackend === "waybar") list.push({ bin: "waybar", group: "desktop" })
    if (Theme.launcherBackend === "rofi") list.push({ bin: "rofi", group: "desktop" })
    return list
  }

  // ─── ESTADO ───
  property var found: ({})
  property bool checked: false
  readonly property bool busy: checkProc.running

  readonly property var missing: root.entries.filter(e => root.checked && root.found[e.bin] === false)
  readonly property var missingRequired: root.missing.filter(e => e.group === "base")
  readonly property int okCount: root.entries.filter(e => root.found[e.bin] === true).length

  function groupEntries(id) { return root.entries.filter(e => e.group === id) }
  function isOk(bin) { return root.found[bin] === true }

  function archName(e) { return e.arch ?? e.bin }
  function nixName(e) { return e.nix ?? e.bin }

  readonly property bool isNix: WM.distro === "nixos"

  function installCommand(list) {
    if (list.length === 0) return ""
    if (root.isNix) return "nix profile install " + list.map(e => "nixpkgs#" + root.nixName(e)).join(" ")
    const helper = WM.packageBackend
    const names = list.map(e => root.archName(e)).join(" ")
    return (helper === "pacman" ? "sudo pacman" : helper) + " -S --needed " + names
  }

  function packageNames(list) {
    return list.map(e => root.isNix ? root.nixName(e) : root.archName(e)).join(" ")
  }

  function searchName(e) { return root.isNix ? root.nixName(e) : root.archName(e) }

  function copy(text) {
    if (text === "") return
    Quickshell.execDetached(["sh", "-c", 'printf %s "$1" | wl-copy', "sh", text])
  }

  // ─── COMPROBACIÓN ───
  function refresh() {
    if (checkProc.running) return
    checkProc.command = ["bash", "-c",
      'export PATH="$HOME/.local/bin:$HOME/.cargo/bin:/run/current-system/sw/bin:$PATH"; ' +
      'for t in "$@"; do if command -v "$t" >/dev/null 2>&1; then echo "$t 1"; else echo "$t 0"; fi; done',
      "sh"].concat(root.entries.map(e => e.bin))
    checkProc.next = ({})
    checkProc.running = true
  }

  Process {
    id: checkProc
    property var next: ({})
    stdout: SplitParser {
      onRead: line => {
        const f = line.trim().split(" ")
        if (f.length === 2) checkProc.next[f[0]] = f[1] === "1"
      }
    }
    onRunningChanged: {
      if (running) return
      root.found = checkProc.next
      root.checked = true
    }
  }
}
