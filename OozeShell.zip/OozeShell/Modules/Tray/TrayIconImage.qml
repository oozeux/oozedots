// TrayIconImage — ícono de un ítem de la bandeja; resuelve a archivo local y nunca usa image://icon.

import QtQuick
import QtQuick.Effects

import "../../COMMON"

Item {
  id: root

  // ─── Entrada ───
  property string raw: ""
  property int texSize: 16
  property string fallbackGlyph: "󰀻"
  property color fallbackColor: Theme.subtext
  property bool adapt: false
  property color tintColor: Theme.text

  // ─── Resolución ───
  readonly property var list: IconResolver.candidates(root.raw)

  property int attempt: 0
  readonly property bool exhausted: root.attempt >= root.list.length
  readonly property bool ready: img.status === Image.Ready

  onListChanged: root.attempt = 0

  // ─── Adaptación a la paleta ───
  readonly property bool namedMono: /symbolic|[-_]mono\b|monochrome/i.test(root.raw)
  property bool sampledMono: false
  property real sampledLum: 1
  readonly property color barColor: Theme.bg
  readonly property real barLum: 0.2126 * root.barColor.r + 0.7152 * root.barColor.g + 0.0722 * root.barColor.b
  readonly property bool lowContrast: Math.abs(root.sampledLum - root.barLum) < 0.35
  readonly property bool iconIsLight: root.sampledLum >= 0.5
  readonly property bool tinted: root.adapt && !root.exhausted && (root.namedMono || root.sampledMono) && root.lowContrast

  Image {
    id: img

    anchors.fill: parent
    sourceSize.width: root.texSize
    sourceSize.height: root.texSize
    fillMode: Image.PreserveAspectFit
    asynchronous: false
    smooth: true
    mipmap: false
    cache: true
    source: root.exhausted ? "" : root.list[root.attempt]

    layer.enabled: root.tinted
    layer.smooth: true
    layer.textureSize: Qt.size(root.texSize, root.texSize)
    layer.effect: MultiEffect {
      brightness: root.iconIsLight ? 0.0 : 0.85
      colorization: 1.0
      colorizationColor: root.tintColor
    }

    onStatusChanged: {
      if (status === Image.Error && root.attempt < root.list.length) root.attempt += 1
    }
  }

  Loader {
    active: root.adapt && root.ready
    sourceComponent: Canvas {
      id: probe

      readonly property int side: 16
      readonly property string src: img.source.toString()

      width: probe.side
      height: probe.side
      opacity: 0
      enabled: false
      renderTarget: Canvas.Image

      function classify(d) {
        let seen = 0, colored = 0, lo = 255, hi = 0, sum = 0, weight = 0
        for (let i = 0; i < d.length; i += 4) {
          if (d[i + 3] < 48) continue
          seen++
          const mx = Math.max(d[i], d[i + 1], d[i + 2])
          const mn = Math.min(d[i], d[i + 1], d[i + 2])
          if (mx - mn > 40) colored++
          const l = 0.2126 * d[i] + 0.7152 * d[i + 1] + 0.0722 * d[i + 2]
          sum += l * d[i + 3]
          weight += d[i + 3]
          if (d[i + 3] >= 160) {
            if (l < lo) lo = l
            if (l > hi) hi = l
          }
        }
        const mono = seen > 6 && colored / seen < 0.06 && (hi - lo) < 110
        return { mono: mono, lum: weight > 0 ? sum / weight / 255 : 1 }
      }

      function begin() {
        if (probe.src === "") return
        const hit = IconResolver.monoMemo[probe.src]
        if (hit !== undefined) { probe.apply(hit); return }
        probe.loadImage(probe.src)
      }

      function apply(r) {
        root.sampledMono = r.mono
        root.sampledLum = r.lum
      }

      onSrcChanged: probe.begin()
      Component.onCompleted: probe.begin()
      onImageLoaded: probe.requestPaint()

      onPaint: {
        if (!probe.isImageLoaded(probe.src)) return
        const ctx = probe.getContext("2d")
        ctx.clearRect(0, 0, probe.side, probe.side)
        ctx.drawImage(probe.src, 0, 0, probe.side, probe.side)
        const r = probe.classify(ctx.getImageData(0, 0, probe.side, probe.side).data)
        IconResolver.rememberMono(probe.src, r)
        probe.apply(r)
      }
    }
  }

  Text {
    anchors.centerIn: parent
    visible: root.exhausted
    text: root.fallbackGlyph
    color: root.fallbackColor
    font.family: Theme.monoFamily
    font.pixelSize: Math.round(root.height * 0.9)
  }
}
