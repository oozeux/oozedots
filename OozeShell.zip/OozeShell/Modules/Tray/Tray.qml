// Tray — bandeja del sistema (reemplaza el módulo "tray" de Waybar).

import Quickshell
import Quickshell.Services.SystemTray
import QtQuick
import QtQuick.Layouts

import "../../COMMON"
import "../../Services/Bluetooth"

BarFlow {
  id: tray


  property int iconSize: 18

  property int cellHeight: 26


  property real renderScale: 1


  property bool adapt: Theme.trayAdaptPref


  property real uiScale: 1


  property bool snapSizes: false
  readonly property var nativeSizes: [16, 22, 24, 32, 48]
  function snap(n) {
    let best = tray.nativeSizes[0]
    for (let i = 0; i < tray.nativeSizes.length; i++) {
      const c = tray.nativeSizes[i]
      if (Math.abs(c - n) <= Math.abs(best - n)) best = c
    }
    return best
  }
  readonly property int drawSize: tray.snapSizes ? tray.snap(tray.iconSize) : tray.iconSize


  readonly property real dpr: Math.max(1, Screen.devicePixelRatio)


  readonly property int texSize:
    Math.max(
      16,
      Math.ceil(tray.drawSize * tray.renderScale * tray.dpr)
    )


  property var activeItem: null

  readonly property bool externalBluetooth: {
    const v = SystemTray.items.values
    for (let i = 0; i < v.length; i++) {
      const it = v[i]
      if (it.status === Status.Passive) continue
      const probe = (String(it.id) + " " + String(it.title) + " " + String(it.tooltipTitle)).toLowerCase()
      if (probe.indexOf("blue") >= 0) return true
    }
    return false
  }

  readonly property bool showBluetooth: BluetoothBackend.trayShown && !tray.externalBluetooth

  readonly property int count: {
    const v = SystemTray.items.values
    let n = tray.showBluetooth ? 1 : 0
    for (let i = 0; i < v.length; i++)
      if (v[i].status !== Status.Passive) n++
    return n
  }

  signal tipEnter(var item)
  signal tipLeave(var item)


  signal menuRequested(var iconItem, var entry)

  gap: 0

  Repeater {
    id: rep

    model: SystemTray.items

    delegate: Rectangle {
      id: trayItem

      required property SystemTrayItem modelData

      visible: modelData.status !== Status.Passive

      readonly property bool active:
        tray.activeItem === trayItem.modelData

      readonly property string tip: {
        const t =
          modelData.tooltipTitle
          || modelData.title
          || modelData.id
          || ""

        const d =
          modelData.tooltipDescription
          || ""

        return d !== "" ? t + "\n" + d : t
      }


      Layout.preferredWidth: Math.max(tray.iconSize, tray.drawSize) + Math.round(8 * tray.uiScale)
      Layout.preferredHeight: Math.round(tray.cellHeight * tray.uiScale)

      radius: Math.round(8 * tray.uiScale)

      color:
        (itemArea.containsMouse || trayItem.active)
        ? tray.hoverColor
        : "transparent"

      Behavior on color {
        ColorAnimation {
          duration: Theme.animDuration(120)
        }
      }


      Item {
        id: iconBox


        x: Math.round((parent.width - width) / 2)
        y: Math.round((parent.height - height) / 2)


        width: tray.drawSize
        height: tray.drawSize

        opacity: itemArea.pressed ? 0.7 : 1.0

        Behavior on opacity {
          NumberAnimation {
            duration: Theme.animDuration(100)
          }
        }

        TrayIconImage {
          id: trayImg

          anchors.fill: parent
          texSize: tray.texSize
          raw: trayItem.modelData.icon
          adapt: tray.adapt
        }
      }

      MouseArea {
        id: itemArea

        anchors.fill: parent

        hoverEnabled: true

        cursorShape: Qt.PointingHandCursor

        acceptedButtons:
          Qt.LeftButton
          | Qt.RightButton
          | Qt.MiddleButton

        onEntered: tray.tipEnter(trayItem)
        onExited: tray.tipLeave(trayItem)

        onClicked: mouse => {
          const it = trayItem.modelData

          if (mouse.button === Qt.RightButton) {

            if (it.hasMenu)
              tray.menuRequested(trayItem, it)
            else
              it.secondaryActivate()

          } else if (mouse.button === Qt.MiddleButton) {

            it.secondaryActivate()

          } else {

            if (it.onlyMenu && it.hasMenu)
              tray.menuRequested(trayItem, it)
            else
              it.activate()
          }
        }
      }
    }
  }

  Rectangle {
    id: btCell

    visible: tray.showBluetooth

    readonly property bool active: tray.activeItem === BluetoothBackend.trayEntry
    readonly property string tip: BluetoothBackend.trayTip

    Layout.preferredWidth: Math.max(tray.iconSize, tray.drawSize) + Math.round(8 * tray.uiScale)
    Layout.preferredHeight: Math.round(tray.cellHeight * tray.uiScale)

    radius: Math.round(8 * tray.uiScale)

    color: (btArea.containsMouse || btCell.active) ? tray.hoverColor : "transparent"

    Behavior on color {
      ColorAnimation { duration: Theme.animDuration(120) }
    }

    Text {
      anchors.centerIn: parent
      text: BluetoothBackend.statusIcon
      color: BluetoothBackend.connectedDevices.length > 0 ? Theme.primary : Theme.text
      font.family: Theme.monoFamily
      font.pixelSize: Math.round(tray.drawSize * 0.95)
      opacity: btArea.pressed ? 0.7 : 1.0

      Behavior on opacity {
        NumberAnimation { duration: Theme.animDuration(100) }
      }
    }

    MouseArea {
      id: btArea

      anchors.fill: parent
      hoverEnabled: true
      cursorShape: Qt.PointingHandCursor
      acceptedButtons: Qt.LeftButton | Qt.RightButton

      onEntered: tray.tipEnter(btCell)
      onExited: tray.tipLeave(btCell)
      onClicked: tray.menuRequested(btCell, BluetoothBackend.trayEntry)
    }
  }
}
