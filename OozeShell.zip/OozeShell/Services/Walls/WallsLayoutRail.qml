// WallsLayoutRail — WALLS
// Columna vertical estrecha pegada al borde de la pantalla: buscador arriba,
// carrusel vertical en medio y controles apilados abajo.

import QtQuick
import QtQuick.Layouts
import "../../COMMON"

Item {
  id: root

  required property var walls
  property real progress: 1

  readonly property int pad: 14
  readonly property int gap: 10
  readonly property int bubbleH: 40
  readonly property real innerW: Math.max(0, root.width - root.pad * 2)

  implicitHeight: col.implicitHeight + root.pad * 2

  ColumnLayout {
    id: col
    x: root.pad
    y: root.pad
    width: root.innerW
    spacing: root.gap

    WallsSearchBar {
      id: search
      walls: root.walls
      compact: true
      narrow: true
      Layout.fillWidth: true
    }

    WallsKindToggle {
      visible: root.walls.onlineMode
      walls: root.walls
      fontSize: 11
      Layout.fillWidth: true
      Layout.preferredHeight: visible ? 30 : 0
    }

    WallsCards {
      id: cards
      walls: root.walls
      progress: root.progress
      vertical: true
      cardAspect: 0.64
      sideLen: 42
      gap: 5
      edgeMargin: 0
      hoverLift: 0
      Layout.fillWidth: true
      Layout.preferredHeight: implicitHeight
    }

    WallsBubble {
      Layout.fillWidth: true
      Layout.preferredHeight: root.bubbleH

      WallsModeToggle {
        walls: root.walls
        compact: true
        anchors { fill: parent; margins: 6 }
      }
    }

    WallsBubble {
      Layout.fillWidth: true
      Layout.preferredHeight: schemes.childrenRect.height + 16

      WallsSchemeChips {
        id: schemes
        walls: root.walls
        chipHeight: 26
        chipPad: 14
        fontSize: 10
        spacing: 6
        columns: Theme.schemeColumns
        anchors { left: parent.left; right: parent.right; top: parent.top; margins: 8 }
      }
    }

    RowLayout {
      Layout.fillWidth: true
      spacing: root.gap

      WallsBubble {
        visible: swatches.shown
        Layout.preferredWidth: swatches.implicitWidth + 20
        Layout.preferredHeight: root.bubbleH

        WallsSourceSwatches {
          id: swatches
          walls: root.walls
          size: 26
          fontSize: 10
          spacing: 6
          anchors.centerIn: parent
        }
      }

      Item { Layout.fillWidth: true }

      WallsCounter {
        walls: root.walls
        pillHeight: root.bubbleH
        fontSize: 11
      }
    }

    WallsBubble {
      Layout.fillWidth: true
      Layout.preferredHeight: root.bubbleH

      WallsActionChips {
        walls: root.walls
        chipHeight: 26
        chipPad: 16
        fontSize: 10
        spacing: 8
        anchors.centerIn: parent
      }
    }
  }

  // ─── MENÚ DE FILTROS / ORDEN ───
  MouseArea {
    anchors.fill: parent
    z: 200
    enabled: root.walls.popup !== ""
    onClicked: root.walls.popup = ""
  }

  WallsPopup {
    walls: root.walls
    fontSize: 11
    width: root.innerW
    z: 201
    x: root.pad
    y: Math.min(root.pad + search.height + 6, Math.max(4, root.height - height - 4))
  }
}
