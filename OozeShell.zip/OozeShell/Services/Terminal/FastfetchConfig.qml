pragma Singleton
import Quickshell
import Quickshell.Io
import QtQuick

Singleton {
  id: root

  // ─── Rutas ───────────────────────────────────────────────────────

  readonly property string home: Quickshell.env("HOME")
  readonly property string backend: Quickshell.shellDir + "/Backends/python/ooze-terminal.py"

  function parse(text) {
    try {
      const j = JSON.parse(String(text).trim())
      return j && j.ok === true ? j : null
    } catch (e) { return null }
  }
  function same(a, b) {
    return JSON.stringify(a) === JSON.stringify(b)
  }

  // ─── Estado ──────────────────────────────────────────────────────

  property var data: ({})
  property bool ready: false
  property bool requested: false

  function opt(k, d) {
    const v = root.data[k]
    return v === undefined || v === null ? d : v
  }
  function set(k, v) {
    const c = Object.assign({}, root.data)
    c[k] = v
    root.data = c
    root.queueSave(k, v)
  }

  readonly property string source: root.opt("fastfetchSource", "images")
  readonly property string builtin: root.opt("fastfetchBuiltin", "")
  readonly property string style: root.opt("fastfetchStyle", "config")
  readonly property bool margins: root.opt("fastfetchMargins", false)
  readonly property int padTop: root.opt("fastfetchPadTop", 4)
  readonly property int padBottom: root.opt("fastfetchPadBottom", 0)
  readonly property int padLeft: root.opt("fastfetchPadLeft", 2)
  readonly property int padRight: root.opt("fastfetchPadRight", 2)
  readonly property int logoWidth: root.opt("fastfetchWidth", 0)
  readonly property int logoHeight: root.opt("fastfetchHeight", 0)
  readonly property string position: root.opt("fastfetchPosition", "config")

  // ─── Tipos de entrada ────────────────────────────────────────────

  readonly property var imageTypes: ["detect", "auto", "sixel", "kitty", "kitty-direct", "kitty-icat", "iterm", "chafa", "raw"]
  readonly property var builtinTypes: ["builtin", "small"]
  readonly property var positions: ["config", "auto", "left", "top", "right"]

  readonly property var validTypes: root.source === "builtin" ? root.builtinTypes : root.imageTypes
  readonly property string storedType: root.opt("fastfetchLogoType", "")
  readonly property string logoType: root.validTypes.indexOf(root.storedType) >= 0
    ? root.storedType : root.validTypes[0]

  // ─── Carga ───────────────────────────────────────────────────────

  function ensure() {
    if (root.requested) return
    root.requested = true
    initProc.running = true
  }
  Process {
    id: initProc
    command: ["python3", root.backend, "init"]
    stdout: StdioCollector {
      onStreamFinished: {
        const j = root.parse(text)
        if (j) {
          root.data = j.data || {}
          root.ansiText = j.ansi || ""
        }
        root.ready = true
      }
    }
  }

  // ─── Guardado ────────────────────────────────────────────────────

  property var pendingKeys: ({})

  function queueSave(k, v) {
    const p = Object.assign({}, root.pendingKeys)
    p[k] = v
    root.pendingKeys = p
    saveDebounce.restart()
  }
  function flushSave() {
    saveDebounce.stop()
    if (Object.keys(root.pendingKeys).length === 0) return
    if (saver.running) { saver.again = true; return }
    saver.payload = JSON.stringify(root.pendingKeys)
    root.pendingKeys = ({})
    saver.running = true
  }
  Timer {
    id: saveDebounce
    interval: 200
    onTriggered: root.flushSave()
  }
  Process {
    id: saver
    property string payload: ""
    property bool again: false
    command: ["python3", root.backend, "save"]
    environment: ({ "OOZE_DATA": saver.payload })
    onRunningChanged: {
      if (running || !saver.again) return
      saver.again = false
      root.flushSave()
    }
  }

  // ─── Presets ─────────────────────────────────────────────────────

  readonly property var fallbackPresets: ["all", "archey", "ci", "neofetch", "paleofetch", "screenfetch"]
    .concat(Array.from({ length: 31 }, (_, i) => "examples/" + (i + 2)))
  property var presets: root.fallbackPresets
  property bool presetsRequested: false

  readonly property var styleChoices: ["config"].concat(root.presets)

  function presetLabel(name) {
    return name.indexOf("examples/") === 0 ? "#" + name.slice(9) : name
  }
  function refreshPresets() {
    if (root.presetsRequested || presetProc.running) return
    root.presetsRequested = true
    presetProc.running = true
  }
  Process {
    id: presetProc
    command: ["python3", root.backend, "presets"]
    stdout: StdioCollector {
      onStreamFinished: {
        const j = root.parse(text)
        if (j && j.presets && j.presets.length > 0 && !root.same(root.presets, j.presets)) root.presets = j.presets
      }
    }
  }

  // ─── Vista previa de módulos ─────────────────────────────────────

  property var previewCache: ({})
  readonly property string preview: root.previewCache[root.style] ?? ""
  readonly property bool previewing: previewProc.running || previewDebounce.running
  property bool previewForce: false

  function refreshPreview(force) {
    if (force) root.previewForce = true
    else if (root.previewCache[root.style] !== undefined) return
    previewDebounce.restart()
  }
  function runPreview() {
    if (previewProc.running) { previewProc.pendingRun = true; return }
    previewProc.target = root.style
    previewProc.mode = root.previewForce ? "force" : "cache"
    root.previewForce = false
    previewProc.running = true
  }
  Timer {
    id: previewDebounce
    interval: 300
    onTriggered: root.runPreview()
  }
  Process {
    id: previewProc
    property string target: "config"
    property string mode: "cache"
    property bool pendingRun: false
    command: ["python3", root.backend, "preview", previewProc.target, previewProc.mode]
    stdout: StdioCollector {
      onStreamFinished: {
        const j = root.parse(text)
        if (j && j.html) {
          const c = Object.assign({}, root.previewCache)
          c[previewProc.target] = j.html
          root.previewCache = c
        }
      }
    }
    onRunningChanged: {
      if (running) return
      if (!previewProc.pendingRun) return
      previewProc.pendingRun = false
      if (root.previewForce || root.previewCache[root.style] === undefined) previewDebounce.restart()
    }
  }

  // ─── Logo ANSI ───────────────────────────────────────────────────

  property string ansiText: ""
  property string renderHtml: ""
  property int renderLines: 0
  property int renderCols: 0
  property bool renderDirty: false
  property bool renderQueued: false

  function render(text) {
    renderProc.draft = text
    if (renderProc.running) { root.renderQueued = true; return }
    renderProc.running = true
  }
  Process {
    id: renderProc
    property string draft: ""
    command: ["python3", root.backend, "render"]
    environment: ({ "OOZE_DATA": renderProc.draft })
    stdout: StdioCollector {
      onStreamFinished: {
        const j = root.parse(text)
        if (!j) return
        root.renderHtml = j.html
        root.renderLines = j.lines
        root.renderCols = j.cols
        root.renderDirty = j.dirty
      }
    }
    onRunningChanged: {
      if (running) return
      if (!root.renderQueued) return
      root.renderQueued = false
      renderProc.running = true
    }
  }

  function saveAnsi(text) {
    ansiSaver.draft = text
    if (ansiSaver.running) ansiSaver.pending = true
    else ansiSaver.running = true
  }
  Process {
    id: ansiSaver
    property string draft: ""
    property bool pending: false
    command: ["python3", root.backend, "save-ansi"]
    environment: ({ "OOZE_DATA": ansiSaver.draft })
    stdout: StdioCollector {
      onStreamFinished: {
        const j = root.parse(text)
        if (!j) return
        root.ansiText = j.text
        root.renderDirty = false
        root.data = Object.assign({}, root.data, { fastfetchSource: "ansi" })
      }
    }
    onRunningChanged: {
      if (running) return
      if (ansiSaver.pending) { ansiSaver.pending = false; ansiSaver.running = true }
    }
  }

  property string imported: ""
  property int importSeq: 0

  function importAnsi(path) {
    if (path === "" || importProc.running) return
    importProc.path = path
    importProc.running = true
  }
  Process {
    id: importProc
    property string path: ""
    command: ["python3", root.backend, "import", importProc.path]
    stdout: StdioCollector {
      onStreamFinished: {
        const j = root.parse(text)
        if (!j) return
        root.imported = j.text
        root.importSeq++
      }
    }
  }
}
