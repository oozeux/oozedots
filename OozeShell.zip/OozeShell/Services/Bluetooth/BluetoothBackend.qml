// BluetoothBackend — estado y acciones de Bluetooth (BlueZ, vía Quickshell.Bluetooth).

pragma Singleton
import QtQuick
import Quickshell
import Quickshell.Bluetooth
import "../Lang"

Singleton {
  id: root

  // ─── Quién está mirando ────────────────────────────────────────

  property bool panelWatch: false

  property bool scanRequested: true

  // ─── Adaptador ─────────────────────────────────────────────────
  readonly property var adapter: Bluetooth.defaultAdapter
  readonly property bool available: adapter !== null && adapter !== undefined
  readonly property bool enabled: available ? adapter.enabled : false
  readonly property bool scanning: available ? adapter.discovering : false

  function setEnabled(on) {
    if (root.available) root.adapter.enabled = on
  }


  Binding {
    target: root.adapter
    property: "discovering"
    value: root.scanRequested && root.enabled
    when: root.available && root.panelWatch
  }

  onPanelWatchChanged: {
    if (panelWatch) scanRequested = true
    else if (available) adapter.discovering = false
  }

  // ─── Dispositivos ──────────────────────────────────────────────
  readonly property var allDevices: available ? adapter.devices.values : []

  readonly property var connectedDevices: allDevices.filter(d => d.connected)


  function looksLikeAddress(n) {
    return n === "" || /^([0-9a-f]{2}[-:]){5}[0-9a-f]{2}$/i.test(n)
  }

  function isBusy(d) {
    return d.pairing
      || d.state === BluetoothDeviceState.Connecting
      || d.state === BluetoothDeviceState.Disconnecting
  }

  function rank(d) {
    if (d.connected || root.isBusy(d)) return 0
    if (d.paired) return 1
    return 2
  }


  readonly property var devices: {
    const list = root.allDevices.filter(d => d.paired || d.connected || !root.looksLikeAddress(d.name))
    return list.sort((a, b) => (root.rank(a) - root.rank(b)) || String(a.name).localeCompare(String(b.name)))
  }

  // ─── Textos / íconos ───────────────────────────────────────────
  readonly property string summary: {
    if (!available) return "—"
    if (!enabled) return Translations.t("btOffSummary")
    const n = connectedDevices.length
    if (n === 0) return Translations.t("btOnSummary")
    if (n === 1) return connectedDevices[0].name
    return n + " " + Translations.t("btDevices")
  }

  readonly property string statusIcon: {
    if (!available || !enabled) return "󰂲"
    return connectedDevices.length > 0 ? "󰂱" : "󰂯"
  }


  function deviceGlyph(icon) {
    const i = String(icon || "")
    if (i.indexOf("headset") !== -1 || i.indexOf("headphone") !== -1) return "󰋋"
    if (i.indexOf("audio") !== -1) return "󰓃"
    if (i.indexOf("keyboard") !== -1) return "󰌌"
    if (i.indexOf("mouse") !== -1 || i.indexOf("tablet") !== -1) return "󰍽"
    if (i.indexOf("gaming") !== -1) return "󰊗"
    if (i.indexOf("phone") !== -1) return "󰏲"
    if (i.indexOf("computer") !== -1) return "󰌢"
    return "󰂯"
  }

  function statusText(d) {
    if (d.pairing) return Translations.t("btPairing")
    if (d.state === BluetoothDeviceState.Connecting) return Translations.t("btConnecting")
    if (d.state === BluetoothDeviceState.Disconnecting) return Translations.t("btDisconnecting")
    if (d.connected) {
      const bat = d.batteryAvailable ? "  ·  " + Math.round(d.battery * 100) + "%" : ""
      return Translations.t("btConnected") + bat
    }
    if (d.paired) return Translations.t("btPaired")
    return ""
  }

  // ─── Acciones ──────────────────────────────────────────────────


  property var pairingDevice: null

  Connections {
    target: root.pairingDevice
    ignoreUnknownSignals: true

    function onPairedChanged() {
      const d = root.pairingDevice
      if (d && d.paired) {
        root.pairingDevice = null
        d.trusted = true
        d.connect()
      }
    }

    function onPairingChanged() {
      const d = root.pairingDevice
      if (d && !d.pairing && !d.paired) root.pairingDevice = null
    }
  }


  function activate(d) {
    if (root.isBusy(d)) return
    if (d.connected) d.disconnect()
    else if (d.paired) d.connect()
    else {
      root.pairingDevice = d
      d.pair()
    }
  }

  function forget(d) {
    if (root.pairingDevice === d) root.pairingDevice = null
    d.forget()
  }

  // ─── Entrada de la bandeja ─────────────────────────────────────
  readonly property bool trayShown: available && enabled

  readonly property string trayTip: Translations.t("btTitle") + " · " + summary

  function trayRow(text, glyph, enabled, fn) {
    return { isSeparator: false, hasChildren: false, enabled: enabled, icon: "", text: text, glyph: glyph, triggered: fn }
  }

  function traySeparator() {
    return { isSeparator: true, hasChildren: false, enabled: false, icon: "", text: "", glyph: "", triggered: () => {} }
  }

  function trayItems() {
    const out = [root.trayRow(Translations.t("btTurnOff"), "󰂲", true, () => root.setEnabled(false))]
    const known = root.devices.filter(d => d.paired || d.connected)
    if (known.length > 0) out.push(root.traySeparator())
    for (let i = 0; i < known.length; i++) {
      const d = known[i]
      const st = root.statusText(d)
      out.push(root.trayRow(d.name + (st !== "" ? "  ·  " + st : ""), root.deviceGlyph(d.icon), !root.isBusy(d), () => root.activate(d)))
    }
    return out
  }

  readonly property var trayEntry: QtObject {
    readonly property bool custom: true
    readonly property string title: root.trayTip
    readonly property string glyph: root.statusIcon
    readonly property var items: root.trayItems()
  }
}
