// BatteryBarIcon.qml — BATTERY

import QtQuick
import QtQuick.Layouts
import QtQuick.Shapes
import "../../COMMON"


GridLayout {
  id: root

  property string batteryStyle: "compact"
  property bool showPercent: true
  property real percentage: 1
  property bool charging: false
  property bool full: false
  property bool low: false
  property int iconHeight: 12

  // ── Estado ──
  readonly property real pct: Math.max(0, Math.min(1, root.percentage))
  readonly property string label: String(Math.round(root.pct * 100))
  readonly property color tone: root.low ? Theme.error
                               : (root.charging || root.full) ? Theme.primary
                               : Theme.text
  readonly property bool vertical: Theme.barVertical
  readonly property int textPx: Math.max(9, Theme.fs(11))
  readonly property bool textOn: root.showPercent && root.batteryStyle !== "classic"

  readonly property var levelGlyphs: [0xF008E, 0xF007A, 0xF007B, 0xF007C, 0xF007D, 0xF007E,
                                      0xF007F, 0xF0080, 0xF0081, 0xF0082, 0xF0079]
  readonly property string glyph: root.charging ? String.fromCodePoint(0xF0084)
                                  : String.fromCodePoint(root.levelGlyphs[Math.min(10, Math.round(root.pct * 10))])

  // ── Disposición ──
  flow: root.vertical ? GridLayout.LeftToRight : GridLayout.TopToBottom
  columns: root.vertical ? 1 : -1
  rows: root.vertical ? -1 : 1
  columnSpacing: 4
  rowSpacing: 1

  // ── Clásico y compacto ──
  BatteryIcon {
    visible: root.batteryStyle === "classic" || root.batteryStyle === "compact"
    Layout.alignment: Qt.AlignCenter
    percentage: root.percentage
    charging: root.charging
    full: root.full
    low: root.low
    showPercent: root.batteryStyle === "classic"
    iconHeight: root.batteryStyle === "classic" ? root.iconHeight : Math.max(8, Math.round(root.iconHeight * 0.8))
  }

  // ── Glifo ──
  Text {
    visible: root.batteryStyle === "glyph"
    Layout.alignment: Qt.AlignCenter
    text: root.glyph
    color: root.tone
    font.family: Theme.monoFamily
    font.pixelSize: Math.max(13, Theme.fs(15))
  }

  // ── Anillo ──
  Item {
    id: ring
    visible: root.batteryStyle === "ring"
    Layout.alignment: Qt.AlignCenter
    readonly property int size: Math.max(14, root.iconHeight + 4)
    readonly property real stroke: Math.max(2, Math.round(ring.size * 0.17))
    Layout.preferredWidth: ring.size
    Layout.preferredHeight: ring.size

    Shape {
      anchors.fill: parent
      antialiasing: true
      preferredRendererType: Shape.CurveRenderer

      ShapePath {
        strokeWidth: ring.stroke
        strokeColor: Theme.tint(0.16)
        fillColor: "transparent"
        capStyle: ShapePath.FlatCap
        PathAngleArc {
          centerX: ring.size / 2; centerY: ring.size / 2
          radiusX: (ring.size - ring.stroke) / 2; radiusY: (ring.size - ring.stroke) / 2
          startAngle: -90; sweepAngle: 359.9
        }
      }
      ShapePath {
        strokeWidth: ring.stroke
        strokeColor: root.tone
        fillColor: "transparent"
        capStyle: Theme.cozy ? ShapePath.FlatCap : ShapePath.RoundCap
        PathAngleArc {
          centerX: ring.size / 2; centerY: ring.size / 2
          radiusX: (ring.size - ring.stroke) / 2; radiusY: (ring.size - ring.stroke) / 2
          startAngle: -90; sweepAngle: Math.max(root.pct > 0 ? 8 : 0, 359.9 * root.pct)
          Behavior on sweepAngle { NumberAnimation { duration: Theme.animDuration(200); easing.type: Easing.OutCubic } }
        }
      }
    }

    Text {
      anchors.centerIn: parent
      visible: root.charging
      text: String.fromCodePoint(0xF140B)
      color: Theme.primary
      font.family: Theme.monoFamily
      font.pixelSize: Math.round(ring.size * 0.5)
    }
  }

  // ── Barra fina ──
  Rectangle {
    visible: root.batteryStyle === "bar"
    Layout.alignment: Qt.AlignCenter
    Layout.preferredWidth: root.vertical ? 22 : 30
    Layout.preferredHeight: 6
    radius: Theme.cozy ? 0 : height / 2
    color: Theme.tint(0.16)
    antialiasing: !Theme.cozy

    Rectangle {
      width: root.pct <= 0 ? 0 : Math.max(3, Math.round(parent.width * root.pct))
      height: parent.height
      radius: parent.radius
      color: root.tone
      antialiasing: !Theme.cozy
      Behavior on width { NumberAnimation { duration: Theme.animDuration(200); easing.type: Easing.OutCubic } }
      Behavior on color { ColorAnimation { duration: Theme.animDuration(150) } }
    }
  }

  // ── Porcentaje ──
  Text {
    visible: root.textOn
    Layout.alignment: Qt.AlignCenter
    text: root.label + "%"
    color: root.low ? Theme.error : (root.charging ? Theme.primary : Theme.text)
    font.bold: true
    font.family: Theme.fontFamily
    font.pixelSize: root.textPx
  }
}
