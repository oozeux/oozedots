// ScreenshotBackend.qml — SCREENSHOT

pragma Singleton
import QtQuick
import Quickshell
import Quickshell.Io
import "../../COMMON"
import "../Lang"

QtObject {
  id: root


  property int borderWidth: 2

  property real backgroundOpacity: 0.1

  property real settleDelay: 0.3

  // ─── Selección de área (con la pantalla congelada) ───────────────


  property bool pickerOpen: false

  property string pickerMode: "copy"


  property bool capturing: false


  property int freezeSettleMs: 90

  function openPicker(mode) {
    if (root.pickerOpen) return
    root.pickerMode = mode
    root.capturing = false
    root.pickerOpen = true
  }
  function closePicker() {
    root.pickerOpen = false
    root.capturing = false
  }

  function areaCopy() { root.openPicker("copy") }
  function areaSave() { root.openPicker("save") }

  // ─── Editor de anotaciones ───────────────────────────────────────

  property bool editorOpen: false

  property string editRaw: ""

  property string editScreen: ""

  property real editDpr: 1

  readonly property string tmpDir: Quickshell.env("XDG_RUNTIME_DIR") || "/tmp"

  function areaEdit() {
    if (root.pickerOpen || root.editorOpen) return
    root.editRaw = root.tmpDir + "/oozeshell-edit-" + Date.now() + ".png"
    root.openPicker("edit")
  }
  function colorPick() { root.openPicker("color") }

  function openEditor() { root.editorOpen = true }
  function closeEditor(discard) {
    root.editorOpen = false
    if (discard && root.editRaw !== "") Quickshell.execDetached(["rm", "-f", root.editRaw])
  }

  function captureCommand(geo) {
    if (root.pickerMode === "edit") return CaptureConfig.editShotCommand(geo, root.editRaw)
    if (root.pickerMode === "color") return CaptureConfig.colorCommand(geo)
    return CaptureConfig.shotCommand(root.pickerMode === "copy", geo)
  }

  function fullSave() {
    Quickshell.execDetached(CaptureConfig.shotCommand(false, ""))
  }
}
