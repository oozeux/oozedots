// EditorToolbar — SCREENSHOT EDITOR

import QtQuick
import "../../COMMON"
import "../Lang"

Rectangle {
  id: bar

  property var editor

  readonly property var tools: [
    { id: "pen", g: "󰏫", k: "edPen" },
    { id: "marker", g: "󰙒", k: "edMarker" },
    { id: "arrow", g: "󰁜", k: "edArrow" },
    { id: "rect", g: "󰹟", k: "edRect" },
    { id: "ellipse", g: "󰝦", k: "edEllipse" },
    { id: "text", g: "󰊄", k: "edText" },
    { id: "picker", g: "󰈊", k: "edPicker" }
  ]
  readonly property var palette: ["#ef4444", "#f97316", "#facc15", "#22c55e", "#06b6d4", "#3b82f6", "#a855f7", "#ffffff", "#111111"]

  width: row.implicitWidth + 24
  height: 52
  radius: 16
  color: Theme.bg
  border.width: Theme.bw1
  border.color: Theme.edge

  // ── Componentes ──

  component TBtn: Item {
    id: b
    property string glyph: ""
    property bool active: false
    property bool dim: false
    property string tip: ""
    property var host: null
    signal clicked()
    width: 36
    height: 36
    opacity: b.dim ? 0.35 : 1

    Rectangle {
      anchors.fill: parent
      radius: 10
      color: b.active ? Theme.primary : (ma.containsMouse ? Theme.withAlpha(Theme.text, 0.12) : "transparent")
    }
    Text {
      anchors.centerIn: parent
      text: b.glyph
      color: b.active ? Theme.textOnPrimary : Theme.text
      font.family: Theme.monoFamily
      font.pixelSize: 18
    }
    MouseArea {
      id: ma
      anchors.fill: parent
      hoverEnabled: true
      cursorShape: Qt.PointingHandCursor
      onClicked: if (!b.dim) b.clicked()
      onEntered: if (b.host) b.host.hint = b.tip
      onExited: if (b.host && b.host.hint === b.tip) b.host.hint = ""
    }
  }

  component Sep: Item {
    width: 9
    height: 36
    Rectangle {
      anchors.centerIn: parent
      width: 1
      height: 24
      color: Theme.edge
      opacity: 0.6
    }
  }

  // ── Fila principal ──

  Row {
    id: row
    anchors.centerIn: parent
    spacing: 4

    Repeater {
      model: bar.tools
      TBtn {
        required property var modelData
        glyph: modelData.g
        tip: Translations.t(modelData.k)
        host: bar.editor
        active: bar.editor.tool === modelData.id
        onClicked: bar.editor.setTool(modelData.id)
      }
    }

    Sep {}

    Repeater {
      model: bar.palette
      Item {
        id: sw
        required property string modelData
        width: 26
        height: 36
        readonly property bool on: String(bar.editor.ink).toLowerCase() === sw.modelData
        Rectangle {
          anchors.centerIn: parent
          width: sw.on ? 24 : 20
          height: width
          radius: width / 2
          color: sw.modelData
          border.width: sw.on ? 2 : 1
          border.color: sw.on ? Theme.primary : Theme.edge
        }
        MouseArea {
          anchors.fill: parent
          cursorShape: Qt.PointingHandCursor
          onClicked: bar.editor.ink = sw.modelData
        }
      }
    }

    Sep {}

    Repeater {
      model: [0, 1, 2]
      Item {
        id: sz
        required property int modelData
        width: 30
        height: 36
        Rectangle {
          anchors.fill: parent
          anchors.margins: 3
          radius: 9
          color: bar.editor.sizeIdx === sz.modelData ? Theme.withAlpha(Theme.primary, 0.3) : (szMa.containsMouse ? Theme.withAlpha(Theme.text, 0.12) : "transparent")
        }
        Rectangle {
          anchors.centerIn: parent
          width: 6 + sz.modelData * 4
          height: width
          radius: width / 2
          color: Theme.text
        }
        MouseArea {
          id: szMa
          anchors.fill: parent
          hoverEnabled: true
          cursorShape: Qt.PointingHandCursor
          onClicked: bar.editor.sizeIdx = sz.modelData
          onEntered: bar.editor.hint = Translations.t("edSize")
          onExited: bar.editor.hint = ""
        }
      }
    }

    Sep {}

    TBtn { glyph: "󰕌"; tip: Translations.t("edUndo"); host: bar.editor; dim: !bar.editor.canUndo; onClicked: bar.editor.undo() }
    TBtn { glyph: "󰑎"; tip: Translations.t("edRedo"); host: bar.editor; dim: !bar.editor.canRedo; onClicked: bar.editor.redo() }

    Sep {}

    TBtn { glyph: "󰆏"; tip: Translations.t("edCopy"); host: bar.editor; onClicked: bar.editor.doCopy() }
    TBtn { glyph: "󰆓"; tip: Translations.t("edSave"); host: bar.editor; active: true; onClicked: bar.editor.doSave() }
    TBtn { glyph: "󰅖"; tip: Translations.t("edClose"); host: bar.editor; onClicked: bar.editor.cancel() }
  }
}
