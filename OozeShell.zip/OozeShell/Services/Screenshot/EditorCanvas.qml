// EditorCanvas — SCREENSHOT EDITOR

import QtQuick

Canvas {
  id: cv

  property var items: []
  property var draft: null
  property string family: "sans-serif"

  antialiasing: true

  onItemsChanged: cv.requestPaint()
  onDraftChanged: cv.requestPaint()
  onWidthChanged: cv.requestPaint()
  onHeightChanged: cv.requestPaint()

  // ── Utilidades ──

  function rgba(hex, a) {
    const n = parseInt(hex.slice(1, 7), 16)
    return "rgba(" + ((n >> 16) & 255) + "," + ((n >> 8) & 255) + "," + (n & 255) + "," + a + ")"
  }

  // ── Trazos ──

  function drawPath(ctx, it) {
    const p = it.p
    ctx.beginPath()
    ctx.moveTo(p[0][0], p[0][1])
    if (p.length === 1) ctx.lineTo(p[0][0] + 0.01, p[0][1])
    for (let i = 1; i < p.length - 1; i++) {
      const mx = (p[i][0] + p[i + 1][0]) / 2
      const my = (p[i][1] + p[i + 1][1]) / 2
      ctx.quadraticCurveTo(p[i][0], p[i][1], mx, my)
    }
    if (p.length > 1) ctx.lineTo(p[p.length - 1][0], p[p.length - 1][1])
    ctx.stroke()
  }

  function drawArrow(ctx, it) {
    const x0 = it.a[0], y0 = it.a[1], x1 = it.b[0], y1 = it.b[1]
    const len = Math.hypot(x1 - x0, y1 - y0)
    if (len < 2) return
    const ang = Math.atan2(y1 - y0, x1 - x0)
    const head = Math.min(len, Math.max(14, it.w * 4.5))
    ctx.beginPath()
    ctx.moveTo(x0, y0)
    ctx.lineTo(x1 - Math.cos(ang) * head * 0.7, y1 - Math.sin(ang) * head * 0.7)
    ctx.stroke()
    ctx.beginPath()
    ctx.moveTo(x1, y1)
    ctx.lineTo(x1 - head * Math.cos(ang - 0.42), y1 - head * Math.sin(ang - 0.42))
    ctx.lineTo(x1 - head * Math.cos(ang + 0.42), y1 - head * Math.sin(ang + 0.42))
    ctx.closePath()
    ctx.fill()
  }

  function drawRect(ctx, it) {
    ctx.strokeRect(Math.min(it.a[0], it.b[0]), Math.min(it.a[1], it.b[1]),
                   Math.abs(it.b[0] - it.a[0]), Math.abs(it.b[1] - it.a[1]))
  }

  function drawEllipse(ctx, it) {
    const w = Math.abs(it.b[0] - it.a[0])
    const h = Math.abs(it.b[1] - it.a[1])
    if (w < 1 || h < 1) return
    ctx.beginPath()
    ctx.ellipse(Math.min(it.a[0], it.b[0]), Math.min(it.a[1], it.b[1]), w, h)
    ctx.stroke()
  }

  function drawText(ctx, it) {
    ctx.font = it.px + "px \"" + cv.family + "\""
    ctx.textBaseline = "top"
    const lines = it.s.split("\n")
    for (let i = 0; i < lines.length; i++) ctx.fillText(lines[i], it.x, it.y + i * it.px * 1.25)
  }

  function drawItem(ctx, it) {
    const col = it.t === "marker" ? cv.rgba(it.c, 0.4) : it.c
    ctx.strokeStyle = col
    ctx.fillStyle = col
    ctx.lineWidth = it.w || 1
    ctx.lineCap = it.t === "marker" ? "butt" : "round"
    ctx.lineJoin = "round"
    if (it.t === "pen" || it.t === "marker") cv.drawPath(ctx, it)
    else if (it.t === "arrow") cv.drawArrow(ctx, it)
    else if (it.t === "rect") cv.drawRect(ctx, it)
    else if (it.t === "ellipse") cv.drawEllipse(ctx, it)
    else if (it.t === "text") cv.drawText(ctx, it)
  }

  // ── Pintado ──

  onPaint: {
    const ctx = cv.getContext("2d")
    ctx.clearRect(0, 0, cv.width, cv.height)
    for (let i = 0; i < cv.items.length; i++) cv.drawItem(ctx, cv.items[i])
    if (cv.draft) cv.drawItem(ctx, cv.draft)
  }
}
