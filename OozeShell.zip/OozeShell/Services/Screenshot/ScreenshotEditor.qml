// ScreenshotEditor — SCREENSHOT EDITOR

import Quickshell
import Quickshell.Wayland
import QtQuick

Scope {
  id: root

  readonly property var targets: {
    const m = Quickshell.screens.filter(s => s.name === ScreenshotBackend.editScreen)
    return m.length > 0 ? m : (Quickshell.screens.length > 0 ? [Quickshell.screens[0]] : [])
  }

  Variants {
    model: ScreenshotBackend.editorOpen ? root.targets : []

    delegate: PanelWindow {
      id: win

      required property var modelData
      screen: modelData

      anchors { top: true; bottom: true; left: true; right: true }
      color: "transparent"
      exclusiveZone: -1

      WlrLayershell.layer: WlrLayer.Overlay
      WlrLayershell.namespace: "oozeshell-screenshot-editor"
      WlrLayershell.keyboardFocus: WlrKeyboardFocus.Exclusive

      EditorSurface {
        anchors.fill: parent
        focus: true
      }
    }
  }
}
