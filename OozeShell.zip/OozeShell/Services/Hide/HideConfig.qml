// HideConfig — HIDE

pragma Singleton
import QtQuick
import Quickshell
import Quickshell.Io
import "../../COMMON"
import "../../Core"

Singleton {
  id: root

  // ─── Estado ───
  readonly property var cfg: ConfigService.config.hide ?? ({})
  readonly property bool enabled: root.cfg.enabled !== false
  readonly property bool shellLayers: root.cfg.shellLayers === true
  readonly property string mode: root.cfg.mode === "all" ? "all" : "screencast"
  readonly property var windows: root.cfg.windows ?? []
  readonly property var layers: root.cfg.layers ?? []

  readonly property string shellPattern: "^(oozeshell|quickshell)-"

  function save(patch) {
    const c = Object.assign({}, root.cfg, patch)
    ConfigService.set("hide", c)
    applyTimer.restart()
  }
  function newId() { return Date.now().toString(36) + Math.floor(Math.random() * 1296).toString(36) }

  function regexEscape(s) { return String(s).replace(/[.*+?^${}()|[\]\\]/g, "\\$&") }
  function exact(s) { return "^" + root.regexEscape(s) + "$" }

  // ─── Edición ───
  function setEnabled(on) { root.save({ enabled: on === true }) }
  function setShellLayers(on) { root.save({ shellLayers: on === true }) }
  function setMode(m) { root.save({ mode: m === "all" ? "all" : "screencast" }) }

  function addWindow(appId, title) {
    const a = String(appId ?? "").trim()
    const t = String(title ?? "").trim()
    if (a === "" && t === "") return false
    if (root.windows.some(w => (w.appId ?? "") === a && (w.title ?? "") === t)) return false
    root.save({ windows: root.windows.concat([{ id: root.newId(), appId: a, title: t, on: true }]) })
    return true
  }
  function addLayer(namespace) {
    const n = String(namespace ?? "").trim()
    if (n === "") return false
    if (root.layers.some(l => (l.namespace ?? "") === n)) return false
    root.save({ layers: root.layers.concat([{ id: root.newId(), namespace: n, on: true }]) })
    return true
  }
  function listKey(kind) { return kind === "layer" ? "layers" : "windows" }
  function remove(kind, id) {
    const k = root.listKey(kind)
    const patch = {}
    patch[k] = root[k].filter(r => r.id !== id)
    root.save(patch)
  }
  function toggle(kind, id) {
    const k = root.listKey(kind)
    const patch = {}
    patch[k] = root[k].map(r => r.id === id ? Object.assign({}, r, { on: r.on === false }) : r)
    root.save(patch)
  }
  function isWindowHidden(appId) { return root.windows.some(w => (w.appId ?? "") === appId) }
  function isLayerHidden(namespace) { return root.layers.some(l => (l.namespace ?? "") === namespace) }

  function windowRule(appId) {
    const pat = root.exact(appId)
    return root.windows.find(w => (w.appId ?? "") === pat && (w.title ?? "") === "")
  }
  function layerRule(namespace) {
    const pat = root.exact(namespace)
    return root.layers.find(l => (l.namespace ?? "") === pat)
  }
  function isWindowPicked(appId) { const r = root.windowRule(appId); return !!r && r.on !== false }
  function isLayerPicked(namespace) { const r = root.layerRule(namespace); return !!r && r.on !== false }

  function pickWindow(appId) {
    const r = root.windowRule(appId)
    if (!r) root.addWindow(root.exact(appId), "")
    else if (r.on === false) root.toggle("window", r.id)
    else root.remove("window", r.id)
  }
  function pickLayer(namespace) {
    const r = root.layerRule(namespace)
    if (!r) root.addLayer(root.exact(namespace))
    else if (r.on === false) root.toggle("layer", r.id)
    else root.remove("layer", r.id)
  }

  function get() {
    return JSON.stringify({ enabled: root.enabled, mode: root.mode, shellLayers: root.shellLayers,
                            windows: root.windows, layers: root.layers })
  }

  // ─── Reglas activas ───
  readonly property var activeWindows: root.windows.filter(w => w.on !== false && ((w.appId ?? "") !== "" || (w.title ?? "") !== ""))
  readonly property var activeLayers: {
    const l = root.layers.filter(r => r.on !== false && (r.namespace ?? "") !== "").map(r => r.namespace)
    if (root.shellLayers) l.unshift(root.shellPattern)
    return l
  }

  // ─── Texto por WM ───
  function luaStr(s) {
    let lvl = ""
    while ((s + "]").indexOf("]" + lvl + "]") >= 0) lvl += "="
    return "[" + lvl + "[" + s + "]" + lvl + "]"
  }
  function kdlStr(s) {
    let h = "#"
    while (s.indexOf("\"" + h) >= 0) h += "#"
    return "r" + h + "\"" + s + "\"" + h
  }
  function mangoStr(s) { return String(s).replace(/,/g, ".").replace(/[\r\n]/g, "") }

  function ruleText() {
    const ws = root.enabled ? root.activeWindows : []
    const ls = root.enabled ? root.activeLayers : []
    let s = WmAppearance.commentPrefix + " Auto-generado por OozeShell (HIDE). No editar a mano.\n"
    switch (WM.wm) {
      case "niri": {
        const m = root.mode === "all" ? "screen-capture" : "screencast"
        for (const w of ws) {
          let match = ""
          if ((w.appId ?? "") !== "") match += " app-id=" + root.kdlStr(w.appId)
          if ((w.title ?? "") !== "") match += " title=" + root.kdlStr(w.title)
          s += "\nwindow-rule {\n    match" + match + "\n    block-out-from \"" + m + "\"\n}\n"
        }
        for (const n of ls)
          s += "\nlayer-rule {\n    match namespace=" + root.kdlStr(n) + "\n    block-out-from \"" + m + "\"\n}\n"
        return s
      }
      case "mango": {
        for (const w of ws) {
          let r = "window_rule=shield_when_capture:1"
          if ((w.appId ?? "") !== "") r += ",app_id:" + root.mangoStr(w.appId)
          if ((w.title ?? "") !== "") r += ",title:" + root.mangoStr(w.title)
          s += r + "\n"
        }
        for (const n of ls)
          s += "layer_rule=shield_when_capture:1,no_animation:1,layer_name:" + root.mangoStr(n) + "\n"
        return s
      }
      default: {
        ws.forEach((w, i) => {
          const parts = []
          if ((w.appId ?? "") !== "") parts.push("class = " + root.luaStr(w.appId))
          if ((w.title ?? "") !== "") parts.push("title = " + root.luaStr(w.title))
          s += "\nhl.window_rule({\n    name = \"ooze-hide-window-" + (i + 1) + "\",\n    match = { " + parts.join(", ") + " },\n    no_screen_share = true,\n})\n"
        })
        ls.forEach((n, i) => {
          s += "\nhl.layer_rule({\n    name = \"ooze-hide-layer-" + (i + 1) + "\",\n    match = { namespace = " + root.luaStr(n) + " },\n    no_screen_share = true,\n})\n"
        })
        return s
      }
    }
  }

  // ─── Archivo ───
  readonly property string home: Quickshell.env("HOME")
  readonly property string fileDir: {
    switch (WM.wm) {
      case "mango": return root.home + "/.config/mango/autogen"
      case "niri":  return root.home + "/.config/niri/autogen"
      default:      return root.home + "/.config/hypr/modules/rules/autogen"
    }
  }
  readonly property string fileName: WM.wm === "mango" ? "hide.conf" : (WM.wm === "niri" ? "hide.kdl" : "hide.lua")
  readonly property var reloadCmd: {
    switch (WM.wm) {
      case "mango": return ["mmsg", "dispatch", "reload_config"]
      case "niri":  return []
      default:      return ["hyprctl", "reload"]
    }
  }

  property var queue: []
  function apply() {
    root.queue.push({ dir: root.fileDir, name: root.fileName, content: root.ruleText(), reload: root.reloadCmd })
    root.pump()
  }
  function ensure() { if (ConfigService.ready) root.apply() }
  function pump() {
    if (writer.running || root.queue.length === 0) return
    writer.job = root.queue.shift()
    writer.result = ""
    writer.running = true
  }

  Timer {
    id: applyTimer
    interval: 400
    repeat: false
    onTriggered: root.apply()
  }

  Connections {
    target: ConfigService
    function onLoaded() { root.apply() }
  }
  Connections {
    target: WM
    function onWmChanged() { root.apply() }
  }

  Process {
    id: writer
    property var job: ({ dir: "", name: "", content: "", reload: [] })
    property string result: ""
    command: ["sh", "-c",
      'mkdir -p "$1" && if printf %s "$3" | cmp -s - "$1/$2"; then echo same; else printf %s "$3" > "$1/$2.tmp" && mv "$1/$2.tmp" "$1/$2" && echo written; fi',
      "sh", writer.job.dir, writer.job.name, writer.job.content]
    stdout: SplitParser { onRead: line => writer.result = line.trim() }
    stderr: SplitParser { onRead: line => console.log("[hide] error:", line) }
    onRunningChanged: {
      if (running) return
      if (writer.result === "written" && writer.job.reload.length > 0) Quickshell.execDetached(writer.job.reload)
      root.pump()
    }
  }

  // ─── Detección de ventanas ───
  property var detectedWindows: []

  function collectWindows(list) {
    const byApp = {}
    const out = []
    for (const c of list) {
      const a = c["class"] ?? ""
      if (a === "") continue
      if (byApp[a]) { byApp[a].count += 1; continue }
      byApp[a] = { appId: a, title: c.title ?? "", count: 1 }
      out.push(byApp[a])
    }
    out.sort((x, y) => x.appId.localeCompare(y.appId))
    root.detectedWindows = out
  }
  function scanWindows() { WM.withClients(list => root.collectWindows(list)) }

  // ─── Detección de layers ───
  property var detectedLayers: []
  property var openLayers: ({})

  readonly property var transientLayers: [
    "oozeshell-toasts",
    "oozeshell-alarm-toast",
    "oozeshell-toast-osd",
    "oozeshell-caps-osd",
    "oozeshell-layout-osd",
    "oozeshell-notifications"
  ]
  function isLayerOpen(namespace) { return root.openLayers[namespace] === true }
  property string lastLayer: ""
  property bool scanning: false

  function scanLayers() {
    if (scanner.running) return
    scanner.buffer = ""
    scanner.wmAtStart = WM.wm
    root.scanning = true
    scanner.running = true
  }

  Process {
    id: scanner
    property string buffer: ""
    property string wmAtStart: "hyprland"
    command: WM.wm === "niri" ? ["niri", "msg", "--json", "layers"]
           : (WM.wm === "mango" ? ["mmsg", "get", "last_open_surface"]
                                : ["hyprctl", "layers", "-j"])
    stdout: SplitParser { onRead: line => scanner.buffer += line + "\n" }
    onRunningChanged: {
      if (running) return
      root.scanning = false
      const out = scanner.buffer.trim()
      if (scanner.wmAtStart === "mango") {
        root.lastLayer = out.split("\n")[0].trim()
        return
      }
      const seen = {}
      try {
        const j = JSON.parse(out)
        if (Array.isArray(j)) {
          for (const e of j) if (e && e.namespace) seen[e.namespace] = true
        } else {
          for (const mon in j) {
            const lv = (j[mon] && j[mon].levels) ? j[mon].levels : {}
            for (const k in lv) for (const e of lv[k]) if (e && e.namespace) seen[e.namespace] = true
          }
        }
      } catch (e) { console.log("[hide] no se pudo leer la lista de layers") }
      root.openLayers = seen
      const all = Object.assign({}, seen)
      for (const n of root.transientLayers) all[n] = true
      root.detectedLayers = Object.keys(all).sort()
    }
  }
}
