// NightLightBackend — luz nocturna: temperatura de color de la pantalla (hyprsunset en Hyprland, wlsunset o gammastep en el resto).

pragma Singleton
import QtQuick
import Quickshell
import Quickshell.Io
import "../../Core"

Singleton {
  id: root

  // ─── Configuración ───
  readonly property var cfg: ConfigService.config.nightlight ?? ({})
  function opt(k, d) {
    const v = root.cfg[k]
    return v === undefined || v === null ? d : v
  }
  function set(k, v) {
    const c = Object.assign({}, root.cfg)
    c[k] = v
    ConfigService.set("nightlight", c)
  }

  readonly property bool enabled: root.opt("enabled", false)
  readonly property int temperature: Math.max(1000, Math.min(6500, root.opt("temperature", 4500)))
  readonly property int gamma: Math.max(50, Math.min(100, root.opt("gamma", 100)))
  readonly property string mode: root.opt("mode", "manual")
  readonly property string startTime: root.opt("start", "20:00")
  readonly property string endTime: root.opt("end", "07:00")
  readonly property string tool: root.opt("tool", "auto")

  function toggle() { root.set("enabled", !root.enabled) }
  function setEnabled(on) { root.set("enabled", !!on) }
  function setTemperature(t) { root.set("temperature", Math.max(1000, Math.min(6500, Math.round(t)))) }
  function adjust(delta) { root.setTemperature(root.temperature + delta) }

  // ─── Motores disponibles ───
  property var available: ({})
  readonly property bool probed: Object.keys(root.available).length >= 3

  function recheck() { probe.running = true }

  Process {
    id: probe
    command: ["bash", "-c",
      "export PATH=\"$HOME/.local/bin:/run/current-system/sw/bin:$PATH\"; " +
      "for t in hyprsunset wlsunset gammastep; do " +
      "if command -v \"$t\" >/dev/null 2>&1; then echo \"$t 1\"; else echo \"$t 0\"; fi; done"]
    running: true
    stdout: SplitParser {
      onRead: line => {
        const f = line.trim().split(" ")
        if (f.length !== 2) return
        const a = Object.assign({}, root.available)
        a[f[0]] = f[1] === "1"
        root.available = a
      }
    }
  }

  readonly property string resolved: {
    const hypr = CompositorPlatform.isHyprland
    const order = root.tool === "auto"
      ? (hypr ? ["hyprsunset", "wlsunset", "gammastep"] : ["wlsunset", "gammastep"])
      : [root.tool]
    for (const t of order) {
      if (t === "hyprsunset" && !hypr) continue
      if (root.available[t] === true) return t
    }
    return ""
  }

  // ─── Programación ───
  property int nowMin: root.minutesNow()
  function minutesNow() {
    const d = new Date()
    return d.getHours() * 60 + d.getMinutes()
  }
  function parseMin(s) {
    const m = /^(\d{1,2}):(\d{2})$/.exec(String(s).trim())
    if (!m) return -1
    const h = parseInt(m[1]), mi = parseInt(m[2])
    return h > 23 || mi > 59 ? -1 : h * 60 + mi
  }
  readonly property bool inWindow: {
    const s = root.parseMin(root.startTime), e = root.parseMin(root.endTime)
    if (s < 0 || e < 0 || s === e) return true
    return s < e ? (root.nowMin >= s && root.nowMin < e) : (root.nowMin >= s || root.nowMin < e)
  }

  Timer {
    interval: 30000
    repeat: true
    running: root.enabled && root.mode === "schedule"
    onTriggered: root.nowMin = root.minutesNow()
  }

  readonly property bool applied: root.enabled && root.resolved !== "" && (root.mode === "manual" || root.inWindow)

  // ─── Proceso ───
  readonly property var command: {
    const t = root.temperature
    switch (root.resolved) {
      case "hyprsunset": return ["hyprsunset", "-t", String(t), "-g", String(root.gamma)]
      case "wlsunset":   return ["wlsunset", "-t", String(t), "-T", String(t + 1), "-S", "07:00", "-s", "19:00"]
      case "gammastep":  return ["gammastep", "-O", String(t), "-b", (root.gamma / 100).toFixed(2)]
    }
    return []
  }
  readonly property string signature: root.applied ? root.command.join(" ") : ""

  property bool failed: false
  property string runSig: ""
  property double startedAt: 0

  function sync() {
    if (proc.running) { proc.running = false; return }
    if (root.signature === "" || root.failed) return
    root.runSig = root.signature
    root.startedAt = Date.now()
    proc.command = root.command
    proc.running = true
  }

  onSignatureChanged: debounce.restart()

  Timer {
    id: debounce
    interval: 300
    onTriggered: { root.failed = false; root.sync() }
  }

  Process {
    id: proc
    onExited: {
      if (root.runSig === root.signature && Date.now() - root.startedAt < 1500) root.failed = true
      root.sync()
    }
  }
}
