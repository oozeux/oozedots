// AudioService.qml — data

pragma Singleton

import QtQuick
import Quickshell
import Quickshell.Io


Singleton {
    id: root

    property string scriptPath:
        decodeURIComponent(Qt.resolvedUrl("../backend/audio.sh").toString().replace("file://", ""))

    property bool busy: false

    property var outputs: []
    property var inputs: []
    property var sinks: []
    property var sources: []
    property var streams: []
    property var links: []
    property var appStreams: []
    property var appLinks: []

    signal refreshed()
    signal commandFailed(string message)


    function shellQuote(str) {
        return "'" + String(str).replace(/'/g, "'\\''") + "'";
    }

    function parseTsv(text) {
        return text
            .split("\n")
            .filter(function (line) { return line.length > 0; })
            .map(function (line) { return line.split("\t"); });
    }


    function destinationCandidates() {
        return root.sinks.filter(function (s) {
            return s.name.indexOf("ooze_") !== 0;
        });
    }

    function sourceCandidates() {
        return root.sources.filter(function (s) {
            return s.name.indexOf("ooze_") !== 0;
        });
    }

    function monitorCandidates() {
        return root.sinks.slice();
    }

    function isAppConnected(key, inputName) {
        for (var i = 0; i < root.appLinks.length; i++) {
            if (root.appLinks[i].key === key && root.appLinks[i].input === inputName)
                return true;
        }
        return false;
    }

    function appCandidates(inputName) {
        var seen = {};
        var out = [];

        root.appStreams.forEach(function (s) {
            if (seen[s.key]) return;
            seen[s.key] = true;
            out.push({ key: s.key, label: s.label || s.key });
        });

        root.appLinks.forEach(function (l) {
            if (l.input !== inputName || seen[l.key]) return;
            seen[l.key] = true;
            out.push({ key: l.key, label: l.key });
        });

        return out.map(function (a) {
            return Object.assign({}, a, { connected: root.isAppConnected(a.key, inputName) });
        });
    }

    function isConnected(srcName, dstName) {
        for (var i = 0; i < root.links.length; i++) {
            if (root.links[i].src === srcName && root.links[i].dst === dstName)
                return true;
        }
        return false;
    }


    function refreshAll() {
        outputsProc.running = true;
        inputsProc.running = true;
        sinksProc.running = true;
        sourcesProc.running = true;
        streamsProc.running = true;
        linksProc.running = true;
        root.refreshRouting();
    }

    function refreshRouting() {
        appStreamsProc.running = true;
        appLinksProc.running = true;
        linksProc.running = true;
    }

    Process {
        id: outputsProc
        command: ["bash", "-c", root.scriptPath + " outputs"]
        stdout: StdioCollector {
            onStreamFinished: {
                root.outputs = root.parseTsv(text).map(function (f) {
                    return {
                        id: f[0], name: f[1] || "", desc: f[2] || f[1] || "",
                        volume: parseInt(f[3] || "0") || 0,
                        muted: f[4] === "1"
                    };
                });
                root.refreshed();
            }
        }
    }

    Process {
        id: inputsProc
        command: ["bash", "-c", root.scriptPath + " inputs"]
        stdout: StdioCollector {
            onStreamFinished: {
                root.inputs = root.parseTsv(text).map(function (f) {
                    return {
                        id: f[0], name: f[1] || "", desc: f[2] || f[1] || "",
                        volume: parseInt(f[3] || "0") || 0,
                        muted: f[4] === "1"
                    };
                });
            }
        }
    }

    Process {
        id: sinksProc
        command: ["bash", "-c", root.scriptPath + " sinks"]
        stdout: StdioCollector {
            onStreamFinished: {
                root.sinks = root.parseTsv(text).map(function (f) {
                    return {
                        id: f[0], name: f[1] || "", desc: f[2] || f[1] || "",
                        volume: parseInt(f[3] || "0") || 0,
                        muted: f[4] === "1"
                    };
                });
            }
        }
    }

    Process {
        id: sourcesProc
        command: ["bash", "-c", root.scriptPath + " sources"]
        stdout: StdioCollector {
            onStreamFinished: {
                root.sources = root.parseTsv(text).map(function (f) {
                    return { id: f[0], name: f[1] || "", desc: f[2] || f[1] || "" };
                });
            }
        }
    }

    Process {
        id: streamsProc
        command: ["bash", "-c", root.scriptPath + " streams"]
        stdout: StdioCollector {
            onStreamFinished: {
                root.streams = root.parseTsv(text).map(function (f) {
                    return {
                        id: f[0],
                        mediaClass: f[1] || "",
                        app: f[2] || "",
                        name: f[3] || "",
                        desc: f[4] || f[3] || ""
                    };
                });
            }
        }
    }

    Process {
        id: appStreamsProc
        command: ["bash", "-c", root.scriptPath + " app-streams"]
        stdout: StdioCollector {
            onStreamFinished: {
                root.appStreams = root.parseTsv(text).map(function (f) {
                    return { id: f[0], key: f[1] || "", label: f[2] || f[1] || "" };
                });
            }
        }
    }

    Process {
        id: appLinksProc
        command: ["bash", "-c", root.scriptPath + " input-apps"]
        stdout: StdioCollector {
            onStreamFinished: {
                root.appLinks = root.parseTsv(text).map(function (f) {
                    return { input: f[0] || "", key: f[1] || "" };
                });
            }
        }
    }

    Process {
        id: linksProc
        command: ["bash", "-c", root.scriptPath + " links"]
        stdout: StdioCollector {
            onStreamFinished: {
                root.links = root.parseTsv(text).map(function (f) {
                    return { src: f[0] || "", dst: f[1] || "" };
                });
            }
        }
    }


    function createOutput(displayName) {
        root.busy = true;
        mutateProc.command = [
            "bash", "-c",
            root.scriptPath + " create " + root.shellQuote(displayName)
        ];
        mutateProc.running = true;
    }

    function deleteOutput(displayName) {
        root.busy = true;
        mutateProc.command = [
            "bash", "-c",
            root.scriptPath + " delete " + root.shellQuote(displayName)
        ];
        mutateProc.running = true;
    }

    function createInput(displayName) {
        root.busy = true;
        mutateProc.command = [
            "bash", "-c",
            root.scriptPath + " create-input " + root.shellQuote(displayName)
        ];
        mutateProc.running = true;
    }

    function deleteInput(displayName) {
        root.busy = true;
        mutateProc.command = [
            "bash", "-c",
            root.scriptPath + " delete-input " + root.shellQuote(displayName)
        ];
        mutateProc.running = true;
    }

    function setConnection(srcName, dstName, connected) {
        root.busy = true;
        mutateProc.command = [
            "bash", "-c",
            root.scriptPath +
            (connected ? " connect " : " disconnect ") +
            root.shellQuote(srcName) + " " + root.shellQuote(dstName)
        ];
        mutateProc.running = true;
    }


    function setAppConnection(key, inputName, connected) {
        root.busy = true;
        mutateProc.command = [
            "bash", "-c",
            root.scriptPath +
            (connected ? " connect-app " : " disconnect-app ") +
            root.shellQuote(key) + " " + root.shellQuote(inputName)
        ];
        mutateProc.running = true;
    }


    function updateLocalNode(kind, nodeId, patch) {
        var arr = kind === "outputs" ? root.outputs : (kind === "inputs" ? root.inputs : root.sinks);
        var next = arr.map(function (n) {
            return n.id === nodeId ? Object.assign({}, n, patch) : n;
        });
        if (kind === "outputs") root.outputs = next;
        else if (kind === "inputs") root.inputs = next;
        else root.sinks = next;
    }

    function setVolume(kind, nodeId, percent) {
        var pct = Math.max(0, Math.min(150, Math.round(percent)));
        root.updateLocalNode(kind, nodeId, { volume: pct });
        volumeProc.command = [
            "bash", "-c",
            root.scriptPath + " volume-set " + root.shellQuote(nodeId) + " " + pct
        ];
        volumeProc.running = false;
        volumeProc.running = true;
    }

    function setMute(kind, nodeId, muted) {
        root.updateLocalNode(kind, nodeId, { muted: muted });
        volumeProc.command = [
            "bash", "-c",
            root.scriptPath + " mute-set " + root.shellQuote(nodeId) + " " + (muted ? "1" : "0")
        ];
        volumeProc.running = false;
        volumeProc.running = true;
    }

    Process {
        id: volumeProc
        stdout: StdioCollector {}
        stderr: StdioCollector { id: volumeErr }
        onExited: function (exitCode) {
            if (exitCode !== 0) {
                root.commandFailed(volumeErr.text.trim() || "Volume command failed");


                root.refreshAll();
            }
        }
    }

    Process {
        id: mutateProc
        stdout: StdioCollector { id: mutateOut }
        stderr: StdioCollector { id: mutateErr }
        onExited: function (exitCode) {
            root.busy = false;


            root.refreshAll();
            if (exitCode !== 0) {
                var msg = mutateErr.text.trim() || mutateOut.text.trim() || "Command failed";
                root.commandFailed(msg);
            }
        }
    }

    Component.onCompleted: refreshAll()
}
