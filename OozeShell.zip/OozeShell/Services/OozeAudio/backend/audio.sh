# audio.sh — backend

set -u

SCRIPT_NAME="$(basename "$0")"

# ============================================================================


# ============================================================================


# ============================================================================

# ============================================================================

die() {
    echo "ERROR: $*" >&2
    exit 1
}


require_command() {
    command -v "$1" >/dev/null 2>&1 || \
        die "Required command not found: $1"
}


normalize_name() {
    echo "$1" |
        tr '[:upper:]' '[:lower:]' |
        tr ' ' '_' |
        tr -cd '[:alnum:]_-'
}


# ============================================================================

# ============================================================================

require_command "pw-cli"
require_command "pw-dump"
require_command "pw-link"
require_command "pw-loopback"
require_command "jq"
require_command "python3"
require_command "pgrep"
require_command "systemd-run"
require_command "systemctl"
require_command "wpctl"
require_command "flock"
require_command "pw-metadata"


# ============================================================================

# ============================================================================


STATE_DIR="${XDG_CONFIG_HOME:-$HOME/.config}/oozeshell"
STATE_FILE="$STATE_DIR/audio.toml"
LEGACY_FILE="$STATE_DIR/audio.json"
STATE_LOCK="$STATE_DIR/.audio.lock"
OPS_LOCK="$STATE_DIR/.audio.ops.lock"
STATE_DEFAULT='{"outputs":[],"inputs":[],"apps":{}}'
TOML_TOOL="$(cd "$(dirname "$(readlink -f "${BASH_SOURCE[0]}")")/../../../Tools" 2>/dev/null && pwd)/ooze_toml.py"

state_json() {
    if [ -s "$STATE_FILE" ]; then
        python3 "$TOML_TOOL" to-json "$STATE_FILE" 2>/dev/null
    elif [ -s "$LEGACY_FILE" ]; then
        python3 "$TOML_TOOL" to-json "$LEGACY_FILE" 2>/dev/null
    else
        return 1
    fi
}

state_valid() {
    state_json | jq -e 'type == "object"' >/dev/null 2>&1
}

state_read() {
    local data
    if data="$(state_json)" && printf '%s' "$data" | jq -e 'type == "object"' >/dev/null 2>&1; then
        printf '%s' "$data"
    else
        printf '%s' "$STATE_DEFAULT"
    fi
}


state_update() {
    mkdir -p "$STATE_DIR" 2>/dev/null || return 0

    (
        flock 9

        if [ -s "$STATE_FILE" ] && ! state_valid; then
            cp -f "$STATE_FILE" "$STATE_FILE.bak" 2>/dev/null || true
        fi

        tmp="$(mktemp "$STATE_DIR/.audio.toml.XXXXXX")" || exit 0
        tmp_json="$tmp.json"

        if state_read | jq "$@" >"$tmp_json" 2>/dev/null && [ -s "$tmp_json" ] \
            && python3 "$TOML_TOOL" from-json <"$tmp_json" >"$tmp" 2>/dev/null && [ -s "$tmp" ]; then
            mv -f "$tmp" "$STATE_FILE"
            [ -e "$LEGACY_FILE" ] && mv -f "$LEGACY_FILE" "$LEGACY_FILE.bak" 2>/dev/null
        else
            rm -f "$tmp"
        fi
        rm -f "$tmp_json"
    ) 9>"$STATE_LOCK"
}

acquire_ops_lock() {
    mkdir -p "$STATE_DIR" 2>/dev/null || true
    exec 8>"$OPS_LOCK"
    flock -w 30 8 || die "Otra operación de OozeAudio sigue en curso"
}

state_add_output() {
    state_update --arg d "$1" --arg n "$2" '
        .outputs = ((.outputs // []) | map(select(.node != $n)))
                   + [{display: $d, node: $n, volume: 100, muted: false, links: []}]'
}

state_remove_output() {
    state_update --arg n "$1" '
        .outputs = ((.outputs // []) | map(select(.node != $n)))
        | .apps = ((.apps // {}) | with_entries(select(.value != $n)))'
}

state_set_links() {
    local node="$1"; shift
    local arr
    arr="$(printf '%s\n' "$@" | jq -R 'select(length > 0)' | jq -s '.')"
    state_update --arg n "$node" --argjson l "$arr" \
        '.outputs |= map(if .node == $n then .links = $l else . end)'
}

state_link_add() {
    state_update --arg n "$1" --arg d "$2" '
        .outputs |= map(if .node == $n
                        then .links = (((.links // []) + [$d]) | unique)
                        else . end)'
}

state_link_remove() {
    state_update --arg n "$1" --arg d "$2" '
        .outputs |= map(if .node == $n
                        then .links = ((.links // []) | map(select(. != $d)))
                        else . end)'
}

state_set_volume() {
    state_update --arg n "$1" --argjson v "$2" \
        '.outputs |= map(if .node == $n then .volume = $v else . end)'
}

state_set_muted() {
    local m="false"; [ "$2" = "1" ] && m="true"
    state_update --arg n "$1" --argjson m "$m" \
        '.outputs |= map(if .node == $n then .muted = $m else . end)'
}

# ============================================================================
# STATE - VIRTUAL INPUTS
# ============================================================================

state_add_input() {
    state_update --arg d "$1" --arg n "$2" '
        .inputs = ((.inputs // []) | map(select(.node != $n)))
                  + [{display: $d, node: $n, volume: 100, muted: false, links: []}]'
}

state_remove_input() {
    state_update --arg n "$1" '
        .inputs = ((.inputs // []) | map(select(.node != $n)))'
}

state_input_in_state() {
    state_read | jq -e --arg n "$1" 'any((.inputs // [])[]?; .node == $n)' >/dev/null 2>&1
}

state_set_input_links() {
    local node="$1"; shift
    local arr
    arr="$(printf '%s\n' "$@" | jq -R 'select(length > 0)' | jq -s '.')"
    state_update --arg n "$node" --argjson l "$arr" \
        '.inputs = ((.inputs // []) | map(if .node == $n then .links = $l else . end))'
}

state_input_link_add() {
    state_update --arg n "$1" --arg s "$2" '
        .inputs = ((.inputs // []) | map(if .node == $n
                        then .links = (((.links // []) + [$s]) | unique)
                        else . end))'
}

state_input_link_remove() {
    state_update --arg n "$1" --arg s "$2" '
        .inputs = ((.inputs // []) | map(if .node == $n
                        then .links = ((.links // []) | map(select(. != $s)))
                        else . end))'
}

state_set_input_volume() {
    state_update --arg n "$1" --argjson v "$2" \
        '.inputs = ((.inputs // []) | map(if .node == $n then .volume = $v else . end))'
}

state_set_input_muted() {
    local m="false"; [ "$2" = "1" ] && m="true"
    state_update --arg n "$1" --argjson m "$m" \
        '.inputs = ((.inputs // []) | map(if .node == $n then .muted = $m else . end))'
}

state_input_app_add() {
    state_update --arg n "$1" --arg k "$2" '
        .inputs = ((.inputs // []) | map(if .node == $n
                        then .apps = (((.apps // []) + [$k]) | unique)
                        else . end))'
}

state_input_app_remove() {
    state_update --arg n "$1" --arg k "$2" '
        .inputs = ((.inputs // []) | map(if .node == $n
                        then .apps = ((.apps // []) | map(select(. != $k)))
                        else . end))'
}

state_app_set() {
    state_update --arg k "$1" --arg s "$2" '.apps = ((.apps // {}) + {($k): $s})'
}

state_app_clear() {
    state_update --arg k "$1" '.apps = ((.apps // {}) | del(.[$k]))'
}


# ============================================================================

# ============================================================================

find_node_id() {
    local node_name="$1"

    pw-dump |
        jq -r --arg name "$node_name" '
            .[]
            | select(.type == "PipeWire:Interface:Node")
            | select(.info.props["node.name"] == $name)
            | .id
        ' |
        head -n1
}


find_loopback_nodes() {
    local sink_name="$1"

    pw-dump |
        jq -r --arg name "$sink_name" '
            .[]
            | select(.type == "PipeWire:Interface:Node")
            | select(
                .info.props["node.name"] == $name
                or
                .info.props["node.name"] == ("playback." + $name)
            )
            | .id
        '
}


virtual_output_exists() {
    local sink_name="$1"

    pw-dump |
        jq -e --arg name "$sink_name" '
            any(
                .[];
                .type == "PipeWire:Interface:Node"
                and
                .info.props["node.name"] == $name
            )
        ' >/dev/null 2>&1
}


sink_names() {
    pw-dump |
        jq -r '
            .[]
            | select(.type == "PipeWire:Interface:Node")
            | select((.info.props["media.class"] // "") == "Audio/Sink")
            | (.info.props["node.name"] // empty)
        '
}


current_links_of() {
    local name="$1"
    list_links | awk -F'\t' -v n="$name" '$1 == n { print $2 }'
}


sink_only() {
    local names n
    names="$(sink_names)"

    while IFS= read -r n; do
        [ -n "$n" ] || continue
        printf '%s\n' "$names" | grep -Fxq -- "$n" && printf '%s\n' "$n"
    done
}


# ============================================================================
# DISCOVERY - VIRTUAL INPUTS
# ============================================================================

source_names() {
    pw-dump |
        jq -r '
            .[]
            | select(.type == "PipeWire:Interface:Node")
            | select((.info.props["media.class"] // "") == "Audio/Source")
            | (.info.props["node.name"] // empty)
        '
}

source_only() {
    local names n
    names="$(source_names)"

    while IFS= read -r n; do
        [ -n "$n" ] || continue
        printf '%s\n' "$names" | grep -Fxq -- "$n" && printf '%s\n' "$n"
    done
}

virtual_input_exists() {
    local source_name="$1"

    pw-dump |
        jq -e --arg name "$source_name" '
            any(
                .[];
                .type == "PipeWire:Interface:Node"
                and
                .info.props["node.name"] == $name
                and
                (.info.props["media.class"] // "") == "Audio/Source"
            )
        ' >/dev/null 2>&1
}

current_sources_of() {
    local name="$1"
    list_links | awk -F'\t' -v n="$name" '$2 == n { print $1 }'
}


# ============================================================================
# DISCOVERY - APP STREAMS
# ============================================================================

APP_KEY_JQ='
def appkey:
    ([.info.props["application.process.binary"],
      .info.props["application.name"],
      .info.props["node.name"]]
     | map(select(. != null and . != "")) | (first // ""))
    | tostring | ascii_downcase | gsub("\\s+"; "_") | gsub("[^a-z0-9_.-]"; "");

def is_app_stream:
    .type == "PipeWire:Interface:Node"
    and (.info.props["media.class"] // "") == "Stream/Output/Audio"
    and (((.info.props["node.name"] // "") | test("^(playback|capture)\\.ooze_|^ooze_")) | not);
'

list_app_streams() {
    pw-dump |
        jq -r "$APP_KEY_JQ"'
            .[]
            | select(is_app_stream)
            | select(appkey != "")
            | .info.props as $p
            | [
                .id,
                appkey,
                ($p["application.name"] // $p["node.description"] // $p["node.name"] // "")
              ]
            | @tsv
        '
}

list_input_apps() {
    state_read |
        jq -r '(.inputs // [])[] | .node as $n | (.apps // [])[]? | [$n, .] | @tsv'
}

# ============================================================================

# ============================================================================

node_volume_pct() {
    local node_id="$1"
    local line
    line="$(wpctl get-volume "$node_id" 2>/dev/null)"

    local vol
    vol="$(printf '%s' "$line" | awk '{ for (i = 1; i <= NF; i++) if ($i == "Volume:") print $(i+1) }')"
    [ -n "$vol" ] || vol="0"

    local muted="0"
    printf '%s' "$line" | grep -qi "MUTED" && muted="1"

    local pct
    pct="$(awk -v v="$vol" 'BEGIN { printf "%d", (v * 100) + 0.5 }' 2>/dev/null)"
    [ -n "$pct" ] || pct="0"

    printf '%s\t%s' "$pct" "$muted"
}


# ============================================================================

# ============================================================================

list_outputs() {

    pw-dump |
        jq -r '
            .[]
            | select(.type == "PipeWire:Interface:Node")
            | .info.props as $p
            | select(
                ($p["media.class"] // "") == "Audio/Sink"
                and
                (($p["node.name"] // "") | startswith("ooze_"))
            )
            | [
                .id,
                ($p["node.name"] // ""),
                ($p["node.description"] // $p["node.name"])
            ]
            | @tsv
        ' |
        while IFS=$'\t' read -r id name desc; do
            [ -n "$id" ] || continue
            printf '%s\t%s\t%s\t%s\n' "$id" "$name" "$desc" "$(node_volume_pct "$id")"
        done
}


# ============================================================================
# LIST - VIRTUAL INPUTS
# ============================================================================

list_inputs() {

    pw-dump |
        jq -r '
            .[]
            | select(.type == "PipeWire:Interface:Node")
            | .info.props as $p
            | select(
                ($p["media.class"] // "") == "Audio/Source"
                and
                (($p["node.name"] // "") | startswith("ooze_in_"))
            )
            | [
                .id,
                ($p["node.name"] // ""),
                ($p["node.description"] // $p["node.name"])
            ]
            | @tsv
        ' |
        while IFS=$'\t' read -r id name desc; do
            [ -n "$id" ] || continue
            printf '%s\t%s\t%s\t%s\n' "$id" "$name" "$desc" "$(node_volume_pct "$id")"
        done
}


# ============================================================================

# ============================================================================

list_sinks() {

    pw-dump |
        jq -r '
            .[]
            | select(.type == "PipeWire:Interface:Node")
            | .info.props as $p
            | select(
                ($p["media.class"] // "") == "Audio/Sink"
            )
            | [
                .id,
                ($p["node.name"] // ""),
                ($p["node.description"] // "")
            ]
            | @tsv
        ' |
        while IFS=$'\t' read -r id name desc; do
            [ -n "$id" ] || continue
            printf '%s\t%s\t%s\t%s\n' "$id" "$name" "$desc" "$(node_volume_pct "$id")"
        done
}


# ============================================================================

# ============================================================================

list_sources() {

    pw-dump |
        jq -r '
            .[]
            | select(.type == "PipeWire:Interface:Node")
            | .info.props as $p
            | select(
                ($p["media.class"] // "") == "Audio/Source"
            )
            | [
                .id,
                ($p["node.name"] // ""),
                ($p["node.description"] // "")
            ]
            | @tsv
        '
}


# ============================================================================

# ============================================================================

list_streams() {

    pw-dump |
        jq -r '
            .[]
            | select(.type == "PipeWire:Interface:Node")
            | .info.props as $p
            | select(
                ($p["media.class"] // "") == "Stream/Output/Audio"
                or
                ($p["media.class"] // "") == "Stream/Input/Audio"
            )
            | [
                .id,
                ($p["media.class"] // ""),
                ($p["application.name"] // ""),
                ($p["node.name"] // ""),
                ($p["node.description"] // "")
            ]
            | @tsv
        '
}


# ============================================================================

# ============================================================================


spawn_loopback() {

    local display_name="$1"
    local sink_name="$2"


    local desc_escaped="${display_name//\"/\\\"}"

    local capture_props="node.name=$sink_name node.description=\"$desc_escaped\" media.class=Audio/Sink audio.position=[ FL FR ]"
    local playback_props="node.name=playback.$sink_name audio.position=[ FL FR ] node.passive=true stream.dont-remix=true"

    local unit_name="oozeaudio-${sink_name}"


    systemctl --user stop "$unit_name" >/dev/null 2>&1 || true
    systemctl --user reset-failed "$unit_name" >/dev/null 2>&1 || true

    local run_err
    run_err="$(mktemp)"

    systemd-run --user \
        --unit "$unit_name" \
        --description "OozeAudio virtual output: $display_name" \
        --collect \
        -p Restart=always \
        -p RestartSec=1 \
        pw-loopback \
            --capture-props "$capture_props" \
            --playback-props "$playback_props" \
        2>"$run_err"

    local run_status=$?

    if [ $run_status -ne 0 ]; then

        echo
        echo "systemd-run failed to start the unit (exit $run_status)."

        if [ -s "$run_err" ]; then
            echo "systemd-run said:"
            cat "$run_err"
        fi

        rm -f "$run_err"

        die "Virtual output creation failed"
    fi

    rm -f "$run_err"

    echo "systemd unit: $unit_name.service"


    local tries=0
    while ! virtual_output_exists "$sink_name" && [ "$tries" -lt 20 ]; do
        sleep 0.15
        tries=$((tries + 1))
    done

    if ! virtual_output_exists "$sink_name"; then

        echo
        echo "Unit started but the sink was not found. Recent logs:"
        journalctl --user -u "$unit_name" --no-pager -n 20 2>/dev/null

        systemctl --user stop "$unit_name" >/dev/null 2>&1 || true

        die "Virtual output creation failed"

    fi
}


wait_playback_linked() {
    local sink_name="$1"
    local tries=0

    while [ "$tries" -lt 20 ]; do
        if [ -n "$(current_links_of "$sink_name")" ]; then
            return 0
        fi
        sleep 0.1
        tries=$((tries + 1))
    done

    return 0
}


create_output() {

    local display_name="$1"

    [ -n "$display_name" ] ||
        die "Output name is required"


    local safe_name
    safe_name="$(normalize_name "$display_name")"


    [ -n "$safe_name" ] ||
        die "Invalid output name"


    local sink_name="ooze_${safe_name}"


    if virtual_output_exists "$sink_name"; then
        die "Virtual output already exists: $display_name"
    fi


    echo "Creating virtual output: $display_name"
    echo "Node: $sink_name"

    spawn_loopback "$display_name" "$sink_name"


    state_add_output "$display_name" "$sink_name"


    wait_playback_linked "$sink_name"

    state_set_links "$sink_name" $(current_links_of "$sink_name" | sink_only)

    echo "Created virtual output: $display_name"
    echo "Internal sink: $sink_name"
}


# ============================================================================

# ============================================================================

delete_output() {

    local display_name="$1"

    [ -n "$display_name" ] ||
        die "Output name is required"


    local safe_name
    safe_name="$(normalize_name "$display_name")"


    [ -n "$safe_name" ] ||
        die "Invalid output name"


    local sink_name="ooze_${safe_name}"
    local unit_name="oozeaudio-${sink_name}"

    local stopped=0
    local stop_err
    stop_err="$(mktemp)"

    if systemctl --user stop "$unit_name" 2>"$stop_err"; then
        echo "Stopped systemd unit: $unit_name.service"
        stopped=1
    fi

    rm -f "$stop_err"

    systemctl --user reset-failed "$unit_name" >/dev/null 2>&1 || true


    if [ "$stopped" -eq 0 ]; then

        local pids
        pids="$(pgrep -f -- "pw-loopback.*node.name=$sink_name" || true)"

        if [ -n "$pids" ]; then
            echo "Stopping pw-loopback process(es) for: $display_name"
            kill $pids 2>/dev/null || true
            stopped=1
        fi
    fi


    if [ "$stopped" -eq 0 ]; then


        if state_read | jq -e --arg n "$sink_name" 'any(.outputs[]?; .node == $n)' >/dev/null 2>&1; then
            state_remove_output "$sink_name"
            echo "Removed saved output (was not running): $display_name"
            return 0
        fi

        die "Virtual output not found: $display_name"
    fi


    local tries=0
    while virtual_output_exists "$sink_name" && [ "$tries" -lt 20 ]; do
        sleep 0.1
        tries=$((tries + 1))
    done

    if virtual_output_exists "$sink_name"; then
        die "El nodo $sink_name sigue en el grafo tras detener la unidad"
    fi


    state_remove_output "$sink_name"

    echo "Deleted virtual output: $display_name"
}


# ============================================================================
# CREATE / DELETE - VIRTUAL INPUTS
# ============================================================================

spawn_input_loopback() {

    local display_name="$1"
    local source_name="$2"

    local desc_escaped="${display_name//\"/\\\"}"

    local capture_props="node.name=capture.$source_name node.passive=true audio.position=[ FL FR ]"
    local playback_props="node.name=$source_name node.description=\"$desc_escaped\" media.class=Audio/Source audio.position=[ FL FR ]"

    local unit_name="oozeaudio-${source_name}"

    systemctl --user stop "$unit_name" >/dev/null 2>&1 || true
    systemctl --user reset-failed "$unit_name" >/dev/null 2>&1 || true

    local run_err
    run_err="$(mktemp)"

    systemd-run --user \
        --unit "$unit_name" \
        --description "OozeAudio virtual input: $display_name" \
        --collect \
        -p Restart=always \
        -p RestartSec=1 \
        pw-loopback \
            --capture-props "$capture_props" \
            --playback-props "$playback_props" \
        2>"$run_err"

    local run_status=$?

    if [ $run_status -ne 0 ]; then

        echo
        echo "systemd-run failed to start the unit (exit $run_status)."

        if [ -s "$run_err" ]; then
            echo "systemd-run said:"
            cat "$run_err"
        fi

        rm -f "$run_err"

        die "Virtual input creation failed"
    fi

    rm -f "$run_err"

    echo "systemd unit: $unit_name.service"

    local tries=0
    while ! virtual_input_exists "$source_name" && [ "$tries" -lt 20 ]; do
        sleep 0.15
        tries=$((tries + 1))
    done

    if ! virtual_input_exists "$source_name"; then

        echo
        echo "Unit started but the source was not found. Recent logs:"
        journalctl --user -u "$unit_name" --no-pager -n 20 2>/dev/null

        systemctl --user stop "$unit_name" >/dev/null 2>&1 || true

        die "Virtual input creation failed"
    fi
}


wait_capture_linked() {
    local source_name="$1"
    local tries=0

    while [ "$tries" -lt 20 ]; do
        if [ -n "$(current_sources_of "$source_name")" ]; then
            return 0
        fi
        sleep 0.1
        tries=$((tries + 1))
    done

    return 0
}


create_input() {

    local display_name="$1"

    [ -n "$display_name" ] ||
        die "Input name is required"

    local safe_name
    safe_name="$(normalize_name "$display_name")"

    [ -n "$safe_name" ] ||
        die "Invalid input name"

    local source_name="ooze_in_${safe_name}"

    if virtual_output_exists "$source_name"; then
        die "Virtual input already exists: $display_name"
    fi

    echo "Creating virtual input: $display_name"
    echo "Node: $source_name"

    spawn_input_loopback "$display_name" "$source_name"

    state_add_input "$display_name" "$source_name"

    wait_capture_linked "$source_name"

    state_set_input_links "$source_name" $(current_sources_of "$source_name" | source_only)

    echo "Created virtual input: $display_name"
    echo "Internal source: $source_name"
}


delete_input() {

    local display_name="$1"

    [ -n "$display_name" ] ||
        die "Input name is required"

    local safe_name
    safe_name="$(normalize_name "$display_name")"

    [ -n "$safe_name" ] ||
        die "Invalid input name"

    local source_name="ooze_in_${safe_name}"
    local unit_name="oozeaudio-${source_name}"

    if ! virtual_input_exists "$source_name"; then

        if state_input_in_state "$source_name"; then
            state_remove_input "$source_name"
            echo "Removed saved input (was not running): $display_name"
            return 0
        fi

        die "Virtual input not found: $display_name"
    fi

    local stopped=0

    if systemctl --user stop "$unit_name" 2>/dev/null; then
        echo "Stopped systemd unit: $unit_name.service"
        stopped=1
    fi

    systemctl --user reset-failed "$unit_name" >/dev/null 2>&1 || true

    if [ "$stopped" -eq 0 ]; then

        local pids
        pids="$(pgrep -f -- "pw-loopback.*node.name=$source_name" || true)"

        if [ -n "$pids" ]; then
            echo "Stopping pw-loopback process(es) for: $display_name"
            kill $pids 2>/dev/null || true
            stopped=1
        fi
    fi

    [ "$stopped" -eq 1 ] ||
        die "No se pudo detener la entrada virtual: $display_name"

    local tries=0
    while virtual_input_exists "$source_name" && [ "$tries" -lt 20 ]; do
        sleep 0.1
        tries=$((tries + 1))
    done

    if virtual_input_exists "$source_name"; then
        die "El nodo $source_name sigue en el grafo tras detener la unidad"
    fi

    state_remove_input "$source_name"

    echo "Deleted virtual input: $display_name"
}


# ============================================================================

# ============================================================================

list_ports() {
    local node_id="$1"
    local direction="$2"

    pw-dump |
        jq -r --arg id "$node_id" --arg dir "$direction" '
            .[]
            | select(.type == "PipeWire:Interface:Port")
            | select((.info.props["node.id"] | tostring) == $id)
            | select(.info.direction == $dir)
            | [
                .id,
                (.info.props["port.name"] // ""),
                (.info.props["audio.channel"] // "MONO")
              ]
            | @tsv
        '
}


resolve_output_node_id() {
    local name="$1"
    local id

    id="$(find_node_id "playback.$name")"

    if [ -z "$id" ]; then
        id="$(find_node_id "$name")"
    fi

    echo "$id"
}

resolve_input_node_id() {
    case "$1" in
        ooze_in_*) find_node_id "capture.$1" ;;
        *)         find_node_id "$1" ;;
    esac
}


link_nodes() {
    local src_name="$1"
    local dst_name="$2"

    local src_id dst_id
    src_id="$(resolve_output_node_id "$src_name")"
    dst_id="$(resolve_input_node_id "$dst_name")"

    [ -n "$src_id" ] || die "Source node not found: $src_name"
    [ -n "$dst_id" ] || die "Destination node not found: $dst_name"

    link_node_ids "$src_id" "$dst_id" "$src_name" "$dst_name"
}


link_node_ids() {
    local src_id="$1"
    local dst_id="$2"
    local src_name="$3"
    local dst_name="$4"

    local src_ports dst_ports
    src_ports="$(list_ports "$src_id" "output")"
    dst_ports="$(list_ports "$dst_id" "input")"

    [ -n "$src_ports" ] || die "Source node has no output ports: $src_name"
    [ -n "$dst_ports" ] || die "Destination node has no input ports: $dst_name"


    local linked=0

    while IFS=$'\t' read -r sport _sname schan; do

        [ -n "$sport" ] || continue

        local dport
        dport="$(printf '%s\n' "$dst_ports" | awk -F'\t' -v c="$schan" '$3==c{print $1; exit}')"

        if [ -z "$dport" ] && [ "$schan" = "MONO" ]; then

            while IFS=$'\t' read -r dport2 _ _; do
                [ -n "$dport2" ] || continue
                pw-link "$sport" "$dport2" >/dev/null 2>&1
                linked=1
            done <<< "$dst_ports"
            continue
        fi

        if [ -z "$dport" ]; then

            dport="$(printf '%s\n' "$dst_ports" | head -n1 | cut -f1)"
        fi

        [ -n "$dport" ] || continue
        pw-link "$sport" "$dport" >/dev/null 2>&1
        linked=1

    done <<< "$src_ports"

    [ "$linked" = "1" ] ||
        die "No se pudo emparejar ningún canal entre $src_name y $dst_name"

    echo "Connected: $src_name -> $dst_name"
}


connect_nodes() {
    link_nodes "$1" "$2"

    case "$2" in
        ooze_in_*) state_input_link_add "$2" "$1" ;;
        *)
            case "$1" in
                ooze_*) state_link_add "$1" "$2" ;;
            esac
            ;;
    esac
}


unlink_nodes() {
    local src_name="$1"
    local dst_name="$2"

    local src_id dst_id
    src_id="$(resolve_output_node_id "$src_name")"
    dst_id="$(resolve_input_node_id "$dst_name")"

    [ -n "$src_id" ] || die "Source node not found: $src_name"
    [ -n "$dst_id" ] || die "Destination node not found: $dst_name"

    unlink_node_ids "$src_id" "$dst_id"

    echo "Disconnected: $src_name -> $dst_name"
}


unlink_node_ids() {
    local src_id="$1"
    local dst_id="$2"

    pw-dump |
        jq -r --arg sid "$src_id" --arg did "$dst_id" '
            .[]
            | select(.type == "PipeWire:Interface:Link")
            | select((.info["output-node-id"] | tostring) == $sid)
            | select((.info["input-node-id"] | tostring) == $did)
            | .id
        ' |
        while read -r lid; do
            [ -n "$lid" ] || continue
            pw-cli destroy "$lid" || true
        done
}


disconnect_nodes() {
    unlink_nodes "$1" "$2"

    case "$2" in
        ooze_in_*) state_input_link_remove "$2" "$1" ;;
        *)
            case "$1" in
                ooze_*) state_link_remove "$1" "$2" ;;
            esac
            ;;
    esac
}


list_links() {
    pw-dump |
        jq -r '
            . as $all
            | (map(select(.type == "PipeWire:Interface:Node"))) as $nodes
            | ($nodes | map({(.id | tostring): (.info.props["node.name"] // "")}) | add) as $names
            | $all[]
            | select(.type == "PipeWire:Interface:Link")
            | ($names[(.info["output-node-id"] | tostring)] // "") as $srcname
            | ($names[(.info["input-node-id"] | tostring)] // "") as $dstname
            | select($srcname != "" and $dstname != "")
            | [
                ($srcname | sub("^playback\\."; "")),
                (if ($dstname | test("^capture\\.ooze_in_")) then ($dstname | sub("^capture\\."; "")) else $dstname end)
              ]
            | @tsv
        ' |
        sort -u
}


# ============================================================================

# ============================================================================


find_sink_id() {
    local sink_name="$1"

    pw-dump |
        jq -r --arg name "$sink_name" '
            .[]
            | select(.type == "PipeWire:Interface:Node")
            | select((.info.props["media.class"] // "") == "Audio/Sink")
            | select(.info.props["node.name"] == $name)
            | .id
        ' |
        head -n1
}


stream_move() {
    local sid="$1"
    local sink="${2:-default}"

    case "$sid" in
        ''|*[!0-9]*) die "Stream id must be a number" ;;
    esac

    if [ "$sink" = "default" ]; then
        pw-metadata -n default -d "$sid" target.node   >/dev/null 2>&1 || true
        pw-metadata -n default -d "$sid" target.object >/dev/null 2>&1 || true
        echo "Stream $sid -> default output"
        return 0
    fi

    local did
    did="$(find_sink_id "$sink")"
    [ -n "$did" ] || die "Sink not found: $sink"

    pw-metadata -n default "$sid" target.node "$did" >/dev/null 2>&1 ||
        die "pw-metadata no pudo mover el stream $sid"


    pw-metadata -n default "$sid" target.object "$sink" >/dev/null 2>&1 || true

    echo "Stream $sid -> $sink"
}


valid_app_key() {
    case "$1" in
        ''|*[!a-z0-9_.-]*) return 1 ;;
    esac
    return 0
}


stream_route() {
    valid_app_key "$2" || die "Invalid app key: $2"
    [ -n "$3" ] && [ "$3" != "default" ] || die "Usage: $SCRIPT_NAME stream-route ID KEY SINK"


    state_app_set "$2" "$3"
    stream_move "$1" "$3"
}


stream_unroute() {
    valid_app_key "$2" || die "Invalid app key: $2"
    state_app_clear "$2"
    stream_move "$1" default
}


list_app_rules() {
    state_read |
        jq -r '(.apps // {}) | to_entries[] | [.key, .value] | @tsv'
}


# ============================================================================

# ============================================================================


wait_for_pipewire() {
    local i=0
    while [ "$i" -lt 60 ]; do
        if pw-dump >/dev/null 2>&1 && wpctl status >/dev/null 2>&1; then
            return 0
        fi
        sleep 0.5
        i=$((i + 1))
    done
    return 1
}


wait_for_hardware_sink() {
    local i=0
    while [ "$i" -lt 20 ]; do
        if sink_names | grep -qv '^ooze_'; then
            return 0
        fi
        sleep 0.4
        i=$((i + 1))
    done
    return 0
}


adopt_live_outputs() {
    local id name desc pct muted
    local known
    known="$(state_read | jq -r '.outputs[]?.node')"

    while IFS=$'\t' read -r id name desc pct muted; do
        [ -n "$name" ] || continue
        printf '%s\n' "$known" | grep -Fxq -- "$name" && continue

        state_add_output "$desc" "$name"
        state_set_volume "$name" "${pct:-100}"
        state_set_muted "$name" "${muted:-0}"

        state_set_links "$name" $(current_links_of "$name" | sink_only)
    done < <(list_outputs)
}


restore_outputs() {
    wait_for_pipewire || die "PipeWire no responde"
    wait_for_hardware_sink

    adopt_live_outputs

    local state count i
    state="$(state_read)"
    count="$(printf '%s' "$state" | jq '.outputs | length')"

    for ((i = 0; i < count; i++)); do

        local display node volume muted links created=0

        IFS=$'\t' read -r display node volume muted < <(
            printf '%s' "$state" |
                jq -r ".outputs[$i] | [.display, .node, (.volume // 100), (.muted // false)] | @tsv"
        )
        links="$(printf '%s' "$state" | jq -r ".outputs[$i].links // [] | .[]")"

        [ -n "$node" ] || continue

        if ! virtual_output_exists "$node"; then
            if ( spawn_loopback "${display:-$node}" "$node" ) >/dev/null 2>&1; then
                created=1
                echo "Restored output: $display ($node)"
            else
                echo "restore: no se pudo recrear $node" >&2
                continue
            fi
        fi

        if [ "$created" -eq 1 ]; then
            local nid
            nid="$(find_node_id "$node")"

            if [ -n "$nid" ]; then
                wpctl set-volume "$nid" "${volume:-100}%" >/dev/null 2>&1 || true
                if [ "$muted" = "true" ]; then
                    wpctl set-mute "$nid" 1 >/dev/null 2>&1 || true
                else
                    wpctl set-mute "$nid" 0 >/dev/null 2>&1 || true
                fi
            fi


            wait_playback_linked "$node"


            local dst
            while IFS= read -r dst; do
                [ -n "$dst" ] || continue
                printf '%s\n' "$links" | grep -Fxq -- "$dst" && continue
                ( unlink_nodes "$node" "$dst" ) </dev/null >/dev/null 2>&1 || true
            done < <(current_links_of "$node" | sink_only)
        fi


        local want present
        present="$(sink_names)"

        while IFS= read -r want; do
            [ -n "$want" ] || continue
            printf '%s\n' "$present" | grep -Fxq -- "$want" || continue
            current_links_of "$node" | grep -Fxq -- "$want" && continue
            ( link_nodes "$node" "$want" ) </dev/null >/dev/null 2>&1 || true
        done <<< "$links"

    done
}


# ============================================================================
# ROUTING - APP SOURCES
# ============================================================================

apply_app_links() {
    local want="$1"
    local plan sid dst try

    plan="$(pw-dump | jq -r --argjson want "$want" "$APP_KEY_JQ"'
        . as $all
        | ($all | map(select(.type == "PipeWire:Interface:Node"))) as $nodes
        | ($nodes | map({key: (.info.props["node.name"] // ""), value: .id}) | from_entries) as $ids
        | [$nodes[] | select(is_app_stream) | {id: .id, key: appkey}] as $streams
        | [$all[] | select(.type == "PipeWire:Interface:Link")
            | "\(.info["output-node-id"]):\(.info["input-node-id"])"] as $links
        | $want[] as [$in, $k]
        | $ids["capture." + $in] as $dst
        | select($dst != null)
        | $streams[]
        | select(.key == $k)
        | select(("\(.id):\($dst)") as $p | ($links | any(. == $p)) | not)
        | "\(.id)\t\($dst)"
    ' 2>/dev/null)"

    while IFS=$'\t' read -r sid dst; do
        [ -n "$sid" ] || continue

        for try in 1 2 3; do
            ( link_node_ids "$sid" "$dst" "stream:$sid" "node:$dst" ) </dev/null >/dev/null 2>&1 && break
            sleep 0.25
        done
    done <<< "$plan"
}


connect_app() {
    local key="$1"
    local input="$2"

    valid_app_key "$key" || die "Invalid app key: $key"

    case "$input" in
        ooze_in_*) ;;
        *) die "Destination must be a virtual input: $input" ;;
    esac

    virtual_input_exists "$input" || die "Virtual input not found: $input"

    state_input_app_add "$input" "$key"

    apply_app_links "$(jq -nc --arg i "$input" --arg k "$key" '[[$i, $k]]')"

    echo "Connected app: $key -> $input"
}


disconnect_app() {
    local key="$1"
    local input="$2"

    valid_app_key "$key" || die "Invalid app key: $key"

    state_input_app_remove "$input" "$key"

    local dst_id sid
    dst_id="$(resolve_input_node_id "$input")"

    if [ -n "$dst_id" ]; then
        while IFS=$'\t' read -r sid _; do
            [ -n "$sid" ] || continue
            unlink_node_ids "$sid" "$dst_id" </dev/null
        done < <(list_app_streams | awk -F'\t' -v k="$key" '$2 == k')
    fi

    echo "Disconnected app: $key -> $input"
}


sync_input_apps() {
    [ -s "$STATE_FILE" ] && grep -q '^apps = \["' "$STATE_FILE" 2>/dev/null || return 0

    local want
    want="$(state_read | jq -c '[(.inputs // [])[] | .node as $n | (.apps // [])[]? | [$n, .]]')"

    [ -n "$want" ] && [ "$want" != "[]" ] || return 0

    apply_app_links "$want"
}


# ============================================================================
# RESTORE - VIRTUAL INPUTS
# ============================================================================

wait_for_hardware_source() {
    local i=0
    while [ "$i" -lt 10 ]; do
        if source_names | grep -qv '^ooze_'; then
            return 0
        fi
        sleep 0.4
        i=$((i + 1))
    done
    return 0
}


adopt_live_inputs() {
    local id name desc pct muted
    local known
    known="$(state_read | jq -r '(.inputs // [])[]?.node')"

    while IFS=$'\t' read -r id name desc pct muted; do
        [ -n "$name" ] || continue
        printf '%s\n' "$known" | grep -Fxq -- "$name" && continue

        state_add_input "$desc" "$name"
        state_set_input_volume "$name" "${pct:-100}"
        state_set_input_muted "$name" "${muted:-0}"

        state_set_input_links "$name" $(current_sources_of "$name" | source_only)
    done < <(list_inputs)
}


restore_inputs() {
    wait_for_hardware_source

    adopt_live_inputs

    local state count i
    state="$(state_read)"
    count="$(printf '%s' "$state" | jq '(.inputs // []) | length')"

    for ((i = 0; i < count; i++)); do

        local display node volume muted links created=0

        IFS=$'\t' read -r display node volume muted < <(
            printf '%s' "$state" |
                jq -r ".inputs[$i] | [.display, .node, (.volume // 100), (.muted // false)] | @tsv"
        )
        links="$(printf '%s' "$state" | jq -r ".inputs[$i].links // [] | .[]")"

        [ -n "$node" ] || continue

        if ! virtual_input_exists "$node"; then
            if ( spawn_input_loopback "${display:-$node}" "$node" ) >/dev/null 2>&1; then
                created=1
                echo "Restored input: $display ($node)"
            else
                echo "restore: no se pudo recrear $node" >&2
                continue
            fi
        fi

        if [ "$created" -eq 1 ]; then
            local nid
            nid="$(find_node_id "$node")"

            if [ -n "$nid" ]; then
                wpctl set-volume "$nid" "${volume:-100}%" >/dev/null 2>&1 || true
                if [ "$muted" = "true" ]; then
                    wpctl set-mute "$nid" 1 >/dev/null 2>&1 || true
                else
                    wpctl set-mute "$nid" 0 >/dev/null 2>&1 || true
                fi
            fi

            wait_capture_linked "$node"

            local src
            while IFS= read -r src; do
                [ -n "$src" ] || continue
                printf '%s\n' "$links" | grep -Fxq -- "$src" && continue
                ( unlink_nodes "$src" "$node" ) </dev/null >/dev/null 2>&1 || true
            done < <(current_sources_of "$node" | source_only)
        fi

        local want present
        present="$(source_names; sink_names)"

        while IFS= read -r want; do
            [ -n "$want" ] || continue
            printf '%s\n' "$present" | grep -Fxq -- "$want" || continue
            current_sources_of "$node" | grep -Fxq -- "$want" && continue
            ( link_nodes "$want" "$node" ) </dev/null >/dev/null 2>&1 || true
        done <<< "$links"

    done

    sync_input_apps
}


# ============================================================================

# ============================================================================


node_name_of() {
    wpctl inspect "$1" 2>/dev/null |
        awk -F'"' '/^[ *]*node\.name = / { print $2; exit }'
}


persist_node_volume() {
    local name
    name="$(node_name_of "$1")"
    case "$name" in
        ooze_*)
            if virtual_input_exists "$name"; then
                state_set_input_volume "$name" "$2"
            else
                state_set_volume "$name" "$2"
            fi
            ;;
    esac
}

persist_node_mute() {
    local name
    name="$(node_name_of "$1")"
    case "$name" in
        ooze_*)
            if virtual_input_exists "$name"; then
                state_set_input_muted "$name" "$2"
            else
                state_set_muted "$name" "$2"
            fi
            ;;
    esac
}


set_node_volume() {
    local node_id="$1"
    local percent="$2"

    [ -n "$node_id" ] || die "Node id is required"

    case "$percent" in
        ''|*[!0-9]*) die "Volume must be a whole number (0-150)" ;;
    esac

    wpctl set-volume "$node_id" "${percent}%" ||
        die "No se pudo cambiar el volumen del nodo $node_id"

    persist_node_volume "$node_id" "$percent"

    echo "Volume set: $node_id -> ${percent}%"
}

set_node_mute() {
    local node_id="$1"
    local muted="$2"

    [ -n "$node_id" ] || die "Node id is required"

    case "$muted" in
        1)
            wpctl set-mute "$node_id" 1 ||
                die "No se pudo mutear el nodo $node_id"
            persist_node_mute "$node_id" 1
            echo "Muted: $node_id"
            ;;
        0)
            wpctl set-mute "$node_id" 0 ||
                die "No se pudo desmutear el nodo $node_id"
            persist_node_mute "$node_id" 0
            echo "Unmuted: $node_id"
            ;;
        *)
            die "Usage: $SCRIPT_NAME mute-set NODE_ID <0|1>"
            ;;
    esac
}


# ============================================================================

# ============================================================================

status() {

    echo
    echo "=== OozeAudio / PipeWire ==="
    echo

    echo "Virtual Outputs:"
    echo "----------------"

    local outputs
    outputs="$(list_outputs)"

    if [ -n "$outputs" ]; then
        echo "$outputs"
    else
        echo "No virtual outputs."
    fi


    echo
    echo "Physical / Other Sinks:"
    echo "-----------------------"

    list_sinks


    echo
    echo "Audio Sources:"
    echo "--------------"

    list_sources


    echo
    echo "Audio Streams:"
    echo "--------------"

    list_streams
}


# ============================================================================

# ============================================================================

dump() {

    pw-dump
}


# ============================================================================

# ============================================================================

case "${1:-}" in

    status)

        status

        ;;


    sinks)

        list_sinks

        ;;


    sources)

        list_sources

        ;;


    streams)

        list_streams

        ;;


    outputs)

        list_outputs

        ;;


    inputs)

        list_inputs

        ;;


    app-streams)

        list_app_streams

        ;;


    input-apps)

        list_input_apps

        ;;


    connect-app)

        [ "$#" -ge 3 ] ||
            die "Usage: $SCRIPT_NAME connect-app APP_KEY INPUT"

        connect_app "$2" "$3"

        ;;


    disconnect-app)

        [ "$#" -ge 3 ] ||
            die "Usage: $SCRIPT_NAME disconnect-app APP_KEY INPUT"

        disconnect_app "$2" "$3"

        ;;


    sync-apps)

        sync_input_apps

        ;;


    dump)

        dump

        ;;


    create)

        [ "$#" -ge 2 ] ||
            die "Usage: $SCRIPT_NAME create NAME"

        acquire_ops_lock

        create_output "$2"

        ;;


    delete)

        [ "$#" -ge 2 ] ||
            die "Usage: $SCRIPT_NAME delete NAME"

        acquire_ops_lock

        delete_output "$2"

        ;;


    create-input)

        [ "$#" -ge 2 ] ||
            die "Usage: $SCRIPT_NAME create-input NAME"

        acquire_ops_lock

        create_input "$2"

        ;;


    delete-input)

        [ "$#" -ge 2 ] ||
            die "Usage: $SCRIPT_NAME delete-input NAME"

        acquire_ops_lock

        delete_input "$2"

        ;;


    links)

        list_links

        ;;


    connect)

        [ "$#" -ge 3 ] ||
            die "Usage: $SCRIPT_NAME connect SOURCE DEST"

        connect_nodes "$2" "$3"

        ;;


    disconnect)

        [ "$#" -ge 3 ] ||
            die "Usage: $SCRIPT_NAME disconnect SOURCE DEST"

        disconnect_nodes "$2" "$3"

        ;;


    volume-set)

        [ "$#" -ge 3 ] ||
            die "Usage: $SCRIPT_NAME volume-set NODE_ID PERCENT"

        set_node_volume "$2" "$3"

        ;;


    mute-set)

        [ "$#" -ge 3 ] ||
            die "Usage: $SCRIPT_NAME mute-set NODE_ID <0|1>"

        set_node_mute "$2" "$3"

        ;;


    restore)

        acquire_ops_lock

        restore_outputs

        restore_inputs

        ;;


    app-rules)

        list_app_rules

        ;;


    app-forget)

        [ "$#" -ge 2 ] ||
            die "Usage: $SCRIPT_NAME app-forget APP_KEY"

        valid_app_key "$2" || die "Invalid app key: $2"
        state_app_clear "$2"
        echo "Forgot rule: $2"

        ;;


    stream-move)

        [ "$#" -ge 3 ] ||
            die "Usage: $SCRIPT_NAME stream-move STREAM_ID SINK|default"

        stream_move "$2" "$3"

        ;;


    stream-route)

        [ "$#" -ge 4 ] ||
            die "Usage: $SCRIPT_NAME stream-route STREAM_ID APP_KEY SINK"

        stream_route "$2" "$3" "$4"

        ;;


    stream-unroute)

        [ "$#" -ge 3 ] ||
            die "Usage: $SCRIPT_NAME stream-unroute STREAM_ID APP_KEY"

        stream_unroute "$2" "$3"

        ;;


    state)

        echo "$STATE_FILE"
        state_read | jq .

        ;;


    *)

        echo
        echo "OozeAudio - PipeWire Audio Manager"
        echo
        echo "Usage:"
        echo
        echo "  $SCRIPT_NAME status"
        echo "      Show complete OozeAudio status"
        echo
        echo "  $SCRIPT_NAME sinks"
        echo "      List audio sinks"
        echo
        echo "  $SCRIPT_NAME sources"
        echo "      List audio sources"
        echo
        echo "  $SCRIPT_NAME streams"
        echo "      List audio streams"
        echo
        echo "  $SCRIPT_NAME outputs"
        echo "      List OozeAudio virtual outputs"
        echo
        echo "  $SCRIPT_NAME dump"
        echo "      Dump complete PipeWire graph as JSON"
        echo
        echo "  $SCRIPT_NAME create NAME"
        echo "      Create a virtual output"
        echo
        echo "  $SCRIPT_NAME delete NAME"
        echo "      Delete a virtual output"
        echo
        echo "  $SCRIPT_NAME inputs"
        echo "      List OozeAudio virtual inputs"
        echo
        echo "  $SCRIPT_NAME create-input NAME"
        echo "      Create a virtual input (virtual microphone)"
        echo
        echo "  $SCRIPT_NAME delete-input NAME"
        echo "      Delete a virtual input"
        echo
        echo "  $SCRIPT_NAME app-streams"
        echo "      List playing app streams as ID<TAB>APP_KEY<TAB>NAME"
        echo
        echo "  $SCRIPT_NAME input-apps"
        echo "      List saved routing as INPUT<TAB>APP_KEY"
        echo
        echo "  $SCRIPT_NAME connect-app APP_KEY INPUT"
        echo "      Feed an app's audio into a virtual input and remember it"
        echo
        echo "  $SCRIPT_NAME disconnect-app APP_KEY INPUT"
        echo "      Stop feeding an app into a virtual input and forget it"
        echo
        echo "  $SCRIPT_NAME sync-apps"
        echo "      Link saved apps that are playing now (idempotent)"
        echo
        echo "  $SCRIPT_NAME links"
        echo "      List active connections as SRC<TAB>DST"
        echo
        echo "  $SCRIPT_NAME connect SOURCE DEST"
        echo "      Link SOURCE node ports to DEST node ports"
        echo
        echo "  $SCRIPT_NAME disconnect SOURCE DEST"
        echo "      Remove links between SOURCE and DEST"
        echo
        echo "  $SCRIPT_NAME volume-set NODE_ID PERCENT"
        echo "      Set a node's volume (0-150)"
        echo
        echo "  $SCRIPT_NAME mute-set NODE_ID <0|1>"
        echo "      Mute or unmute a node"
        echo
        echo "  $SCRIPT_NAME restore"
        echo "      Recreate saved virtual outputs, links and volumes (idempotent)"
        echo
        echo "  $SCRIPT_NAME state"
        echo "      Show the saved configuration ($STATE_FILE)"
        echo
        echo "  $SCRIPT_NAME app-rules"
        echo "      List saved per-app output rules as APP<TAB>SINK"
        echo
        echo "  $SCRIPT_NAME stream-route STREAM_ID APP_KEY SINK"
        echo "      Move an app's stream to SINK and remember it"
        echo
        echo "  $SCRIPT_NAME stream-unroute STREAM_ID APP_KEY"
        echo "      Back to the default output and forget the rule"
        echo
        echo "  $SCRIPT_NAME app-forget APP_KEY"
        echo "      Forget a saved per-app output rule"
        echo
        echo "  $SCRIPT_NAME stream-move STREAM_ID SINK|default"
        echo "      Move a stream without saving anything"
        echo

        exit 1

        ;;

esac
