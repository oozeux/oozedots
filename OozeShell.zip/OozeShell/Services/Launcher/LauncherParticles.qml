// LauncherParticles

import Quickshell
import Quickshell.Io
import QtQuick
import "../../COMMON"

Item {
  id: root

  property bool active: false
  property string style: "dust"
  property int density: 1
  property string pattern: "even"
  property rect avoid: Qt.rect(0, 0, 0, 0)

  // ─── Estilos ────────────────────────────────────────────────────
  readonly property var styles: ({
    dust:      { glyphs: ["✦", "·", "✧"],      sway: 14, lowOpacity: 0.25, motion: "rise" },
    stars:     { glyphs: ["✦", "✧", "·", "✦"], sway: 0,  lowOpacity: 0.05, motion: "still" },
    snow:      { glyphs: ["•", "·", "∙"],      sway: 22, lowOpacity: 0.35, motion: "fall" },
    fireflies: { glyphs: ["●", "•"],           sway: 26, lowOpacity: 0.0,  motion: "wander" }
  })
  readonly property var spec: root.styles[root.style] ?? root.styles.dust
  readonly property int count: [12, 20, 34][Math.max(0, Math.min(2, root.density))] + (root.style === "stars" ? 10 : 0)
  readonly property string patternId: ["even", "random", "cascade"].indexOf(root.pattern) >= 0 ? root.pattern : "even"
  readonly property bool cascade: root.patternId === "cascade"

  visible: root.active

  // ─── Generación (backend Python con respaldo local) ─────────────
  readonly property string script: Quickshell.shellDir + "/Backends/python/ooze-particles.py"
  readonly property string avoidArg: {
    const w = Math.max(1, root.width), h = Math.max(1, root.height)
    const a = root.avoid
    if (a.width <= 0 || a.height <= 0) return ""
    const f = v => Math.max(0, Math.min(1, v)).toFixed(3)
    return f(a.x / w) + "," + f(a.y / h) + "," + f((a.x + a.width) / w) + "," + f((a.y + a.height) / h)
  }
  readonly property string wantedKey: root.style + "|" + root.count + "|" + root.patternId + "|" + root.avoidArg

  property var motes: []
  property string moteKey: ""
  property var cache: ({})

  function request() {
    if (!root.active) return
    const key = root.wantedKey
    if (root.patternId === "even" && root.cache[key]) {
      root.motes = root.cache[key]
      root.moteKey = key
      return
    }
    root.motes = []
    root.moteKey = ""
    gen.running = false
    gen.reqKey = key
    gen.running = true
    fallbackTimer.restart()
  }

  function ingest(line) {
    let data
    try { data = JSON.parse(line) } catch (e) { return }
    if (!data || data.key !== root.wantedKey || !Array.isArray(data.motes)) return
    fallbackTimer.stop()
    root.motes = data.motes
    root.moteKey = data.key
    if (root.patternId === "even") root.cache[data.key] = data.motes
  }

  function localMotes() {
    const n = root.count
    const gl = root.spec.glyphs.length
    let s = root.patternId === "even" ? 7 : (Date.now() % 100000)
    const rnd = () => {
      s = (s + 0x6D2B79F5) | 0
      let t = Math.imul(s ^ (s >>> 15), 1 | s)
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296
    }
    const ox = rnd(), oy = rnd()
    const jitter = 0.35 / Math.sqrt(n)
    const out = []
    for (let i = 0; i < n; i++) {
      out.push({
        x: Math.max(0, Math.min(1, ((ox + i * 0.7548776662466927) % 1) + (rnd() - 0.5) * jitter)),
        y: Math.max(0, Math.min(1, ((oy + i * 0.5698402909980532) % 1) + (rnd() - 0.5) * jitter)),
        g: Math.floor(rnd() * gl), s: rnd(), o: rnd(), t: rnd(),
        tr: root.cascade ? 11000 : 9000 + Math.floor(rnd() * 7000),
        sw: 2600 + Math.floor(rnd() * 1800),
        tw: root.cascade ? 1700 : 900 + Math.floor(rnd() * 1100),
        ph: root.cascade ? 0 : rnd(), dl: 0
      })
    }
    if (root.cascade) {
      const order = out.map((m, i) => i).sort((a, b) => out[a].x - out[b].x)
      order.forEach((i, rank) => { out[i].dl = Math.floor(rank / 3) * 220 })
    }
    return out
  }

  Timer {
    id: fallbackTimer
    interval: 700
    repeat: false
    onTriggered: {
      if (root.motes.length > 0) return
      root.motes = root.localMotes()
      root.moteKey = root.wantedKey
    }
  }

  Process {
    id: gen
    property string reqKey: ""
    command: ["python3", root.script,
      "--style", root.style, "--count", String(root.count),
      "--glyphs", String(root.spec.glyphs.length), "--pattern", root.patternId,
      "--aspect", String(Math.max(0.2, root.width / Math.max(1, root.height))),
      "--avoid", root.avoidArg, "--key", gen.reqKey]
    stdout: SplitParser {
      onRead: line => root.ingest(line)
    }
  }

  onActiveChanged: { if (root.active) root.request(); else { gen.running = false; fallbackTimer.stop() } }
  onWantedKeyChanged: root.request()
  Component.onCompleted: root.request()

  // ─── Campo de partículas ────────────────────────────────────────
  Repeater {
    id: field
    model: root.motes

    delegate: Text {
      id: mote

      required property var modelData
      required property int index

      readonly property real baseX: mote.modelData.x * root.width
      readonly property real baseY: mote.modelData.y * root.height
      readonly property int travelMs: mote.modelData.tr > 0 ? mote.modelData.tr : 12000
      readonly property int swayMs: mote.modelData.sw > 0 ? mote.modelData.sw : 3000
      readonly property int twinkleMs: mote.modelData.tw
      readonly property real delayMs: mote.modelData.dl
      readonly property string glyph: root.spec.glyphs[mote.modelData.g % root.spec.glyphs.length]
      readonly property real maxOpacity: root.style === "stars" ? 0.18 + mote.modelData.o * 0.39
                                       : root.style === "fireflies" ? 0.30 + mote.modelData.o * 0.39
                                       : 0.08 + mote.modelData.o * 0.21

      readonly property real phase: mote.modelData.ph
      readonly property real hoverSeed: mote.modelData.s * 6.2832
      property real travel: mote.phase
      property real wave: 0
      property real tw: 0.6
      property real appear: 1

      readonly property bool animated: root.active && Theme.uiAnimationsEnabled

      text: mote.glyph
      color: root.style === "fireflies" ? (mote.modelData.t < 0.5 ? Theme.primary : Qt.lighter(Theme.primary, 1.4))
           : mote.modelData.t < 0.25 ? Theme.primary : Theme.text
      font.family: Theme.fontFamily
      font.pixelSize: root.style === "stars" ? Math.round(9 + mote.modelData.s * 13)
                    : root.style === "snow" ? Math.round(8 + mote.modelData.s * 8)
                    : root.style === "fireflies" ? Math.round(8 + mote.modelData.s * 6)
                    : (mote.glyph === "·" ? Math.round(10 + mote.modelData.s * 9) : Math.round(8 + mote.modelData.s * 12))

      x: root.spec.motion === "wander"
           ? mote.baseX + mote.wave * root.spec.sway + Math.sin(mote.travel * 12.566 + mote.hoverSeed) * 10
           : mote.baseX + mote.wave * root.spec.sway
      y: root.spec.motion === "rise" ? root.height + 30 - mote.travel * (root.height + 60)
       : root.spec.motion === "fall" ? -30 + mote.travel * (root.height + 60)
       : root.spec.motion === "wander" ? mote.baseY + Math.sin(mote.travel * 6.2832 + mote.hoverSeed) * 18 + Math.cos(mote.wave * 2.4 + mote.hoverSeed) * 10
       : mote.baseY
      opacity: mote.appear * mote.maxOpacity * (root.spec.lowOpacity + (1 - root.spec.lowOpacity) * mote.tw)
      scale: root.style === "stars" ? 0.7 + 0.6 * mote.tw : 1.0

      SequentialAnimation on travel {
        running: mote.animated && root.spec.motion !== "still"
        NumberAnimation { from: mote.phase; to: mote.phase; duration: Theme.animDuration(mote.delayMs) }
        NumberAnimation { from: mote.phase; to: 1; duration: Theme.animDuration(mote.travelMs * (1 - mote.phase)) }
        SequentialAnimation {
          loops: Animation.Infinite
          NumberAnimation { from: 0; to: 1; duration: Theme.animDuration(mote.travelMs) }
        }
      }

      SequentialAnimation on appear {
        running: mote.animated && root.cascade
        NumberAnimation { from: 0; to: 0; duration: Theme.animDuration(mote.delayMs) }
        NumberAnimation { from: 0; to: 1; duration: Theme.animDuration(600); easing.type: Easing.OutCubic }
      }

      SequentialAnimation on wave {
        running: mote.animated && root.spec.sway > 0
        loops: Animation.Infinite
        NumberAnimation { from: -1; to: 1; duration: Theme.animDuration(mote.swayMs); easing.type: Easing.InOutSine }
        NumberAnimation { from: 1; to: -1; duration: Theme.animDuration(mote.swayMs); easing.type: Easing.InOutSine }
      }

      SequentialAnimation on tw {
        running: mote.animated
        NumberAnimation { from: 0.6; to: 0.6; duration: Theme.animDuration(root.cascade ? mote.delayMs : 0) }
        SequentialAnimation {
          loops: Animation.Infinite
          NumberAnimation { from: 0; to: 1; duration: Theme.animDuration(mote.twinkleMs); easing.type: Easing.InOutSine }
          NumberAnimation { from: 1; to: 0; duration: Theme.animDuration(mote.twinkleMs); easing.type: Easing.InOutSine }
        }
      }
    }
  }
}
