// LauncherCovers

import Quickshell
import Quickshell.Io
import QtQuick

Item {
  id: root

  width: 0
  height: 0

  // ─── Estado ─────────────────────────────────────────────────────
  property var steam: ({})
  property var custom: ({})
  property int rev: 0

  readonly property string home: Quickshell.env("HOME")
  readonly property string customDir: root.home + "/.config/oozeshell/covers"

  // ─── Búsqueda de archivos ───────────────────────────────────────
  readonly property string script:
    'home="$1"; cdir="$2"; ' +
    'for r in "$home/.local/share/Steam" "$home/.steam/steam" "$home/.var/app/com.valvesoftware.Steam/.local/share/Steam"; do ' +
    'd="$r/appcache/librarycache"; [ -d "$d" ] || continue; ' +
    'find -L "$d" -maxdepth 3 -type f \\( -name "library_600x900*.jpg" -o -name library_capsule.jpg -o -name library_header.jpg -o -name header.jpg \\) -printf "S\\t%p\\n" 2>/dev/null; ' +
    'done; ' +
    '[ -d "$cdir" ] && find -L "$cdir" -maxdepth 1 -type f \\( -iname "*.png" -o -iname "*.jpg" -o -iname "*.jpeg" -o -iname "*.webp" \\) -printf "C\\t%p\\n" 2>/dev/null; ' +
    'exit 0'

  function refresh() {
    if (proc.running) return
    proc.buf = []
    proc.running = true
  }

  // ─── Resolución ─────────────────────────────────────────────────
  function rankOf(name) {
    if (name.indexOf("library_600x900") === 0) return 4
    if (name === "library_capsule.jpg") return 3
    if (name === "library_header.jpg") return 2
    if (name === "header.jpg") return 1
    return 0
  }

  function toUrl(path) {
    return "file://" + path.split("/").map(encodeURIComponent).join("/")
  }

  function ingest(lines) {
    const steam = {}
    const custom = {}
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i]
      const tab = line.indexOf("\t")
      if (tab < 0) continue
      const kind = line.slice(0, tab)
      const path = line.slice(tab + 1)
      if (kind === "S") {
        const m = /librarycache\/(\d+)[_\/](?:.*\/)?([^\/]+)$/.exec(path)
        if (!m) continue
        const rank = root.rankOf(m[2])
        const cur = steam[m[1]]
        if (rank > 0 && (!cur || rank > cur.rank)) steam[m[1]] = { rank: rank, url: root.toUrl(path) }
      } else if (kind === "C") {
        const base = path.slice(path.lastIndexOf("/") + 1)
        const dot = base.lastIndexOf(".")
        if (dot > 0) custom[base.slice(0, dot).toLowerCase()] = root.toUrl(path)
      }
    }
    root.steam = steam
    root.custom = custom
    root.rev++
  }

  function lookup(item) {
    void root.rev
    if (!item) return ""
    const id = String(item.id ?? "").toLowerCase()
    const name = String(item.name ?? "").toLowerCase()
    if (root.custom[id]) return root.custom[id]
    if (root.custom[name]) return root.custom[name]
    if (item.steamId && root.steam[item.steamId]) return root.steam[item.steamId].url
    return ""
  }

  Process {
    id: proc
    property var buf: []
    command: ["sh", "-c", root.script, "sh", root.home, root.customDir]
    stdout: SplitParser { onRead: line => proc.buf.push(line) }
    onRunningChanged: {
      if (running) return
      root.ingest(proc.buf)
      proc.buf = []
    }
  }
}
