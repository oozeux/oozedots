import QtQuick
import "../COMMON"

Text {
  id: root

  property string html: ""

  text: root.html
  textFormat: Text.RichText
  wrapMode: Text.NoWrap
  color: Theme.text
  font.family: Theme.monoFamily
  font.pixelSize: Theme.sfs(12)
}
