import QtQuick
import QtQuick.Layouts
import "../COMMON"
import "../Services/Lang"

ColumnLayout {
  id: pg

  property var model: []
  property var current: null

  signal picked(var value)

  readonly property int cols: pg.width >= 460 ? 3 : 2

  readonly property var groups: {
    const out = []
    for (const m of pg.model) {
      let g = null
      for (const x of out) if (x.id === m.group) { g = x; break }
      if (!g) { g = { id: m.group, items: [] }; out.push(g) }
      g.items.push(m)
    }
    return out
  }

  Layout.fillWidth: true
  spacing: 12

  Repeater {
    model: pg.groups

    delegate: ColumnLayout {
      id: grp
      required property var modelData

      Layout.fillWidth: true
      spacing: 6

      Text {
        Layout.fillWidth: true
        Layout.leftMargin: 2
        elide: Text.ElideRight
        text: Translations.t("advPalGroup_" + grp.modelData.id)
        color: Theme.subtext
        font.bold: true
        font.capitalization: Font.AllUppercase
        font.letterSpacing: 1.1
        font.pixelSize: Theme.sfs(9)
        font.family: Theme.fontFamily
      }

      Flow {
        id: tiles
        Layout.fillWidth: true
        spacing: 8
        readonly property real tileW: Math.floor((width - spacing * (pg.cols - 1)) / pg.cols)

        Repeater {
          model: grp.modelData.items

          delegate: SkinRect {
            id: tile
            required property var modelData

            readonly property bool active: tile.modelData.value === pg.current

            width: tiles.tileW
            height: 50
            radius: Theme.cozy ? 4 : MdTokens.rXs + 4
            color: tile.active ? Qt.tint(Theme.bg, Qt.rgba(Theme.primary.r, Theme.primary.g, Theme.primary.b, 0.18))
                 : (tileArea.containsMouse ? (Theme.cozy ? Theme.surfaceHigh : MdTokens.controlHover)
                                           : (Theme.cozy ? Theme.bg : MdTokens.control))
            border.width: tile.active ? 2 : (Theme.cozy ? Theme.bw1 : 1)
            border.color: tile.active ? Theme.primary : (Theme.cozy ? Theme.edge : MdTokens.controlEdge)
            Behavior on color { ColorAnimation { duration: Theme.animDuration(150) } }
            Behavior on border.color { ColorAnimation { duration: Theme.animDuration(150) } }

            RowLayout {
              anchors { fill: parent; leftMargin: 8; rightMargin: 10 }
              spacing: 10

              Rectangle {
                Layout.preferredWidth: 44
                Layout.preferredHeight: 34
                Layout.alignment: Qt.AlignVCenter
                radius: Theme.cozy ? 2 : 8
                color: tile.modelData.bg
                border.width: 1
                border.color: Qt.rgba(Theme.text.r, Theme.text.g, Theme.text.b, 0.22)
                clip: true

                Rectangle {
                  anchors { left: parent.left; right: parent.right; bottom: parent.bottom }
                  height: 11
                  color: tile.modelData.surface
                }
                Rectangle {
                  x: 6; y: 6
                  width: 16; height: 16
                  radius: Theme.cozy ? 0 : 8
                  color: tile.modelData.color
                }
                Rectangle {
                  x: 25; y: 11
                  width: 11; height: 11
                  radius: Theme.cozy ? 0 : 6
                  color: tile.modelData.tertiary
                }
              }

              ColumnLayout {
                Layout.fillWidth: true
                Layout.minimumWidth: 0
                Layout.alignment: Qt.AlignVCenter
                spacing: 0

                Text {
                  Layout.fillWidth: true
                  elide: Text.ElideRight
                  text: tile.modelData.label
                  color: Theme.text
                  font.bold: tile.active
                  font.pixelSize: Theme.sfs(11)
                  font.family: Theme.fontFamily
                }
                Text {
                  Layout.fillWidth: true
                  elide: Text.ElideRight
                  text: Translations.t(tile.modelData.dark ? "advPalDark" : "advPalLight")
                  color: Theme.subtext
                  font.pixelSize: Theme.sfs(9)
                  font.family: Theme.fontFamily
                }
              }

              Rectangle {
                Layout.preferredWidth: 8
                Layout.preferredHeight: 8
                Layout.alignment: Qt.AlignVCenter
                radius: 4
                color: Theme.primary
                visible: tile.active
              }
            }

            MouseArea {
              id: tileArea
              anchors.fill: parent
              hoverEnabled: true
              cursorShape: Qt.PointingHandCursor
              onClicked: pg.picked(tile.modelData.value)
            }
          }
        }
      }
    }
  }
}
