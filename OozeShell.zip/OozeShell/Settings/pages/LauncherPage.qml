// LauncherPage — categoría "Launcher": motor (Quickshell/Rofi), ubicación y tamaño, búsqueda y efectos.

import QtQuick
import QtQuick.Layouts
import ".."
import "../../COMMON"
import "../../Services/Lang"

SettingsPage {
  id: page
  catId: "launcher"

  readonly property bool rofiReady: WM.isInstalled("rofi")

  SettingsSection {
    titleKey: "lnBackendTitle"
    hintKey: "lnBackendHint"

    SettingsRow {
      stacked: true
      SettingsChoice {
        model: [
          { value: "quickshell", label: Translations.t("lnQuickshell"), icon: "󰀻" },
          { value: "rofi",       label: Translations.t("lnRofi"),       icon: "󰆍", enabled: page.rofiReady }
        ]
        current: (Theme.launcherBackend === "rofi" && page.rofiReady) ? "rofi" : "quickshell"
        onPicked: v => Theme.setLauncherBackend(v)
      }
    }

    SettingsNote {
      visible: !page.rofiReady
      kind: "error"
      text: Translations.t("lnRofiMissing")
    }
    SettingsNote {
      visible: page.rofiReady && Theme.launcherBackend === "rofi"
      text: Translations.t("lnRofiNote")
    }
  }

  SettingsSection {
    titleKey: "settingsLauncherSection"
    hintKey: "settingsLauncherHint"

    SettingsRow {
      titleKey: "settingsLauncherPlacement"
      SettingsChoice {
        model: [
          { value: true,  label: Translations.t("settingsLauncherBar"),    icon: "▀" },
          { value: false, label: Translations.t("settingsLauncherCenter"), icon: "▣" }
        ]
        current: Theme.launcherAttached
        onPicked: v => Theme.setLauncherAttached(v)
      }
    }

    SettingsRow {
      titleKey: "settingsLauncherFloating"
      hintKey: "settingsLauncherFloatingHint"
      visible: Theme.launcherAttached
      SettingsSwitch {
        checked: Theme.launcherFloating
        onToggled: Theme.setLauncherFloating(!Theme.launcherFloating)
      }
    }

    SettingsRow {
      titleKey: "settingsLauncherLayout"
      hintKey: "settingsLauncherLayoutHint"
      SettingsChoice {
        model: [
          { value: "split",   label: Translations.t("lnLayoutSplit") },
          { value: "frosted", label: Translations.t("lnLayoutFrosted") },
          { value: "detail",  label: Translations.t("lnLayoutDetail") },
          { value: "grid",    label: Translations.t("lnLayoutGrid") },
          { value: "deck",    label: Translations.t("lnLayoutDeck") },
          { value: "orbit",   label: Translations.t("lnLayoutOrbit") }
        ]
        current: Theme.launcherLayout
        onPicked: v => Theme.setLauncherLayout(v)
      }
    }

    SettingsRow {
      titleKey: "settingsLauncherSize"
      SettingsChoice {
        model: [
          { value: 0, label: Translations.t("settingsSizeCompact") },
          { value: 1, label: Translations.t("settingsSizeNormal") },
          { value: 2, label: Translations.t("settingsSizeLarge") }
        ]
        current: Theme.launcherSize
        onPicked: v => Theme.setLauncherSize(v)
      }
    }

    SettingsRow {
      titleKey: "settingsLauncherImage"
      SettingsSwitch {
        checked: Theme.launcherShowImage
        onToggled: Theme.setLauncherShowImage(!Theme.launcherShowImage)
      }
    }

    SettingsRow {
      titleKey: "settingsLauncherRecents"
      hintKey: "settingsLauncherRecentsHint"
      SettingsSwitch {
        checked: Theme.launcherRecents
        onToggled: Theme.setLauncherRecents(!Theme.launcherRecents)
      }
    }

    SettingsRow {
      titleKey: "settingsLauncherCapsule"
      hintKey: "settingsLauncherCapsuleHint"
      visible: Theme.launcherShowImage && Theme.launcherLayout !== "detail"
      SettingsSwitch {
        checked: Theme.launcherCapsule
        onToggled: Theme.setLauncherCapsule(!Theme.launcherCapsule)
      }
    }

    SettingsRow {
      titleKey: "settingsLauncherDoubleClick"
      hintKey: "settingsLauncherDoubleClickHint"
      SettingsSwitch {
        checked: Theme.launcherDoubleClick
        onToggled: Theme.setLauncherDoubleClick(!Theme.launcherDoubleClick)
      }
    }
  }

  SettingsSection {
    titleKey: "settingsLauncherPrefixes"
    hintKey: "settingsLauncherPrefixesHint"

    SettingsRow {
      title: "> · !"
      SettingsSwitch {
        checked: Theme.launcherCommandMode
        onToggled: Theme.setLauncherCommandMode(!Theme.launcherCommandMode)
      }
    }
  }

  SettingsSection {
    titleKey: "settingsEffectsSection"
    hintKey: "settingsEffectsHint"

    SettingsRow {
      titleKey: "settingsEffectsLabel"
      SettingsSwitch {
        checked: Theme.effectsOn
        onToggled: Theme.setEffects(!Theme.effectsOn)
      }
    }

    SettingsRow {
      titleKey: "settingsLauncherParticles"
      hintKey: "settingsLauncherParticlesHint"
      SettingsSwitch {
        checked: Theme.launcherParticlesEnabled
        onToggled: Theme.setLauncherParticlesEnabled(!Theme.launcherParticlesEnabled)
      }
    }

    SettingsRow {
      titleKey: "settingsLauncherParticleStyle"
      SettingsChoice {
        model: [
          { value: "dust",      label: Translations.t("lnParticleDust") },
          { value: "stars",     label: Translations.t("lnParticleStars") },
          { value: "snow",      label: Translations.t("lnParticleSnow") },
          { value: "fireflies", label: Translations.t("lnParticleFireflies") }
        ]
        current: Theme.launcherParticleStyle
        onPicked: v => Theme.setLauncherParticleStyle(v)
      }
    }

    SettingsRow {
      titleKey: "settingsLauncherParticlePattern"
      hintKey: "settingsLauncherParticlePatternHint"
      SettingsChoice {
        model: [
          { value: "even",    label: Translations.t("lnPatternEven") },
          { value: "random",  label: Translations.t("lnPatternRandom") },
          { value: "cascade", label: Translations.t("lnPatternCascade") }
        ]
        current: Theme.launcherParticlePattern
        onPicked: v => Theme.setLauncherParticlePattern(v)
      }
    }

    SettingsRow {
      titleKey: "settingsLauncherParticleDensity"
      SettingsChoice {
        model: [
          { value: 0, label: Translations.t("lnDensityLow") },
          { value: 1, label: Translations.t("lnDensityNormal") },
          { value: 2, label: Translations.t("lnDensityHigh") }
        ]
        current: Theme.launcherParticleDensity
        onPicked: v => Theme.setLauncherParticleDensity(v)
      }
    }

    SettingsRow {
      titleKey: "settingsLauncherGlow"
      hintKey: "settingsLauncherGlowHint"
      SettingsSwitch {
        checked: Theme.launcherGlowEnabled
        onToggled: Theme.setLauncherGlowEnabled(!Theme.launcherGlowEnabled)
      }
    }

    SettingsRow {
      titleKey: "settingsLauncherImageGlow"
      hintKey: "settingsLauncherImageGlowHint"
      visible: Theme.launcherShowImage && Theme.launcherLayout !== "detail"
      SettingsSwitch {
        checked: Theme.launcherImageGlow
        onToggled: Theme.setLauncherImageGlow(!Theme.launcherImageGlow)
      }
    }

    SettingsRow {
      titleKey: "settingsLauncherEnter"
      hintKey: "settingsLauncherEnterHint"
      SettingsChoice {
        model: [
          { value: "slide", label: Translations.t("lnEnterSlide") },
          { value: "fade",  label: Translations.t("lnEnterFade") },
          { value: "zoom",  label: Translations.t("lnEnterZoom") },
          { value: "none",  label: Translations.t("lnEnterNone") }
        ]
        current: Theme.launcherEnterAnim
        onPicked: v => Theme.setLauncherEnterAnim(v)
      }
    }

    SettingsRow {
      titleKey: "settingsLauncherWallpaperLive"
      hintKey: "settingsLauncherWallpaperLiveHint"
      SettingsSwitch {
        checked: Theme.launcherWallpaperLiveEnabled
        onToggled: Theme.setLauncherWallpaperLiveEnabled(!Theme.launcherWallpaperLiveEnabled)
      }
    }
  }
}
