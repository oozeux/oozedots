// AudioBgPage

import Quickshell
import QtQuick
import QtQuick.Layouts
import ".."
import "../../COMMON"
import "../../Services/Lang"
import "../../Modules/AudioBg"

SettingsPage {
  id: page
  catId: "audiobg"

  // ─── Utilidades ───
  function tr(prefix, id) {
    const k = prefix + id
    const t = Translations.t(k)
    return t === k ? id : t
  }
  function chips(prefix, list) { return list.map(v => ({ value: v, label: page.tr(prefix, v) })) }

  readonly property string statusText: AudioBgService.status === "error"
    ? Translations.t("abErr_" + (AudioBgService.error === "nocava" || AudioBgService.error === "python" ? AudioBgService.error : "cava"))
    : Translations.t("abStatus_" + AudioBgService.status)
  readonly property string statusKind: AudioBgService.status === "error" ? "error"
    : (AudioBgService.status === "active" ? "accent" : "info")

  component NumRow: SettingsRow {
    id: nr
    property string key: ""
    property int lo: 0
    property int hi: 100
    property int stp: 1
    property string unit: ""
    NumberStepper {
      Layout.fillWidth: false
      Layout.preferredWidth: 150
      Layout.preferredHeight: 34
      value: AudioBgConfig.values[nr.key] ?? nr.lo
      min: nr.lo
      max: nr.hi
      step: nr.stp
      suffix: nr.unit
      onEdited: v => AudioBgConfig.set(nr.key, v)
    }
  }

  // ─── General ───
  SettingsSection {
    titleKey: "abGeneralTitle"
    hintKey: "abGeneralHint"

    SettingsRow {
      titleKey: "abEnabled"
      SettingsSwitch {
        checked: AudioBgConfig.enabled
        onToggled: AudioBgConfig.set("enabled", !AudioBgConfig.enabled)
      }
    }

    SettingsRow {
      titleKey: "abDemo"
      hintKey: "abDemoHint"
      SettingsSwitch {
        checked: AudioBgConfig.demo
        onToggled: AudioBgConfig.set("demo", !AudioBgConfig.demo)
      }
    }

    SettingsRow {
      visible: Quickshell.screens.length > 1
      titleKey: "abMonitor"
      stacked: true
      SettingsChips {
        model: [{ value: "", label: Translations.t("abMonitorAll") }]
          .concat(Quickshell.screens.map(s => ({ value: s.name, label: s.name })))
        current: AudioBgConfig.monitor
        onPicked: v => AudioBgConfig.set("monitor", v)
      }
    }

    SettingsNote {
      visible: AudioBgConfig.enabled
      kind: page.statusKind
      text: page.statusText
    }
  }

  // ─── Posición ───
  SettingsSection {
    titleKey: "abPlacementTitle"
    hintKey: "abPlacementHint"

    SettingsRow {
      titleKey: "abEdge"
      hintKey: "abEdgeHint"
      stacked: true
      SettingsChips {
        model: page.chips("abEdge_", AudioBgConfig.edges)
        current: AudioBgConfig.edge
        onPicked: v => AudioBgConfig.set("edge", v)
      }
    }

    SettingsRow {
      titleKey: "abFit"
      hintKey: "abFitHint"
      stacked: true
      SettingsChips {
        model: page.chips("abFit_", AudioBgConfig.fitModes)
        current: AudioBgConfig.fit
        onPicked: v => AudioBgConfig.set("fit", v)
      }
    }

    SettingsRow {
      titleKey: "abLayer"
      hintKey: "abLayerHint"
      stacked: true
      SettingsChips {
        model: page.chips("abLayer_", AudioBgConfig.layers)
        current: AudioBgConfig.layer
        onPicked: v => AudioBgConfig.set("layer", v)
      }
    }

    SettingsRow {
      titleKey: "abRaise"
      SettingsBtn {
        icon: "󰁝"
        text: ""
        enabled: AudioBgConfig.enabled
        onClicked: AudioBgConfig.raiseRequested()
      }
    }

    NumRow { titleKey: "abThickness"; hintKey: "abThicknessHint"; key: "thickness"; lo: 5; hi: 100; stp: 5; unit: "%" }
  }

  // ─── Estilo ───
  SettingsSection {
    titleKey: "abStyleTitle"
    hintKey: "abStyleHint"

    SettingsRow {
      titleKey: "abStyle"
      stacked: true
      SettingsChips {
        model: page.chips("abStyle_", AudioBgConfig.styles)
        current: AudioBgConfig.style
        onPicked: v => AudioBgConfig.set("style", v)
      }
    }

    SettingsRow {
      titleKey: "abColor"
      stacked: true
      SettingsChips {
        model: page.chips("abColor_", AudioBgConfig.colorModes)
        current: AudioBgConfig.colorMode
        onPicked: v => AudioBgConfig.set("colorMode", v)
      }
    }

    SettingsRow {
      visible: AudioBgConfig.colorMode === "custom"
      titleKey: "abCustomColor"
      SettingsField {
        mono: true
        value: AudioBgConfig.customColor
        placeholder: "#c8a6f2"
        onSubmitted: t => AudioBgConfig.set("customColor", t)
      }
    }

    NumRow { titleKey: "abOpacity"; key: "opacity"; lo: 5; hi: 100; stp: 5; unit: "%" }
    NumRow { titleKey: "abGap"; key: "gap"; lo: 0; hi: 24; stp: 1; unit: " px" }
    NumRow { visible: ["radial", "blackhole", "void"].indexOf(AudioBgConfig.style) >= 0; titleKey: "abInner"; hintKey: "abInnerHint"; key: "inner"; lo: 10; hi: 80; stp: 5; unit: "%" }
    NumRow { titleKey: "abRoundness"; key: "roundness"; lo: 0; hi: 100; stp: 10; unit: "%" }

    SettingsRow {
      titleKey: "abPeaks"
      hintKey: "abPeaksHint"
      SettingsSwitch {
        checked: AudioBgConfig.peaks
        onToggled: AudioBgConfig.set("peaks", !AudioBgConfig.peaks)
      }
    }

    SettingsRow {
      titleKey: "abSymmetric"
      hintKey: "abSymmetricHint"
      stacked: true
      SettingsChips {
        model: page.chips("abSym_", AudioBgConfig.symmetricModes)
        current: AudioBgConfig.symmetric
        onPicked: v => AudioBgConfig.set("symmetric", v)
      }
    }
  }

  // ─── Audio ───
  SettingsSection {
    titleKey: "abAudioTitle"
    hintKey: "abAudioHint"

    NumRow { titleKey: "abBars"; hintKey: "abBarsHint"; key: "bars"; lo: 16; hi: 128; stp: 8 }
    NumRow { titleKey: "abFps"; hintKey: "abFpsHint"; key: "fps"; lo: 15; hi: 60; stp: 5 }
    NumRow { titleKey: "abSmooth"; key: "smooth"; lo: 0; hi: 100; stp: 5; unit: "%" }
    NumRow { titleKey: "abSensitivity"; key: "sensitivity"; lo: 20; hi: 400; stp: 10; unit: "%" }

    SettingsRow {
      titleKey: "abAutosens"
      hintKey: "abAutosensHint"
      SettingsSwitch {
        checked: AudioBgConfig.autosens
        onToggled: AudioBgConfig.set("autosens", !AudioBgConfig.autosens)
      }
    }

    SettingsNote { text: Translations.t("abNeedsCava") }
  }
}
