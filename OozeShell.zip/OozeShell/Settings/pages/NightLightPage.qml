// NightLightPage — categoría "Luz nocturna": activar, temperatura, programación y motor (hyprsunset / wlsunset / gammastep).

import QtQuick
import QtQuick.Layouts
import ".."
import "../../COMMON"
import "../../Core"
import "../../Services/Lang"
import "../../Services/NightLight"

SettingsPage {
  id: page
  catId: "nightlight"

  SettingsSection {
    titleKey: "nlMainTitle"
    hintKey: "nlMainHint"

    SettingsRow {
      titleKey: "nlEnable"
      SettingsSwitch {
        checked: NightLightBackend.enabled
        onToggled: NightLightBackend.toggle()
      }
    }

    SettingsRow {
      titleKey: "nlTemp"
      hintKey: "nlTempHint"
      ScaleSlider {
        Layout.fillWidth: false
        Layout.preferredWidth: 240
        value: NightLightBackend.temperature
        min: 1000
        max: 6500
        step: 100
        defaultValue: 4500
        suffix: " K"
        valueWidth: 64
        onEdited: v => NightLightBackend.set("temperature", v)
      }
    }

    SettingsRow {
      visible: NightLightBackend.resolved !== "wlsunset"
      titleKey: "nlGamma"
      hintKey: "nlGammaHint"
      divider: false
      ScaleSlider {
        Layout.fillWidth: false
        Layout.preferredWidth: 240
        value: NightLightBackend.gamma
        min: 50
        max: 100
        step: 5
        defaultValue: 100
        onEdited: v => NightLightBackend.set("gamma", v)
      }
    }
  }

  SettingsSection {
    titleKey: "nlScheduleTitle"
    hintKey: "nlScheduleHint"

    SettingsRow {
      titleKey: "nlMode"
      divider: NightLightBackend.mode === "schedule"
      SettingsChoice {
        model: [
          { value: "manual",   label: Translations.t("nlModeManual") },
          { value: "schedule", label: Translations.t("nlModeSchedule") }
        ]
        current: NightLightBackend.mode
        onPicked: v => NightLightBackend.set("mode", v)
      }
    }

    SettingsRow {
      visible: NightLightBackend.mode === "schedule"
      titleKey: "nlStart"
      SettingsField {
        Layout.preferredWidth: 110
        Layout.fillWidth: false
        mono: true
        placeholder: "20:00"
        value: NightLightBackend.startTime
        onSubmitted: text => { if (NightLightBackend.parseMin(text) >= 0) NightLightBackend.set("start", text.trim()) }
      }
    }

    SettingsRow {
      visible: NightLightBackend.mode === "schedule"
      titleKey: "nlEnd"
      hintKey: "nlTimeHint"
      divider: false
      SettingsField {
        Layout.preferredWidth: 110
        Layout.fillWidth: false
        mono: true
        placeholder: "07:00"
        value: NightLightBackend.endTime
        onSubmitted: text => { if (NightLightBackend.parseMin(text) >= 0) NightLightBackend.set("end", text.trim()) }
      }
    }
  }

  SettingsSection {
    titleKey: "nlEngineTitle"
    hintKey: "nlEngineHint"

    SettingsRow {
      titleKey: "nlTool"
      stacked: true
      SettingsChoice {
        model: {
          const m = [{ value: "auto", label: Translations.t("nlToolAuto") }]
          if (CompositorPlatform.isHyprland) m.push({ value: "hyprsunset", label: "hyprsunset" })
          m.push({ value: "wlsunset", label: "wlsunset" })
          m.push({ value: "gammastep", label: "gammastep" })
          return m
        }
        current: NightLightBackend.tool
        onPicked: v => NightLightBackend.set("tool", v)
      }
    }

    SettingsNote {
      visible: NightLightBackend.probed && NightLightBackend.resolved !== ""
      kind: NightLightBackend.failed ? "error" : "accent"
      text: NightLightBackend.failed
        ? Translations.t("nlStatusFailed") + " " + NightLightBackend.resolved
        : Translations.t("nlStatusUsing") + " " + NightLightBackend.resolved
    }

    SettingsNote {
      visible: NightLightBackend.probed && NightLightBackend.resolved === ""
      kind: "warn"
      text: Translations.t(CompositorPlatform.isHyprland ? "nlStatusNoneHypr" : "nlStatusNone")
    }

    SettingsRow {
      stacked: true
      divider: false
      SettingsBtn {
        icon: "󰑓"
        text: Translations.t("nlRecheck")
        onClicked: NightLightBackend.recheck()
      }
    }
  }
}
