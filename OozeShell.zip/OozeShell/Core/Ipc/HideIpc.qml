// CORE — HideIpc
// IPC: target="hide" get(): string, enable(), disable(), toggle(), mode(string), addWindow(string, string), addLayer(string), remove(string), apply()

import Quickshell
import Quickshell.Io
import QtQuick
import "../../Services/Hide"

Item {
  id: self
  property var shell
  IpcHandler {
    target: "hide"
    function get(): string { return HideConfig.get() }
    function enable(): void { HideConfig.setEnabled(true) }
    function disable(): void { HideConfig.setEnabled(false) }
    function toggle(): void { HideConfig.setEnabled(!HideConfig.enabled) }
    function mode(value: string): void { HideConfig.setMode(value) }
    function addWindow(appId: string, title: string): void { HideConfig.addWindow(appId, title) }
    function addLayer(namespace: string): void { HideConfig.addLayer(namespace) }
    function remove(id: string): void {
      const kind = HideConfig.layers.some(r => r.id === id) ? "layer" : "window"
      HideConfig.remove(kind, id)
    }
    function apply(): void { HideConfig.apply() }
  }
}
