// CORE — BarIpc
// IPC: target="bar" position(), togglePosition(), floating(), fusedIslands(), toggleFusedIslands(), fusedOutline(), toggleFusedOutline(), modularOutline(), toggleModularOutline(), get(): string

import Quickshell
import Quickshell.Io
import QtQuick
import "../../COMMON"

Item {
  id: self
  property var shell
  IpcHandler {
    target: "bar"
    function position(p: string): void { Theme.setBarPosition(p) }
    function togglePosition(): void {
      const flip = { top: "bottom", bottom: "top", left: "right", right: "left" }
      Theme.setBarPosition(flip[Theme.barPosition] ?? "top")
    }
    function floating(on: bool): void { Theme.setBarFloating(on) }
    function toggleFloating(): void { Theme.setBarFloating(!Theme.barFloatingPref) }

    function floatWindows(on: bool): void { Theme.setFloatWindows(on) }
    function toggleFloatWindows(): void { Theme.setFloatWindows(!Theme.floatWindowsPref) }
    function windowAnim(style: string): void { Theme.setWindowAnimStyle(style) }
    function cycleWindowAnim(): void {
      const list = Theme.windowAnimStyles
      Theme.setWindowAnimStyle(list[(list.indexOf(Theme.windowAnimStyle) + 1) % list.length])
    }

    function hidden(on: bool): void { Theme.setBarHidden(on) }
    function toggleHidden(): void { Theme.setBarHidden(!Theme.barHiddenPref) }
    function hiddenFrame(on: bool): void { Theme.setBarHiddenFrame(on) }
    function revealMode(mode: string): void { Theme.setBarRevealMode(mode) }
    function peek(): void { Theme.requestBarPeek("click") }

    function templateSave(name: string): bool { return Theme.saveBarTemplate(name) }
    function templateLoad(name: string): bool { return Theme.loadBarTemplate(name) }
    function templateDelete(name: string): bool { return Theme.deleteBarTemplate(name) }
    function templates(): string { return JSON.stringify(Theme.barBuiltinNames.concat(Theme.barTemplateNames)) }
    function islands(on: bool): void { Theme.setIslandsEnabled(on) }
    function toggleIslands(): void { Theme.setIslandsEnabled(!Theme.islandsPref) }
    function fusedIslands(on: bool): void { Theme.setFusedIslands(on) }
    function toggleFusedIslands(): void { Theme.setFusedIslands(!Theme.fusedIslandsPref) }
    function fusedOutline(on: bool): void { Theme.setFusedOutline(on) }
    function toggleFusedOutline(): void { Theme.setFusedOutline(!Theme.fusedOutlinePref) }
    function pill(on: bool): void { Theme.setPillModeEnabled(on) }
    function togglePill(): void { Theme.setPillModeEnabled(!Theme.pillModePref) }
    function workspaceStyle(style: string): void { Theme.setWorkspaceStyle(style) }
    function workspaceNameAfter(on: bool): void { Theme.setWorkspaceNameAfter(on) }
    function toggleWorkspaceNameAfter(): void { Theme.setWorkspaceNameAfter(!Theme.workspaceNameAfter) }
    function modular(on: bool): void { Theme.setBarModular(on) }
    function toggleModular(): void { Theme.setBarModular(!Theme.barModularPref) }
    function modularOutline(on: bool): void { Theme.setBarModularOutline(on) }
    function toggleModularOutline(): void { Theme.setBarModularOutline(!Theme.barModularOutlinePref) }
    function trayAdapt(on: bool): void { Theme.setTrayAdapt(on) }
    function toggleTrayAdapt(): void { Theme.setTrayAdapt(!Theme.trayAdaptPref) }
    function mixed(on: bool): void { Theme.setBarMixed(on) }
    function toggleMixed(): void { Theme.setBarMixed(!Theme.barMixedPref) }
    function mixedStyle(style: string): void { Theme.setBarMixedStyle(style) }
    function get(): string {
      return JSON.stringify({ position: Theme.barPosition, floating: Theme.barFloatingPref,
                              islands: Theme.islandsPref, fusedIslands: Theme.fusedIslandsPref, fusedOutline: Theme.fusedOutlinePref, pill: Theme.pillModePref,
                              modular: Theme.barModularPref, modularOutline: Theme.barModularOutlinePref, trayAdapt: Theme.trayAdaptPref, mixed: Theme.barMixedPref, mixedStyle: Theme.barMixedStyle,
                              floatWindows: Theme.floatWindowsPref, windowAnim: Theme.windowAnimStyle,
                              hidden: Theme.barHiddenPref, hiddenFrame: Theme.barHiddenFramePref, revealMode: Theme.barRevealMode })
    }
  }
}
