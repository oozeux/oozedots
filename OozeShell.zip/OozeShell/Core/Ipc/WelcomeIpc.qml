// CORE — WelcomeIpc
// IPC: target="welcome" open(), close(), toggle(), reset(), get(): string

import Quickshell
import Quickshell.Io
import QtQuick
import "../../Core"

Item {
  id: self
  property var shell
  IpcHandler {
    target: "welcome"
    function open(): void { self.shell.openPopup("welcome") }
    function close(): void { self.shell.welcomeOpen = false }
    function toggle(): void { self.shell.togglePopup("welcome") }
    function reset(): void { self.shell.resetWelcome() }
    function get(): string {
      return JSON.stringify({ done: ConfigService.config.welcomeDone === true, step: self.shell.welcomeStep })
    }
  }
}
