// CORE — NightLightIpc
// IPC: target="nightlight" toggle(), set(bool), get(): bool, temperature(int), adjust(int)

import Quickshell
import Quickshell.Io
import QtQuick
import "../../Services/NightLight"

Item {
  id: self
  property var shell
  IpcHandler {
    target: "nightlight"
    function toggle(): void { NightLightBackend.toggle(); self.shell.nightLightToast() }
    function set(on: bool): void { NightLightBackend.setEnabled(on); self.shell.nightLightToast() }
    function get(): bool { return NightLightBackend.enabled }
    function temperature(kelvin: int): void { NightLightBackend.setTemperature(kelvin); self.shell.nightLightToast() }
    function adjust(delta: int): void { NightLightBackend.adjust(delta); self.shell.nightLightToast() }
  }
}
