#!/usr/bin/env python3
import argparse
import json
import math
import os
import random
import sys

STYLES = {
    "dust": {"travel": (9000, 16000), "sway": (2600, 4400), "twinkle": (900, 2000), "cascade_travel": 11000},
    "stars": {"travel": (0, 0), "sway": (0, 0), "twinkle": (1400, 2500), "cascade_travel": 0, "cascade_twinkle": 2600},
    "snow": {"travel": (10000, 17000), "sway": (2600, 4400), "twinkle": (900, 2000), "cascade_travel": 12500},
    "fireflies": {"travel": (9000, 16000), "sway": (2600, 4400), "twinkle": (900, 2000), "cascade_travel": 9500},
}

DIRECTIONS = ("ltr", "rtl", "center", "edges")


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--style", default="dust", choices=sorted(STYLES))
    p.add_argument("--count", type=int, default=20)
    p.add_argument("--glyphs", type=int, default=3)
    p.add_argument("--pattern", default="even", choices=("even", "random", "cascade"))
    p.add_argument("--seed", type=int, default=None)
    p.add_argument("--aspect", type=float, default=16 / 9)
    p.add_argument("--avoid", default="")
    p.add_argument("--direction", default="", choices=("",) + DIRECTIONS)
    p.add_argument("--key", default="")
    return p.parse_args()


def parse_avoid(text):
    try:
        x0, y0, x1, y1 = (float(v) for v in text.split(","))
    except ValueError:
        return None
    if x1 <= x0 or y1 <= y0:
        return None
    return (x0, y0, x1, y1)


def inside(pt, rect):
    return rect is not None and rect[0] <= pt[0] <= rect[2] and rect[1] <= pt[1] <= rect[3]


def gap(a, b, aspect):
    return math.hypot((a[0] - b[0]) * aspect, a[1] - b[1])


def best_candidate(rng, count, aspect, avoid, tries):
    pts = []
    for _ in range(count):
        best, best_score = None, -1.0
        for _ in range(tries if pts else 1):
            c = (rng.random(), rng.random())
            d = min((gap(c, q, aspect) for q in pts), default=1.0)
            score = d * (0.3 if inside(c, avoid) else 1.0)
            if score > best_score:
                best, best_score = c, score
        pts.append(best)
    return pts


def dart_throw(rng, count, aspect, avoid):
    pts = []
    floor = 0.55 / math.sqrt(max(count, 1)) * 0.5
    attempts = 0
    while len(pts) < count and attempts < count * 60:
        attempts += 1
        c = (rng.random(), rng.random())
        if inside(c, avoid) and rng.random() < 0.7:
            continue
        if all(gap(c, q, aspect) >= floor for q in pts):
            pts.append(c)
    while len(pts) < count:
        pts.append((rng.random(), rng.random()))
    return pts


def wave_order(pts, direction):
    if direction == "ltr":
        key = lambda i: pts[i][0]
    elif direction == "rtl":
        key = lambda i: -pts[i][0]
    elif direction == "center":
        key = lambda i: abs(pts[i][0] - 0.5)
    else:
        key = lambda i: -abs(pts[i][0] - 0.5)
    return sorted(range(len(pts)), key=key)


def build(args):
    seed = args.seed
    if seed is None:
        seed = 7 if args.pattern == "even" else int.from_bytes(os.urandom(4), "big")
    rng = random.Random(seed)
    spec = STYLES[args.style]
    avoid = parse_avoid(args.avoid)
    count = max(1, min(args.count, 120))
    glyphs = max(1, args.glyphs)

    if args.pattern == "random":
        pts = dart_throw(rng, count, args.aspect, avoid)
    else:
        pts = best_candidate(rng, count, args.aspect, avoid, 14)

    direction = args.direction or ("ltr" if args.pattern != "cascade" else rng.choice(DIRECTIONS))
    delays = [0] * count
    if args.pattern == "cascade":
        order = wave_order(pts, direction)
        group = 3 if count <= 20 else 4
        step = rng.randint(190, 260)
        for rank, i in enumerate(order):
            delays[i] = (rank // group) * step + rng.randint(0, 40)

    motes = []
    for i, (x, y) in enumerate(pts):
        if args.pattern == "cascade":
            travel = int(spec["cascade_travel"] * rng.uniform(0.98, 1.02))
            twinkle = int(spec.get("cascade_twinkle", 1700) * rng.uniform(0.98, 1.02))
            phase = 0.0
        else:
            travel = rng.randint(*spec["travel"]) if spec["travel"][1] else 0
            twinkle = rng.randint(*spec["twinkle"])
            phase = round(rng.random(), 4)
        sway = rng.randint(*spec["sway"]) if spec["sway"][1] else 0
        motes.append({
            "x": round(x, 4),
            "y": round(y, 4),
            "g": rng.randrange(glyphs),
            "s": round(rng.random(), 4),
            "o": round(rng.random(), 4),
            "t": round(rng.random(), 4),
            "tr": travel,
            "sw": sway,
            "tw": twinkle,
            "ph": phase,
            "dl": delays[i],
        })
    return {"key": args.key, "seed": seed, "direction": direction, "motes": motes}


def main():
    args = parse_args()
    sys.stdout.write(json.dumps(build(args), separators=(",", ":")) + "\n")
    sys.stdout.flush()


if __name__ == "__main__":
    main()
