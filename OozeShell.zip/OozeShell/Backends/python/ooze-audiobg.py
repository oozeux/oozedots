#!/usr/bin/env python3

import argparse
import ctypes
import math
import random
import os
import re
import selectors
import shutil
import signal
import subprocess
import sys
import time

try:
    import tomllib
except ImportError:
    tomllib = None

# ─── Constantes ───

DEFAULT_CONFIG = os.path.expanduser("~/.config/oozeshell/audiobg.toml")
CAVA_KEYS = ("bars", "fps", "method", "source", "autosens", "lowCut", "highCut", "symmetric", "demo", "fpsCap")
WAVE_STYLES = ("wave", "line")
METHODS = ("pulse", "pipewire", "alsa", "fifo", "sndio", "oss", "jack", "portaudio", "shmem")
SYMMETRIC = ("off", "center", "edges")
SCALE = 1000
SILENCE_GATE = 0.006
IDLE_AFTER = 1.5
PEAK_HOLD = 0.45
PEAK_GRAVITY = 2.4
RESTART_BACKOFF = 3.0
CONFIG_POLL = 0.4

DEFAULTS = {
    "bars": 64,
    "fps": 60,
    "fpsCap": 0,
    "smooth": 55,
    "sensitivity": 100,
    "spread": 20,
    "autosens": True,
    "peaks": False,
    "symmetric": "off",
    "style": "bars",
    "method": "pulse",
    "source": "auto",
    "lowCut": 40,
    "highCut": 12000,
    "demo": False,
}


# ─── Utilidades ───

def clamp(v, lo, hi):
    return lo if v < lo else (hi if v > hi else v)


def as_int(v, default):
    try:
        return int(round(float(v)))
    except (TypeError, ValueError):
        return default


def as_bool(v, default):
    if isinstance(v, bool):
        return v
    if isinstance(v, str):
        return v.strip().lower() in ("1", "true", "yes", "on")
    return default


def emit(line):
    try:
        sys.stdout.write(line + "\n")
        sys.stdout.flush()
    except (BrokenPipeError, OSError):
        raise SystemExit(0)


def die_with_parent():
    try:
        libc = ctypes.CDLL("libc.so.6", use_errno=True)
        libc.prctl(1, int(signal.SIGTERM), 0, 0, 0)
    except Exception:
        pass


# ─── Configuración ───

def normalize(raw):
    cfg = dict(DEFAULTS)
    cfg["bars"] = clamp(as_int(raw.get("bars"), cfg["bars"]), 16, 128)
    cfg["fps"] = clamp(as_int(raw.get("fps"), cfg["fps"]), 15, 60)
    cfg["fpsCap"] = clamp(as_int(raw.get("fpsCap"), 0), 0, 60)
    cfg["smooth"] = clamp(as_int(raw.get("smooth"), cfg["smooth"]), 0, 100)
    cfg["sensitivity"] = clamp(as_int(raw.get("sensitivity"), cfg["sensitivity"]), 20, 400)
    cfg["spread"] = clamp(as_int(raw.get("spread"), cfg["spread"]), 0, 100)
    cfg["autosens"] = as_bool(raw.get("autosens"), cfg["autosens"])
    cfg["peaks"] = as_bool(raw.get("peaks"), cfg["peaks"])
    cfg["demo"] = as_bool(raw.get("demo"), cfg["demo"])
    sym = str(raw.get("symmetric", cfg["symmetric"]))
    cfg["symmetric"] = sym if sym in SYMMETRIC else "off"
    cfg["style"] = str(raw.get("style", cfg["style"]))
    method = str(raw.get("method", cfg["method"]))
    cfg["method"] = method if method in METHODS else "pulse"
    source = str(raw.get("source", cfg["source"]))
    cfg["source"] = source if re.fullmatch(r"[A-Za-z0-9_.:@\-]{1,120}", source) else "auto"
    cfg["lowCut"] = clamp(as_int(raw.get("lowCut"), cfg["lowCut"]), 20, 500)
    cfg["highCut"] = clamp(as_int(raw.get("highCut"), cfg["highCut"]), 2000, 20000)
    if cfg["fpsCap"] > 0:
        cfg["fps"] = min(cfg["fps"], max(15, cfg["fpsCap"]))
    if cfg["symmetric"] != "off":
        cfg["bars"] -= cfg["bars"] % 2
    return cfg


def read_config(path):
    if tomllib is None:
        raise RuntimeError("python>=3.11")
    with open(path, "rb") as fh:
        return normalize(tomllib.load(fh))


def mtime_of(path):
    try:
        return os.stat(path).st_mtime_ns
    except OSError:
        return 0


def cava_signature(cfg):
    return tuple(cfg[k] for k in CAVA_KEYS)


# ─── Procesado ───

class Engine:
    def __init__(self, cfg):
        self.last_t = None
        self.level = []
        self.peak = []
        self.hold = []
        self.fall = []
        self.configure(cfg)

    def configure(self, cfg):
        self.cfg = cfg
        self.sym = cfg["symmetric"]
        self.n_in = cfg["bars"] // 2 if self.sym != "off" else cfg["bars"]
        self.k = 4 if cfg["style"] in WAVE_STYLES else 1
        self.gain = cfg["sensitivity"] / 100.0
        self.spread = cfg["spread"] / 100.0 * 0.5
        self.attack_ms = 35.0
        self.release_ms = 70.0 + cfg["smooth"] * 3.2
        self.peaks_on = cfg["peaks"]
        if len(self.level) != self.n_in:
            self.level = [0.0] * self.n_in
            self.peak = [0.0] * self.n_in
            self.hold = [0.0] * self.n_in
            self.fall = [0.0] * self.n_in
        self.weights = [(1 - math.cos(i / self.k * math.pi)) / 2 for i in range(self.k)]

    def arrange(self, half):
        if self.sym == "center":
            return half[::-1] + half
        if self.sym == "edges":
            return half + half[::-1]
        return half

    def interpolate(self, vals):
        if self.k == 1 or len(vals) < 2:
            return vals
        out = []
        w = self.weights
        for i in range(len(vals) - 1):
            a = vals[i]
            d = vals[i + 1] - a
            for m in w:
                out.append(a + d * m)
        out.append(vals[-1])
        return out

    def step(self, raw, now):
        dt = 1.0 / 60 if self.last_t is None else clamp(now - self.last_t, 1.0 / 240, 0.25)
        self.last_t = now
        n = self.n_in
        g = self.gain
        src = [clamp(raw[i] / SCALE * g, 0.0, 1.0) if i < len(raw) else 0.0 for i in range(n)]

        s = self.spread
        if s > 0 and n > 2:
            sm = [0.0] * n
            sm[0] = src[0] * (1 - s) + src[1] * s
            sm[-1] = src[-1] * (1 - s) + src[-2] * s
            for i in range(1, n - 1):
                sm[i] = src[i] * (1 - 2 * s) + (src[i - 1] + src[i + 1]) * s
            src = sm

        ka = 1 - math.exp(-dt * 1000 / self.attack_ms)
        kr = 1 - math.exp(-dt * 1000 / self.release_ms)
        lvl = self.level
        for i in range(n):
            t = src[i]
            p = lvl[i]
            v = p + (t - p) * (ka if t > p else kr)
            lvl[i] = 0.0 if v < SILENCE_GATE and t < SILENCE_GATE else v

        if self.peaks_on:
            pk, hd, fl = self.peak, self.hold, self.fall
            for i in range(n):
                if lvl[i] >= pk[i]:
                    pk[i] = lvl[i]
                    hd[i] = PEAK_HOLD
                    fl[i] = 0.0
                elif hd[i] > 0:
                    hd[i] -= dt
                else:
                    fl[i] += PEAK_GRAVITY * dt
                    pk[i] = max(lvl[i], pk[i] - fl[i] * dt)
        else:
            pk = None

        vals = self.interpolate(self.arrange(lvl[:]))
        quant = [int(v * SCALE + 0.5) for v in vals]
        line = "D " + " ".join(map(str, quant))
        if pk is not None:
            peaks = self.interpolate(self.arrange(pk[:]))
            line += "|" + " ".join(str(int(v * SCALE + 0.5)) for v in peaks)
        return line, any(quant)


# ─── Fuentes de datos ───

class CavaSource:
    def __init__(self, cfg, conf_path):
        self.cfg = cfg
        self.conf_path = conf_path
        self.proc = None
        self.buf = b""
        self.sel = None

    def write_conf(self):
        cfg = self.cfg
        n = cfg["bars"] // 2 if cfg["symmetric"] != "off" else cfg["bars"]
        text = "\n".join([
            "[general]",
            "framerate = %d" % cfg["fps"],
            "autosens = %d" % (1 if cfg["autosens"] else 0),
            "bars = %d" % n,
            "lower_cutoff_freq = %d" % cfg["lowCut"],
            "higher_cutoff_freq = %d" % cfg["highCut"],
            "[input]",
            "method = %s" % cfg["method"],
            "source = %s" % cfg["source"],
            "[output]",
            "method = raw",
            "raw_target = /dev/stdout",
            "data_format = ascii",
            "ascii_max_range = %d" % SCALE,
            "bar_delimiter = 59",
            "frame_delimiter = 10",
            "channels = mono",
            "[smoothing]",
            "noise_reduction = 60",
            "",
        ])
        os.makedirs(os.path.dirname(self.conf_path), exist_ok=True)
        with open(self.conf_path, "w") as fh:
            fh.write(text)

    def start(self):
        self.write_conf()
        self.proc = subprocess.Popen(
            ["cava", "-p", self.conf_path],
            stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, stdin=subprocess.DEVNULL,
            preexec_fn=die_with_parent)
        os.set_blocking(self.proc.stdout.fileno(), False)
        self.sel = selectors.DefaultSelector()
        self.sel.register(self.proc.stdout, selectors.EVENT_READ)
        self.buf = b""

    def alive(self):
        return self.proc is not None and self.proc.poll() is None

    def read(self, timeout):
        if self.proc is None:
            return None, False
        if not self.sel.select(timeout):
            return None, True
        try:
            chunk = os.read(self.proc.stdout.fileno(), 65536)
        except BlockingIOError:
            return None, True
        if chunk == b"":
            return None, False
        self.buf += chunk
        if b"\n" not in self.buf:
            return None, True
        lines = self.buf.split(b"\n")
        self.buf = lines[-1]
        for raw in reversed(lines[:-1]):
            parts = [p for p in raw.decode("ascii", "ignore").split(";") if p != ""]
            if parts:
                try:
                    return [int(p) for p in parts], True
                except ValueError:
                    continue
        return None, True

    def stop(self):
        if self.proc is None:
            return
        try:
            self.proc.terminate()
            self.proc.wait(timeout=1.5)
        except Exception:
            try:
                self.proc.kill()
            except Exception:
                pass
        try:
            self.sel.close()
        except Exception:
            pass
        self.proc = None


class DemoSource:
    def __init__(self, cfg):
        self.cfg = cfg
        self.t0 = time.monotonic()
        self.next = 0.0
        self.level = []

    def start(self):
        self.next = time.monotonic()

    def alive(self):
        return True

    def read(self, timeout):
        now = time.monotonic()
        wait = self.next - now
        if wait > 0:
            time.sleep(min(wait, timeout))
            if self.next - time.monotonic() > 0:
                return None, True
        self.next = max(self.next + 1.0 / self.cfg["fps"], time.monotonic() - 0.1)
        n = self.cfg["bars"] // 2 if self.cfg["symmetric"] != "off" else self.cfg["bars"]
        t = time.monotonic() - self.t0
        if len(self.level) != n:
            self.level = [0.0] * n
        beat = max(0.0, math.sin(t * 4.1)) ** 8
        out = []
        for i in range(n):
            x = i / max(1, n - 1)
            env = 0.95 - 0.7 * x ** 0.7
            spike = random.random() ** 2.4
            wobble = 0.55 + 0.45 * abs(math.sin(t * 1.7 + i * 0.9))
            target = clamp(env * (0.15 + 0.85 * spike) * wobble + beat * (1 - x) ** 2 * 0.5, 0.0, 1.0)
            cur = self.level[i]
            cur = cur + (target - cur) * 0.65 if target > cur else cur * 0.86
            self.level[i] = cur
            out.append(int(cur * SCALE))
        return out, True

    def stop(self):
        pass


# ─── Bucle principal ───

def conf_path_for_cava():
    base = os.environ.get("XDG_RUNTIME_DIR") or "/tmp"
    return os.path.join(base, "oozeshell", "audiobg-cava-%d.conf" % os.getuid())


def make_source(cfg):
    return DemoSource(cfg) if cfg["demo"] else CavaSource(cfg, conf_path_for_cava())


def run(path):
    if tomllib is None:
        emit("S error python")
        return 2

    cfg = None
    waited = 0.0
    while cfg is None:
        try:
            cfg = read_config(path)
        except FileNotFoundError:
            cfg = normalize({})
        except Exception:
            time.sleep(0.5)
            waited += 0.5
            if waited > 5:
                cfg = normalize({})

    if not cfg["demo"] and shutil.which("cava") is None:
        emit("S error nocava")
        return 3

    engine = Engine(cfg)
    source = make_source(cfg)
    signature = cava_signature(cfg)
    stamp = mtime_of(path)
    next_poll = time.monotonic() + CONFIG_POLL
    state = "starting"
    emit("S starting")
    last_line = ""
    silent_since = None
    restart_at = 0.0
    running = False
    stop_flag = {"v": False}

    def on_term(*_):
        stop_flag["v"] = True

    signal.signal(signal.SIGTERM, on_term)
    signal.signal(signal.SIGINT, on_term)
    parent = os.getppid()

    def set_state(s):
        nonlocal state
        if s != state:
            state = s
            emit("S " + s)

    try:
        while not stop_flag["v"]:
            now = time.monotonic()

            if os.getppid() != parent:
                break

            if now >= next_poll:
                next_poll = now + CONFIG_POLL
                m = mtime_of(path)
                if m != stamp:
                    stamp = m
                    try:
                        new = read_config(path)
                    except Exception:
                        new = None
                    if new is not None:
                        if not new["demo"] and shutil.which("cava") is None:
                            emit("S error nocava")
                            break
                        sig = cava_signature(new)
                        engine.configure(new)
                        cfg = new
                        if sig != signature:
                            signature = sig
                            source.stop()
                            source = make_source(cfg)
                            running = False
                            restart_at = 0.0
                            last_line = ""

            if not running:
                if now < restart_at:
                    time.sleep(0.05)
                    continue
                try:
                    source.start()
                    running = True
                except Exception:
                    emit("S error cava")
                    restart_at = now + RESTART_BACKOFF
                    continue

            raw, ok = source.read(CONFIG_POLL)
            if not ok or not source.alive():
                source.stop()
                running = False
                restart_at = time.monotonic() + RESTART_BACKOFF
                state = "error"
                emit("S error cava-exit")
                source = make_source(cfg)
                continue
            if raw is None:
                continue

            line, loud = engine.step(raw, time.monotonic())
            if loud:
                silent_since = None
                set_state("active")
            else:
                if silent_since is None:
                    silent_since = time.monotonic()
                if state in ("active", "starting") and time.monotonic() - silent_since > IDLE_AFTER:
                    if line != last_line:
                        emit(line)
                        last_line = line
                    set_state("idle")
            if line != last_line and state != "idle":
                emit(line)
                last_line = line
    finally:
        source.stop()
    return 0


def main():
    die_with_parent()
    ap = argparse.ArgumentParser(prog="ooze-audiobg")
    ap.add_argument("--config", default=DEFAULT_CONFIG)
    args = ap.parse_args()
    try:
        sys.exit(run(args.config))
    except KeyboardInterrupt:
        sys.exit(0)


if __name__ == "__main__":
    main()
