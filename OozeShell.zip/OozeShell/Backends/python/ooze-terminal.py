#!/usr/bin/env python3
# BACKEND — ooze-terminal

import hashlib
import json
import os
import re
import shutil
import subprocess
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "Tools"))
import ooze_toml

HOME = os.path.expanduser("~")
CONFIG = os.environ.get("XDG_CONFIG_HOME") or os.path.join(HOME, ".config")
CACHE = os.environ.get("XDG_CACHE_HOME") or os.path.join(HOME, ".cache")
STATE_DIR = os.path.join(CONFIG, "oozeshell")
STATE_FILE = os.path.join(STATE_DIR, "terminal.toml")
ANSI_FILE = os.path.join(STATE_DIR, "fastfetch-logo.ansi")
IMAGES_DIR = os.path.join(HOME, ".config", "fastfetch", "images")
USER_CONFIG = os.path.join(HOME, ".config", "fastfetch", "config.jsonc")
CACHE_DIR = os.path.join(CACHE, "oozeshell", "terminal")
IMAGE_EXTS = (".png", ".jpg", ".jpeg", ".gif", ".webp")
PREVIEW_TIMEOUT = 10
IMPORT_LIMIT = 200000
DEFAULT_FG = "#cdd9e5"
STYLE_OK = re.compile(r"^[A-Za-z0-9_/-]+$")
PRESET_OK = re.compile(r"^[A-Za-z0-9_/-]+$")


# ─── ANSI ─────────────────────────────────────────────────────────────────
ESC = "\x1b"
BASE = ["#1e1e2e", "#e5534b", "#57ab5a", "#c69026", "#539bf5", "#b083f0", "#39c5cf", "#adbac7",
        "#545d68", "#ff938a", "#6bc46d", "#daaa3f", "#6cb6ff", "#dcbdfb", "#56d4dd", "#cdd9e5"]
NOTATIONS = re.compile(r"\\(?:e|E|033|x1[bB]|u001[bB])")
TOKEN = re.compile(r"\x1b\[([0-9;:]*)m|\x1b\[[0-9;?]*[A-Za-ln-z]|\x1b\][^\x07]*\x07")
CSI_ALL = re.compile(r"\x1b\[[0-9;:?]*[A-Za-z]")
OSC_ALL = re.compile(r"\x1b\][^\x07]*\x07")


def normalize(text):
    return NOTATIONS.sub(ESC, text or "")


def denormalize(text):
    return (text or "").replace(ESC, "\\e")


def rgb(r, g, b):
    return "#%02x%02x%02x" % tuple(max(0, min(255, int(v))) for v in (r, g, b))


def palette256(n):
    if n < 16:
        return BASE[n]
    if n >= 232:
        v = 8 + (n - 232) * 10
        return rgb(v, v, v)
    i = n - 16
    lv = [0, 95, 135, 175, 215, 255]
    return rgb(lv[(i // 36) % 6], lv[(i // 6) % 6], lv[i % 6])


def fresh_state():
    return {"fg": None, "bg": None, "bold": False, "italic": False, "underline": False, "reverse": False}


def apply_sgr(st, params):
    p = params if params else [0]
    i = 0
    while i < len(p):
        c = p[i]
        if c == 0:
            st.update(fresh_state())
        elif c == 1:
            st["bold"] = True
        elif c == 3:
            st["italic"] = True
        elif c == 4:
            st["underline"] = True
        elif c == 7:
            st["reverse"] = True
        elif c == 22:
            st["bold"] = False
        elif c == 23:
            st["italic"] = False
        elif c == 24:
            st["underline"] = False
        elif c == 27:
            st["reverse"] = False
        elif 30 <= c <= 37:
            st["fg"] = BASE[c - 30]
        elif 90 <= c <= 97:
            st["fg"] = BASE[c - 90 + 8]
        elif 40 <= c <= 47:
            st["bg"] = BASE[c - 40]
        elif 100 <= c <= 107:
            st["bg"] = BASE[c - 100 + 8]
        elif c == 39:
            st["fg"] = None
        elif c == 49:
            st["bg"] = None
        elif c in (38, 48):
            nxt = p[i + 1] if i + 1 < len(p) else None
            if nxt == 5 and len(p) > i + 2:
                col = palette256(p[i + 2])
                i += 2
            elif nxt == 2 and len(p) > i + 4:
                col = rgb(p[i + 2], p[i + 3], p[i + 4])
                i += 4
            else:
                break
            st["fg" if c == 38 else "bg"] = col
        i += 1


def style_of(st, default_fg):
    fg, bg = st["fg"], st["bg"]
    if st["reverse"]:
        fg, bg = (bg or "#000000"), (fg or default_fg)
    css = []
    if fg:
        css.append("color:" + fg)
    if bg:
        css.append("background-color:" + bg)
    if st["bold"]:
        css.append("font-weight:bold")
    if st["italic"]:
        css.append("font-style:italic")
    if st["underline"]:
        css.append("text-decoration:underline")
    return ";".join(css)


def escape_html(s):
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def to_html(text, default_fg=DEFAULT_FG):
    src = normalize(text)
    st = fresh_state()
    out = ['<pre style="margin:0">']
    state = {"css": "", "buf": []}

    def flush():
        if not state["buf"]:
            return
        safe = escape_html("".join(state["buf"]))
        state["buf"] = []
        out.append(safe if state["css"] == "" else '<span style="%s">%s</span>' % (state["css"], safe))

    def push(chunk):
        if chunk == "":
            return
        css = style_of(st, default_fg)
        if css != state["css"]:
            flush()
            state["css"] = css
        state["buf"].append(chunk)

    last = 0
    for m in TOKEN.finditer(src):
        push(src[last:m.start()])
        last = m.end()
        if m.group(1) is not None:
            raw = m.group(1)
            params = [] if raw == "" else [to_int(x) for x in re.split(r"[;:]", raw)]
            apply_sgr(st, params)
    push(src[last:])
    flush()
    out.append("</pre>")
    return "".join(out)


def to_int(x):
    try:
        return int(x)
    except ValueError:
        return 0


def strip_codes(text):
    return OSC_ALL.sub("", CSI_ALL.sub("", normalize(text)))


def measure(text):
    lines = strip_codes(text).rstrip("\n").split("\n")
    cols = max((len(l) for l in lines), default=0)
    return (0 if text == "" else len(lines)), cols


# ─── ARCHIVOS ─────────────────────────────────────────────────────────────
def mtime(path):
    try:
        return int(os.stat(path).st_mtime)
    except OSError:
        return 0


def read_text(path, limit=None):
    try:
        with open(path, "rb") as fh:
            raw = fh.read(limit) if limit else fh.read()
    except OSError:
        return ""
    return raw.decode("utf-8", errors="replace")


def write_atomic(path, text):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        fh.write(text)
    os.replace(tmp, path)


def read_state():
    try:
        data = ooze_toml.read(STATE_FILE)
    except Exception:
        data = None
    return data if isinstance(data, dict) else {}


def write_state(data):
    ooze_toml.write(STATE_FILE, data)


def payload():
    return os.environ.get("OOZE_DATA", "")


# ─── IMÁGENES Y PRESETS ───────────────────────────────────────────────────
def list_images():
    try:
        names = [n for n in os.listdir(IMAGES_DIR)
                 if n.lower().endswith(IMAGE_EXTS) and os.path.isfile(os.path.join(IMAGES_DIR, n))]
    except OSError:
        return []
    return sorted(names)


def preset_order(name):
    if name.startswith("examples/"):
        try:
            return (1, int(name[9:]), "")
        except ValueError:
            return (1, 0, name)
    return (0, 0, name)


def list_presets():
    try:
        res = subprocess.run(["fastfetch", "--list-presets", "autocompletion"],
                             capture_output=True, text=True, timeout=8)
    except (OSError, subprocess.TimeoutExpired):
        return []
    names = set()
    for line in (res.stdout or "").splitlines():
        name = re.sub(r"\.jsonc?$", "", line.strip())
        if name and PRESET_OK.match(name):
            names.add(name)
    return sorted(names, key=preset_order)


# ─── COMANDOS ─────────────────────────────────────────────────────────────
def cmd_init(args):
    os.makedirs(STATE_DIR, exist_ok=True)
    return {"ok": True, "data": read_state(), "images": list_images(),
            "ansi": denormalize(read_text(ANSI_FILE).rstrip("\n"))}


def cmd_images(args):
    return {"ok": True, "images": list_images()}


def cmd_presets(args):
    return {"ok": True, "presets": list_presets()}


def cmd_save(args):
    data = json.loads(payload() or "{}")
    if not isinstance(data, dict):
        return {"ok": False, "error": "invalid"}
    current = read_state()
    current.update(data)
    write_state(current)
    return {"ok": True}


def cmd_preview(args):
    style = args[0] if args else "config"
    force = len(args) > 1 and args[1] == "force"
    if style != "config" and (not STYLE_OK.match(style) or ".." in style):
        return {"ok": False, "error": "style"}
    key = hashlib.sha1(style.encode()).hexdigest()[:16]
    cache_file = os.path.join(CACHE_DIR, "preview-%s.json" % key)
    stamp = "%s|%s" % (mtime(USER_CONFIG) if style == "config" else 0, mtime(shutil.which("fastfetch") or ""))
    if not force:
        try:
            with open(cache_file, "r", encoding="utf-8") as fh:
                cached = json.load(fh)
            if cached.get("stamp") == stamp and cached.get("html"):
                return {"ok": True, "html": cached["html"], "cached": True}
        except (OSError, ValueError):
            pass
    cmd = ["fastfetch"] + ([] if style == "config" else ["--config", style]) \
        + ["--logo-type", "none", "--pipe", "false"]
    try:
        res = subprocess.run(cmd, capture_output=True, text=True, errors="replace",
                             timeout=PREVIEW_TIMEOUT, preexec_fn=lambda: os.nice(19))
    except FileNotFoundError:
        return {"ok": False, "error": "missing"}
    except subprocess.TimeoutExpired:
        return {"ok": False, "error": "timeout"}
    out = (res.stdout or "").rstrip("\n")
    if out == "":
        return {"ok": False, "error": "empty"}
    html = to_html(out)
    try:
        write_atomic(cache_file, json.dumps({"stamp": stamp, "html": html}))
    except OSError:
        pass
    return {"ok": True, "html": html, "cached": False}


def cmd_render(args):
    text = payload()
    lines, cols = measure(text)
    saved = read_text(ANSI_FILE).rstrip("\n")
    current = normalize(text).rstrip("\n")
    return {"ok": True, "html": to_html(text) if text != "" else "", "lines": lines, "cols": cols,
            "dirty": current != saved}


def cmd_save_ansi(args):
    real = normalize(payload()).rstrip("\n")
    write_atomic(ANSI_FILE, real + "\n")
    data = read_state()
    data["fastfetchSource"] = "ansi"
    write_state(data)
    lines, cols = measure(real)
    return {"ok": True, "text": denormalize(real), "lines": lines, "cols": cols}


def cmd_import(args):
    if not args or args[0] == "":
        return {"ok": False, "error": "path"}
    text = read_text(args[0], IMPORT_LIMIT)
    if text == "":
        return {"ok": False, "error": "empty"}
    return {"ok": True, "text": denormalize(text.rstrip("\n"))}


COMMANDS = {
    "init": cmd_init,
    "images": cmd_images,
    "presets": cmd_presets,
    "save": cmd_save,
    "preview": cmd_preview,
    "render": cmd_render,
    "save-ansi": cmd_save_ansi,
    "import": cmd_import,
}


def main(argv):
    name = argv[1] if len(argv) > 1 else ""
    fn = COMMANDS.get(name)
    if fn is None:
        result = {"ok": False, "error": "unknown-command"}
    else:
        try:
            result = fn(argv[2:])
        except Exception as exc:
            result = {"ok": False, "error": str(exc)[:200]}
    sys.stdout.write(json.dumps(result, ensure_ascii=False) + "\n")
    sys.stdout.flush()
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
