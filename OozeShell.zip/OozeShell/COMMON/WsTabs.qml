// WsTabs.qml — COMMON

import QtQuick
import QtQuick.Layouts

WsBase {
  id: root

  readonly property real tabH: 22
  readonly property real gap: 5

  implicitWidth: grid.implicitWidth
  implicitHeight: grid.implicitHeight

  // ─── Pestañas ───
  GridLayout {
    id: grid
    anchors.centerIn: parent
    flow: root.vertical ? GridLayout.LeftToRight : GridLayout.TopToBottom
    columns: root.vertical ? 1 : -1
    rows: root.vertical ? -1 : 1
    columnSpacing: root.gap
    rowSpacing: root.gap

    Repeater {
      model: root.items
      delegate: Item {
        id: tab
        required property var modelData
        readonly property bool isActive: !!tab.modelData.active
        readonly property bool isUrgent: !!tab.modelData.urgent && !tab.isActive
        readonly property bool hot: area.containsMouse

        Layout.preferredWidth: Math.max(26, label.implicitWidth + 16)
        Layout.preferredHeight: root.tabH
        Layout.alignment: root.vertical ? Qt.AlignHCenter : Qt.AlignVCenter

        Rectangle {
          visible: tab.isActive && !Theme.cozy
          anchors.centerIn: parent
          width: parent.width + 6
          height: parent.height + 6
          radius: height / 2
          color: root.accent
          opacity: 0.22
        }

        Rectangle {
          anchors.fill: parent
          radius: height / 2
          color: tab.isActive ? root.accent : (tab.isUrgent ? Qt.alpha(Theme.error, 0.25) : (tab.hot ? root.hoverColor : Qt.alpha(root.accent, 0.08)))
          border.width: tab.isActive ? 0 : 1
          border.color: tab.isUrgent ? Theme.error : Qt.alpha(root.accent, tab.hot ? 0.6 : 0.3)
          Behavior on color { ColorAnimation { duration: Theme.animDuration(150) } }
        }

        Text {
          id: label
          anchors.centerIn: parent
          text: String(tab.modelData.id)
          color: tab.isActive ? root.onAccent : (tab.isUrgent ? Theme.error : (tab.hot ? Theme.text : Theme.subtext))
          font.family: Theme.fontFamily
          font.pixelSize: Theme.fs(12)
          font.bold: tab.isActive
          Behavior on color { ColorAnimation { duration: Theme.animDuration(150) } }
        }

        MouseArea {
          id: area
          anchors.fill: parent
          hoverEnabled: true
          cursorShape: Qt.PointingHandCursor
          onClicked: WM.clickWorkspace(tab.modelData)
        }
      }
    }
  }
}
