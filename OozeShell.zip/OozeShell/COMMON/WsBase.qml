// WsBase.qml — COMMON

import QtQuick

Item {
  id: base

  property var host: null

  readonly property var items: base.host ? base.host.shown : []
  readonly property bool vertical: base.host ? base.host.vertical : false
  readonly property color accent: base.host ? base.host.accent : Theme.primary
  readonly property color onAccent: base.host ? base.host.onAccent : Theme.textOnPrimary
  readonly property color hoverColor: base.host ? base.host.hoverColor : Theme.surfaceHigh
  readonly property int count: base.items.length

  readonly property int activeIndex: {
    for (let i = 0; i < base.items.length; i++)
      if (base.items[i].active) return i
    return -1
  }
}
