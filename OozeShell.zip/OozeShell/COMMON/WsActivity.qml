// WsActivity.qml — COMMON

import QtQuick
import QtQuick.Layouts

WsBase {
  id: root

  readonly property real barThick: 4
  readonly property real gap: 4
  readonly property real face: 16

  implicitWidth: root.vertical ? root.face : grid.implicitWidth
  implicitHeight: root.vertical ? grid.implicitHeight : root.face

  // ─── Barras ───
  GridLayout {
    id: grid
    anchors.centerIn: parent
    flow: root.vertical ? GridLayout.LeftToRight : GridLayout.TopToBottom
    columns: root.vertical ? 1 : -1
    rows: root.vertical ? -1 : 1
    columnSpacing: root.gap
    rowSpacing: root.gap

    Repeater {
      model: root.items
      delegate: Item {
        id: cell
        required property var modelData
        required property int index
        readonly property bool isActive: !!cell.modelData.active
        readonly property bool isUrgent: !!cell.modelData.urgent && !cell.isActive
        readonly property bool isEmpty: cell.modelData.occupied === false && !cell.isActive
        readonly property bool hot: area.containsMouse
        readonly property int dist: root.activeIndex >= 0 ? Math.abs(index - root.activeIndex) : 3
        readonly property real len: cell.isActive ? root.face : (cell.isEmpty ? 5 : Math.max(5, 12 - (cell.dist - 1) * 2.5))

        Layout.preferredWidth: root.vertical ? root.face : root.barThick
        Layout.preferredHeight: root.vertical ? root.barThick : root.face

        Rectangle {
          id: bar
          x: 0
          y: root.vertical ? 0 : cell.height - bar.height
          width: root.vertical ? cell.len : root.barThick
          height: root.vertical ? root.barThick : cell.len
          radius: root.barThick / 2
          color: cell.isUrgent ? Theme.error
               : (cell.isActive ? root.accent
               : (cell.hot ? Theme.text : Qt.alpha(root.accent, cell.isEmpty ? 0.22 : 0.42)))
          Behavior on width { NumberAnimation { duration: Theme.animDuration(180); easing.type: Easing.OutCubic } }
          Behavior on height { NumberAnimation { duration: Theme.animDuration(180); easing.type: Easing.OutCubic } }
          Behavior on color { ColorAnimation { duration: Theme.animDuration(150) } }
        }

        MouseArea {
          id: area
          anchors.fill: parent
          anchors.margins: -2
          hoverEnabled: true
          cursorShape: Qt.PointingHandCursor
          onClicked: WM.clickWorkspace(cell.modelData)
        }
      }
    }
  }
}
