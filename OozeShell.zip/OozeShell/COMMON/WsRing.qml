// WsRing.qml — COMMON

import QtQuick
import QtQuick.Layouts
import QtQuick.Shapes

WsBase {
  id: root

  readonly property real ringSize: 24
  readonly property real stroke: 2.5
  readonly property real gap: 5

  implicitWidth: grid.implicitWidth
  implicitHeight: grid.implicitHeight

  // ─── Círculos ───
  GridLayout {
    id: grid
    anchors.centerIn: parent
    flow: root.vertical ? GridLayout.LeftToRight : GridLayout.TopToBottom
    columns: root.vertical ? 1 : -1
    rows: root.vertical ? -1 : 1
    columnSpacing: root.gap
    rowSpacing: root.gap

    Repeater {
      model: root.items
      delegate: Item {
        id: cell
        required property var modelData
        required property int index
        readonly property bool isActive: !!cell.modelData.active
        readonly property bool isUrgent: !!cell.modelData.urgent && !cell.isActive
        readonly property bool hot: area.containsMouse
        property real sweep: cell.isActive && root.count > 0 ? 359.9 * (cell.index + 1) / root.count : 0
        readonly property color tone: cell.isUrgent ? Theme.error : root.accent

        Layout.preferredWidth: root.ringSize
        Layout.preferredHeight: root.ringSize
        Behavior on sweep { NumberAnimation { duration: Theme.animDuration(260); easing.type: Easing.OutCubic } }

        Rectangle {
          visible: cell.isActive && !Theme.cozy
          anchors.centerIn: parent
          width: parent.width + 6
          height: parent.height + 6
          radius: width / 2
          color: root.accent
          opacity: 0.16
        }

        Rectangle {
          anchors.fill: parent
          radius: width / 2
          color: "transparent"
          border.width: root.stroke
          border.color: cell.isUrgent ? Theme.error : Qt.alpha(root.accent, cell.hot ? 0.6 : 0.28)
        }

        Shape {
          id: arc
          visible: cell.sweep > 0.5
          anchors.fill: parent
          preferredRendererType: Shape.CurveRenderer
          ShapePath {
            strokeColor: cell.tone
            strokeWidth: root.stroke
            fillColor: "transparent"
            capStyle: ShapePath.RoundCap
            PathAngleArc {
              centerX: arc.width / 2
              centerY: arc.height / 2
              radiusX: (arc.width - root.stroke) / 2
              radiusY: (arc.height - root.stroke) / 2
              startAngle: -90
              sweepAngle: cell.sweep
            }
          }
        }

        Text {
          anchors.centerIn: parent
          text: String(cell.modelData.id)
          color: cell.isActive ? root.accent : (cell.isUrgent ? Theme.error : (cell.hot ? Theme.text : Theme.subtext))
          font.family: Theme.fontFamily
          font.pixelSize: Theme.fs(11)
          font.bold: cell.isActive
          Behavior on color { ColorAnimation { duration: Theme.animDuration(150) } }
        }

        MouseArea {
          id: area
          anchors.fill: parent
          hoverEnabled: true
          cursorShape: Qt.PointingHandCursor
          onClicked: WM.clickWorkspace(cell.modelData)
        }
      }
    }
  }
}
