// COMMON — IconResolver

pragma Singleton
import Quickshell
import QtQuick

Singleton {
  id: root

  property var themeMemo: ({})
  property var monoMemo: ({})

  readonly property string providerPrefix: "image://icon/"
  readonly property var fileExtensions: [".png", ".svg", ".xpm"]

  function themeFile(name) {
    const hit = root.themeMemo[name]
    if (hit !== undefined) return hit
    const p = Quickshell.iconPath(name, true)
    if (p === "") return ""
    const url = p.charAt(0) === "/" ? "file://" + p : p
    root.themeMemo[name] = url
    return url
  }

  function rememberMono(url, mono) {
    root.monoMemo[url] = mono
  }

  function hasExtension(name) {
    return /\.(png|svg|xpm|jpg|jpeg|webp)$/i.test(name)
  }

  function safeDecode(s) {
    try { return decodeURIComponent(s) } catch (e) { return s }
  }

  function candidates(raw) {
    const s = String(raw || "")
    if (s === "") return []
    if (s.indexOf(root.providerPrefix) !== 0) return [s]

    let name = s.substring(root.providerPrefix.length)
    let dir = ""
    const q = name.indexOf("?")
    if (q >= 0) {
      const query = name.substring(q + 1)
      name = name.substring(0, q)
      const m = /(?:^|&)path=([^&]*)/.exec(query)
      if (m) dir = root.safeDecode(m[1])
    }
    name = root.safeDecode(name)
    if (name === "") return []

    if (name.charAt(0) === "/") return ["file://" + name]

    const out = []

    if (dir !== "") {
      const base = dir.replace(/\/+$/, "") + "/" + name
      if (root.hasExtension(name)) out.push("file://" + base)
      else for (let i = 0; i < root.fileExtensions.length; i++) out.push("file://" + base + root.fileExtensions[i])
    }

    const t = root.themeFile(name)
    if (t !== "") out.push(t)

    return out
  }
}
