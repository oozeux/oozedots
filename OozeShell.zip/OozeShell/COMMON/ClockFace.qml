// ClockFace — cara del reloj según el estilo (la comparten ClockModule de la barra y PillClock de la píldora).

import QtQuick
import QtQuick.Layouts

Loader {
  id: face

  property string clockStyle: "classic"
  property bool vertical: false
  property var now: new Date()
  property string localeCode: "en_US"

  readonly property var loc: Qt.locale(face.localeCode)
  readonly property bool dayFirst: face.localeCode.indexOf("en") !== 0

  readonly property bool h24: Theme.barClock24h

  function h12(d) { return d.getHours() % 12 || 12 }
  function pad(n) { return (n < 10 ? "0" : "") + n }
  function hourText(d, padded) { return face.h24 ? face.pad(d.getHours()) : (padded ? face.pad(face.h12(d)) : String(face.h12(d))) }

  function hm(d) { return face.h24 ? Qt.formatTime(d, "HH:mm") : Qt.formatTime(d, "h:mm AP") }

  function meridiem(d) { return d.getHours() < 12 ? "AM" : "PM" }

  function compactTime(d) {
    return face.hourText(d, false) + ":" + face.pad(d.getMinutes()) + (face.h24 ? "" : face.meridiem(d))
  }

  function compactDate(d) {
    const day = face.loc.toString(d, "ddd").replace(/\./g, "")
    const num = face.loc.toString(d, face.dayFirst ? "dd/MM" : "MM/dd")
    return (day + " " + num).toLowerCase()
  }

  function timeText(d) {
    if (face.vertical) return face.hourText(d, face.h24) + "\n" + Qt.formatTime(d, "mm")
    return face.hm(d)
  }

  sourceComponent: face.clockStyle === "seconds" ? cSeconds
                 : face.clockStyle === "date"    ? cDate
                 : face.clockStyle === "datesoft" ? cDateSoft
                 : face.clockStyle === "cards"   ? cCards
                 : cText

  // ─── Estilos ─────────────────────────────────────────────────

  Component {
    id: cText

    Text {
      text: face.timeText(face.now)
      horizontalAlignment: Text.AlignHCenter
      lineHeight: 0.9
      color: Theme.text
      font.family: Theme.fontFamily
      font.pixelSize: Theme.fs(15)
    }
  }

  Component {
    id: cSeconds

    RowLayout {
      spacing: 1

      Text {
        Layout.alignment: Qt.AlignBaseline
        text: face.hourText(face.now, false) + ":" + Qt.formatTime(face.now, "mm")
        color: Theme.text
        font.family: Theme.fontFamily
        font.pixelSize: Theme.fs(15)
      }
      Text {
        Layout.alignment: Qt.AlignBaseline
        text: ":" + Qt.formatTime(face.now, "ss") + (face.h24 ? "" : " " + Qt.formatTime(face.now, "AP"))
        color: Theme.subtext
        font.family: Theme.fontFamily
        font.pixelSize: Theme.fs(10)
      }
    }
  }

  Component {
    id: cDate

    RowLayout {
      spacing: 6

      Text {
        Layout.alignment: Qt.AlignBaseline
        text: face.loc.toString(face.now, "ddd d MMM")
        color: Theme.primary
        font.family: Theme.fontFamily
        font.pixelSize: Theme.fs(12)
        font.bold: true
      }
      Text {
        Layout.alignment: Qt.AlignBaseline
        text: face.hm(face.now)
        color: Theme.text
        font.family: Theme.fontFamily
        font.pixelSize: Theme.fs(15)
      }
    }
  }

  Component {
    id: cDateSoft

    RowLayout {
      spacing: 6

      Text {
        Layout.alignment: Qt.AlignBaseline
        text: face.compactTime(face.now)
        color: Theme.text
        font.family: Theme.fontFamily
        font.pixelSize: Theme.fs(15)
      }
      Text {
        Layout.alignment: Qt.AlignBaseline
        text: face.compactDate(face.now)
        color: Theme.subtext
        font.family: Theme.fontFamily
        font.pixelSize: Theme.fs(12)
      }
    }
  }

  Component {
    id: cCards

    GridLayout {
      columns: face.vertical ? 1 : (face.h24 ? 2 : 3)
      columnSpacing: 3
      rowSpacing: 2

      Repeater {
        model: ["h", "m"]

        delegate: Rectangle {
          required property string modelData

          implicitWidth: Math.max(26, cardText.implicitWidth + 10)
          implicitHeight: face.vertical ? 18 : 22
          radius: 6
          color: Theme.surfaceHigh

          Text {
            id: cardText
            anchors.centerIn: parent
            text: parent.modelData === "h" ? face.hourText(face.now, true) : face.pad(face.now.getMinutes())
            color: Theme.text
            font.family: Theme.fontFamily
            font.pixelSize: Theme.fs(13)
            font.bold: true
          }
        }
      }

      Text {
        visible: !face.h24 && !face.vertical
        text: Qt.formatTime(face.now, "AP")
        color: Theme.subtext
        font.family: Theme.fontFamily
        font.pixelSize: Theme.fs(10)
        font.bold: true
      }
    }
  }
}
