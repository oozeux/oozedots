// WsTag.qml — COMMON

import QtQuick
import QtQuick.Layouts
import QtQuick.Shapes

WsBase {
  id: root

  readonly property real tagH: 22
  readonly property real slant: 6
  readonly property real gap: 3

  implicitWidth: grid.implicitWidth
  implicitHeight: grid.implicitHeight

  // ─── Etiquetas ───
  GridLayout {
    id: grid
    anchors.centerIn: parent
    flow: root.vertical ? GridLayout.LeftToRight : GridLayout.TopToBottom
    columns: root.vertical ? 1 : -1
    rows: root.vertical ? -1 : 1
    columnSpacing: root.gap
    rowSpacing: root.gap

    Repeater {
      model: root.items
      delegate: Item {
        id: tag
        required property var modelData
        readonly property bool isActive: !!tag.modelData.active
        readonly property bool isUrgent: !!tag.modelData.urgent && !tag.isActive
        readonly property bool hot: area.containsMouse
        readonly property color fill: tag.isActive ? root.accent
                                     : (tag.isUrgent ? Qt.alpha(Theme.error, 0.25)
                                     : (tag.hot ? root.hoverColor : Qt.alpha(root.accent, 0.08)))
        readonly property color edge: tag.isActive ? root.accent
                                     : (tag.isUrgent ? Theme.error : Qt.alpha(root.accent, tag.hot ? 0.6 : 0.3))

        Layout.preferredWidth: Math.max(34, label.implicitWidth + 22)
        Layout.preferredHeight: root.tagH
        Layout.alignment: root.vertical ? Qt.AlignHCenter : Qt.AlignVCenter

        Shape {
          anchors.fill: parent
          preferredRendererType: Shape.CurveRenderer
          ShapePath {
            fillColor: tag.fill
            strokeColor: tag.edge
            strokeWidth: 1
            joinStyle: ShapePath.RoundJoin
            startX: root.slant
            startY: 0.5
            PathLine { x: tag.width - 0.5; y: 0.5 }
            PathLine { x: tag.width - root.slant; y: tag.height - 0.5 }
            PathLine { x: 0.5; y: tag.height - 0.5 }
            PathLine { x: root.slant; y: 0.5 }
          }
        }

        Text {
          id: label
          anchors.centerIn: parent
          text: String(tag.modelData.id)
          color: tag.isActive ? root.onAccent : (tag.isUrgent ? Theme.error : (tag.hot ? Theme.text : Theme.subtext))
          font.family: Theme.fontFamily
          font.pixelSize: Theme.fs(12)
          font.bold: tag.isActive
          Behavior on color { ColorAnimation { duration: Theme.animDuration(150) } }
        }

        MouseArea {
          id: area
          anchors.fill: parent
          hoverEnabled: true
          cursorShape: Qt.PointingHandCursor
          onClicked: WM.clickWorkspace(tag.modelData)
        }
      }
    }
  }
}
