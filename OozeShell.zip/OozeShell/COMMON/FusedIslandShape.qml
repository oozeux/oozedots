// FusedIslandShape.qml — COMMON
// Fondo de una isla fusionada al borde de pantalla (estilo FusedIslands)

import QtQuick
import QtQuick.Shapes

Item {
  id: root

  // ─── Geometría ───
  property real flare: Theme.fusedFlare
  property real radius: Theme.fusedRadius
  property bool flipped: Theme.barAtBottom

  // ─── Teñido (Mixed) ───
  property string tintSide: ""
  readonly property bool tinted: Theme.barFusedTint && root.tintSide !== ""
  readonly property bool horizontal: root.tinted && Theme.barMixedStyle === "gradient"
  readonly property real tintFrom: root.tintSide === "left" ? 0 : (root.tintSide === "center" ? 0.34 : 0.67)
  readonly property real tintTo: root.tintSide === "left" ? 0.33 : (root.tintSide === "center" ? 0.66 : 1)

  // ─── Color ───
  property color color: (root.tinted && !root.horizontal) ? Theme.mixedFill(Theme.islandPos(root.tintSide)) : Theme.islandBg
  Behavior on color { ColorAnimation { duration: Theme.animDuration(200) } }
  property bool outline: Theme.fusedOutline
  property color stroke: Qt.rgba(Theme.primary.r, Theme.primary.g, Theme.primary.b, 0.85)
  property real strokeWidth: Theme.fusedStroke

  readonly property real r: Math.max(0, Math.min(root.radius, root.height / 2, root.width / 2))
  readonly property real f: Math.max(0, Math.min(root.flare, root.height / 2))
  readonly property color fillTop: Qt.rgba(Math.min(1, root.color.r * 1.12), Math.min(1, root.color.g * 1.12), Math.min(1, root.color.b * 1.12), root.color.a)
  readonly property color fillBottom: root.color

  function n(v) { return v.toFixed(2) }

  readonly property string outlinePath: {
    const w = root.width
    const h = root.height
    return "M " + root.n(-root.f) + " 0"
      + " A " + root.n(root.f) + " " + root.n(root.f) + " 0 0 1 0 " + root.n(root.f)
      + " L 0 " + root.n(h - root.r)
      + " A " + root.n(root.r) + " " + root.n(root.r) + " 0 0 0 " + root.n(root.r) + " " + root.n(h)
      + " L " + root.n(w - root.r) + " " + root.n(h)
      + " A " + root.n(root.r) + " " + root.n(root.r) + " 0 0 0 " + root.n(w) + " " + root.n(h - root.r)
      + " L " + root.n(w) + " " + root.n(root.f)
      + " A " + root.n(root.f) + " " + root.n(root.f) + " 0 0 1 " + root.n(w + root.f) + " 0"
  }

  transform: Scale { origin.y: root.height / 2; yScale: root.flipped ? -1 : 1 }

  // ─── Relleno ───
  Shape {
    anchors.fill: parent
    visible: !root.horizontal
    preferredRendererType: Shape.CurveRenderer

    ShapePath {
      strokeWidth: -1
      strokeColor: "transparent"
      fillGradient: LinearGradient {
        x1: 0; y1: 0
        x2: 0; y2: root.height
        GradientStop { position: 0; color: root.fillTop }
        GradientStop { position: 1; color: root.fillBottom }
      }
      PathSvg { path: root.outlinePath + " Z" }
    }
  }

  // ─── Relleno degradado (Mixed) ───
  Shape {
    anchors.fill: parent
    visible: root.horizontal
    preferredRendererType: Shape.CurveRenderer

    ShapePath {
      strokeWidth: -1
      strokeColor: "transparent"
      fillGradient: LinearGradient {
        x1: 0; y1: 0
        x2: root.width; y2: 0
        GradientStop { position: 0; color: Theme.mixedFill(root.tintFrom) }
        GradientStop { position: 1; color: Theme.mixedFill(root.tintTo) }
      }
      PathSvg { path: root.outlinePath + " Z" }
    }

    ShapePath {
      strokeWidth: -1
      strokeColor: "transparent"
      fillGradient: LinearGradient {
        x1: 0; y1: 0
        x2: 0; y2: root.height
        GradientStop { position: 0; color: Qt.rgba(1, 1, 1, 0.07) }
        GradientStop { position: 1; color: Qt.rgba(1, 1, 1, 0) }
      }
      PathSvg { path: root.outlinePath + " Z" }
    }
  }

  // ─── Contorno ───
  Shape {
    anchors.fill: parent
    visible: root.outline
    preferredRendererType: Shape.CurveRenderer

    ShapePath {
      fillColor: "transparent"
      strokeColor: root.stroke
      strokeWidth: root.strokeWidth
      capStyle: ShapePath.RoundCap
      joinStyle: ShapePath.RoundJoin
      PathSvg { path: root.outlinePath }
    }
  }
}
