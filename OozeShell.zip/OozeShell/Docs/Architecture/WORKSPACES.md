# WORKSPACES — Indicador de escritorios y sus estilos

- Qué es: el indicador de escritorios de la barra y de la píldora. Un solo componente (`WorkspaceDots`) elige entre 12 estilos; los 6 más recientes viven cada uno en su propio archivo.
- Ajuste: Ajustes → Barra → Workspaces (`Theme.workspaceStyle`, `Theme.workspaceShowName`, `Theme.workspaceNameAfter`). Persistido en `ui.toml` (`workspaceStyle`, `workspaceShowName`). IPC `bar workspaceStyle <estilo>`.

## Estilos

| id | Nombre | Qué dibuja |
|---|---|---|
| `dots` · `bubbles` · `lines` | Puntos · Burbujas · Líneas | un elemento por escritorio; el activo se alarga o se rellena |
| `numbers` · `kanji` · `roman` | Números · Kanji · Romanos | texto por escritorio |
| `activity` | Barras de actividad | barras verticales tipo ecualizador: la activa es la más alta y las vecinas bajan según su distancia |
| `progress` | Barra de progreso | pista continua con marcas entre escritorios y un cursor que se desliza hasta el activo |
| `path` | Ruta de nodos | nodos huecos unidos por una línea; el activo va relleno y con brillo |
| `tabs` | Pestañas con etiqueta | cápsulas con el número; la activa va rellena y con brillo |
| `tag` | Pestañas con forma de etiqueta | paralelogramos inclinados con el número; el activo va relleno |
| `ring` | Indicador circular | círculo por escritorio con su número; el activo lleva un anillo que avanza según su posición (1/N, 2/N… N/N) |

Los estilos con forma propia son `Theme.workspaceCustomStyles` (`activity`, `progress`, `path`, `tabs`, `tag`, `ring`). `Theme.workspaceStyles` es la lista completa que usa el selector.

## Nombre del espacio

- Interruptor: `Theme.workspaceShowName` (Ajustes → Barra → Workspaces → "Mostrar el nombre").
- Se aplica a todos los estilos salvo `numbers`, `kanji` y `roman`, y solo en barra horizontal (en vertical no cabe).
- Posición: `Theme.workspaceNameAfter` (`ui.toml` → `workspaceNameAfter`; Ajustes → Barra → Workspaces → "Nombre después del indicador", visible solo con el nombre activado; IPC `bar workspaceNameAfter <b>` / `toggleWorkspaceNameAfter`). Apagado (por defecto): el nombre va antes del indicador. Encendido: va después. Aplica igual a estilos clásicos y nuevos.
- Cada bloque de texto tiene dos `Text` (antes y después) y solo se ve el que corresponde a `nameAfter`.
- Sin nombre propio, el texto es `Workspace <id>` (`wsLabel` en `WorkspaceDots.qml`). Ancho máximo: `maxNameWidth` (170 px), con elipsis.

## Archivos y bloques

| Archivo | Bloques |
|---|---|
| `COMMON/WorkspaceDots.qml` | **Cápsula** (opcional, hoy sin uso) · **Contenido** (estilos clásicos con `GridLayout`) · **Estilos con forma propia** (nombre + `Loader`) · **Componentes de estilo** (un `Component` por estilo y el selector `styleComponent`) |
| `COMMON/WsBase.qml` | base de los estilos con forma propia: recibe `host` (el `WorkspaceDots`) y expone `items`, `vertical`, `accent`, `onAccent`, `hoverColor`, `count`, `activeIndex` |
| `COMMON/WsActivity.qml` | **Barras** |
| `COMMON/WsProgress.qml` | **Pista** · **Marcas** · **Cursor** · **Tramos** (zonas de clic y hover) |
| `COMMON/WsPath.qml` | **Nodos** (línea izquierda, línea derecha, brillo, nodo) |
| `COMMON/WsTabs.qml` | **Pestañas** |
| `COMMON/WsTag.qml` | **Etiquetas** (forma con `Shape`) |
| `COMMON/WsRing.qml` | **Círculos** (base, arco de progreso, número) |

## Cómo funciona

1. `WorkspaceDots` calcula `shown` (escritorios activos, urgentes u ocupados) y los colores `accent` / `onAccent`. Con Mixed relleno (`Theme.barMixedFilled`) usa `Theme.text` y `Theme.bg` para que el activo no se pierda sobre la píldora.
2. Si `custom` es verdadero, `styleComponent` devuelve el `Component` del estilo y el `Loader` lo instancia con `host: root`. Cada estilo lee todo de `host` a través de `WsBase`, así no hay propiedades duplicadas.
3. El tamaño de `WorkspaceDots` sale del `implicitWidth/Height` del estilo cargado (más el nombre); en el resto sigue saliendo de la `GridLayout` clásica, igual que antes.
4. Horizontal y vertical comparten layout: cada estilo cambia `flow`, `columns` y `rows` de su `GridLayout` según `vertical`.
5. Clic: todos llaman a `WM.clickWorkspace(modelData)`.

## Cómo agregar un estilo

1. Crear `COMMON/WsNombre.qml` que herede de `WsBase`, con `implicitWidth` / `implicitHeight` y un `MouseArea` por escritorio.
2. Registrarlo en `COMMON/qmldir`.
3. Agregar el `Component` y su `case` en `styleComponent` de `WorkspaceDots.qml`.
4. Sumar el id a `Theme.workspaceCustomStyles` (`COMMON/Theme.qml`).
5. Agregar la clave `barWorkspaceStyle_<id>` a `LangEs.qml` y `LangEn.qml`, y palabras clave a `Settings/SettingsRegistry.qml`.

## A vigilar

- `shown` oculta los escritorios vacíos, por eso los estilos casi nunca ven `occupied === false`; `activity` lo contempla (barra más baja) por si el compositor los entrega.
- `ring` calcula el avance con la posición del activo dentro de `shown`, no con el número del escritorio.
- `tabs`, `tag` y `ring` miden 22–24 px de alto; la cara de la barra es de 30 px (`WorkspacesModule`), no subir de ahí.
