# NIGHTLIGHT — luz nocturna

- Qué es
  - Filtro de temperatura de color de la pantalla. El shell lo gestiona de forma nativa; ya no depende de un script externo ni del nombre de ninguna herramienta.
- Archivos
  - `Services/NightLight/NightLightBackend.qml` → singleton: configuración (`[nightlight]` en el config), detección de motores, programación y proceso.
  - `Core/Ipc/NightLightIpc.qml` → IPC y toast (`shell.nightLightToast()`).
  - `Settings/pages/NightLightPage.qml` → categoría "Luz nocturna" en Ajustes avanzados (grupo Escritorio).
- Funcionamiento
  - Motor: `tool = auto` elige el primero disponible. Hyprland: `hyprsunset` → `wlsunset` → `gammastep`. Otros compositores (Niri, MangoWM…): `wlsunset` → `gammastep`. `hyprsunset` solo se usa en Hyprland.
  - Se lanza un proceso por motor con la temperatura (y gamma/brillo en hyprsunset y gammastep). Si cambian los valores, se reinicia con un retardo de 300 ms.
  - Modo `manual`: activa mientras `enabled`. Modo `schedule`: solo entre `start` y `end` (HH:MM, puede cruzar medianoche), reevaluado cada 30 s.
  - Si el proceso muere en menos de 1,5 s se marca `failed` y no se reintenta hasta el próximo cambio.
- Claves de config (`[nightlight]`): `enabled`, `temperature` (1000–6500), `gamma` (50–100), `mode`, `start`, `end`, `tool`.
- IPC (target `nightlight`): `toggle`, `set <bool>`, `get`, `temperature <K>`, `adjust <delta>`. Ej.: `quickshell ipc -p ~/.config/quickshell/OozeShell/shell.qml call nightlight toggle`.
- Integración
  - Sustituye en tu bind de `SUPER+Y` el script de hyprsunset por la llamada IPC `nightlight toggle`. No dejes un hyprsunset propio en `exec-once`: competiría con el del shell.
  - Dependencias (una basta): `hyprsunset`, `wlsunset` o `gammastep`.
