# HIDE — Ocultar ventanas y layers de capturas

- Qué es: ajustes de Ocultar de capturas, que escriben reglas del window manager para que ventanas y layers salgan negros u ocultos al compartir pantalla o grabar. Es lo que antes se hacía a mano en las reglas de cada WM, pero editable desde Ajustes.
- Equivalencia por WM:

  | WM | Regla de ventana | Regla de layer | Archivo generado |
  |---|---|---|---|
  | Hyprland | `no_screen_share` (`hl.window_rule`) | `no_screen_share` (`hl.layer_rule`) | `~/.config/hypr/modules/rules/autogen/hide.lua` |
  | niri | `block-out-from` (`window-rule`) | `block-out-from` (`layer-rule`) | `~/.config/niri/autogen/hide.kdl` |
  | MangoWM | `shield_when_capture` (`window_rule`) | `shield_when_capture` + `no_animation` (`layer_rule`) | `~/.config/mango/autogen/hide.conf` |

- Archivos:
  - `Services/Hide/HideConfig.qml` → singleton: estado, edición, generación del texto por WM, escritura del archivo y detección de ventanas y layers abiertos (`scanWindows`, `scanLayers`, `pickWindow`, `pickLayer`).
  - `Settings/pages/HidePage.qml` → categoría `hide` (grupo Escritorio): interruptor general, modo (solo niri), superficies del shell y, para ventanas y layers, la lista de reglas activas, el buscador con botón Ocultar/Mostrar por elemento y un bloque plegable de alta manual.
  - `Core/Ipc/HideIpc.qml` → target `hide`.
- Buscar y ocultar desde Ajustes:
  - Bloque `DetectRow` (componente interno de `HidePage`): una fila por ventana o layer encontrado, con el nombre, el título de la ventana y un botón. El botón dice `Ocultar` (destacado) si no hay regla activa y `Mostrar` si ya la hay.
  - Ventanas: el botón `Buscar` pide una lectura nueva de los clientes abiertos al WM (`WM.withClients`; en Hyprland ejecuta `hyprctl clients -j`, porque ese estado solo se refresca mientras alguien lo usa) y los agrupa por app-id (si hay varias ventanas de la misma app muestra `×N`). Ocultar crea una regla con el app-id exacto y sin título.
  - Layers: el botón `Buscar` consulta al WM los layers abiertos (`hyprctl layers -j` o `niri msg --json layers`) y los lista por namespace. Ocultar crea una regla con el namespace exacto.
  - Layers pasajeros: los toasts, el toast de alarmas y los OSD (`transientLayers` en `HideConfig`) siempre aparecen en la lista aunque no estén abiertos, marcados como «Pasajero». Hace falta porque mientras Ajustes está abierto el shell suprime los toasts (`otherPopupOpen`) y esos layers no existirían para detectarlos.
  - Pulsar `Mostrar` borra la regla; si existía pero estaba apagada, solo la vuelve a encender.
  - Las listas se llenan solas al abrir la página; `Buscar` las actualiza cuando se abre o cierra algo.
  - Las reglas que escribiste a mano en los archivos del WM (por ejemplo `private/rules.lua`) no se leen, así que esas apps aparecen como `Ocultar` aunque ya estén ocultas; es inofensivo, solo duplica la regla.
  - Escribir a mano (app-id, título o namespace con regex) sigue disponible en el bloque plegable `Agregar manualmente`. En Mango, que no lista layers, ese bloque está siempre visible con el botón `Usar el último layer abierto`.
- Funcionamiento:
  - Las reglas viven en la clave `hide` de `~/.config/oozeshell/config.toml` (`enabled`, `mode`, `shellLayers`, `windows[]`, `layers[]`).
  - Cada cambio regenera el archivo del WM actual (400 ms de espera). Solo recarga el WM si el contenido cambió: `hyprctl reload` en Hyprland, `mmsg dispatch reload_config` en Mango; niri recarga solo.
  - Al arrancar y al cambiar de WM se vuelve a escribir el archivo, así que la primera vez no hace falta tocar nada.
  - Una ventana se define por app-id/class y/o título (regex). Una regla sin ninguno de los dos se ignora, para no ocultar todo por error.
  - "Superficies de OozeShell" agrega un layer con `^(oozeshell|quickshell)-` (barra, dock, widgets y paneles).
- Detalles por WM:
  - niri: el modo elige `screencast` (solo compartir pantalla) o `screen-capture` (todas las capturas, también herramientas de screenshot).
  - Mango: las comas de un patrón se reemplazan por un punto porque separan los parámetros. Los layers añaden `no_animation:1`, como recomienda su documentación. No hay lista de layers abiertos; el botón "Usar el último layer abierto" rellena el campo con `mmsg get last_open_surface`.
  - Hyprland y Mango ocultan por completo; niri lo reemplaza por un rectángulo negro.
- IPC (target `hide`):

  | Función | Efecto |
  |---|---|
  | `get` | JSON con el estado y las reglas (con su `id`) |
  | `enable` / `disable` / `toggle` | enciende o apaga todas las reglas |
  | `mode <screencast\|all>` | modo de niri |
  | `addWindow <appId> <título>` | agrega una ventana (título puede ir vacío) |
  | `addLayer <namespace>` | agrega un layer |
  | `remove <id>` | borra una regla |
  | `apply` | regenera el archivo |

  ```bash
  quickshell ipc -p .../shell.qml call -- hide addWindow '^org\.keepassxc\.KeePassXC$' ''
  quickshell ipc -p .../shell.qml call -- hide addLayer '^swaync$'
  ```
- Dependencias: `COMMON` (`WM`, `WmAppearance.commentPrefix`), `Core/ConfigService`, `Services/Lang`.
- Notas:
  - Los WM cargan el archivo desde su config principal: `pcall(require, "modules.rules.autogen.hide")` en `hyprland.lua`, `include "autogen/hide.kdl"` en `config.kdl` (niri exige que exista; el repo trae uno vacío) y `source_optional=./autogen/hide.conf` en `config.conf` de Mango.
  - Las reglas que ya tengas a mano (por ejemplo `modules/rules/private/rules.lua`) siguen funcionando; el shell no las toca ni las lista.
