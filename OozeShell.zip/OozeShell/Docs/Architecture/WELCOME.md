# WELCOME — asistente de primer inicio

- Qué es: ventana centrada de 15 pasos que se abre sola la primera vez (`config.toml` → `welcomeDone`) y se
  puede repetir desde Ajustes → General → Asistente de bienvenida o por IPC (`welcome open`).
- Se monta como un popup más (`welcomeOpen` en `shell.qml`, `LazyPopup`): existe solo mientras está abierto.

## Archivos

| Archivo | Rol |
|---|---|
| `Modules/Welcome/Welcome.qml` | ventana, riel de pasos, scroll, pie (Omitir · Atrás · Siguiente). Lista `steps[]` |
| `Modules/Welcome/steps/Step*.qml` | un paso por archivo; son `SettingsPage` y reutilizan los controles de `Settings/` |
| `Modules/Welcome/WelcomePackages.qml` | singleton: catálogo de programas, comprobación con `command -v` y comandos de instalación |
| `Core/Ipc/WelcomeIpc.qml` | target `welcome`: `open`, `close`, `toggle`, `reset`, `get` |

## Pasos

Idioma · Barra (barra / islas / píldora / Waybar + posición) · Pantalla (monitor del shell, editor de monitores,
tamaño de interfaz, marco) · Dock · Launcher · QuickSearch · Apps predeterminadas (navegador, archivos, editor) ·
Terminal y fastfetch (las imágenes se eligen en Ajustes → Fastfetch) · OozeLock · Carpetas (wallpapers, descargas,
capturas, grabaciones y API key de Wallhaven) · Perfil (reutiliza `Settings/pages/ProfilePage.qml`) · Asistente de IA
(solo explica dónde configurarlo) · Paquetes · Keybinds (reutiliza `Translations.sections()`, los mismos atajos del panel; filtra por WM). Último paso, Gracias, con enlace a los dotfiles (`StepThanks.repoUrl`).

Los pasos escriben por los mismos setters que Ajustes (`Theme.set*`, `CaptureConfig.set`, `LockConfig.setValue`,
`TerminalConfig.set*`, `UserProfile`): no hay estado propio, así que Welcome y Ajustes nunca se desincronizan.

## Flujo

- Como Ajustes avanzados, Welcome **no** se cierra con `closeAllPopupsExceptAdvanced()` (lo dispara `Theme` al cambiar barra, píldora o islas); solo `closeAllPopups()` lo cierra.
- Cerrar con Esc o con la X no marca el asistente como hecho; **Omitir** y **Finalizar** sí.
- El editor de monitores y la búsqueda de paquetes son otras ventanas: `requestFromWelcome()` pone
  `welcomeReturn` y `returnToWelcome()` reabre Welcome (mismo paso, `welcomeStep`) al cerrarlas.
- `welcome reset` vuelve a marcarlo como pendiente: aparecerá en el próximo arranque.

## Paquetes

- Grupos: base (obligatorios), escritorio, audio, capturas, wallpapers, terminal. Se añaden `waybar`/`rofi`
  si están elegidos y el binario de la terminal activa.
- Pulsar un programa faltante abre `PackageSearch` con su nombre; los botones copian el comando
  (`paru|yay|sudo pacman -S --needed …` en Arch, `nix profile install nixpkgs#…` en NixOS).

## Funciones a vigilar

- `WelcomePackages.fixed` (nombres `arch`/`nix`): son la parte más frágil. Los nombres de paquete cambian entre
  distros y versiones (`awww`, `matugen`, `mpvpaper`, `cava` son los dudosos). Si uno falla, corrige el campo
  `arch`/`nix` de su entrada; la búsqueda por clic sigue funcionando porque consulta el repositorio real.
- `StepBar.chooseStyle()`: toca cuatro preferencias de `Theme` a la vez (píldora, islas, motor, posición). Si
  se añade un estilo nuevo de barra hay que ampliar esta función y `style`, o el chip actual será incorrecto.
- `StepAi`: la categoría de IA está oculta hasta `agent unlock` (`SettingsRegistry.hidden`); el texto lo menciona.
- `Welcome.steps`: modificable sin riesgo (añadir/quitar pasos). Cada `source` es relativo a `Welcome.qml`.
- `shell.qml` → `maybeShowWelcome()`: abre a los 2,5 s para dejar que monitores y barra existan. Con usuarios
  ya existentes lo verán una vez; si no se desea, escribir `welcomeDone = true` en la migración.
