# WALLS — galería y aplicador de fondos

- Qué es
  - Galería de wallpapers estáticos, live (vídeo vía `mpvpaper`) y online (wallhaven/bing) con recolorado `matugen`. `Walls.qml` es un `Item` con `open` (no singleton); `Core/Ipc/ToggleWallsIpc.qml` lo alterna con el target `toggleWalls`.
  - Aplica con `awww img … --resize <wallFit> --fill-color <wallFillColor>` y recuerda el último en `~/.cache/awww/last`.
  - Motor elegible (Ajustes avanzados → Wallpapers): estáticos `awww` | `OozeWalls` (`Theme.wallStaticBackend`), live `mpvpaper` | `OozeWalls` (`Theme.liveBackend`). Con OozeWalls el shell llama `oozewalls apply <archivo> --output <salida|'*'> --scaling fit|fill|stretch --no-palette` (la paleta sigue siendo la de `runMatugen`), el socket live pasa a `$XDG_RUNTIME_DIR/oozewalls/mpv_<salida|all>.sock` y al arrancar (`bootRestore`, tras `Theme.wallsPrefsLoaded`) corre `oozewalls restore --only static|live`. Cambiar el motor reaplica el fondo actual.
- Archivos
  - `Services/Walls/Walls.qml` → lógica del módulo: modos `static/live/online/downloaded`, `wallpaperFolder/liveFolder`, `applyWallpaper/applyLive/applyOnline`, `runMatugen`, lector `~/.cache/awww/last`, IPC live `/tmp/oozeshell-live.sock`. Monta `FusedWindow` + `WallsPanel` y expone `compact`, `liveCount`, `onlineCount`, `downloadedCount`, `liveScanning`, `thumbsGenerating` para la UI.
  - `Services/Walls/WallsPanel.qml` → `FusedPanel` de la galería; elige borde, `faceOffset`, escala (`uiScale` = `Theme.wallsScale`) y cuerpo según `Theme.wallsLayout`. En `compact-top` es flotante (`detached`, sin fusión con la isla de la píldora) y deja un hueco de 10 px respecto a la barra, o solo al marco si la píldora se oculta sola.
  - `Services/Walls/WallsLayoutNormal.qml` → diseño `normal`: buscador, tarjetas y barra de controles (modo, esquemas, acciones, contador), panel abajo.
  - `Services/Walls/WallsLayoutCompact.qml` → diseño `compact-top`: panel pegado a la barra, buscador y tira de controles (escalada si no cabe); va debajo de las tarjetas con la barra arriba y encima con la barra abajo.
  - `Services/Walls/WallsHeader.qml` → cabecera del diseño normal (4 burbujas).
  - `Services/Walls/WallsModeToggle.qml`, `WallsSchemeChips.qml`, `WallsSourceSwatches.qml`, `WallsActionChips.qml`, `WallsCounter.qml` → controles compartidos por ambos diseños (`compact`/tamaños por propiedad).
  - `Services/Walls/WallsSchemeChips.qml` muestra los esquemas en el orden de `Theme.schemeOrder` (vivos → fieles → apagados) sin tocar los índices guardados (`schemeIndex` sigue siendo el de `Theme.schemes`). Con `columns > 0` usa celdas iguales en cuadrícula (el rail usa `Theme.schemeColumns`); sin él, chips a su ancho como antes. `Settings/pages/WallpapersPage.qml` usa el mismo orden.
  - `Services/Walls/WallsSearchBar.qml` → campo de búsqueda (Ctrl+K o `/`), selector Imágenes/Live (solo Online), botones Filtros y Orden; maneja el teclado mientras el campo tiene foco.
  - `Services/Walls/WallsPopup.qml` → menú de Filtros / Orden según el modo; `WallsBarButton.qml` y `WallsKindToggle.qml` son sus controles.
  - `Services/Walls/WallsCards.qml` + `WallsCard.qml` → tira de tarjetas (central ancha, laterales recortadas, `cardRatio` 0.34 normal / 0.30 compacto) y su delegado; en Online la tarjeta central carga la imagen original tras 450 ms.
  - `Services/Walls/WallsFrameFlare.qml` → marco/animación al cambiar de fondo (`Theme.wallpaperChanging`, `frameCornerRadius`).
- IPC (Core/Ipc/ToggleWallsIpc.qml, target `toggleWalls`):
  | función | efecto |
  |---|---|
  | `handle` | alterna `wallsOpen` (abre/cierra la galería) |

  ```bash
  quickshell ipc -p .../shell.qml call -- toggleWalls handle
  ```
- Estado y datos
  - Sin singleton ni JSON propio: carpetas y ajustes (`wallpaperDir`, `liveWallpaperDir`, `wallFit`, `wallFillColor`, `wallsLayout` (`normal` | `compact-top`), `wallsScaleNormal`/`wallsScaleCompact`/`wallsScaleFullview`/`wallsScaleRail`/`wallsScaleList` (50–150 %, escala todo el panel incluida la fuente, un tamaño por diseño; `Theme.wallsScale` devuelve el del activo; Ajustes → Wallpapers → Galería), `live*`, `online*`, `defaultSchemeIndex`, `schemes`, `paletteMode`) se leen de `Theme` (`~/.config/oozeshell/ui.toml`).
  - Caché en `~/.cache/`: `awww/last` (fondo actual), `oozeshell/live/` + `live-active` + `live-player.log`, `oozeshell/live/opt` (copias optimizadas ffmpeg).
  - `indexMemory` (índice por modo) y `currentIndex` son memoria de sesión; `thumbRev` invalida miniaturas.
- Dependencias
  - `Theme` para toda la configuración; backends externos: `awww`, `mpvpaper` + `mpv` (live, con `socat` al socket), `ffmpeg` (optimización), `matugen` (paletas), script online (`curl`/`jq`).
  - `PowerProfile` (`power-saver` pausa el live), `WidgetConfig.raise` para capas sobre el fondo.
- Notas
  - `targetScreen` por defecto es `"DP-3"` (fijo en código), no el monitor enfocado.
  - Monitores (Ajustes → Wallpapers → Monitores): `Theme.wallOutput` = `*` (todos), `focused` (monitor donde se abre el selector, `targetScreen`) o el nombre de una salida. `Walls.outName` lo resuelve y cae a `*` si la salida no está conectada. Se usa en `oozewalls apply --output`, `awww img --outputs`, el último argumento de mpvpaper y los sockets IPC (`mpv_<salida>.sock` en OozeWalls, `/tmp/oozeshell-live-<salida>.sock` en mpvpaper). `killLiveOutCmd` solo mata el mpvpaper de esa salida; las pausas por fullscreen o power-saver se envían a todos los sockets.
  - Limitación con mpvpaper: un video lanzado en `*` no se puede acotar a un monitor; para mezclar estático y live por monitor usar OozeWalls. El restore de arranque con mpvpaper recupera un único video; con OozeWalls `oozewalls restore` recupera cada salida.
  - `onlineApiKey` viaja como `OOZE_WH_KEY` al script y se guarda en texto plano en `ui.toml` (aviso visible en la interfaz).

## Búsqueda, filtros y Online Live

- Estado en `Walls.qml`, bloque "Búsqueda, filtros y orden": `searchText`, `filterExt`, `sortLocal`, `popup`. En Static, Live y Descargas se filtra por nombre al escribir y `activeModel` pasa a `viewModel` (copia filtrada y ordenada); en Online con Wallhaven o los sitios live el texto se envía como `onlineQuery` (tras 850 ms o con Enter); con Bing se filtra en local.
- Orden local: nombre A-Z / Z-A, más nuevos / más viejos (usa `mtime` de `find -printf`). Orden online: el de `onlineSorting` (en live: recientes o relevancia).
- Teclado con el campo enfocado: Tab cambia de modo, ↑↓ y PgUp/PgDn navegan, ←/→ y Home/End navegan si el texto está vacío, Enter busca o aplica, Esc cierra menú → borra texto → cierra el selector, Ctrl+R aleatorio, Ctrl+P vista previa.
- Online → Live (`Theme.onlineKind = "live"`): fuentes Moewalls y WallpaperWaifu (API REST de WordPress, sin API key). El flujo completo está en la sección "Online Live: flujo y bloques" más abajo.
- Descargas lista imágenes y videos de la carpeta de descargas (incluida `Live/`); los videos se aplican como live.
- Ajustes → Wallpapers → "Wallpapers en línea · Live": fuente y calidad. En la galería, Filtros (Online → Live) muestra las mismas dos opciones; el orden solo admite Recientes y Relevancia.

## Online Live: flujo y bloques

Tres momentos: **listar** (rápido, solo miniaturas), **previsualizar** (clips animados en segundo plano) y **aplicar** (descarga en la mejor calidad disponible).

```
Walls.qml (fetchOnline) ──► Tools/online-live.sh ──► filas por stdout
        │                                              │
        │                                              ▼
        │                                  onlineModel (ListModel)
        ├─► startOnlineClips ─► genOnlineClips ─► Tools/online-clip.sh ─► clips .gif
        └─► applyOnlineItem  ─► applyOnline    ─► Tools/online-download.sh
                                                         └─► Tools/online-resolve.sh
```

### 1. Listar — `Tools/online-live.sh`

Uso: `online-live.sh <fuente> <busqueda> <orden> <pagina> <dir miniaturas> <calidad>`. Fuentes: `moewalls`, `wallpaperwaifu` (API de WordPress) y `desktophut` (solo HTML). `calidad` es `4k` o `any` (`Theme.onlineLiveRes`).

- Moewalls y WallpaperWaifu consultan `/wp-json/wp/v2/posts` (18 por página); si no responde 200 con un array, caen al HTML. DesktopHut va siempre por HTML. Código de salida 3 si no hay red.
- `listing_url()` decide la página a pedir y `extract_links()` saca los enlaces de posts (misma web, un solo segmento de ruta, sin secciones de navegación):

| Fuente | Sin búsqueda, calidad 4K | Sin búsqueda, cualquiera | Con búsqueda |
|---|---|---|---|
| `desktophut` | `/tag/4k?page=N` | `/category/live-wallpapers?page=N` | `/search/<texto>?page=N` (sin filtro 4K) |

- En las fuentes HTML, un post sin ninguna pista de video (`.mp4`, `.webm`, `.zip`, `/dl/`, `/download`) se descarta y se anota en `meta/<clave>.skip` para no volver a pedirlo.
- Procesa los posts en paralelo (`ONLINE_LIVE_JOBS`, por defecto 8) y **emite las filas en el orden del sitio apenas están listas**, sin esperar a las lentas.
- Separa los videos del post en dos grupos: el principal y los de vista previa (nombres con `preview`, `sample`, `thumb` o `poster`). Antes se tomaba el primer `.mp4`, que muchas veces era la vista previa de baja calidad.
- Guarda en `~/.cache/oozeshell/online/meta/` el video, título y vista previa de cada post, así que volver a abrir una página ya vista no consulta el sitio otra vez. Las miniaturas quedan en `online/thumbs/`.
- Separador interno de campos: `\037` (no tabulador, para no perder campos vacíos).
- Salida, una línea por wallpaper, separada por tabuladores:

| # | Campo | Uso en `Walls.qml` |
|---|---|---|
| 1 | nombre de archivo | `name`/destino en `<descargas>/Live/` |
| 2 | URL del video (o del post si no se encontró) | `url` |
| 3 | miniatura local | `thumb` |
| 4 | título · fuente | `name` visible |
| 5 | URL del post | `page`, para resolver la mejor calidad |
| 6 | ruta del clip animado | `clip` |
| 7 | URL del video de vista previa | `pv` |

### 2. Previsualizar — `Tools/online-clip.sh` y `startOnlineClips`

- Al terminar cada página, `fetchOnline.onExited` llama a `startOnlineClips()`, que arma la lista `ruta<TAB>clip<TAB>url` de los items sin clip y se la pasa a `online-clip.sh` por heredoc (`OOZE_CLIPS`).
- `online-clip.sh <referer>` genera un GIF de 3 s, 320 px, 12 fps (`ONLINE_CLIP_JOBS`, por defecto 4 a la vez). Usa el video de vista previa del sitio (pequeño) y, si no hay, el principal. Si `ffmpeg` no puede leer la URL directamente, baja el archivo (máx. 80 MB) y lo convierte en local.
- Cada clip terminado se imprime por stdout; `genOnlineClips` marca `clipReady` y `WallsCard.qml` lo muestra en la tarjeta central con `AnimatedImage`. Mientras tanto la tarjeta muestra la miniatura.
- Si llega otra página mientras se generan clips, `rerun` encola una segunda pasada. Cambiar fuente, búsqueda u orden cancela el proceso.
- La vista previa respeta `previewOn` (Ctrl+P) y `Theme.shellPerf`.

### 3. Precarga de páginas

- Al terminar la página 1 de Online Live se pide la 2 automáticamente (`Qt.callLater(loadMoreOnline)`).
- Después se pide la siguiente cuando el cursor está a 8 tarjetas del final (antes 4).

### 4. Aplicar — `Tools/online-download.sh` y `Tools/online-resolve.sh`

`applyOnline` ejecuta `online-download.sh <fuente> <url> <destino> <post> <referer>` para videos:

1. `online-resolve.sh` abre la página del post y reúne candidatos: la URL ya conocida, todo `.mp4`/`.webm` del HTML y los enlaces de descarga. Descarta vistas previas.
2. Consulta las cabeceras (`HEAD`, 6 en paralelo) de cada candidato, conserva los que sean video y elige **el de mayor tamaño**, usando la resolución del nombre (`2160`, `1080`, `4k`…) como desempate. Devuelve `URL<TAB>bytes`.
3. Si el destino ya existe y pesa lo mismo o más, no se vuelve a bajar; si pesa menos (por ejemplo una descarga anterior de baja calidad) se reemplaza.
4. Descarga con `aria2c` (8 conexiones) si está instalado; si no, con `curl` con reanudación (`-C -`), reintentos y corte solo por velocidad mínima (ya no hay límite fijo de 300 s, que cortaba los 4K).
5. Solo entonces entra por `startVideo` (fotograma, matugen, mpvpaper/OozeWalls).

Calidad y ZIP:
- El resolutor ordena primero por resolución deducida del enlace (`reso()`: 4320, 2160/3840/`4k`, 1440, 1080, 720, con límites de dígito para no confundir ids como `/media/1080/`) y luego por tamaño. Así `/dl/4k/…` gana a `/dl/hd/…` y a la vista previa.
- DesktopHut entrega el video dentro de un `.zip`: `online-download.sh` lo detecta por los primeros bytes (`PK`), extrae el video más grande con `zipfile` y guarda el resultado en el destino `.mp4`. Con ZIP no se compara el tamaño para saltar la descarga.
- Con `ffprobe`, al terminar se registra `download: resolucion <alto>p`; si se pidió 4K (`OOZE_LIVE_RES`) y quedó por debajo, avisa `el sitio no ofrecio 4K`.
- La descarga conserva la calidad original, pero `liveOptimize` reduce la copia que se reproduce a `liveOptMaxHeight` (1080 por defecto): para ver 4K hay que subir ese límite.

Si el sitio no expone ningún video, el script termina con código 1 y la tarjeta muestra el error de red.

Diagnóstico (salen por `[online]` en el log de quickshell):

| Mensaje | Significa |
|---|---|
| `resolve: pagina http 403 en …` | el sitio bloquea a `curl` (WAF/Cloudflare); sin la página no hay video que encontrar |
| `resolve: el sitio devolvio un desafio anti-bot…` | llegó 200 pero con la página de verificación, no con el post |
| `resolve: N candidatos de M encontrados` | `N` enlaces útiles tras descartar vistas previas; `0` con `M > 0` = solo había previews |
| `resolve: solo hay vista previa disponible…` | último recurso: se baja la vista previa en vez de fallar |
| `sin video en <post>` | no se halló ningún video; mirar las líneas `resolve:` anteriores |

A vigilar:
- DesktopHut se escribió sin poder ver su HTML real (sus páginas no se pueden leer de forma automática desde el entorno de desarrollo). Las rutas de listado, el patrón `/dl/4k/<id>` y el enlace del ZIP son las más probables: si una fuente sale vacía o sin enlace de descarga, las líneas `resolve:` y `http` del log dicen qué falló y los ajustes están en `listing_url()`, `extract_links()` y la regex de enlaces de `online-resolve.sh`.
- `extract_links()` solo acepta rutas de un segmento; si DesktopHut cambia a `/categoria/slug`, hay que relajar esa regla y ampliar la lista de secciones excluidas.
- MotionBGs se retiró como fuente: su listado no devolvía resultados y se descartó en lugar de mantenerlo.
- Estos sitios pueden prohibir el acceso automatizado en su `robots.txt` o términos; conviene revisarlo antes de usarlos de forma intensiva.
- `probe()` en `online-resolve.sh`: pide solo el primer byte (`-r 0-0`, `--max-filesize 2048`) en vez de `HEAD`, porque muchos CDN responden mal a `HEAD`. Si un servidor ignora `Range` y no informa tamaño, el corte lo pone `-m 15`.
- `PREVIEW_RE` filtra por nombre (`preview|sample|thumb|poster`): si un sitio nombrara así su video real, solo se usaría gracias al último recurso (calidad baja).
- Con 403 persistente en `wp-json` y en las páginas, el problema es la huella TLS de `curl`, no las cabeceras: haría falta `curl-impersonate` o cookies del navegador.

### Vista previa HQ (Live local)

Ajustes → Wallpapers → Galería → "Vista previa HQ (Live)" (`Theme.wallsHqPreview`, apagado por defecto; se llama así y no `live*` porque `setWallsOpt` relanza el reproductor con los nombres que empiezan por `live`).

- `Walls.qml` (`hqPreview`, `clipFor`, `startClipGen`): normal = GIF de 3 s, 320 px, 12 fps (`-preview.gif`); HQ = 4 s, 640 px, 20 fps, paleta completa y dither `sierra2_4a` (`-preview-hq.gif`). Cada calidad tiene su archivo en `~/.cache/oozeshell/live/`, así que alternar no regenera lo ya creado.
- Al cambiar el toggle, `rebuildClips` apunta cada item a su clip, lo marca pendiente y relanza `startClipGen` (250 ms después, para dar tiempo a que pare la pasada anterior). Los clips se escriben en `.part.gif` y se renombran al terminar, por lo que una pasada cortada no deja GIF truncados.
- A vigilar: el GIF HQ pesa unas 4 veces más y `AnimatedImage` lo guarda en RAM mientras la tarjeta central está visible (unas decenas de MB por clip); si ves tirones, baja `scale`/`fps` en `startClipGen`. No aplica a Online Live: allí el clip sale de la vista previa pequeña del sitio (`Tools/online-clip.sh`), así que subir la calidad no mejoraría la imagen. Se omite con `Theme.shellPerf` o con la vista previa apagada (Ctrl+P).

### Calidad al reproducir

La descarga queda en su calidad original, pero `liveOptimize` (Ajustes → Wallpapers → En vivo · ahorro de recursos) crea una copia liviana limitada a `liveOptMaxHeight` (1080 por defecto) y `liveOptMaxFps` (30). Para un monitor 1440p o 4K hay que subir esos límites o desactivar la copia liviana; si no, el video se reproduce reducido aunque se haya bajado completo.

## Animación de cambio

Ajustes → Wallpapers → "Animación al cambiar de fondo".

- Preferencias en `Theme.qml`: `wallTransition` (26 tipos, por defecto `fade`) y `wallTransitionMs` (100–3000, por defecto 600). Se guardan con el resto de `wallsPrefs`. Los 26 valores coinciden con `oozewalls transitions`. Ajustes los muestra agrupados por `Theme.wallTransitionGroups` (Clásicas, Deslizar, Barrido, Olas y formas, Barras y diagonales, Otras); `wallTransitionKinds` conserva el orden del catálogo de OozeWalls. Las de forma (`wallTransitionShapeKinds`) solo se ven completas con OozeWalls; en video con mpvpaper solo animan las de `wallTransitionVideoKinds` y el resto cae a desvanecido (aviso en Ajustes).
- `Walls.qml`, bloque "Transiciones":
  - `oozeTransitionArgs(animate)` añade `--transition` y `--transition-duration` (o `--no-transition`) a `oozewalls apply`.
  - `awwwTransitionArgs(animate)` traduce el tipo a `--transition-type` de awww.
  - `liveReplaceKillCmd` evita matar el video anterior cuando OozeWalls ya tiene su socket, para que pueda animar la salida.
- Anima: cambio de wallpaper estático y de video. No anima: reajuste de ajuste (fit) y relanzado automático del video por RAM o energía.
- Con el backend `mpvpaper` independiente no hay animación de video.
- Con awww los tipos de forma se aproximan (`wave-*` y `slime` → `wave`, `blob` → `grow`, `diagonal-*` → `wipe`, `bars-left/right` → `left/right`, `drip` → `top`, `rings` → `center`); la lista está en `awwwTransitionTypes` y la página de ajustes muestra un aviso mientras se use esa combinación.
- Si cambia la lista de tipos de OozeWalls hay que reflejarla en `Theme.wallTransitionKinds`, `awwwTransitionTypes`, las chips de `WallpapersPage.qml` y las claves `wallsAnim*` de `LangEs`/`LangEn`.
- Diagnóstico cuando "cambia al instante": ejecutar `oozewalls apply <archivo> --output '*' --transition drip --transition-duration 1500` en una terminal. Si anima, el fallo está en la configuración del shell (motor estático en `awww`, o `wallTransition` en `none`); si no anima, revisar `pgrep -af 'oozewalls __bg'` (un proceso residente de una versión anterior no conoce los tipos nuevos) y `oozewalls transitions`.
- Detalle del motor: `OozeWalls/docs/TRANSICIONES.md`.
- `transitionHoldMs` (cuánto tiempo la barra y el marco quedan en modo "cambiando") sigue la duración elegida más 300 ms; con "sin animación" es 400 ms.

## Página de ajustes (Ajustes avanzados → Wallpapers)

`Settings/pages/WallpapersPage.qml`, orden de secciones:

| Sección | Contenido |
|---|---|
| Carpetas | estáticos, live y descargas online |
| Galería | diseño y tamaño |
| Imágenes y animación | motor, ajuste, color de bandas, tipo y duración de la animación |
| Wallpapers en vivo | motor, ajuste, capa, decodificación |
| En vivo · ahorro de recursos | copia liviana, alto y fps máximos, parar si no se ve, tope de RAM |
| Wallpapers en línea | fuente, búsqueda, orden, categorías, resolución, contenido, API key |
| Wallpapers en línea · Live | fuente (Moewalls / WallpaperWaifu / DesktopHut) y calidad (4K / Todos) |
| Paleta (matugen) | esquema |
| Herramientas | estado de las dependencias |

Componentes locales: `ChipRow`, `StepRow`, `SwitchRow`, `TextRow`, `FolderEntry`, `Duo` (dos controles lado a lado) y `Divider`.

Las ayudas solo se muestran donde el nombre de la opción no basta (motores, capa, ahorro, filtros de contenido, API key). Cada sección y fila está en `SettingsRegistry.qml` para el buscador; al añadir una opción hay que añadirla también ahí.


## Diseños flotantes: fullview, rail y list

Los tres se salen de la fusión con la barra (`detached`) y se eligen en Ajustes → Wallpapers → Galería. `WallsPanel.qml` decide cuerpo, borde y tamaño; cada diseño es un archivo `WallsLayout*.qml`.

| Diseño | Archivo | Ubicación | Fondo del contenedor |
|---|---|---|---|
| `fullview` | `WallsLayoutFullview.qml` | centro de la pantalla, hasta 90 % del ancho (máx. 1720 px) | ninguno: se ven el escritorio, las tarjetas inclinadas y las burbujas |
| `rail` | `WallsLayoutRail.qml` | borde izquierdo o derecho (`Theme.wallsRailSide`), centrado en vertical | panel normal |
| `list` | `WallsLayoutList.qml` | centro de la pantalla (hasta 62 %, máx. 1120 px), miniaturas a la izquierda y `WallsPreview` a la derecha | panel normal |

- **Sin fondo (fullview)**: `WallsPanel` define `floatingBare`, que activa `bare` en `FusedPanel` (ver `COMMON.md`). Con `bare` el panel no dibuja cuerpo, sombra ni desenfoque, y solo conserva el área de entrada y la animación de apertura. Las burbujas (`WallsBubble`) y las tarjetas mantienen su propio fondo.
- **Rail**, de arriba abajo: buscador estrecho → selector Imágenes/Live (solo Online) → tira vertical de tarjetas (`cardAspect` 0.64, laterales de 42 px) → modos → esquemas → fila de colores matugen + contador → burbuja de aleatorio/vista previa. Ancho base 320, margen 14, separación 10, burbujas de 40 px.

## Contador (`WallsCounter.qml`)

- Ancho fijo calculado con `TextMetrics` sobre `999 / 999` (crece solo si el número no cabe). Ya no cambia al buscar o generar miniaturas, así que el campo de búsqueda no se encoge.
- El estado ocupado (buscando, generando miniaturas, cargando Online) se muestra con un punto parpadeante a la izquierda. El texto de estado largo ya no va en el contador; el aviso "Buscando wallpapers…" sigue en el área de tarjetas cuando no hay resultados.
- `WallsSearchBar.qml`: el campo tiene ancho mínimo (150 salvo en rail; el selector Imágenes/Live mide 180 en list), recorta su contenido y oculta el atajo `Ctrl + K` si hay poco espacio.
- **Opacidad de las tarjetas laterales (fullview)**: como no hay fondo detrás, las tarjetas inclinadas (`skew > 0` en `WallsCard.qml`) son totalmente opacas (1.0), todas iguales, sin degradado por distancia ni por cursor. Los demás diseños conservan la curva anterior (0.80 con mínimo 0.45).
- **Buscador del fullview**: se centra y mide lo mismo que el conjunto de controles inferior (`controls.implicitWidth` de `WallsHeader`, limitado al ancho útil), así la galería domina la composición. El menú de filtros se alinea con el borde derecho del buscador.

## Fuentes vacías (Static / Live / Downloads)

- `Walls.qml` sondea las carpetas con el proceso `sourceProbe` (función `probeSources`): busca si hay al menos una imagen en la carpeta de wallpapers, un video en las carpetas Live y un archivo en la carpeta de descargas. Guarda el resultado en `hasStatic`, `hasLive` y `hasDownloaded`.
- `availableModes` lista los modos visibles. Online siempre aparece, y el modo actual nunca se oculta mientras está activo.
- `WallsModeToggle.qml` dibuja solo esos modos y reparte el ancho entre ellos. `cycleMode` (tecla Tab) también recorre solo los modos visibles.
- Al abrir la galería se sondea una vez; si el modo actual está vacío, `autoPickMode` pasa al primero con contenido (Static, Live, Downloads y por último Online).
- Mientras la galería está abierta en Online se vuelve a sondear cada 4 s, para que Downloads aparezca apenas se descargue algo.

## Tope de RAM del live

- `liveRssProc` suma el RSS de `mpvpaper` o, con OozeWalls, de `oozewalls __live`, cada 60 s. Al superar `liveRamLimitMB` llama a `relaunchLiveNow`.
- El relanzado usa `liveRelaunchKillCmd`: con mpvpaper mata el proceso de esa salida; con OozeWalls ejecuta `oozewalls stop --output <salida>` (un `loadfile` en el mismo proceso no liberaría la memoria) y vuelve a aplicar el video.
- `syncOozeBudget` copia el tope a `oozewalls set ram_budget_mb` (mínimo 128) al cambiarlo o al elegir OozeWalls como motor live, para que el indicador de la GUI use el mismo valor.
- "Parar si no se ve" sigue matando solo mpvpaper.
