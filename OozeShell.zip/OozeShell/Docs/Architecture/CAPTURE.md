# CAPTURE — capturas y grabación de pantalla

- Qué es
  - Capturas con `grim` y grabación de video con `wf-recorder`, con dos modos: zona (selector con la pantalla congelada) y pantalla completa (el monitor enfocado).
  - La captura de zona abre un editor breve de anotaciones (ver «Editor de capturas»).
  - Mientras se graba aparece un indicador (punto rojo parpadeante + tiempo) en la barra y en la píldora. Clic izquierdo pausa o reanuda; clic derecho abre el menú.
- Archivos
  - `Services/Screenshot/RecorderBackend.qml` → singleton con la máquina de estados (`idle`, `preparing`, `countdown`, `recording`, `paused`, `finishing`), el reloj y el menú (`menuEntry`).
  - `Services/Screenshot/CaptureConfig.qml` → singleton con los ajustes (guardados en `~/.config/oozeshell/config.toml`, clave `capture`) y los comandos de captura.
  - `Services/Screenshot/ScreenshotBackend.qml` → selector de zona, modos de captura (`copy`, `save`, `edit`, `color`) y estado del editor; `ScreenshotFreeze.qml` → ventana del selector (sirve a capturas, editor, selector de color y grabación).
  - `Services/Screenshot/ScreenshotEditor.qml` → ventana del editor (una capa `Overlay` en el monitor donde se eligió la zona); `EditorSurface.qml` → estado, herramientas, deshacer y exportación; `EditorToolbar.qml` → barra de herramientas; `EditorCanvas.qml` → lienzo que dibuja las anotaciones.
  - `Tools/ooze-capture.sh` → `shot`, `editshot`, `editfinish`, `colorpick`, `recpath`, `recseg`, `recjoin`, `open`.
  - `Core/Ipc/ScreenshotIpc.qml` → target `screenshot`; `Core/Ipc/RecordIpc.qml` → target `record`.
  - `Modules/Privacy/Privacy.qml` → icono de grabación (`RecordIcon`), compartido por `Modules/Bar/modules/PrivacyModule.qml` y `Modules/Pill/PillTray.qml`.
  - `Modules/Tray/TrayMenuList.qml` → también pinta menús propios: una entrada con `custom: true`, `title`, `glyph` e `items`.
  - `Settings/pages/CapturePage.qml` y `Settings/FolderField.qml` → categoría «Capturas y grabación».
- Editor de capturas
  - Flujo: `areaEdit` congela la pantalla, eliges la zona y `grim` la guarda en `$XDG_RUNTIME_DIR/oozeshell-edit-<ms>.png`; el editor se abre sobre ese archivo, con la imagen a su tamaño real (reducida si no cabe).
  - Herramientas: lápiz (`P`), marcador translúcido (`M`), flecha (`A`), rectángulo (`R`), elipse (`E`), texto (`T`) y cuentagotas (`I`). El texto se escribe en el sitio y se confirma con Enter (Esc lo cancela).
  - Color y grosor: 9 colores y 3 grosores; el cuentagotas toma el color de un píxel de la propia captura, lo copia como hex al portapapeles y vuelve a la herramienta anterior. Solo actúa al hacer clic con él: el lienzo de muestreo (`sampler`) está «armado» únicamente tras `sample()`, así que abrir el editor no copia ningún color. La herramienta, el color y el grosor se recuerdan (`edTool`, `edColor`, `edSize` en `capture`).
  - Acciones: Copiar (`Ctrl+C`) deja la imagen anotada en el portapapeles; Guardar (`Ctrl+S`) la guarda con el nombre, carpeta y formato de Ajustes (y la copia si «copiar también al portapapeles» está activo); Cerrar (`Esc`) descarta. Deshacer `Ctrl+Z`, rehacer `Ctrl+Shift+Z` o `Ctrl+Y`.
  - Cómo se exporta: `EditorSurface.exportTo` captura el bloque `content` (imagen + lienzo) a tamaño completo con `grabToImage` y lo escribe en `<captura>_edit.png`; `ooze-capture.sh editfinish` lo copia o lo guarda (JPEG vía `ffmpeg` si el formato es JPEG; sin `ffmpeg` se guarda PNG) y borra los dos temporales.
  - Estructura del dibujo: cada anotación es un objeto en `EditorSurface.items` (`pen`/`marker` con `p`, `arrow`/`rect`/`ellipse` con `a` y `b`, `text` con `x`, `y`, `px`, `s`). `EditorCanvas.drawItem` las pinta en orden; deshacer mueve el último a `redoItems`.
  - Sustituye a «zona → archivo»: Guardar vive dentro del editor, por lo que ya no hace falta un atajo aparte. `areaCopy` y `areaSave` siguen existiendo por IPC y en el launcher.
- Selector de color
  - `colorPick` congela la pantalla sin oscurecerla; un clic lee ese píxel (`grim` en PPM de 1×1), copia `#rrggbb` con `wl-copy` y lo notifica. Esc o clic derecho cancelan.
- Atajos de teclado (Hyprland, Lua)
  ```lua
  hl.bind("PRINT", hl.dsp.exec_cmd("quickshell ipc -p ~/.config/quickshell/OozeShell/shell.qml call -- screenshot fullSave"))
  hl.bind(mainMod .. " + PRINT", hl.dsp.exec_cmd("quickshell ipc -p ~/.config/quickshell/OozeShell/shell.qml call -- screenshot areaEdit"))
  hl.bind(mainMod .. " + CTRL + PRINT", hl.dsp.exec_cmd("quickshell ipc -p ~/.config/quickshell/OozeShell/shell.qml call -- screenshot colorPick"))
  ```
- Indicador
  - Vive dentro del módulo `privacy`: si ese módulo no está en la barra, la barra no muestra el icono. En modo píldora sale en la píldora derecha y el menú se despliega como el de la bandeja.
  - Menú (clic derecho): Pausar/Reanudar, Detener y guardar, Descartar, Nueva grabación de zona, Nueva grabación de pantalla completa, Abrir carpeta de grabaciones. «Nueva» guarda la actual y empieza la siguiente.
- Pausa
  - `wf-recorder` no pausa: cada pausa cierra un segmento y reanudar abre otro. Al detener, `ffmpeg -f concat -c copy` los une en un solo archivo (sin recodificar). Sin `ffmpeg`, los segmentos se guardan como `nombre_part1`, `nombre_part2`…
  - Los segmentos viven en `~/.cache/oozeshell/rec/` hasta unirse.
- Dónde empieza a grabar
  - Dashboard → Acceso rápido: mosaicos «Grabar zona» y «Grabar pantalla» (con la grabación activa detienen y guardan).
  - Launcher (`>`): «Grabar: zona», «Grabar: pantalla completa», «Detener grabación».
  - IPC.
- IPC de capturas (`qs ipc call screenshot …`)
  | función | efecto |
  |---|---|
  | `areaEdit` | elige una zona y abre el editor |
  | `colorPick` | copia el color de un píxel |
  | `fullSave` | guarda el monitor enfocado |
  | `areaCopy` / `areaSave` | zona → portapapeles / archivo, sin editor |
- IPC de grabación (`qs ipc call record …`)
  | función | efecto |
  |---|---|
  | `toggleArea` / `toggleScreen` | empieza la grabación o, si ya hay una, la detiene y guarda |
  | `startArea` / `startScreen` | empieza (no hace nada si ya hay una) |
  | `stop` | detiene y guarda |
  | `pause` / `resume` / `togglePause` | pausa y reanuda |
  | `cancel` | descarta la grabación |
  | `status` | devuelve fase y tiempo, por ejemplo `recording 01:23` |
- Ajustes (Ajustes avanzados → Capturas y grabación)
  - Carpetas de capturas y de grabaciones (vacío = `Imágenes/Screenshots` y `Vídeos/Recordings`), nombres con formato de fecha `strftime`.
  - Capturas: PNG o JPEG (con calidad), cursor, copiar también al portapapeles.
  - Grabación: MP4, MKV o WebM; 24/30/60 fps; calidad baja/media/alta; audio ninguno, del sistema o micrófono; codificador (CPU, NVENC de NVIDIA o VAAPI de AMD/Intel); cuenta atrás.
  - Avisos al terminar y comprobación de las herramientas instaladas.
- Audio
  - El dispositivo se resuelve con `pactl` (o `wpctl` si falta): «sistema» usa el monitor de la salida por defecto, «micrófono» la entrada por defecto. Cada segmento deja en `~/.cache/oozeshell/rec.log` el comando de `wf-recorder` y su salida de error.
- Dependencias: `grim`, `wl-clipboard`, `wf-recorder`, `ffmpeg`, `libnotify`, `pulseaudio` (solo el binario `pactl`, para elegir el audio), `xdg-utils` y `xdg-user-dirs`.
