# TERMINAL — categoría Terminal de Ajustes e IPC `terminal`

- Qué es
  - Una categoría de **Ajustes avanzados → Terminal** que edita los dotfiles de tus terminales sin abrirlos a mano: cambiar la opacidad de cada terminal y modificar el prompt de starship.
  - OozeShell **busca** los archivos en `~/.config` (y `~/.zshrc`), sigue los enlaces simbólicos hasta el repositorio de dotfiles y escribe **sobre el archivo real**, así el cambio queda en tu repositorio y `git diff` lo muestra.
  - También se controla desde fuera con el target IPC `terminal`.
- Archivos
  - `Tools/terminal-config.py` → backend en Python (solo librería estándar): detecta, lee y edita. Imprime siempre una línea JSON.
  - `Services/Terminal/TerminalConfig.qml` → singleton que llama al backend con una cola y expone el último escaneo a la interfaz.
  - `Services/Terminal/qmldir` → registra el singleton.
  - `Settings/pages/TerminalPage.qml` → la página (dotfiles, opacidad, starship).
  - `Core/Ipc/TerminalIpc.qml` → `IpcHandler` del target `terminal`.
  - `Settings/SettingsRegistry.qml` → categoría `terminal` (grupo Aspecto) y su índice de búsqueda.
  - `Services/Lang/languages/Lang{En,Es}.qml` → claves `term*` y `advCatTerminal`.
  - `shell.qml` → una línea `TerminalIpc { shell: root }`.
  - `random-fastfetch` (en el repositorio de dotfiles, enlazado a `~/.local/bin/`) → lee el estado y decide qué mostrar.

## Qué edita y dónde

| Opción | Archivo (relativo a `~/.config`) | Clave |
|---|---|---|
| Fastfetch encendido / apagado | `oozeshell/terminal.toml` | `fastfetch` |
| Imagen aleatoria encendida / apagada | `oozeshell/terminal.toml` | `fastfetchRandom` |
| Imagen fija (con aleatorio apagado) | `oozeshell/terminal.toml` | `fastfetchImage` |
| Imágenes de fastfetch | `fastfetch/images/` | archivos `png`, `jpg`, `jpeg`, `gif`, `webp` |
| Opacidad de Kitty | `kitty/kitty.conf` | `background_opacity` |
| Opacidad de Ghostty | `ghostty/config.ghostty` | `background-opacity` |
| Opacidad de Foot | `foot/foot.ini` | `alpha` en `[colors-dark]` (o `[colors]`) |
| Opacidad de Alacritty | `alacritty/alacritty.toml` | `opacity` en `[window]` |
| Opacidad de WezTerm | `wezterm/wezterm.lua` | `config.window_background_opacity` |
| Prompt de starship | `starship.toml` **y** `matugen/templates/starship.toml` | ver tabla de Starship |

La opacidad se muestra en porcentaje (10 a 100) y se escribe como fracción de dos decimales (`60` → `0.60`). Los demás valores del archivo no se tocan: solo cambia la línea de la clave.

## Cómo se encuentran los dotfiles

1. El backend revisa una lista fija: `~/.zshrc`, `starship.toml`, la plantilla de starship de matugen, `fastfetch/config.jsonc`, `~/.local/bin/random-fastfetch` y la configuración de cada terminal.
2. De cada archivo guarda si existe, si es enlace (`linked`), su ruta real (`real`) y si se puede escribir (`writable`).
3. `dotfilesRoot` se deduce de la primera ruta real que cae dentro de un `/.config/` fuera de tu carpeta personal (el repositorio); si no hay enlaces, se usa `~/dotfiles` cuando existe, y si no queda vacío.
4. Al escribir se usa siempre la ruta real: archivo temporal en la misma carpeta + `os.replace`, conservando los permisos. Si el destino es de solo lectura (por ejemplo enlaces al store de Nix), el backend responde `io:…` y la página avisa que el archivo no se puede escribir.

## Fastfetch

Tiene su propia categoría: ver `FASTFETCH.md`. Sigue usando `TerminalConfig` y `Tools/terminal-config.py` para encender/apagar, imagen aleatoria y miniaturas.

## Opacidad: recarga de cada terminal

| Terminal | Cómo se aplica el cambio |
|---|---|
| Kitty | señal `USR1` (recarga la configuración) |
| Ghostty | señal `USR2` (requiere una versión que la soporte; si no, `Ctrl+Shift+,`) |
| Alacritty | recarga sola por `live_config_reload = true` |
| WezTerm | recarga sola al cambiar el archivo |
| Foot | no recarga: se ve en ventanas nuevas |

Mientras se arrastra el control deslizante los valores se acumulan como borrador (`TerminalConfig.drafts`) y se escriben 350 ms después de soltar, para no reescribir el archivo en cada paso.

## Starship

`~/.config/starship.toml` **lo regenera matugen** (`matugen/config.toml`, plantilla `templates/starship.toml`) al cambiar el fondo, y `Tools/palette-apply.py` hace lo mismo en modo Paletas. Editar solo el archivo generado perdería el cambio en la siguiente regeneración, por eso cada opción se escribe en **los dos archivos**: el generado (efecto inmediato) y la plantilla (persistencia).

| Clave del backend | Sección y clave de starship | Tipo |
|---|---|---|
| `newline` | `add_newline` | bool |
| `time` | `[time] disabled` (invertida) | bool |
| `timeFormat` | `[time] time_format` | texto (`%H:%M` o `%I:%M %p`) |
| `duration` | `[cmd_duration] disabled` (invertida) | bool |
| `durationMin` | `[cmd_duration] min_time` (milisegundos; la página usa segundos) | entero |
| `dirDepth` | `[directory] truncation_length` | entero |

- Si la clave no existe en el archivo se inserta tras la última clave de su sección (sin pasar por los comentarios de la sección siguiente); si la sección no existe se crea al final.
- El editor por líneas respeta las cadenas multilínea `"""…"""` (el `format` del prompt), así que no confunde sus corchetes con encabezados de sección.
- Tras escribir se envía `USR1` a `zsh`, igual que el `post_hook` de matugen, y `TRAPUSR1` de `.zshrc` redibuja el prompt.
- Los botones **Editar** abren el archivo con la app de la función `editor` de Apps predeterminadas (`DefaultApps.run("editor", …)`). Para cambios que no están en la lista (colores, segmentos, símbolos) se edita la plantilla.

## Mapa de bloques

### `Services/Terminal/TerminalConfig.qml`

| Bloque | Qué contiene |
|---|---|
| `ESTADO` | `data` (último escaneo), `loaded`, `lastError`, `queue`, `drafts`, señal `failed` y las propiedades derivadas (`terminals`, `items`, `starship`, `fastfetch`, `images`, `dotfilesRoot`, `busy`…) |
| `CONSULTAS` | `terminalInfo`, `itemInfo`, `opacityOf`, `imageUrl`, `shortPath` |
| `COLA` | `enqueue`, `pump`, `refresh` (no apila dos escaneos) y `finish` (interpreta la respuesta; tras cada cambio pide un escaneo nuevo) |
| `ACCIONES` | `setFastfetch`, `setRandom`, `useImage`, `addImage`, `removeImage`, `setStarship`, `toggleFastfetch`, `toggleRandom`, `applyOpacity`, `setOpacity`, `openInEditor`, `openFolder` |
| `TRABAJADOR` | `Timer` del borrador de opacidad y el `Process` que ejecuta `python3 Tools/terminal-config.py <comando>`; procesa la salida cuando termina y sigue con la cola |

El singleton no corre nada al arrancar el shell: se crea al abrir la categoría o al llamar al IPC.

### `Settings/pages/TerminalPage.qml`

| Bloque | Qué contiene |
|---|---|
| `FUNCIONES` | `errorMessage`, `itemHint`, `terminalHint` |
| `COMPONENTES` | `DotItem` (fila de un dotfile con botón Editar) |
| `AVISO DE ERROR` | `SettingsNote` con el último error del backend traducido |
| `DOTFILES` | carpeta del repositorio, botón de buscar de nuevo y la lista de archivos detectados |
| `OPACIDAD` | un control deslizante por cada terminal cuya configuración existe |
| `STARSHIP` | interruptores, formato de hora, números y botones de edición |

### `Tools/terminal-config.py`

| Bloque | Qué contiene |
|---|---|
| `RUTAS` | constantes de rutas, `which`, `real`, `writable`, lectura y escritura atómica |
| `TOML POR LÍNEAS` | `scan_lines`, `toml_get`, `toml_set`, `parse_literal`, `quote` |
| `ESTADO DE FASTFETCH` | lectura y escritura de `terminal.toml`, listado y nombres de imágenes |
| `TERMINALES` | tabla `TERMINALS` (archivo, clave, señal) y lectura / escritura de la opacidad |
| `STARSHIP` | tabla `STARSHIP_KEYS`, `starship_values`, `starship_write` |
| `DETECCIÓN` | `tracked_items`, `dotfiles_root`, `scan` |
| `COMANDOS` | un `cmd_*` por comando y `main` |

### `random-fastfetch`

| Bloque | Qué contiene |
|---|---|
| `ESTADO` | `state_value` y las tres lecturas de `terminal.toml`; sale si está apagado |
| `IMAGEN` | elige al azar o la fija |
| `PROTOCOLO` | detecta `sixel` / `kitty` / `auto` según la terminal |
| `EJECUCIÓN` | `exec fastfetch` con o sin `--logo` |

## Comandos del backend

`python3 Tools/terminal-config.py <comando> [argumentos]`. Todos responden una línea JSON; los que cambian algo devuelven `{"ok": true}` o `{"ok": false, "error": "…"}`.

| Comando | Efecto |
|---|---|
| `scan` | devuelve el estado completo (ver abajo); es el comando por defecto |
| `opacity <terminal> <0-100>` | escribe la opacidad y recarga la terminal si puede |
| `fastfetch <on\|off\|toggle>` | enciende, apaga o alterna fastfetch |
| `random <on\|off\|toggle>` | enciende, apaga o alterna la imagen aleatoria |
| `image-use <nombre>` | fija una imagen (vacío la quita) |
| `image-add <ruta>` | copia una imagen a `fastfetch/images/` y devuelve el nombre final |
| `image-remove <nombre>` | borra una imagen |
| `starship <clave> <valor>` | cambia una opción en el archivo generado y en la plantilla |

Errores posibles: `unknown-command`, `unknown-terminal`, `unknown-key`, `invalid`, `missing`, `unsupported`, `nokey` e `io:<detalle>`.

Forma de `scan`:

| Campo | Contenido |
|---|---|
| `dotfilesRoot` | carpeta del repositorio de dotfiles (o vacío) |
| `items[]` | `{ id, path, real, exists, linked, writable }` por archivo vigilado |
| `terminals[]` | `{ id, name, installed, found, path, writable, opacity, live }` |
| `starship` | `{ installed, found, path, templatePath, templateFound, writable, values }` |
| `fastfetch` | `{ installed, enabled, random, image, dir, imagesDir, configFound, scriptFound, zshrcHook, images[] }` |

## IPC

Target `terminal`.

| Función | Efecto |
|---|---|
| `fastfetch <bool>` | enciende o apaga fastfetch |
| `toggleFastfetch` | alterna fastfetch |
| `random <bool>` | enciende o apaga la imagen aleatoria |
| `toggleRandom` | alterna la imagen aleatoria |
| `opacity <terminal> <0-100>` | cambia la opacidad; devuelve `ok` o `invalid` |
| `rescan` | vuelve a buscar los dotfiles |

Ejemplos: `oozeshell terminal toggleFastfetch` · `oozeshell terminal opacity kitty 80`.

## Dependencias

- `TerminalConfig.qml` importa `Services/DefaultApps` (abrir en el editor y la carpeta).
- `TerminalPage.qml` importa `COMMON`, `Services/Lang` y `Services/Terminal`, y reutiliza `ScaleSlider`, `NumberStepper`, `SettingsChoice`, `SettingsSwitch` y `SettingsBtn`.
- Externos: `python3` y `pkill` para las recargas. `random-fastfetch` y `fastfetch` solo si se quiere usar esa parte.

## Notas

- Agregar una terminal: una entrada en `TERMINALS` de `Tools/terminal-config.py` (`id`, `name`, `bin`, `file`, cómo se lee la opacidad y, si existe, la señal de recarga). La página la muestra sola cuando encuentra su archivo.
- Agregar una opción de starship: una entrada en `STARSHIP_KEYS`, su control en `TerminalPage.qml` y las claves `termStarship*` en los dos idiomas.
- Agregar un idioma: replicar las claves `term*` y `advCatTerminal` en el nuevo `LangXx.qml`.
- Los cambios se escriben en el repositorio de dotfiles, no en una copia: aparecen en `git status`. Con dotfiles administrados por Nix (solo lectura) la página los marca y no permite editarlos.
