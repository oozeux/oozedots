# BAR — Barra por pantalla + marco y esquinas

- Qué es: `Variants` por pantalla con fondo blur, módulos izquierda/centro/derecha y marco continuo (Border + FrameCorner). Se oculta en fullscreen o durante cambio de wallpaper; vacía (`[]`) en `pillMode`.
- Archivos:
  - `Modules/Bar/Bar.qml` → `Variants { model: pillMode ? [] : screens }`: `PanelWindow` fondo, `cornersTop`/`cornersBottom`, `Border`, `CenterModules`/`LeftModules`/`RightModules`; señales `*ButtonClicked` hacia `shell.qml`.
  - `Modules/Bar/Border.qml` → 4 `PanelWindow` rectos (top/bottom/left/right, namespaces `oozeshell-frame-*`); solo visibles con marco curvo activo y lado sin barra.
  - `Modules/Bar/GlassFrame.qml` → marco translúcido de una sola forma para el modo cristal (namespace `oozeshell-frame-glass`).
  - `Modules/Bar/components/FrameCorner.qml` → esquina deformada (Shape); única parte curva del marco.
  - `Modules/Bar/LEFT/LeftModules.qml`, `Modules/Bar/CENTER/CenterModules.qml`, `Modules/Bar/RIGHT/RightModules.qml` → las tres islas. Solo contienen geometría (ventana, píldora, tooltip, rectángulo de isla); qué módulos muestran lo decide el picker.
  - `Modules/Bar/components/BarHost.qml` → base común de las tres islas: señales de botones, estado de popups, tooltips, menús de bandeja/taskbar, publicación en `IslandState`.
  - `Modules/Bar/components/BarSectionRow.qml` → contenido de una isla: lee `Theme.barModulesOf(side)`, instancia los módulos en orden, pone separadores entre módulos visibles y expone `occupied` (hay algo visible).
  - `Modules/Bar/components/BarRevealZone.qml` → zona de disparo (ns `oozeshell-bar-reveal`) que aparece cuando la barra está oculta; al pasar el ratón o clic pide el `peek`.
  - `Modules/Bar/modules/` → un archivo por módulo (`PowerModule`, `LangModule`, `MprisModule`, `NotificationsModule`, `WorkspacesModule`, `ClockModule`, `AudioModule`, `BatteryModule`, `PrivacyModule` (también muestra el icono de grabación, ver CAPTURE.md), `TaskbarModule`, `TrayModule`, `MenuModule`) y `BarPillButton`. Cada uno recibe `host` (la isla) y expone `shown`.
  - Formato de hora (`Theme.barClock24h`, `ui.toml` → `barClock24h`, Ajustes → Barra → Reloj): interruptor 24 h / 12 h que se aplica a todos los estilos: `classic` y `date` muestran `h:mm AM/PM`, `datesoft` muestra `h:mmAM` (sin espacio), `seconds` muestra `h:mm` con `:ss AM/PM` atenuado y `cards` usa `hh` y `mm` más una etiqueta AM/PM (en barra vertical se omite). Un estilo `ampm` guardado antes se migra a `classic` + 12 h.
  - Estilo del reloj (`Theme.barClockStyle`, `ui.toml` → `barClockStyle`, Ajustes → Barra → Reloj): `classic` (HH:mm), `seconds` (HH:mm con `:ss` más pequeño y atenuado), `date` (fecha en negrita y color primario + hora), `datesoft` (hora + fecha discreta) y `cards` (HH y mm en tarjetas). Se dibujan en `COMMON/ClockFace.qml`, que comparten `Modules/Bar/modules/ClockModule.qml` (barra) y `Modules/Pill/PillClock.qml` (píldora).
    - Idioma de la fecha: `ClockFace` no importa `Translations` (COMMON no depende de servicios). Quien lo usa le pasa `localeCode: Translations.localeCode` y la cara formatea con `Qt.locale(localeCode)`, así `date` y `datesoft` siguen el idioma de OozeShell y no el del sistema. El `AM/PM` de `datesoft` se calcula a mano (`meridiem`) para no depender del locale.
    - `datesoft`: `h:mmAM  dom 01/11`. La hora va en `Theme.fs(15)` y color de texto; la fecha en `Theme.fs(12)`, color `Theme.subtext`, sin negrita y en minúsculas (`compactDate`). El numeral es día/mes (`dd/MM`) en español y mes/día (`MM/dd`) cuando el idioma empieza por `en`. Para quitar el AM/PM pegado a la hora, o cambiar el orden del numeral, se edita `compactTime` / `compactDate`.
    - Disponibilidad (`Theme.clockStyleUsable(style)`): barra horizontal → los 5; barra vertical → `classic` (HH sobre mm) y `cards`; modo píldora → todos. Los no disponibles salen atenuados en el selector y, si el estilo guardado no aplica, se usa `Theme.barClockStyleEffective` (`classic`) sin borrar la elección.
    - Estilo `analog` eliminado: un `ui.toml` que aún lo tenga guardado cae a `classic` al cargar (la lista `Theme.barClockStyles` ya no lo contiene).
    - A vigilar: `clockStyleUsable` es el único sitio donde se decide qué aplica en cada modo; si agregas un estilo, súmalo ahí, a `Theme.barClockStyles` y a las claves `barClockStyle_<estilo>` de `LangEs.qml` / `LangEn.qml`. El `Timer` de 1 s es común a todos: solo `seconds` lo necesita realmente.
  - Icono del botón de menú (`Theme.menuIconMode`, `menuIconPath`, `menuIconDarkPath`, `menuIconLightPath`, Ajustes → Barra → Icono del botón de menú): `distro` (logo de NixOS/Arch, por defecto), `single` (una imagen para claro y oscuro) o `pair` (una imagen por modo, según `Theme.bgIsDark`). Se dibuja en `MenuModule.qml`; si la ruta está vacía o la imagen no carga, vuelve al logo de la distro. El selector de archivo es `Settings/FileField.qml` (reutiliza `ImageBrowser`). Acepta `~`, PNG/JPG/WEBP/SVG.
  - `Modules/Bar/CENTER/CALENDAR/CalendarDrop.qml` → calendario del reloj; siempre se dibuja en la ventana de CENTER, aunque el reloj esté en otra isla (estado en `COMMON/BarCalendar.qml`).
- IPC (Core/Ipc/BarIpc.qml target `bar`, Core/Ipc/CornersIpc.qml target `corners`):

  | target | función | efecto |
  |---|---|---|
  | `bar` | `position <p>` / `togglePosition` | `top\|bottom\|left\|right` / rota al opuesto |
  | `bar` | `floating <b>` / `toggleFloating` | barra flotante sí/no |
  | `bar` | `floatWindows <b>` / `toggleFloatWindows` | ventanas, paneles y tooltips flotantes (sin curvas de unión), con o sin Cristal; el modo performance (`shellPerf`) los activa mientras esté encendido, sin tocar este ajuste |
  | `bar` | `windowAnim <estilo>` / `cycleWindowAnim` | `spring\|smooth\|zoom\|pop\|slide\|fade`: animación de las ventanas flotantes (Cristal y flotantes) |
  | `bar` | `islands <b>` / `toggleIslands` | modo islas sí/no |
  | `bar` | `fusedIslands <b>` / `toggleFusedIslands` | estilo FusedIslands (islas pegadas al borde con curvas; ver FUSEDISLANDS.md) |
  | `bar` | `fusedOutline <b>` / `toggleFusedOutline` | contorno de las islas fusionadas |
  | `bar` | `hidden <b>` / `toggleHidden` / `hiddenFrame <b>` | ocultar barra / mantener marcos al ocultar |
  | `bar` | `revealMode <hover\|click>` / `peek` | cómo reaparece la barra oculta / mostrarla temporalmente |
  | `bar` | `pill <b>` / `togglePill` | modo pill (sin barra clásica) sí/no |
  | `bar` | `templateSave <nombre>` / `templateLoad <nombre>` / `templateDelete <nombre>` / `templates` | plantillas de barra: guardar / aplicar / borrar / listar (builtin + guardadas) |
  | `bar` | `get` | JSON `{position, floating, islands, fusedIslands, fusedOutline, pill, floatWindows, windowAnim, hidden, hiddenFrame, revealMode}` |
  | `corners` | `toggle` / `set <b>` / `get` | esquinas de pantalla sí/no |

  ```bash
  quickshell ipc -p .../shell.qml call -- bar position top
  quickshell ipc -p .../shell.qml call -- bar toggleFloating
  quickshell ipc -p .../shell.qml call -- bar get
  quickshell ipc -p .../shell.qml call -- corners toggle
  ```
- Estado y datos: sin singleton/JSON propios; todo vive en `Theme` (`COMMON/Theme.qml`): `barPosition`, `barFloatingPref`, `islandsPref`, `pillModePref` (+ derivados `barVertical`, `barAtBottom`, `islandsMode`). Persistidos en `~/.config/oozeshell/ui.toml`. `screenCorners` vive en `shell.qml` (`root.screenCorners`).
- Dependencias: `COMMON` (Theme, SkinRect, GlassRegion, FullscreenState), `Services/Walls` (WallsFrameFlare), `Services/Lang`, `Services/Mpris`. Los botones delegan a popups de `shell.qml` vía señales.
- Notas: `framArmsActive` requiere marco on + curvo + no separado + no reconstruyendo; los brazos (`armTop/Bottom/Left/Right`) reservan espacio junto a esquinas. `Theme.barRebuilding` oculta la barra durante cambios de layout. El módulo de audio y el clic derecho del reloj abren el Dashboard (secciones Audio y Calendario) en lugar de popups propios; el mini-calendario en hover del reloj (`Modules/Bar/CENTER/CALENDAR/CalendarDrop.qml`) se conserva. La caja de componentes compartidos `Modules/Menu/` solo contiene `Sparkline.qml` y `SystemStats.qml`.

## Picker de módulos (Ajustes → Barra → Módulos)

- Aplica a barra normal, flotante, islas y vertical. No aplica a Píldora.
- Datos: `Theme.barLayoutPref` = `{left: [...], center: [...], right: [...]}` con ids de módulo; se guarda en `ui.toml` (`barLayout`). API: `barModulesOf(side)`, `barSideOf(id)`, `placeBarModule(id, side, index)`, `nudgeBarModule(id, delta)`, `resetBarLayout()`. En barra vertical left = arriba, right = abajo.
- Un módulo está en una sola isla a la vez; puede quedar fuera de la barra.
- Isla vacía (o con módulos que no se ven, p. ej. privacidad sin uso): `occupied = false` → su ventana se oculta y se borra de `IslandState`.
  - Barra normal / vertical: el fondo de la barra sigue completo.
  - Islas: la isla vacía desaparece.
  - Flotante: el fondo (`barBg` en `Bar.qml`) se encoge hacia las islas con contenido; si izquierda y derecha tienen contenido queda a todo el ancho, aunque el centro esté vacío.
- Los popups (audio, menú, mpris, energía, notificaciones, agenda) salen del lado donde esté su módulo (`Theme.popupAlign` / `Theme.popupIsland`); en Píldora usan su alineación original.

## Ocultar barra

- `Theme.barHiddenPref` (efectivo: `Theme.barHidden`, nunca en Píldora ni con Waybar). Persistido en `ui.toml` (`barHidden`, `barHiddenFrame`).
- Las ventanas de la barra NO se destruyen: quedan mapeadas pero vacías (máscara de entrada vacía, fondo transparente, `exclusionMode: Ignore`), así que no se reserva espacio y al volver a mostrarla no hay que recrear ventanas. `BarHost.shown = occupied && !barHidden` gobierna las píldoras. Flotante e islas se desactivan mientras está oculta.
- Marcos (`barHiddenFramePref`, por defecto ON): `Theme.frameBarSide` pasa a `""`, así `Border.qml` dibuja las 4 franjas y `Bar.qml` pone brazos y esquinas en los 4 lados; el lado de la antigua barra queda como un lado más del marco. `Theme.barThickness` pasa a valer el grosor de la franja (o 0 sin marco) para que popups y OSD cuelguen debajo de ella sin solaparse. OFF: `Theme.frameOn` es falso mientras está oculta.

## Capa del fondo de la barra (barra normal y flotante)

- Estructura: el fondo (`barPanel` en `Bar.qml`) es una ventana aparte de los módulos (`LeftModules`, `CenterModules`, `RightModules`).
- Capas: fondo en `Top` y módulos en `Overlay` en todos los WM (ver COMMON.md, "Orden de capas"). No se pone el fondo en la misma capa que los módulos porque, al recrear la barra, el fondo podía mapearse después y tapar los módulos.
- Durante fullscreen o cambio de wallpaper el fondo se oculta con `screenRoot.suppressed` (opacidad 0 y máscara vacía).
- Modo cristal: el fondo sigue siendo `barPanel` con su `GlassRegion`; los módulos usan `Theme.islandBg` transparente en barra normal.

## Modo cristal en barra normal

- El modo cristal ya no vuelve flotante la barra horizontal: `Theme.barFloating` depende solo de `barFloatingPref`. La barra queda pegada al borde, igual que en barra lateral. Los paneles y popups siguen saliendo flotantes (`Theme.floatWindows` incluye `glassMode`).
- Para tener la barra flotante con cristal se activa "Barra flotante" en Ajustes, como en cualquier otro modo.

## Marco en modo cristal

- `Theme.frameOn` ya no se apaga con `glassMode`. `Theme.frameGlass` (`frameOn && glassMode`) indica que el marco debe dibujarse translúcido.
- Estilo `curved`: lo dibuja `GlassFrame.qml`, una sola ventana por pantalla con una única forma (rectángulo exterior menos rectángulo interior redondeado, regla de relleno par-impar). Al ser una sola forma no hay solapes y el color `Theme.glassBg` no se duplica. El blur usa una región con la misma forma (rectángulo exterior menos interior redondeado). El lado de la barra no lleva franja: el anillo arranca justo donde termina la barra (`Theme.barOffset`).
- Las franjas de `Border.qml` siguen existiendo en cristal, pero transparentes: solo reservan espacio (`exclusiveZone`) y atienden el clic de revelar la barra. Las esquinas sueltas (`FrameCorner.qml`) se ocultan en `curved` con cristal.
- Estilo `corners`: usa las piezas de esquina de siempre con `Theme.glassBg`. No tienen región de blur propia, así que en las esquinas el cristal se ve translúcido sin desenfoque.
- Se activa con `barModule.screenCorners`, `WM.has("screenFrame")` y sin barra flotante, islas, Modular ni píldora (`!Theme.barSeparated`), igual que el marco opaco.

## Modos Modular y Mixed

- Modular (`Theme.barModularPref`, `ui.toml` → `barModular`; IPC `bar modular|toggleModular`): oculta el fondo de la barra (`barBg`) y de las islas; cada módulo se dibuja como una píldora con `Theme.modularFill` (el mismo color de fondo que las demás barras, `Theme.panelBg`, por defecto; con `barModularTranslucent` una mezcla de `bg` y superficie al 72 %; con Cristal usa `glassBg`) (`BarSectionRow`, rectángulo `z: -1` dentro del `Loader` de cada módulo, separación mayor entre módulos). Sin borde por defecto; el contorno es un ajuste aparte (`Theme.barModularOutlinePref`, `ui.toml` → `barModularOutline`; IPC `bar modularOutline|toggleModularOutline`; Ajustes → Barra, visible solo con píldoras por módulo): borde del color primario (α 0,85) con el grosor de FusedIslands (`Theme.fusedStroke`, 1,5 px). Aplica a Modular y a Mixed `modules` (`Theme.barModularOutline`). Fuerza ventanas flotantes (`Theme.floatWindows`) y cuenta como barra separada (`Theme.barSeparated`, salvo con la barra oculta): apaga el marco de pantalla y separa la barra del borde (`Theme.barEdge`), igual que Flotante e Islas. No aplica en píldora.
  - Altura uniforme: cada píldora mide `Theme.barPillFace` (30 px; 40 px de ancho en vertical) sin importar el contenido, se calcula en `pillBg` de `BarSectionRow`. A vigilar: si un módulo crece más de 30 px su contenido se sale de la píldora; en ese caso sube `barPillFace` en vez de agrandar el módulo. La bandeja usa `cellHeight: 30` (en la píldora sigue en 26).
- Mixed (`barMixedPref`, `barMixedStyle`; IPC `bar mixed|toggleMixed|mixedStyle`): colores distintos derivados de `Theme.primary` (`Theme.mixedAccent/mixedFill`, rotación de matiz). No aplica en cristal ni píldora (`Theme.barMixed`). Funciona con barra normal, flotante, vertical, islas y Modular.
  - `islands`: color por isla (`BarIslandTint`, sobre el fondo de cada isla; con Modular tiñe las píldoras de la isla; con FusedIslands pinta la propia forma, ver `Theme.barFusedTint` y FUSEDISLANDS.md).
  - `modules`: píldora de color por módulo (`Theme.barPillBack`).
  - `gradient`: el color fluye de izquierda a derecha entre las tres islas (en Modular, entre módulos; en FusedIslands, degradado horizontal dentro de cada forma).
  - A vigilar: `barIslandTint` (rectángulo) y `barFusedTint` (forma fusionada) son excluyentes; si agregas un cuarto fondo de isla, elige cuál usa. En FusedIslands el degradado vive en `FusedIslandShape` y sus paradas llaman a `mixedFill`, así que cambiar `mixedStrength` también cambia la fuerza del teñido.
  - `lines`: fondo normal y una línea de acento bajo cada módulo.
- A vigilar: el grosor del contorno comparte `Theme.fusedStroke` con FusedIslands y el dock; cambiarlo allí cambia los tres. `modularFill` es el único color de las píldoras Modular sin Mixed; antes usaba `Theme.surface` (más claro que el fondo de la barra). `modularBase` sigue siendo la superficie porque Mixed la mezcla con el acento; cambiarla oscurecería todos los colores de Mixed. El hover de la píldora usa `Theme.surface` (`barHover`), así que sigue contrastando con el nuevo fondo.
- A vigilar: los popups fusionados a una isla (`FusedTip`) no tienen fondo visible en Modular, por eso se fuerzan flotantes.
- Cómo se pinta el color (de dónde sale y quién lo usa):
  - `Theme.mixedAccent(pos)`: color vivo. Parte del matiz de `Theme.primary` y lo rota hasta 0.7 según `pos` (0 a 1). Saturación entre 0.55 y 0.85.
  - `Theme.mixedFill(pos)`: color de relleno. Mezcla `Theme.modularBase` (la superficie) con `mixedAccent(pos)` usando `Theme.mixedStrength` (0.52 en fondo oscuro, 0.44 en claro). Si `mixedStrength` es bajo, el relleno se ve casi igual a la superficie (gris oscuro); súbelo para más color.
  - `Theme.pillColor(side, k, total)`: elige el color de una píldora según el estilo (`islands` por isla, `modules` por posición del módulo, `gradient` por posición relativa entre todos los módulos, `lines` deja el color base).
  - `Theme.barPillBack`: hay píldora por módulo (Modular, o Mixed en `modules`). `Theme.barIslandTint`: se tiñe la isla (solo Mixed `islands`/`gradient` sin Modular). Con Modular activo la isla no se tiñe: el color lo llevan las píldoras, por eso Mixed y Modular funcionan juntos.
  - Píldora (`pillBg` en `BarSectionRow.qml`): su color es `base = Theme.pillColor(...)` y los `GradientStop` lo leen por el id `pillBg`. No usar `parent.base` dentro de un `GradientStop`: su `parent` es el `Gradient`, no el rectángulo, y la píldora queda con un color por defecto oscuro aunque Mixed esté activo.
  - Hover en Mixed: `Theme.barHover(side, k, total)` devuelve el color de hover de un módulo (`Theme.surface` si Mixed no está activo). Mezcla `Theme.modularBase` con el `mixedAccent` del módulo usando `Theme.mixedHoverStrength` (0.80 oscuro, 0.70 claro), así queda más vivo que la píldora (`mixedStrength` 0.52). La posición de color sale de `Theme.mixedPos`, la misma que usa `pillColor`, por lo que el hover conserva el matiz de su módulo en todos los estilos (en `lines` coincide con la línea de acento).
  - Cómo llega el color: `BarSectionRow` lo asigna con un `Binding` a la propiedad `hoverColor` del módulo cargado (declarada en `BarFlow`). Cada módulo la reenvía a sus botones (`BarPillButton`, `BarToggle`, `Taskbar`, `Tray`, `WorkspaceDots`) o la usa directo (reloj y notificaciones). Fuera de la barra de módulos (píldora) el valor por defecto sigue siendo `Theme.surface`.
  - A vigilar: un módulo nuevo debe usar `mod.hoverColor` en su hover y reenviarlo a sus hijos; si queda `Theme.surface` volverá a verse gris oscuro. Si el texto pierde contraste sobre el hover, baja `mixedHoverStrength`.
  - `Theme.barMixedFilled`: Mixed activo con un estilo que rellena de color (todos menos `lines`). Los elementos que dibujan encima (p. ej. workspaces) lo usan para cambiar a colores que contrasten.

## Estilos de workspaces

- `Theme.workspaceStyle` (`ui.toml` → `workspaceStyle`; IPC `bar workspaceStyle <estilo>`): `dots`, `bubbles`, `lines`, `numbers`, `kanji`, `roman`, `activity` (barras de actividad), `progress` (barra de progreso), `path` (ruta de nodos), `tabs` (pestañas con etiqueta), `tag` (pestañas con forma de etiqueta) y `ring` (indicador circular). `Theme.workspaceShowName` muestra el nombre activo junto a todos los estilos salvo números, kanji y romanos (antes o después del indicador según `Theme.workspaceNameAfter`, IPC `bar workspaceNameAfter <b>`). Los seis estilos nuevos están en `COMMON/Ws*.qml`; ver WORKSPACES.md.
- Todo se dibuja en `COMMON/WorkspaceDots.qml` (barra y píldora, horizontal y vertical con un solo layout). Sin cápsula propia: en la barra normal se integra al fondo; en Modular y Mixed por módulo toma la píldora del módulo (`BarSectionRow`), que lleva degradado y, si se activa, contorno. El activo tiene brillo y degradado.
- Módulo de workspaces en la barra (`Modules/Bar/modules/WorkspacesModule.qml`): reserva siempre la misma cara que el resto de módulos (30 px de alto en barra horizontal, 40 px de ancho en vertical) y 8 px de margen a los lados del contenido. Así la píldora de Modular/Mixed no queda aplastada y el contenido no se pega a los módulos vecinos; la línea de acento de Mixed `lines` queda a la misma altura que en los demás módulos.
- Colores sobre píldoras de color: con `Theme.barMixedFilled`, `WorkspaceDots` dibuja el activo con `Theme.text` (y el texto del activo con `Theme.bg`) en lugar de `Theme.primary`, porque la primera píldora tiene el mismo matiz que `primary` y el punto activo se perdería.
- Kanji hasta 99 (十一, 二十…), romanos hasta 89; fuera de rango muestra el número. Requiere una fuente con kanji (fontconfig la resuelve sola).
