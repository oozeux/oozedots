# TRAY — bandeja del sistema

- Qué es
  - La fila de íconos de aplicaciones (StatusNotifierItem) que ve el usuario en la barra y en la píldora, más sus menús. Además dibuja un ícono de Bluetooth propio cuando hace falta (ver más abajo).
- Archivos
  - `Modules/Tray/Tray.qml` → la fila: un `Repeater` sobre `SystemTray.items` y, al final, la celda de Bluetooth propia. Calcula `count` (cuántos íconos hay) y `texSize` (tamaño de textura según escala y DPR). Lo usan `Modules/Bar/modules/TrayModule.qml` y `Modules/Pill/PillTray.qml`.
  - `Modules/Tray/TrayIconImage.qml` → dibuja un ícono. Recibe `raw` (la cadena `icon` del ítem), pide la lista de archivos candidatos a `IconResolver` y prueba uno por uno hasta que uno carga. Si ninguno carga muestra `fallbackGlyph`.
  - `Modules/Tray/TrayMenu.qml` → ventana del menú de un ícono en la barra (`FusedWindow` + `FusedPanel`, namespace `oozeshell-tray`).
  - `Modules/Tray/TrayMenuList.qml` → contenido del menú: encabezado (ícono + título), lista de entradas y submenús. Sirve tanto a menús de apps como a menús propios (`custom: true`).
  - `COMMON/IconResolver.qml` → singleton que traduce `image://icon/<nombre>?path=<carpeta>` a rutas `file://`.
  - `Services/Bluetooth/BluetoothBackend.qml` → aporta `trayShown`, `trayTip` y `trayEntry` para la celda de Bluetooth propia.
- Cómo se resuelve un ícono
  1. `Quickshell` entrega en `item.icon` una cadena. Puede ser `image://qspixmap/...` (la app mandó el bitmap), una ruta absoluta o `image://icon/<nombre>` con un `?path=` opcional (carpeta de íconos propia de la app, como Steam).
  2. `IconResolver.candidates(raw)` devuelve una lista ordenada:
     - `qspixmap` y cualquier otra cosa que no sea `image://icon/` → se devuelve tal cual.
     - nombre absoluto → `file://<ruta>`.
     - con `?path=` → primero `<carpeta>/<nombre>.png`, `.svg`, `.xpm` (o el nombre tal cual si ya trae extensión).
     - al final, el archivo que encuentre el tema de íconos del sistema (`Quickshell.iconPath`, con memoria en `themeMemo` para no repetir la búsqueda).
  3. `TrayIconImage` prueba cada candidato; un error de carga pasa al siguiente.
- Adaptación a la paleta (`Theme.trayAdaptPref`, `ui.toml` → `trayAdapt`, activada por defecto; Ajustes → Barra; IPC `bar trayAdapt|toggleTrayAdapt`)
  - Solo se recolorea un ícono de un solo color cuando no contrasta con la barra (`lowContrast`: su luminosidad media difiere menos de 0,35 de `Theme.bg`). Un ícono blanco en una barra oscura, o negro en una clara, no se toca y conserva todos sus detalles.
  - Cuando sí se recolorea, se conservan los tonos: `MultiEffect` multiplica la luminosidad del ícono por `Theme.text` (`colorization: 1`), sin aplanarlo a silueta. Un ícono claro se tiñe tal cual (`brightness: 0`); uno oscuro se aclara antes (`brightness: 0.85`) para que sea visible.
  - Detección en `TrayIconImage`: monocromo por nombre (`symbolic`, `mono`, `monochrome`) o muestreando el ícono en un `Canvas` de 16 px (casi sin saturación y poca variación de luminosidad). El muestreo también calcula la luminosidad media. El resultado `{ mono, lum }` se guarda por archivo en `IconResolver.monoMemo`.
  - El teñido usa `layer.effect` con `MultiEffect`; `layer.textureSize` sigue a `texSize`, así que cambiar el tamaño de íconos o la escala de la barra no baja la resolución.
  - A vigilar: los umbrales de `classify` (`40` saturación, `0.06` proporción de color, `110` rango de luminosidad) y `0.35` de `lowContrast` deciden qué se recolorea; bajar `0.35` recolorea menos íconos. `0.85` de `brightness` controla cuánto se aclara un ícono oscuro: subirlo lo vuelve más plano. Si el `Canvas` no llega a pintar, la luminosidad queda en 1 (blanco) y solo se tratan los íconos que cumplan por nombre.
- Por qué no se usa `image://icon`
  - Ese proveedor de Quickshell carga siempre en el hilo lector de imágenes de Qt (`QQuickPixmapReader`). Allí crea `QIcon` y carga SVG mientras el hilo principal también consulta el tema de íconos. Con muchos pedidos seguidos, `QSvgIconEngine::addFile` corrompe memoria y Quickshell muere con `Segmentation fault`.
  - Se disparaba al abrir el menú de nm-applet para activar una red Wi-Fi: cada entrada pide un ícono de señal y, además, el ícono de la bandeja cambia varias veces por segundo (`nm-stage02-connecting01`, `…02`). El stacktrace del reporte pasa por `IconImageProvider::requestPixmap` justo ahí.
  - Las rutas `file://` se cargan en el hilo principal (`asynchronous: false`), así que ya no hay dos hilos tocando el tema de íconos.
  - Regla: en este proyecto no se escribe `image://icon/` en ningún `Image`. Para un ícono de bandeja se usa `TrayIconImage`; para uno de aplicación, `COMMON/AppIcon.qml` (`Quickshell.iconPath`).
- Ícono de Bluetooth propio
  - Qué resuelve: el ícono de Bluetooth de la bandeja lo pone una app externa (blueman, etc.). Si esa app no está corriendo en la sesión, no hay nada que ver. Esto pasa en Hyprland cuando la app no se lanza (Hyprland no ejecuta el autostart de XDG por sí solo); en niri sí se lanza y por eso allí sí aparecía.
  - Cuándo se muestra (`Tray.showBluetooth`): hay adaptador, Bluetooth está encendido (`BluetoothBackend.trayShown`) y no hay ya un ítem externo activo cuyo `id`, `title` o `tooltipTitle` contenga «blue» (`Tray.externalBluetooth`). Así no se duplica si blueman sí está.
  - Aspecto: glifo de `BluetoothBackend.statusIcon`; en color primario si hay dispositivos conectados y color de texto si no. El tooltip es `BluetoothBackend.trayTip` (nombre del dispositivo o cantidad).
  - Menú (clic o clic derecho, `BluetoothBackend.trayEntry`, entrada `custom: true`): «Apagar Bluetooth», y debajo los dispositivos emparejados o conectados; pulsar uno lo conecta o desconecta (`BluetoothBackend.activate`).
  - Si Bluetooth está apagado no se muestra nada (igual que blueman). Se enciende desde el dashboard o con el IPC `bluetooth`.
- Menús propios (`custom: true`)
  - Un objeto con `custom: true`, `title`, `glyph` e `items`. Cada item: `{ isSeparator, hasChildren, enabled, icon, text, glyph, triggered }`. Lo usan la grabación de pantalla (ver CAPTURE.md) y Bluetooth.
- A vigilar
  - `TrayIconImage` solo cubre rutas en `?path=` de la forma `<carpeta>/<nombre>.<ext>`. Una app que ponga sus íconos en subcarpetas del tipo `hicolor/48x48/apps/` mostrará el glifo de respaldo; habría que añadir esas rutas en `IconResolver.candidates`.
  - `IconResolver.themeMemo` solo guarda aciertos. Un ícono que el tema no tiene se vuelve a buscar en cada cambio, que es barato.
  - `Tray.externalBluetooth` se decide por texto («blue»). Una app de otra cosa que lleve «blue» en su nombre ocultaría el ícono propio.
- Cómo probar
  - Crash: abrir el menú de nm-applet en la bandeja y activar varias redes Wi-Fi seguidas; no debe aparecer `Quickshell has crashed`.
  - Bluetooth: con `blueman-applet` cerrado y Bluetooth encendido debe verse el glifo; abrirlo hace que el glifo propio desaparezca y quede el de blueman.
