# FUSEDISLANDS — Estilo de islas fusionadas al borde

- Qué es: un estilo extra del modo Islas. Cada isla (izquierda, centro, derecha) se pega al borde de la pantalla y se une a él con curvas (flares), igual que un panel fusionado. El dock usa la misma forma. Es opcional, se apaga sin perder nada y no es un tema: vive en el shell y sigue la paleta activa (manual o matugen).
- Qué activa por sí mismo:
  - Ventanas, paneles y tooltips flotantes (`Theme.floatWindows` lo incluye mientras `Theme.fusedIslands` sea verdadero).
  - Islas pegadas al borde (`Theme.barEdge` pasa a 0).
  - Compatible con el modo Cristal: el color y el blur salen de `Theme.glassBg` / `Theme.glassBlurOn`.
- Archivos:
  - `COMMON/FusedIslandShape.qml` → dibuja una isla: relleno con degradado suave, curvas de unión y contorno opcional.
  - `COMMON/GlassRegion.qml` → propiedad `rectFlat` (`top` / `bottom` / vacío): la región de blur no redondea el lado que toca el borde.
  - `COMMON/Theme.qml` → preferencias, derivados y setters (ver abajo).
  - `Modules/Bar/LEFT/LeftModules.qml`, `Modules/Bar/CENTER/CenterModules.qml`, `Modules/Bar/RIGHT/RightModules.qml` → usan la forma en lugar del rectángulo de isla.
  - `Modules/Dock/Dock.qml` → mismo radio y curva que las islas, color de cristal y contorno apagado.
  - `Modules/Widgets/clock/FusedClock.qml` + `Modules/Widgets/clock/parts/` → estilos de reloj `pixel` y `floral` (ver CLOCK.md).
  - `Settings/pages/BarPage.qml` y `Settings/BarSettings.qml` → interruptores.
  - `Core/Ipc/BarIpc.qml` → comandos IPC.

## Ajustes (`ui.toml`)

| Clave | Propiedad en `Theme` | Por defecto | Efecto |
|---|---|---|---|
| `fusedIslands` | `fusedIslandsPref` | apagado | activa el estilo; si Islas está apagado, `setFusedIslands(true)` lo enciende |
| `fusedOutline` | `fusedOutlinePref` | encendido | contorno de las islas (color `Theme.primary`); el contorno del dock es aparte (`dockOutline`) |

Derivados:

| Propiedad | Valor |
|---|---|
| `fusedIslands` | `fusedIslandsPref && islandsMode && !barModular && !cozy` |
| `fusedOutline` | `fusedIslands && fusedOutlinePref` |
| `fusedFlare` | `14 × barScale`: ancho y alto de la curva de unión |
| `fusedMargin` | `fusedFlare + 8`: margen lateral de las islas laterales (antes 6) |
| `fusedRadius` | `islandRadius`: radio de las esquinas del lado libre |
| `fusedStroke` | grosor del contorno |

## Cómo se dibuja

1. `FusedIslandShape` recibe el tamaño de la isla y dibuja el cuerpo dentro de él. Las curvas salen hacia afuera, a `flare` píxeles de cada lado.
2. Con la barra abajo (`Theme.barAtBottom`) la forma se voltea en vertical.
3. El contorno no recorre el lado pegado al borde: solo sube por los costados y cruza la base.
4. Color de relleno: `Theme.islandBg` (opaco sin Cristal, `glassBg` con Cristal). El degradado aclara un poco la parte alta.
5. Teñido con Mixed: `islands` rellena la forma con `Theme.mixedFill(islandPos)`; `gradient` usa un degradado horizontal entre los tramos de la isla (0–0,33 / 0,34–0,66 / 0,67–1) y un brillo vertical suave encima, y las curvas de unión toman el color de su extremo. `BarIslandTint` (rectángulo) queda apagado en este estilo porque no seguiría las curvas.
6. Color del contorno: `Theme.primary` al 85 %. Cambia solo con la paleta.

## Ventana de cada isla

Las curvas se dibujan fuera de la isla, así que su ventana necesita ese espacio:

- `fuse` (`Theme.fusedFlare` con el estilo activo, 0 sin él) adelanta el borde exterior de la ventana (`margins.left` / `margins.right` restan `fuse`) y desplaza la isla dentro de ella (`pill.x`).
- La posición de la isla en pantalla no cambia, así que `islandRect`, `spanX`, `panelOrigin` y los tooltips siguen siendo correctos.
- La ventana crece `2 × fuse` de ancho. La máscara de entrada sigue siendo solo la isla: las curvas no reciben clics.
- La isla central no necesita desplazamiento: su ventana ocupa toda la pantalla.

## Cristal

- Color: `islandBg` ya devuelve `glassBg` en modo Islas con Cristal.
- Blur: cada isla pide `rectOn` con `Theme.glassBlurOn` y `rectFlat` según la posición de la barra. Las curvas de unión no tienen blur propio (solo se ven translúcidas), igual que las esquinas del marco.
- Dock: con Cristal usa `Theme.glassBg` y `Theme.glassBlurOn`; sin Cristal conserva `dockOpacity` y `dockBlur`.

## Dock

- Misma curva (`fusedFlare`) y mismo radio (`fusedRadius`) que las islas.
- El contorno depende de `Theme.dockOutline` (apagado por defecto). Con este estilo usa el color y el grosor de las islas; en modo `panel` queda abierto en el lado del borde.

## Incompatibilidades

| Situación | Resultado |
|---|---|
| Barra vertical, barra oculta | `islandsMode` es falso: se ve la barra normal |
| Modular | `fusedIslands` se apaga; las píldoras por módulo mandan |
| Estilo Cozy | `fusedIslands` se apaga (Cozy dibuja sus propios bordes de tinta) |
| Mixed | `islands` y `gradient` tiñen la propia forma (`Theme.barFusedTint`, `tintSide` de `FusedIslandShape`); `modules` y `lines` siguen funcionando. Con Cristal Mixed no aplica |
| Modo píldora | Islas se apaga, por lo tanto también este estilo |

Cuando el estilo está elegido pero no aplica, la página de la barra muestra un aviso y el ajuste se reactiva solo al salir del modo que lo bloquea.

## IPC (target `bar`)

| función | efecto |
|---|---|
| `fusedIslands <b>` / `toggleFusedIslands` | activa o desactiva el estilo |
| `fusedOutline <b>` / `toggleFusedOutline` | contorno de islas sí/no |
| `get` | incluye `fusedIslands` y `fusedOutline` |

```bash
quickshell ipc -p .../shell.qml call -- bar fusedIslands true
quickshell ipc -p .../shell.qml call -- bar toggleFusedOutline
```

## A vigilar

- `Theme.fusedMargin` debe ser mayor que `fusedFlare`: si no, `margins.left - fuse` sería negativo y la curva se cortaría contra el borde de la ventana.
- `Theme.barEdge` vale 0 con el estilo activo: todo lo que cuelga de la barra (popups, OSD, toasts) usa `barOffset`, que ya lo incorpora. No sumar `floatGap` por separado.
- Si se agrega un cuarto elemento a la barra con fondo propio, debe usar `FusedIslandShape` cuando `Theme.fusedIslands` sea verdadero.
- `GlassRegion.rectFlat` solo afecta a las esquinas; no recorta la región a la forma de las curvas.
- El conejo, Sakura y demás adornos del tema D.Va no forman parte de este estilo. Los adornos del reloj que sí se conservan (Sakura, Sparkle, PixelEdge) están en `Modules/Widgets/clock/parts/`.
