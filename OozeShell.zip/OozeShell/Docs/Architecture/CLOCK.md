# CLOCK — widget de reloj de escritorio

- Qué es
  - Un único tipo de widget (`clock`) con 14 estilos. Cada estilo es un bloque visual dentro de `Modules/Widgets/clock/ClockWidget.qml`; solo se muestra el bloque cuyo estilo coincide con `w.sty`.
- Archivos
  - `Modules/Widgets/clock/ClockWidget.qml` → todos los bloques visuales y la lógica de hora/clima.
  - `Modules/Widgets/WidgetRegistry.qml` → entrada `clock`: lista de estilos, tamaños por estilo (`styleSizes`), valores por defecto por estilo (`styleDefaults`), opciones visibles por estilo (`styleOptions`).
  - `Modules/Widgets/WidgetConfig.qml` → aplica `styleDefaults` al crear el widget (`add`) y al cambiar de estilo (`setStyle`).
  - `Services/Lang/languages/LangEs.qml` y `LangEn.qml` → nombres `wgStyle_<estilo>` que ve el usuario en Ajustes.
- Estilos
  | estilo | familia | qué muestra |
  |---|---|---|
  | `digital` `minimal` `analog` `hybrid` `vertical` | originales | hora digital, esfera analógica, mixto y apilado |
  | `weather` `weathermini` | originales | hora + clima |
  | `serif` | serif | hora grande con AM/PM pequeño sobre la línea base, sin fondo |
  | `serifday` | serif | día de la semana en cursiva, hora grande y fecha en versalitas |
  | `serifstack` | serif | horas y minutos apilados, día + fecha + AM/PM en texto vertical lateral |
  | `serifcal` | serif | número del día enorme, con día de la semana, mes y hora al costado |
  | `serifshadow` | serif | hora serif semi-negrita, barra de acento, día y fecha, todo con sombra proyectada |
  | `pixel` | FusedIslands | tarjeta con borde de píxeles dispersos a ambos lados, destellos y cruces |
  | `floral` | FusedIslands | tarjeta redondeada con flores Sakura, línea de acento y destello |
- Estilos `pixel` y `floral`
  - `ClockWidget.qml` los delega en `FusedClock.qml` (propiedad `fusedStyle`); no usan `WidgetCard`, la tarjeta es propia y lleva `WidgetBlur`.
  - Archivos: `Modules/Widgets/clock/FusedClock.qml` y `Modules/Widgets/clock/parts/` (`PixelEdge`, `Sakura`, `Sparkle`).
  - Colores: solo `Theme.*`. `accent` = `primary`; `accent2` y `dayColor` mezclan `primary` con `text`; las flores aclaran `primary`. Cambian con cualquier paleta, manual o matugen.
  - Opciones: `seconds`, `date`, `hour24`, `fontFamily`, `background`, `bgOpacity`, `blur`. Nacen con `background: true` y `bgOpacity: 88`; tamaño 470 × 210.
  - Tipografía: la misma lista serif que los demás estilos (`serifFamily`).
  - No incluye el conejo del tema D.Va.
- Bloques de `ClockWidget.qml` (en orden)
  - `TimeText` → componente: hora grande + sufijo pequeño. Propiedades útiles: `family` (tipografía), `suffixTone` (color del sufijo), `ratio` (tamaño del sufijo respecto a la hora), `availW`/`maxH` (límites para autoajustar).
  - `Hand` y `AnalogFace` → manecilla y esfera, compartidas por `analog` y `hybrid`. `AnalogFace` deriva horas, minutos y segundos de `clk.date` (`hh`, `mm`, `ss`) para que las manecillas se muevan en cada tick del reloj.
  - `TextShadowFx` → componente: `MultiEffect` de sombra usado como `layer.effect` de los bloques serif. Propiedades: `dx`/`dy` (desplazamiento), `strength` (opacidad) y `spread` (difuminado). Con `darkText` cambia a un halo blanco muy tenue.
  - `WidgetCard` → fondo (se oculta con la opción `background`). En los estilos serif no llena la ventana: mide `fitW`/`fitH` (tamaño del contenido) más `padX`/`padY` y se centra, con tope en el tamaño de la ventana. El resto de estilos conserva la tarjeta a tamaño completo.
  - `SerifClock` → estilo `serif`.
  - `SerifDayClock` → estilo `serifday`.
  - `SerifStackClock` → estilo `serifstack`. El texto lateral es un `Text` rotado -90° dentro de un `Item` de ancho fijo; `fontSizeMode: Fit` lo encoge para que quepa.
  - `SerifCalendarClock` → estilo `serifcal`. La columna de la derecha toma el ancho que sobra tras el número del día.
  - `SerifShadowClock` → estilo `serifshadow`. La sombra es un `MultiEffect` aplicado como `layer.effect` al bloque completo; se desactiva con `Theme.shellPerf`. Para ajustarla: `shadowOpacity`, `shadowBlur` y los desplazamientos `shadowHorizontalOffset`/`shadowVerticalOffset`.
  - `CityBox` → editor de ciudad del clima.
- Ajuste de la tarjeta al contenido
  - Cada bloque serif expone un `id` que permite medir su contenido: `sfTime`, `sdDay`/`sdTime`/`sdDate`, `skRow`, `scRow` y `ssTime`/`ssDay`/`ssCol`. `fitW` y `fitH` eligen el que corresponde al estilo activo.
  - El contenido sigue escalando con el tamaño de la ventana (`availW`, `maxH`); la tarjeta solo se encoge alrededor de él. Si la ventana es mucho más grande que el texto, queda área transparente alrededor de la tarjeta.
  - Para más o menos aire, ajustar `padX` y `padY`.
  - `serifshadow` centra su contenido en la ventana como el resto de estilos serif (antes quedaba pegado a la izquierda).
- Estilos apilados (`vertical`, `serifstack`)
  - Horas y minutos usan el mismo tamaño de letra y la hora va siempre con dos dígitos (`hourPad`, por ejemplo `09`) para que ambas líneas queden alineadas. En `vertical` el tamaño sale de `TextMetrics` (`vtm`) y de la altura libre tras reservar AM/PM y fecha; entre las dos líneas hay una barra fina en lugar de los dos puntos.
- Formato 12/24 horas
  - `hourStr`, `minStr` y `apStr` se calculan desde `clock.date` (no con `Qt.formatTime`, donde `h` sin `AP` devuelve 24 h). Con `hour24` activo se muestra `HH:mm`; desactivado, la hora va de 1 a 12 sin cero inicial y el sufijo es `AM` o `PM`. `mainStr` y los estilos apilados (`vertical`, `serifstack`) usan estos valores.
- Actualización
  - El `SystemClock` avanza cada segundo cuando `tick` es verdadero (`seconds` activo, `analog` o `hybrid`) y cada minuto en el resto. El texto `:ss` solo aparece si la opción `seconds` está activa.
- Tamaños por defecto (serif)
  - `styleSizes` en `WidgetRegistry.qml`: `serif` 480×200, `serifday` 440×250, `serifstack` 340×225, `serifcal` 450×200, `serifshadow` 470×225. El texto escala con el tamaño de la ventana, así que estos valores fijan qué tan grande nace. Solo afectan a widgets nuevos o al cambiar de estilo; los ya guardados conservan su tamaño.
  - En `serifstack` el texto vertical (día y fecha) se encoge para caber en la altura de los números: por eso usa poco espaciado entre letras (`letterSpacing: 2`) y un separador corto.
- Fuente del reloj (serif)
  - Opción `fontFamily` (vacía = automática). En Ajustes aparece como un selector con buscador (`Settings/pages/WidgetFontPicker.qml`): cada fuente se muestra con su propio tipo, las serif sugeridas van primero y «Automática» devuelve al comportamiento por defecto.
  - `customFont` resuelve el nombre con `Theme.resolveFont`; si la fuente no existe en el equipo, `serifFamily` cae a la automática. Aplica a los cinco estilos serif.
  - La tarjeta ajustada al contenido se recalcula sola al cambiar de fuente.
- Tipografía serif
  - `serifFamily` usa `customFont` si está definida; si no, busca la primera instalada de: Playfair Display, Cormorant Garamond, Libre Baskerville, Noto Serif, DejaVu Serif; si no hay ninguna usa `serif` del sistema. Para cambiar el aspecto, instala una de esas fuentes o edita la lista en `serifFamily`.
- Legibilidad sin fondo (estilos serif)
  - Sin tarjeta el texto claro se pierde sobre wallpapers claros. Dos opciones lo resuelven; ambas solo actúan con `background` apagado (con tarjeta se ignoran).
  - `textShadow` (activa por defecto): contorno de sombra nítido sobre el texto. Aplica a `serif`, `serifday`, `serifstack` y `serifcal`. `serifshadow` ya lleva su propia sombra marcada y no muestra esta opción.
  - `darkText` (apagada por defecto): cambia el texto a tonos oscuros para wallpapers claros. Aplica a los cinco estilos serif. Los colores salen de `ink`, `inkSoft`, `accent` y `rule` en `ClockWidget.qml`; los bloques serif ya no leen `Theme.text`, `Theme.subtext` ni `Theme.primary` directamente.
  - `shadowOn` también se apaga con `Theme.shellPerf`.
- Opciones por estilo
  - `seconds` y `hour24`: aplican a todos los estilos serif (con `hour24` desactivado aparece AM/PM).
  - `date`: aplica a `serifday`, `serifstack` y `serifcal` (el día de la semana siempre se muestra).
  - `background`: los estilos serif nacen con `background: false` (texto sobre el fondo de pantalla). Se puede activar en Ajustes para dibujar la tarjeta.
  - `textShadow`: `serif`, `serifday`, `serifstack`, `serifcal`. `darkText`: los cinco estilos serif. Ambas se declaran en `defaults` y `styleOptions` de `WidgetRegistry.qml` y sus textos son `wgOpt_textShadow` y `wgOpt_darkText`.
- Valores por defecto por estilo (`styleDefaults`)
  - Al crear un widget o cambiar de estilo, las claves listadas en `styleDefaults` se reescriben con el valor del estilo nuevo. Al volver a un estilo sin entrada, esas claves regresan al valor de `defaults`.
- IPC (target `widgets`, ver WIDGETS.md)
  ```bash
  quickshell ipc -c OozeShell call widgets add clock serif
  quickshell ipc -c OozeShell call widgets add clock serifday
  quickshell ipc -c OozeShell call widgets style <id> serifstack
  quickshell ipc -c OozeShell call widgets option <id> hour24 false
  ```
- Cómo añadir otro estilo
  1. Añadirlo a `styles` y `styleSizes` en `WidgetRegistry.qml` (y a `styleDefaults`, `styleOptions` si aplica).
  2. Crear un bloque con `visible: w.sty === "<estilo>"` en `ClockWidget.qml`.
  3. Añadir `wgStyle_<estilo>` en `LangEs.qml` y `LangEn.qml`.

- Estilo `serifstack` y espacios laterales
  - Los dígitos y la etiqueta vertical tienen una proporción fija: si el widget es más ancho que su contenido, los lados quedan vacíos. `numPx` ahora se calcula con la altura de línea y el ancho medidos (`skm`), así que llena el eje que limite y no desborda. El tamaño por defecto pasó a 200 × 225.
  - `sk.numPx` → vigilar. Los coeficientes `hCoef` (−0.14 es el solape entre filas) y `labelW` (16 % de la altura) deben coincidir con `Column.spacing` y el ancho de la etiqueta; si se cambia uno, cambiar el otro.
  - Los widgets ya creados conservan su tamaño guardado: reducirlos a mano o volver a añadirlos.

