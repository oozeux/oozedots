# DOCK — barra de apps fijadas y abiertas

- Qué es: un panel por monitor (`Variants` sobre `Quickshell.screens`, namespace `quickshell-dock`) con las
  apps fijadas y las abiertas. Se pega al borde opuesto a la barra horizontal, o arriba/abajo si la barra es
  vertical (`Theme.dockEffectivePosition`). Clic activa/minimiza, clic central cierra, clic derecho abre el menú.
- Archivos:
  - `Modules/Dock/Dock.qml` → ventana, panel (`FusedPanel`), tooltip, menú y auto-hide
  - `Modules/Dock/DockBackend.qml` → singleton con las apps fijadas (`dockPins` en `StateStore`)
  - `Settings/pages/DockPage.qml` → ajustes (estado, posición, modo, tamaño, altura, opacidad, blur)

## Ajustes (`ui.toml`)

| Clave | Propiedad en `Theme` | Rango | Efecto |
|---|---|---|---|
| `dockEnabled` | `dockEnabled` | on/off | muestra el dock (`dockUsable` también exige que no haya marco curvo) |
| `dockAutoHide` | `dockAutoHide` | on/off | oculta el dock y libera la zona reservada |
| `dockMode` | `dockMode` | `panel` / `pill` | fusionado al borde o cápsula flotante con hueco (`dockFloatGap`, 3 px) |
| `dockScale` | `dockScalePercent` | 50–150 | escala iconos, celdas y ancho |
| `dockHeight` | `dockHeightPercent` | 85–160 | grosor de la barra; **no** escala los iconos |
| `dockOpacity` / `dockBlur` | `dockOpacity` / `dockBlur` | 0–100 | fondo y desenfoque del compositor |
| `dockOutline` | `dockOutline` | on/off (apagado) | contorno del dock |

Tamaño y altura son independientes: `pillHeight = 58 × dockScale × dockHeightFactor`. Con altura 100 % el
dock queda como antes. El mínimo de 85 % garantiza que la celda (`46 × dockScale`) siempre quepa dentro de la
barra; si se baja ese mínimo, los iconos se saldrán del panel.

## Con FusedIslands

- El dock toma el radio y la curva de las islas (`Theme.fusedRadius`, `Theme.fusedFlare`). Con Cristal usa `Theme.glassBg` y el blur del modo Cristal.
- Con `dockOutline` usa el mismo contorno que las islas (`Theme.primary` al 85 %, grosor `Theme.fusedStroke`); sin FusedIslands conserva `Theme.edge` como color; el grosor es siempre `Theme.fusedStroke`. Ver FUSEDISLANDS.md.

## Comportamientos

- **Zona reservada**: con auto-hide apagado el dock reserva espacio (`exclusiveZone`) y las ventanas no
  quedan debajo de él, también con el marco de esquinas activo. Con auto-hide encendido la zona es `-1` y el
  dock se encima a las apps al aparecer.
- **Contorno**: `FusedPanel` lo dibuja con un `ShapePath` propio sobre `outlinePath`, la misma forma del relleno. En modo `panel` el trazo queda abierto y no recorre el lado pegado al borde de la pantalla; en modo `pill` es cerrado. Como sale de `svgPath`, sigue al dock cuando crece (más apps, `dockScale`, `dockHeight`). Con Cozy no se dibuja: Cozy ya trae su borde de tinta.
- **Modo píldora sin contorno**: la cápsula no dibuja contorno por defecto, así que con opacidad 0 % no queda ningún trazo
  visible. El estilo `cozy` sigue dibujando su borde de tinta, porque lo decide `FusedPanel`.
- **Nueva ventana** (menú contextual): usa la acción `new-window` del `.desktop` si existe (Brave, Firefox,
  Nautilus…); si no, ejecuta la entrada normal. Apps de instancia única (p. ej. Discord) solo se enfocan.

## Puntos a vigilar

- `exclusiveZone` / `reserveZone` (`Dock.qml`): la zona incluye `handleHeight + clearance − gapsOut` para dejar
  aire bajo las ventanas. Si cambias los `gapsOut` del compositor o la altura, revisa que ese aire no quede
  negativo (ya se limita con `Math.max(0, …)`) ni se duplique con el hueco del compositor.
- `newWindow()` (`Dock.qml`): depende del `id` de la acción en el `.desktop`. Es el lugar a ampliar si una app
  usa otro nombre (`new_window`, `NewWindow` ya se aceptan; variantes como `open-new-window` no).
- `implicitHeight` (`Dock.qml`): suma `pillHeight` y los márgenes de tooltip/menú. Si la altura máxima sube
  mucho, el tooltip (`maxDepth`) se recorta antes que el panel crezca; ajusta `tipAllowance` en ese caso.
- `dockUsable` (`Theme.qml`): oculta el dock con el marco curvo; no lo reutilices para decidir la zona
  reservada, que depende solo de `dockAutoHide`.
- `dockFloatGap` (`Theme.qml`): separación entre la cápsula y el borde de la pantalla en modo `pill`. Es 3 px; antes era 8 px. Alimenta `restGap` en `Dock.qml`, que a su vez mueve el panel (`faceOffset`), agranda la ventana (`implicitHeight`) y suma a la zona reservada (`exclusiveZone`), así que las ventanas también quedan 5 px más abajo.
