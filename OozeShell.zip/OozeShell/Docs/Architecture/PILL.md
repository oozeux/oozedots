# PILL — barra minimalista del modo píldora

- Qué es: la superficie que sustituye a la barra cuando `Theme.pillMode` está activo. Una `Pill` por
  monitor (`Variants` sobre `Quickshell.screens`, namespace `oozeshell-pill`) que hospeda las opciones,
  el `Dashboard`, el reloj, los controles MPRIS, el indicador de notificaciones, la taskbar, la bandeja
  del sistema y los indicadores de workspaces. Gestiona auto-hide, zona de disparo y foco de teclado.
- Flujo en dos pasos: **píldora → dashboard**. Clic en el reloj abre el dashboard en la última sección
  usada (otro clic lo cierra); la píldora se transforma en el panel y viceversa con una sola superficie.
  Se cambia de sección con el pager de la cabecera (`DashboardPager`), arrastrando o con el teclado.
  Cerrar: `Esc`, el botón ✕ de la cabecera o clic fuera.
- Atajos: clic en la píldora de música abre `mpris`, clic derecho en el reloj abre `calendar` y los IPC
  (`menu`, `audio`, `agenda`, `mpris`, `powermenu`, `dashboard`) abren su sección directo. Repetir el IPC de
  la sección visible la cierra.
- Archivos:
  - `Modules/Pill/Pill.qml` → barra/píldora por monitor; hospeda `Modules/Dashboard/Dashboard.qml`,
    taskbar, reloj y bandeja; administra auto-hide, foco de teclado y el tamaño de la superficie
  - `Modules/Pill/PillClock.qml` → reloj; usa el estilo de `Theme.barClockStyle` vía `COMMON/ClockFace.qml` (ver BAR.md)
  - `Modules/Pill/PillMedia.qml` → controles MPRIS compactos (lee `Services/Mpris/MprisBackend.qml`)
  - `Modules/Pill/PillNotifications.qml` → indicador y lista de notificaciones de la píldora
  - `Modules/Pill/PillTaskbar.qml` → taskbar (reexporta `Modules/Taskbar/TaskbarList.qml`)
  - `Modules/Pill/PillTray.qml` → bandeja del sistema (`Modules/Tray/TrayMenuList.qml`)
  - `Modules/Pill/PillWorkspaces.qml` / `PillWorkspacesSide.qml` → indicadores de workspaces (el lateral
    usa el namespace `oozeshell-pill-workspaces`)
- IPC: sin target propio. Se interactúa con la píldora a través de los targets que redirigen según el
  modo: `menu toggle` (abre la sección `quickaccess` del dashboard), `notify toggle` (lista de avisos de
  la píldora), `audio`, `agenda`, `mpris`, `performance` y `powermenu`. Ver SHELL.md para la
  tabla completa y DASHBOARD.md para el mapa de secciones por modo.
- Estado y datos: `COMMON/AppState.qml` (`dashboardOpen`, `dashboardScreen`, `dashboardSection`,
  `pillLayerOpen`, `pillAutoHide`, `pillHiddenNow`,
  `pillTraySync`, `trayVisible`). Ojo: las notificaciones de la píldora usan su propio
  `notifyOpen`/`notifyScreen` locales, no el centro de notificaciones de la barra.
- Dependencias: `COMMON` (AppState, WM, Theme), `Services/Lang`, `Modules/Taskbar`, `Modules/Tray`,
  `Modules/Dashboard`, `Services/Notify` y `Services/Mpris` (solo `PillMedia.qml`).
- Notas: con `pillAutoHide` la píldora se oculta y deja una zona de disparo (`triggerH`); `reserveZone`
  compensa `AppState.gapsOut`. La sección de avisos del dashboard no existe en este modo (ver
  DASHBOARD.md) precisamente porque la píldora ya trae la suya.

## Puntos a vigilar

- **Fórmula de tamaño de `surface` (`Pill.qml`)**: `width`/`height` suman dos términos (`progress` panel y `mp` menús) que interpolan desde el tamaño de la píldora; con `progress = 1` el resultado es exactamente el del panel. Un nivel nuevo exige un término propio que reste el anterior. También afecta a `pillT`, `dashT` y `menuT`.
- **Quién cierra qué (`AppState`)**: `closeDashboard()` es la única vía de cierre (`shell.qml`, IPC, secciones, `Esc`). Los guardas de `shell.qml` usan `pillLayerOpen`. Un IPC de sección repetido (`audio`, `agenda`, `dashboard`) cierra el panel también en modo píldora: `closeAllPopupsExceptAdvanced` no lo cierra en este modo, por eso `togglePopup` llama a `closeDashboard()` explícitamente.
- **Teclado**: con el panel abierto la capa pide foco `Exclusive` (con `OnDemand` Hyprland no lo entrega si no hubo clic y `Esc` no llegaba); los menús de la píldora siguen en `OnDemand`.
- **Transición píldora ↔ panel (`surface.flow`)**: los fundidos (`pillT`, `dashT`) se calculan con `flow` (`InOutCubic` 480 ms al abrir, `InOutQuad` 260 ms al cerrar), no con `progress`, que tiene rebote `OutBack`. `progress` solo mueve la geometría. El panel no se desplaza ni escala: queda anclado al borde y la superficie lo revela al crecer, para que parezca la misma pieza.
- **Orden al cerrar**: primero se desvanece el panel (`flow`) y, tras 150 ms (`PauseAnimation` en `progress`), la superficie se encoge hasta la píldora. Si la geometría encogiera a la vez, el panel se vería recortado.
- **Altura por sección (`Dashboard.knownHeights`)**: recuerda la altura de cada sección cargada, así al abrir o saltar a una sección ya vista la superficie crece directo a su tamaño final y no corrige tras la carga.
- **Pager (`Dashboard.qml`)**: el arrastre vive en el propio `Dashboard` (`MouseArea` con `z: -1`), solo se activa en zonas libres y no da la vuelta (`stepClamped`). El desplazamiento del arrastre se aplica a las dos ranuras para que el cruce no salte al soltar. El indicador de `DashboardPager` estira primero el borde de avance.
- **Memoria en reposo**: con «Paneles bajo demanda» el `Dashboard` de la píldora no se destruye (vive en `Pill.qml`); solo se descargan sus secciones. La precarga al pasar el cursor (`noteHover`) se desactiva con «Paneles bajo demanda» y con el modo performance. 5 s después de cerrar se llama a `Theme.trimMemory()` (`trimTimer`), y `shell.qml` lo repite 2,5 s después de activar o desactivar cualquiera de los dos modos.
