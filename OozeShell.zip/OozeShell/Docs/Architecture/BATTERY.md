# BATTERY — indicador de batería

- Qué es: estado de la batería (UPower) y su indicador en la barra, la píldora, el Dashboard y la pantalla de bloqueo. Solo aparece en equipos con batería y con "Mostrar batería" activo.
- Archivos (`Services/Battery/`):
  - `BatteryBackend.qml` → singleton con `available`, `percentage` (0–1), `charging`, `fullyCharged`, `isLow`, tiempos y `formatSecs()`.
  - `BatteryIcon.qml` → icono de pila clásico (con o sin número dentro); lo usan Dashboard, Power, Lock y la píldora.
  - `BatteryBarIcon.qml` → variantes del módulo de la barra, elegidas con `batteryStyle`.
- Estilos de la barra (Ajustes → Barra → Batería): `classic` (pila grande con número), `compact` (pila pequeña + %), `glyph` (icono de fuente + %), `ring` (anillo de progreso), `bar` (barra fina). El interruptor "Mostrar porcentaje" aplica a todos menos `classic`. Por defecto `compact`.
- Estado: `batteryStyle` y `batteryPercent` en `Theme`, guardados en `ui.toml`.
- Colores: error con carga baja (≤20 % sin cargar), primario al cargar o completa, texto normal en el resto.
- Integración: `Modules/Bar/modules/BatteryModule.qml` (tooltip con estado y tiempo restante); en barra vertical el % va debajo.
