# Tools/online-resolve.sh
set -u
LINK="${2:-}"; FALLBACK="${3:-}"
UA="Mozilla/5.0 (X11; Linux x86_64; rv:130.0) Gecko/20100101 Firefox/130.0"
PREVIEW_RE='preview|sample|thumb|poster'
[ -n "$LINK" ] || exit 1
BASE=$(printf '%s' "$LINK" | sed -E 's#^(https?://[^/]+).*#\1#')

# ─── Utilidades ───

absurl() {
  case "$1" in
    "") ;;
    //*) printf 'https:%s' "$1" ;;
    /*) printf '%s%s' "$BASE" "$1" ;;
    http*) printf '%s' "$1" ;;
    *) printf '%s/%s' "$BASE" "$1" ;;
  esac
}

reso() {
  l="$1"
  r='(^|[^0-9])4320([^0-9]|$)|(^|[^a-z0-9])8k([^a-z0-9]|$)'
  [[ $l =~ $r ]] && { echo 4320; return; }
  r='(^|[^0-9])(2160|3840)([^0-9]|$)|(^|[^a-z0-9])4k([^a-z0-9]|$)'
  [[ $l =~ $r ]] && { echo 2160; return; }
  r='(^|[^0-9])(1440|2560)([^0-9]|$)'
  [[ $l =~ $r ]] && { echo 1440; return; }
  r='(^|[^0-9])(1080|1920)([^0-9]|$)'
  [[ $l =~ $r ]] && { echo 1080; return; }
  r='(^|[^0-9])(720|1280)([^0-9]|$)'
  [[ $l =~ $r ]] && { echo 720; return; }
  echo 0
}

probe() {
  u="$1"
  hdr=$(curl -sL -r 0-0 --max-filesize 2048 -m 15 --connect-timeout 6 -A "$UA" -e "$BASE/" -D - -o /dev/null "$u" 2>/dev/null | tr -d '\r')
  ct=$(printf '%s\n' "$hdr" | grep -i '^content-type:' | tail -1 | tr 'A-Z' 'a-z')
  len=$(printf '%s\n' "$hdr" | grep -i '^content-range:' | tail -1 | sed -E 's#.*/##' | tr -dc '0-9')
  [ -n "$len" ] || len=$(printf '%s\n' "$hdr" | grep -i '^content-length:' | tail -1 | tr -dc '0-9')
  case "$ct" in *video/*|*octet-stream*|*binary*|*force-download*|*zip*) ;; *) return ;; esac
  l=$(printf '%s' "$u" | tr 'A-Z' 'a-z')
  kind=file
  case "$ct" in *zip*) kind=zip ;; esac
  case "${l%%\?*}" in *.zip) kind=zip ;; esac
  case "$l" in *.mp4*|*.webm*|*.mkv*|*.mov*|*.zip*) ;; *) [ "${len:-0}" -gt 1000000 ] || return ;; esac
  printf '%s\t%s\t%s\t%s\n' "$(reso "$l")" "${len:-0}" "$u" "$kind"
}
export -f reso probe
export UA BASE

pick() {
  printf '%s\n' "$1" | grep -v '^$' | xargs -r -P 6 -n1 bash -c 'probe "$1"' _ | sort -t$'\t' -k1,1nr -k2,2nr | head -1
}

# ─── Página del post ───

HF=$(mktemp)
trap 'rm -f "$HF"' EXIT
CODE=$(curl -sSL --compressed -m 25 --connect-timeout 8 -A "$UA" -e "$BASE/" \
  -H 'Accept: text/html,application/xhtml+xml,*/*;q=0.8' -H 'Accept-Language: en-US,en;q=0.5' \
  -o "$HF" -w '%{http_code}' "$LINK" 2>/dev/null) || CODE=000
[ "$CODE" = 200 ] || echo "resolve: pagina http $CODE en $LINK" >&2
grep -qiE 'just a moment|cf-chl|challenge-platform|cf-browser-verification' "$HF" \
  && echo "resolve: el sitio devolvio un desafio anti-bot en lugar de la pagina" >&2
HTML=$(sed 's#\\/#/#g; s/&amp;/\&/g' "$HF")

# ─── Candidatos ───

SQ="'"
ALL=$({
  printf '%s\n' "$FALLBACK"
  printf '%s' "$HTML" | grep -oE "[\"$SQ(=][^\"$SQ <>()\\\\]+\\.(mp4|webm|zip)([?][^\"$SQ <>()\\\\]*)?" | sed -E "s/^[\"$SQ(=]//"
  printf '%s' "$HTML" | grep -oE "href=[\"$SQ][^\"$SQ]*(download|/dl/|dl=|\\.zip)[^\"$SQ]*[\"$SQ]" | sed -E "s/^href=[\"$SQ]//; s/[\"$SQ]\$//"
} | grep -v '^$' | while read -r u; do absurl "$u"; echo; done | grep -v '^$' | awk '!s[$0]++')

CANDS=$(printf '%s\n' "$ALL" | grep -viE "$PREVIEW_RE" | head -12)
echo "resolve: $(printf '%s\n' "$CANDS" | grep -vc '^$') candidatos de $(printf '%s\n' "$ALL" | grep -vc '^$') encontrados" >&2

BEST=$(pick "$CANDS")
if [ -z "$BEST" ]; then
  BEST=$(pick "$(printf '%s\n' "$ALL" | head -12)")
  [ -n "$BEST" ] && echo "resolve: solo hay vista previa disponible, se usara esa" >&2
fi

if [ -n "$BEST" ]; then
  printf '%s\t%s\t%s\n' "$(printf '%s' "$BEST" | cut -f3)" "$(printf '%s' "$BEST" | cut -f2)" "$(printf '%s' "$BEST" | cut -f4)"
  exit 0
fi
case "${FALLBACK%%\?*}" in
  *.mp4|*.webm|*.mkv|*.mov) printf '%s\t0\n' "$FALLBACK" ;;
esac
exit 0
