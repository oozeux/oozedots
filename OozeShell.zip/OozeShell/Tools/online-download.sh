# Tools/online-download.sh
set -u
SRC="${1:-}"; URL="${2:-}"; DEST="${3:-}"; PAGE="${4:-}"; REF="${5:-}"
[ -n "$URL" ] && [ -n "$DEST" ] || { echo "uso: $0 FUENTE URL DESTINO [PAGINA] [REFERER]" >&2; exit 1; }
HERE=$(dirname "$(readlink -f "$0")")
UA="Mozilla/5.0 (X11; Linux x86_64; rv:130.0) Gecko/20100101 Firefox/130.0"
LEN=0
KIND=file

if [ -n "$PAGE" ]; then
  R=$(bash "$HERE/online-resolve.sh" "$SRC" "$PAGE" "$URL")
  if [ -n "$R" ]; then
    URL=$(printf '%s' "$R" | cut -f1)
    LEN=$(printf '%s' "$R" | cut -f2)
    KIND=$(printf '%s' "$R" | cut -f3)
  fi
fi
case "$LEN" in ''|*[!0-9]*) LEN=0 ;; esac
case "${URL%%\?*}" in
  *.mp4|*.webm|*.mkv|*.mov|*.zip) ;;
  *) [ "$LEN" -gt 0 ] || { echo "sin video en $URL" >&2; exit 1; } ;;
esac

mkdir -p "$(dirname "$DEST")"
if [ -s "$DEST" ]; then
  HAVE=$(stat -c %s "$DEST")
  if [ "$LEN" -eq 0 ] || [ "$HAVE" -ge "$LEN" ] || [ "$KIND" = zip ]; then echo "$DEST"; exit 0; fi
fi

PART="$DEST.part"
OK=1
if command -v aria2c >/dev/null; then
  aria2c -q -x8 -s8 -k2M -c --allow-overwrite=true --user-agent="$UA" ${REF:+--referer="$REF"} \
    -d "$(dirname "$PART")" -o "$(basename "$PART")" "$URL" && OK=0
fi
if [ "$OK" -ne 0 ]; then
  curl -fL --retry 4 --retry-delay 2 --retry-all-errors --connect-timeout 10 \
    --speed-limit 20000 --speed-time 45 -C - -A "$UA" ${REF:+-e "$REF"} -o "$PART" "$URL" && OK=0
fi
if [ "$OK" -ne 0 ]; then
  rm -f "$PART"
  curl -fL --retry 2 --connect-timeout 10 --speed-limit 20000 --speed-time 45 \
    -A "$UA" ${REF:+-e "$REF"} -o "$PART" "$URL" && OK=0
fi
[ "$OK" -eq 0 ] && [ -s "$PART" ] || { rm -f "$PART"; exit 1; }

# ─── ZIP ───

if [ "$(head -c2 "$PART" | tr -d '\0')" = "PK" ]; then
  python3 - "$PART" "$DEST.tmp" <<'PY' || { rm -f "$PART" "$DEST.tmp"; echo "download: el ZIP no contiene video" >&2; exit 1; }
import shutil, sys, zipfile
z = zipfile.ZipFile(sys.argv[1])
vids = [i for i in z.infolist() if i.filename.lower().endswith((".mp4", ".webm", ".mkv", ".mov")) and not i.is_dir()]
if not vids:
    sys.exit(1)
best = max(vids, key=lambda i: i.file_size)
with z.open(best) as src, open(sys.argv[2], "wb") as dst:
    shutil.copyfileobj(src, dst)
PY
  rm -f "$PART"
  mv -f "$DEST.tmp" "$DEST"
else
  mv -f "$PART" "$DEST"
fi

# ─── Resolución ───

if command -v ffprobe >/dev/null; then
  H=$(ffprobe -v error -select_streams v:0 -show_entries stream=height -of csv=p=0 "$DEST" 2>/dev/null | head -1)
  case "$H" in ''|*[!0-9]*) H=0 ;; esac
  echo "download: resolucion ${H}p" >&2
  if [ "${OOZE_LIVE_RES:-any}" = 4k ] && [ "$H" -gt 0 ] && [ "$H" -lt 2160 ]; then
    echo "download: el sitio no ofrecio 4K para este wallpaper" >&2
  fi
fi
echo "$DEST"
