// WsPath.qml — COMMON

import QtQuick
import QtQuick.Layouts

WsBase {
  id: root

  readonly property real along: 22
  readonly property real face: 18
  readonly property real lineThick: 2
  readonly property color lineColor: Qt.alpha(root.accent, 0.45)

  implicitWidth: root.vertical ? root.face : grid.implicitWidth
  implicitHeight: root.vertical ? grid.implicitHeight : root.face

  // ─── Nodos ───
  GridLayout {
    id: grid
    anchors.centerIn: parent
    flow: root.vertical ? GridLayout.LeftToRight : GridLayout.TopToBottom
    columns: root.vertical ? 1 : -1
    rows: root.vertical ? -1 : 1
    columnSpacing: 0
    rowSpacing: 0

    Repeater {
      model: root.items
      delegate: Item {
        id: cell
        required property var modelData
        required property int index
        readonly property bool isActive: !!cell.modelData.active
        readonly property bool isUrgent: !!cell.modelData.urgent && !cell.isActive
        readonly property bool hot: area.containsMouse
        property real node: cell.isActive ? 12 : 10
        readonly property real reach: root.along / 2 - cell.node / 2 - 1
        readonly property color tone: cell.isUrgent ? Theme.error : root.accent

        Layout.preferredWidth: root.vertical ? root.face : root.along
        Layout.preferredHeight: root.vertical ? root.along : root.face
        Behavior on node { NumberAnimation { duration: Theme.animDuration(180); easing.type: Easing.OutCubic } }

        Rectangle {
          visible: cell.index > 0
          x: root.vertical ? (cell.width - root.lineThick) / 2 : 0
          y: root.vertical ? 0 : (cell.height - root.lineThick) / 2
          width: root.vertical ? root.lineThick : cell.reach
          height: root.vertical ? cell.reach : root.lineThick
          color: root.lineColor
        }

        Rectangle {
          visible: cell.index < root.count - 1
          x: root.vertical ? (cell.width - root.lineThick) / 2 : root.along - cell.reach
          y: root.vertical ? root.along - cell.reach : (cell.height - root.lineThick) / 2
          width: root.vertical ? root.lineThick : cell.reach
          height: root.vertical ? cell.reach : root.lineThick
          color: root.lineColor
        }

        Rectangle {
          visible: cell.isActive && !Theme.cozy
          anchors.centerIn: parent
          width: cell.node + 8
          height: cell.node + 8
          radius: Theme.rad(width / 2)
          color: root.accent
          opacity: 0.25
        }

        Rectangle {
          anchors.centerIn: parent
          width: cell.node
          height: cell.node
          radius: Theme.rad(width / 2)
          color: (cell.isActive || cell.isUrgent) ? cell.tone : "transparent"
          border.width: (cell.isActive || cell.isUrgent) ? 0 : 1.5
          border.color: cell.hot ? root.accent : Qt.alpha(root.accent, 0.55)
          Behavior on color { ColorAnimation { duration: Theme.animDuration(150) } }
        }

        MouseArea {
          id: area
          anchors.fill: parent
          hoverEnabled: true
          cursorShape: Qt.PointingHandCursor
          onClicked: WM.clickWorkspace(cell.modelData)
        }
      }
    }
  }
}
