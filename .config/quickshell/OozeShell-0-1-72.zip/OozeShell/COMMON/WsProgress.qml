// WsProgress.qml — COMMON

import QtQuick

WsBase {
  id: root

  readonly property real cellLen: 14
  readonly property real thick: 10
  readonly property real face: 16
  readonly property real trackLen: Math.max(1, root.count) * root.cellLen

  implicitWidth: root.vertical ? root.face : root.trackLen
  implicitHeight: root.vertical ? root.trackLen : root.face

  // ─── Pista ───
  Rectangle {
    id: track
    anchors.centerIn: parent
    width: root.vertical ? root.thick : root.trackLen
    height: root.vertical ? root.trackLen : root.thick
    radius: Theme.rad(root.thick / 2)
    color: Qt.alpha(Theme.subtext, 0.16)
    border.width: 1
    border.color: Qt.alpha(Theme.subtext, 0.3)
  }

  // ─── Marcas ───
  Repeater {
    model: Math.max(0, root.count - 1)
    delegate: Rectangle {
      required property int index
      x: root.vertical ? (root.width - width) / 2 : (index + 1) * root.cellLen - width / 2
      y: root.vertical ? (index + 1) * root.cellLen - height / 2 : (root.height - height) / 2
      width: root.vertical ? 4 : 1
      height: root.vertical ? 1 : 4
      color: Qt.alpha(Theme.subtext, 0.5)
    }
  }

  // ─── Cursor ───
  Rectangle {
    id: thumb
    visible: root.activeIndex >= 0
    readonly property real pos: Math.max(0, root.activeIndex) * root.cellLen + 1
    readonly property real len: root.cellLen - 2
    x: root.vertical ? (root.width - width) / 2 : thumb.pos
    y: root.vertical ? thumb.pos : (root.height - height) / 2
    width: root.vertical ? root.thick - 2 : thumb.len
    height: root.vertical ? thumb.len : root.thick - 2
    radius: Theme.rad((root.thick - 2) / 2)
    color: root.accent
    Behavior on x { NumberAnimation { duration: Theme.animDuration(220); easing.type: Easing.OutCubic } }
    Behavior on y { NumberAnimation { duration: Theme.animDuration(220); easing.type: Easing.OutCubic } }
    Behavior on color { ColorAnimation { duration: Theme.animDuration(150) } }
  }

  // ─── Tramos ───
  Repeater {
    model: root.items
    delegate: Item {
      id: seg
      required property var modelData
      required property int index
      readonly property bool isUrgent: !!seg.modelData.urgent && !seg.modelData.active
      readonly property bool hot: segArea.containsMouse

      x: root.vertical ? (root.width - width) / 2 : seg.index * root.cellLen
      y: root.vertical ? seg.index * root.cellLen : (root.height - height) / 2
      width: root.vertical ? root.face : root.cellLen
      height: root.vertical ? root.cellLen : root.face

      Rectangle {
        anchors.centerIn: parent
        width: root.vertical ? root.thick - 2 : parent.width - 2
        height: root.vertical ? parent.height - 2 : root.thick - 2
        radius: Theme.rad((root.thick - 2) / 2)
        color: Qt.alpha(Theme.text, 0.14)
        visible: seg.hot && !seg.modelData.active
      }

      Rectangle {
        anchors.centerIn: parent
        width: 4
        height: 4
        radius: Theme.rad(2)
        color: Theme.error
        visible: seg.isUrgent
      }

      MouseArea {
        id: segArea
        anchors.fill: parent
        hoverEnabled: true
        cursorShape: Qt.PointingHandCursor
        onClicked: WM.clickWorkspace(seg.modelData)
      }
    }
  }
}
