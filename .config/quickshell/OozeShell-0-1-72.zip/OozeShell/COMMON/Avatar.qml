// Avatar — foto de perfil circular. Si no hay imagen (o todavía carga), muestra un círculo del color primario con la inicial.

import QtQuick
import QtQuick.Effects

Item {
  id: root

  property real size: 46

  property string source: ""
  property string letter: "?"

  implicitWidth: size
  implicitHeight: size
  width: size
  height: size


  Rectangle {
    anchors.fill: parent
    radius: Theme.rad(Theme.cozy ? 6 : width / 2)
    color: Theme.primary
    visible: img.status !== Image.Ready

    Text {
      anchors.centerIn: parent
      text: root.letter
      color: Theme.textOnPrimary
      font.pixelSize: Theme.fs(Math.round(root.size * 0.43))
      font.bold: true
      font.family: Theme.fontFamily
    }
  }


  Item {
    id: photo
    anchors.fill: parent
    opacity: img.status === Image.Ready ? 1 : 0
    Behavior on opacity { NumberAnimation { duration: Theme.animDuration(180) } }

    layer.enabled: img.status === Image.Ready
    layer.effect: MultiEffect {
      maskEnabled: true
      maskSource: circleMask
      maskThresholdMin: 0.5
      maskSpreadAtMin: 1.0
    }

    Image {
      id: img
      anchors.fill: parent
      source: root.source
      fillMode: Image.PreserveAspectCrop
      asynchronous: true
      smooth: true


      mipmap: false

      sourceSize: Qt.size(Math.ceil(root.size * 3), Math.ceil(root.size * 3))
    }
  }

  Item {
    id: circleMask
    anchors.fill: parent
    layer.enabled: img.status === Image.Ready
    visible: false

    Rectangle {
      anchors.fill: parent
      radius: Theme.rad(Theme.cozy ? 6 : width / 2)
      color: "black"
    }
  }
}
