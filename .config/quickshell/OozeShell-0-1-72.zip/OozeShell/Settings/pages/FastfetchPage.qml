import Quickshell
import QtQuick
import QtQuick.Layouts
import ".."
import "../../COMMON"
import "../../Services/Lang"
import "../../Services/Terminal"

SettingsPage {
  id: page
  catId: "fastfetch"

  property bool browsing: false
  property bool previewOpen: false
  property bool ansiOpen: false

  readonly property bool scriptReady: TerminalConfig.fastfetch.scriptFound === true
  readonly property bool hookReady: TerminalConfig.fastfetch.zshrcHook === true
  readonly property bool usesImages: FastfetchConfig.source === "images"
  readonly property bool usesBuiltin: FastfetchConfig.source === "builtin"
  readonly property bool hasType: page.usesImages || page.usesBuiltin
  readonly property bool pageActive: page.active

  // ─── Estado ──────────────────────────────────────────────────────

  Component.onCompleted: {
    TerminalConfig.refresh()
    FastfetchConfig.ensure()
  }
  onPageActiveChanged: if (page.pageActive) refreshTimer.restart()
  onBrowsingChanged: { if (page.browsing) imageBrowser.go(imageBrowser.home + "/Pictures") }
  onPreviewOpenChanged: if (page.previewOpen) FastfetchConfig.refreshPreview(false)

  Timer {
    id: refreshTimer
    interval: 400
    onTriggered: FastfetchConfig.refreshPresets()
  }
  Connections {
    target: FastfetchConfig
    enabled: page.previewOpen
    function onStyleChanged() { FastfetchConfig.refreshPreview(false) }
  }

  // ─── Funciones ───────────────────────────────────────────────────

  function errorMessage(code) {
    if (code === "tool") return Translations.t("termErrTool")
    if (code.indexOf("io:") === 0) return Translations.t("termErrIo")
    if (code === "unsupported") return Translations.t("termErrUnsupported")
    return Translations.t("termErrGeneric") + " (" + code + ")"
  }
  function typeLabel(t) {
    return t === "detect" ? Translations.t("termFfTypeDetect") : t
  }
  function typeHint(t) {
    return Translations.t("termFfT_" + t.replace(/-/g, "_"))
  }
  function pickImage(name) {
    TerminalConfig.useImage(name)
    if (TerminalConfig.fastfetchRandom) TerminalConfig.setRandom(false)
  }
  function testFastfetch() {
    const script = "\"$HOME/.local/bin/random-fastfetch\" --force; exec \"${SHELL:-bash}\""
    Quickshell.execDetached(Theme.terminalCmd.concat(["bash", "-c", script]))
  }

  // ─── Componentes ─────────────────────────────────────────────────

  component Cycler: RowLayout {
    id: cy

    property var values: []
    property string current: ""
    property var labelOf: v => String(v)
    readonly property int count: cy.values.length
    readonly property int index: Math.max(0, cy.values.indexOf(cy.current))

    signal picked(var value)

    Layout.fillWidth: false
    spacing: 6

    SettingsBtn {
      Layout.preferredHeight: 42
      Layout.preferredWidth: 46
      icon: "󰅁"
      text: ""
      enabled: cy.count > 1
      onClicked: cy.picked(cy.values[(cy.index - 1 + cy.count) % cy.count])
    }
    SkinRect {
      Layout.preferredWidth: 170
      Layout.preferredHeight: 42
      radius: Theme.rad(Theme.cozy ? 4 : 11)
      color: Theme.cozy ? Theme.bg : MdTokens.control
      border.width: Theme.cozy ? Theme.bw1 : 1
      border.color: Theme.cozy ? Theme.edge : MdTokens.controlEdge

      Text {
        anchors.fill: parent
        anchors.leftMargin: 8
        anchors.rightMargin: 8
        horizontalAlignment: Text.AlignHCenter
        verticalAlignment: Text.AlignVCenter
        elide: Text.ElideRight
        text: cy.count > 0 ? cy.labelOf(cy.values[cy.index]) : ""
        color: Theme.text
        font.bold: true
        font.pixelSize: Theme.sfs(12)
        font.family: Theme.fontFamily
      }
    }
    SettingsBtn {
      Layout.preferredHeight: 42
      Layout.preferredWidth: 46
      icon: "󰅂"
      text: ""
      enabled: cy.count > 1
      onClicked: cy.picked(cy.values[(cy.index + 1) % cy.count])
    }
  }

  component ImageCell: Item {
    id: cell
    required property string name
    readonly property bool picked: !TerminalConfig.fastfetchRandom && TerminalConfig.fastfetchImage === cell.name

    width: 92
    height: 92

    SkinRect {
      anchors.fill: parent
      anchors.margins: 3
      radius: Theme.rad(10)
      clip: true
      color: Theme.surface

      Image {
        anchors.fill: parent
        source: TerminalConfig.imageUrl(cell.name)
        sourceSize: Qt.size(184, 184)
        fillMode: Image.PreserveAspectCrop
        asynchronous: true
        smooth: true
        opacity: status === Image.Ready ? 1 : 0
        Behavior on opacity { NumberAnimation { duration: Theme.animDuration(150) } }
      }

      MouseArea {
        id: pickArea
        anchors.fill: parent
        hoverEnabled: true
        cursorShape: Qt.PointingHandCursor
        onClicked: page.pickImage(cell.name)
      }

      Rectangle {
        anchors.fill: parent
        radius: Theme.rad(10)
        color: "transparent"
        border.width: cell.picked ? 2 : 0
        border.color: Theme.primary
      }

      Rectangle {
        visible: cell.picked
        anchors { left: parent.left; bottom: parent.bottom; margins: 5 }
        width: 20
        height: 20
        radius: Theme.rad(10)
        color: Theme.primary

        Text {
          anchors.centerIn: parent
          text: "󰄬"
          color: Theme.textOnPrimary
          font.pixelSize: Theme.sfs(12)
          font.family: Theme.monoFamily
        }
      }

      Rectangle {
        visible: pickArea.containsMouse || delArea.containsMouse
        anchors { right: parent.right; top: parent.top; margins: 5 }
        width: 24
        height: 24
        radius: Theme.rad(12)
        color: Qt.alpha(Theme.bg, 0.78)

        Text {
          anchors.centerIn: parent
          text: "󰆴"
          color: Theme.error
          font.pixelSize: Theme.sfs(13)
          font.family: Theme.monoFamily
        }

        MouseArea {
          id: delArea
          anchors.fill: parent
          hoverEnabled: true
          cursorShape: Qt.PointingHandCursor
          onClicked: TerminalConfig.removeImage(cell.name)
        }
      }
    }
  }

  // ─── Aviso de error ──────────────────────────────────────────────

  SettingsNote {
    visible: TerminalConfig.lastError !== ""
    kind: "error"
    text: page.errorMessage(TerminalConfig.lastError)
  }

  // ─── Fastfetch ───────────────────────────────────────────────────

  SettingsSection {
    titleKey: "termFastfetchTitle"
    hintKey: "termFastfetchHint"

    SettingsNote {
      visible: TerminalConfig.loaded && !page.scriptReady
      kind: "warn"
      text: Translations.t("termFastfetchNoScript")
    }

    SettingsNote {
      visible: TerminalConfig.loaded && page.scriptReady && !page.hookReady
      kind: "warn"
      text: Translations.t("termFastfetchNoHook")
    }

    SettingsRow {
      titleKey: "termFastfetchEnable"
      hintKey: "termFastfetchEnableHint"

      SettingsSwitch {
        checked: TerminalConfig.fastfetchEnabled
        onToggled: TerminalConfig.setFastfetch(!TerminalConfig.fastfetchEnabled)
      }
    }

    SettingsRow {
      titleKey: "termFfTest"
      hintKey: "termFfTestHint"
      divider: false

      SettingsBtn {
        icon: "󰐊"
        text: Translations.t("termFastfetchTest")
        primary: true
        enabled: page.scriptReady
        onClicked: page.testFastfetch()
      }
    }
  }

  // ─── Logo ────────────────────────────────────────────────────────

  SettingsSection {
    titleKey: "termFfLogoTitle"
    enabled: TerminalConfig.fastfetchEnabled
    opacity: TerminalConfig.fastfetchEnabled ? 1 : 0.45

    SettingsRow {
      titleKey: "termFfSource"
      stacked: true

      SettingsChoice {
        model: [
          { value: "images",  label: Translations.t("termFfSrcImages") },
          { value: "builtin", label: Translations.t("termFfSrcBuiltin") },
          { value: "ansi",    label: Translations.t("termFfSrcAnsi") },
          { value: "none",    label: Translations.t("termFfSrcNone") }
        ]
        current: FastfetchConfig.source
        onPicked: v => FastfetchConfig.set("fastfetchSource", v)
      }
    }

    SettingsRow {
      visible: page.usesImages
      titleKey: "termFastfetchRandom"
      hintKey: "termFastfetchRandomHint"

      SettingsSwitch {
        checked: TerminalConfig.fastfetchRandom
        onToggled: TerminalConfig.setRandom(!TerminalConfig.fastfetchRandom)
      }
    }

    SettingsRow {
      visible: page.usesImages
      titleKey: "termFastfetchImagesTitle"
      hintKey: "termFastfetchImagesHint"
      stacked: true

      ColumnLayout {
        Layout.fillWidth: true
        spacing: 8

        Flow {
          Layout.fillWidth: true
          spacing: 0

          Repeater {
            model: TerminalConfig.images
            delegate: ImageCell {
              required property var modelData
              name: modelData.name
            }
          }
        }

        Text {
          visible: TerminalConfig.loaded && TerminalConfig.images.length === 0
          Layout.fillWidth: true
          text: Translations.t("termImagesEmpty")
          wrapMode: Text.WordWrap
          color: Theme.subtext
          font.pixelSize: Theme.sfs(11)
          font.family: Theme.fontFamily
        }
      }
    }

    SettingsRow {
      visible: page.usesImages
      stacked: true
      divider: false

      Flow {
        Layout.fillWidth: true
        spacing: 8

        SettingsBtn {
          primary: page.browsing
          icon: "󰋩"
          text: Translations.t("termImageAdd")
          onClicked: page.browsing = !page.browsing
        }
        SettingsBtn {
          icon: "󰉋"
          text: Translations.t("termImagesOpen")
          onClicked: TerminalConfig.openFolder(TerminalConfig.imagesDir)
        }
      }
    }

    SettingsNote {
      visible: page.usesImages && page.browsing
      text: Translations.t("termImageBrowseHint")
    }

    SettingsRow {
      visible: page.usesImages && page.browsing
      stacked: true

      ImageBrowser {
        id: imageBrowser
        Layout.fillWidth: true
        Layout.preferredHeight: 290
        onPicked: path => TerminalConfig.addImage(path)
        onCancelled: page.browsing = false
      }
    }

    SettingsRow {
      visible: page.usesBuiltin
      titleKey: "termFfBuiltin"
      hintKey: "termFfBuiltinHint"
      stacked: true
      divider: false

      SettingsField {
        mono: true
        placeholder: "arch"
        value: FastfetchConfig.builtin
        onSubmitted: text => FastfetchConfig.set("fastfetchBuiltin", text.trim().replace(/[^A-Za-z0-9_\/. -]/g, ""))
      }
    }

    SettingsNote {
      visible: FastfetchConfig.source === "ansi"
      text: Translations.t("termFfTypeAnsiNote")
    }
    SettingsNote {
      visible: FastfetchConfig.source === "none"
      text: Translations.t("termFfTypeNoneNote")
    }
  }

  // ─── Tipo de entrada ─────────────────────────────────────────────

  SettingsSection {
    titleKey: "termFfTypeTitle"
    hintKey: "termFfTypeHint"
    visible: page.hasType
    enabled: TerminalConfig.fastfetchEnabled
    opacity: TerminalConfig.fastfetchEnabled ? 1 : 0.45

    SettingsRow {
      titleKey: "termFfTypeTitle"
      hint: page.typeHint(FastfetchConfig.logoType)
      divider: false

      Cycler {
        values: FastfetchConfig.validTypes
        current: FastfetchConfig.logoType
        labelOf: page.typeLabel
        onPicked: v => FastfetchConfig.set("fastfetchLogoType", v)
      }
    }
  }

  // ─── Márgenes y tamaño ───────────────────────────────────────────

  SettingsSection {
    titleKey: "termFfMarginsTitle"
    visible: FastfetchConfig.source !== "none"
    enabled: TerminalConfig.fastfetchEnabled
    opacity: TerminalConfig.fastfetchEnabled ? 1 : 0.45

    SettingsRow {
      titleKey: "termFfMarginsOn"
      hintKey: "termFfMarginsOnHint"

      SettingsSwitch {
        checked: FastfetchConfig.margins
        onToggled: FastfetchConfig.set("fastfetchMargins", !FastfetchConfig.margins)
      }
    }

    SettingsRow {
      enabled: FastfetchConfig.margins
      titleKey: "termFfPadTop"

      NumberStepper {
        Layout.fillWidth: false
        Layout.preferredWidth: 150
        value: FastfetchConfig.padTop
        min: 0
        max: 40
        onEdited: v => FastfetchConfig.set("fastfetchPadTop", v)
      }
    }

    SettingsRow {
      enabled: FastfetchConfig.margins
      titleKey: "termFfPadBottom"
      hintKey: "termFfPadBottomHint"

      NumberStepper {
        Layout.fillWidth: false
        Layout.preferredWidth: 150
        value: FastfetchConfig.padBottom
        min: 0
        max: 40
        onEdited: v => FastfetchConfig.set("fastfetchPadBottom", v)
      }
    }

    SettingsRow {
      enabled: FastfetchConfig.margins
      titleKey: "termFfPadLeft"

      NumberStepper {
        Layout.fillWidth: false
        Layout.preferredWidth: 150
        value: FastfetchConfig.padLeft
        min: 0
        max: 60
        onEdited: v => FastfetchConfig.set("fastfetchPadLeft", v)
      }
    }

    SettingsRow {
      enabled: FastfetchConfig.margins
      titleKey: "termFfPadRight"

      NumberStepper {
        Layout.fillWidth: false
        Layout.preferredWidth: 150
        value: FastfetchConfig.padRight
        min: 0
        max: 60
        onEdited: v => FastfetchConfig.set("fastfetchPadRight", v)
      }
    }

    SettingsRow {
      visible: page.usesImages
      titleKey: "termFfWidth"
      hintKey: "termFfSizeHint"

      NumberStepper {
        Layout.fillWidth: false
        Layout.preferredWidth: 150
        value: FastfetchConfig.logoWidth
        min: 0
        max: 200
        onEdited: v => FastfetchConfig.set("fastfetchWidth", v)
      }
    }

    SettingsRow {
      visible: page.usesImages
      titleKey: "termFfHeight"

      NumberStepper {
        Layout.fillWidth: false
        Layout.preferredWidth: 150
        value: FastfetchConfig.logoHeight
        min: 0
        max: 100
        onEdited: v => FastfetchConfig.set("fastfetchHeight", v)
      }
    }

    SettingsRow {
      titleKey: "termFfPosition"
      stacked: true
      divider: false

      SettingsChoice {
        model: FastfetchConfig.positions.map(p => ({ value: p, label: Translations.t("termFfPos_" + p) }))
        current: FastfetchConfig.position
        onPicked: v => FastfetchConfig.set("fastfetchPosition", v)
      }
    }
  }

  // ─── Estilo ──────────────────────────────────────────────────────

  SettingsSection {
    titleKey: "termFfStyleTitle"
    hintKey: "termFfStyleHint"
    enabled: TerminalConfig.fastfetchEnabled
    opacity: TerminalConfig.fastfetchEnabled ? 1 : 0.45

    SettingsRow {
      titleKey: "termFfStyleTitle"

      Cycler {
        values: FastfetchConfig.styleChoices
        current: FastfetchConfig.style
        labelOf: v => v === "config" ? Translations.t("termFfStyleMine") : FastfetchConfig.presetLabel(v)
        onPicked: v => FastfetchConfig.set("fastfetchStyle", v)
      }
    }

    SettingsRow {
      titleKey: "termFfPreview"
      hintKey: "termFfPreviewHint"
      divider: false

      SettingsBtn {
        icon: page.previewOpen ? "󰅃" : "󰅀"
        text: page.previewOpen ? Translations.t("termSectionHide") : Translations.t("termSectionShow")
        onClicked: page.previewOpen = !page.previewOpen
      }
      SettingsBtn {
        visible: page.previewOpen
        icon: "󰑐"
        text: ""
        enabled: !FastfetchConfig.previewing
        onClicked: FastfetchConfig.refreshPreview(true)
      }
    }

    Loader {
      Layout.fillWidth: true
      Layout.topMargin: 6
      Layout.preferredHeight: active ? 380 : 0
      active: page.previewOpen

      sourceComponent: Rectangle {
        color: Theme.bg
        radius: Theme.rad(10)
        border.width: Theme.bw1
        border.color: Theme.edge
        clip: true

        Flickable {
          anchors { fill: parent; margins: 12 }
          contentWidth: previewView.implicitWidth
          contentHeight: previewView.implicitHeight
          boundsBehavior: Flickable.StopAtBounds
          clip: true

          AnsiView {
            id: previewView
            html: FastfetchConfig.preview
          }
        }

        Text {
          anchors.centerIn: parent
          visible: FastfetchConfig.preview === "" && !FastfetchConfig.previewing
          text: Translations.t("termFfPreviewEmpty")
          color: Theme.subtext
          font.family: Theme.fontFamily
          font.pixelSize: Theme.sfs(11)
        }
      }
    }
  }

  // ─── Logo ANSI ───────────────────────────────────────────────────

  SettingsSection {
    titleKey: "termAnsiTitle"
    hintKey: "termAnsiHint"
    enabled: TerminalConfig.fastfetchEnabled
    opacity: TerminalConfig.fastfetchEnabled ? 1 : 0.45

    SettingsRow {
      stacked: true
      divider: false

      SettingsBtn {
        icon: page.ansiOpen ? "󰅃" : "󰅀"
        text: page.ansiOpen ? Translations.t("termSectionHide") : Translations.t("termSectionShow")
        onClicked: page.ansiOpen = !page.ansiOpen
      }
    }

    Loader {
      Layout.fillWidth: true
      Layout.topMargin: 6
      Layout.preferredHeight: item ? item.implicitHeight : 0
      active: page.ansiOpen
      sourceComponent: AnsiEditor {}
    }
  }
}
