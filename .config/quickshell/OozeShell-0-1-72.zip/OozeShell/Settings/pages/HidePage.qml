// HidePage — HIDE

import QtQuick
import QtQuick.Layouts
import ".."
import "../../COMMON"
import "../../Services/Lang"
import "../../Services/Hide"

SettingsPage {
  id: page
  catId: "hide"

  property string winApp: ""
  property string winTitle: ""
  property string layerNs: ""
  property string winMsg: ""
  property string layerMsg: ""
  property bool awaitLast: false
  property bool manualWindow: false
  property bool manualLayer: false

  Component.onCompleted: {
    HideConfig.scanWindows()
    HideConfig.scanLayers()
  }

  Connections {
    target: HideConfig
    function onScanningChanged() {
      if (HideConfig.scanning || !page.awaitLast) return
      page.awaitLast = false
      if (HideConfig.lastLayer === "") return
      page.layerNs = HideConfig.lastLayer
      layerField.input.text = HideConfig.lastLayer
    }
  }

  Timer {
    id: msgTimer
    interval: 3000
    onTriggered: { page.winMsg = ""; page.layerMsg = "" }
  }

  component RuleRow: SkinRect {
    id: rr
    property string title: ""
    property string sub: ""
    property bool ruleOn: true
    signal toggled()
    signal removed()

    Layout.fillWidth: true
    implicitHeight: rrCol.implicitHeight + 20
    radius: Theme.rad(Theme.cozy ? 4 : 10)
    color: Theme.bg
    opacity: rr.ruleOn ? 1 : 0.6
    clip: true

    RowLayout {
      id: rrCol
      anchors { left: parent.left; right: parent.right; top: parent.top; margins: 10 }
      spacing: 8

      ColumnLayout {
        Layout.fillWidth: true
        spacing: 2
        Text {
          Layout.fillWidth: true
          elide: Text.ElideRight
          text: rr.title
          color: Theme.primary
          font.bold: true
          font.pixelSize: Theme.sfs(12)
          font.family: Theme.monoFamily
        }
        Text {
          visible: rr.sub !== ""
          Layout.fillWidth: true
          elide: Text.ElideRight
          text: rr.sub
          color: Theme.subtext
          font.pixelSize: Theme.sfs(10)
          font.family: Theme.monoFamily
        }
      }
      SettingsSwitch {
        checked: rr.ruleOn
        onToggled: rr.toggled()
      }
      SettingsIconBtn {
        icon: "󰆴"
        onClicked: rr.removed()
      }
    }
  }

  component DetectRow: SkinRect {
    id: dr
    property string title: ""
    property string sub: ""
    property bool picked: false
    signal pressed()

    Layout.fillWidth: true
    implicitHeight: drRow.implicitHeight + 20
    radius: Theme.rad(Theme.cozy ? 4 : 10)
    color: Theme.bg
    clip: true

    RowLayout {
      id: drRow
      anchors { left: parent.left; right: parent.right; top: parent.top; margins: 10 }
      spacing: 8

      ColumnLayout {
        Layout.fillWidth: true
        Layout.minimumWidth: 0
        spacing: 2
        Text {
          Layout.fillWidth: true
          elide: Text.ElideRight
          text: dr.title
          color: dr.picked ? Theme.primary : Theme.text
          font.bold: true
          font.pixelSize: Theme.sfs(12)
          font.family: Theme.monoFamily
        }
        Text {
          visible: dr.sub !== ""
          Layout.fillWidth: true
          elide: Text.ElideRight
          text: dr.sub
          color: Theme.subtext
          font.pixelSize: Theme.sfs(10)
          font.family: Theme.monoFamily
        }
      }
      SettingsBtn {
        Layout.alignment: Qt.AlignVCenter
        primary: !dr.picked
        icon: dr.picked ? "󰈈" : "󰈉"
        text: Translations.t(dr.picked ? "hdShowBtn" : "hdHideBtn")
        onClicked: dr.pressed()
      }
    }
  }

  // ─── General ───
  SettingsSection {
    titleKey: "hdTitle"
    hintKey: "hdHint"

    SettingsRow {
      titleKey: "hdEnable"
      hintKey: "hdEnableHint"
      SettingsSwitch {
        checked: HideConfig.enabled
        onToggled: HideConfig.setEnabled(!HideConfig.enabled)
      }
    }

    SettingsRow {
      visible: WM.wm === "niri"
      titleKey: "hdMode"
      hintKey: "hdModeHint"
      SettingsChoice {
        model: [
          { value: "screencast", label: Translations.t("hdModeCast") },
          { value: "all",        label: Translations.t("hdModeAll") }
        ]
        current: HideConfig.mode
        onPicked: v => HideConfig.setMode(v)
      }
    }

    SettingsRow {
      titleKey: "hdShell"
      hintKey: "hdShellHint"
      SettingsSwitch {
        checked: HideConfig.shellLayers
        onToggled: HideConfig.setShellLayers(!HideConfig.shellLayers)
      }
    }

    SettingsNote {
      kind: "accent"
      text: Translations.t("hdNote_" + WM.wm)
    }
  }

  // ─── Ventanas ───
  SettingsSection {
    titleKey: "hdWinTitle"
    hintKey: "hdWinHint"

    SettingsRow {
      stacked: true
      divider: false
      visible: HideConfig.windows.length > 0
      ColumnLayout {
        Layout.fillWidth: true
        spacing: 6
        Repeater {
          model: HideConfig.windows
          delegate: RuleRow {
            required property var modelData
            title: (modelData.appId ?? "") !== "" ? modelData.appId : modelData.title
            sub: (modelData.appId ?? "") !== "" && (modelData.title ?? "") !== ""
                 ? Translations.t("hdTitleLabel") + ": " + modelData.title : ""
            ruleOn: modelData.on !== false
            onToggled: HideConfig.toggle("window", modelData.id)
            onRemoved: HideConfig.remove("window", modelData.id)
          }
        }
      }
    }

    SettingsNote {
      visible: HideConfig.windows.length === 0
      text: Translations.t("hdEmpty")
    }

    SettingsRow {
      titleKey: "hdOpenWindows"
      hintKey: "hdOpenWindowsHint"
      stacked: true
      ColumnLayout {
        Layout.fillWidth: true
        spacing: 8
        SettingsBtn {
          Layout.alignment: Qt.AlignLeft
          icon: "󰍉"
          text: Translations.t("hdSearch")
          primary: true
          onClicked: HideConfig.scanWindows()
        }
        Repeater {
          model: HideConfig.detectedWindows
          delegate: DetectRow {
            required property var modelData
            title: modelData.appId + (modelData.count > 1 ? "  ×" + modelData.count : "")
            sub: modelData.title
            picked: HideConfig.isWindowPicked(modelData.appId)
            onPressed: HideConfig.pickWindow(modelData.appId)
          }
        }
        SettingsNote {
          visible: HideConfig.detectedWindows.length === 0
          text: Translations.t("hdNoWindows")
        }
      }
    }

    SettingsRow {
      stacked: true
      ColumnLayout {
        Layout.fillWidth: true
        spacing: 8
        SettingsBtn {
          Layout.alignment: Qt.AlignLeft
          icon: page.manualWindow ? "󰅃" : "󰅀"
          text: Translations.t("hdManual")
          onClicked: page.manualWindow = !page.manualWindow
        }
        ColumnLayout {
          visible: page.manualWindow
          Layout.fillWidth: true
          spacing: 8
          SettingsNote { text: Translations.t("hdAddWindowHint") }
          SettingsField {
            id: appField
            value: page.winApp
            mono: true
            placeholder: Translations.t("hdAppIdPlaceholder")
            onSubmitted: t => page.winApp = t
          }
          SettingsField {
            id: titleField
            value: page.winTitle
            mono: true
            placeholder: Translations.t("hdTitlePlaceholder")
            onSubmitted: t => page.winTitle = t
          }
          SettingsBtn {
            icon: "󰐕"
            text: Translations.t("hdAdd")
            primary: true
            onClicked: {
              if (HideConfig.addWindow(appField.input.text, titleField.input.text)) {
                page.winApp = ""
                page.winTitle = ""
                appField.input.text = ""
                titleField.input.text = ""
                page.winMsg = ""
              } else {
                page.winMsg = Translations.t("hdInvalid")
                msgTimer.restart()
              }
            }
          }
          SettingsNote {
            visible: page.winMsg !== ""
            kind: "warn"
            text: page.winMsg
          }
        }
      }
    }
  }

  // ─── Layers ───
  SettingsSection {
    titleKey: "hdLayerTitle"
    hintKey: "hdLayerHint"

    SettingsRow {
      stacked: true
      divider: false
      visible: HideConfig.layers.length > 0
      ColumnLayout {
        Layout.fillWidth: true
        spacing: 6
        Repeater {
          model: HideConfig.layers
          delegate: RuleRow {
            required property var modelData
            title: modelData.namespace
            ruleOn: modelData.on !== false
            onToggled: HideConfig.toggle("layer", modelData.id)
            onRemoved: HideConfig.remove("layer", modelData.id)
          }
        }
      }
    }

    SettingsNote {
      visible: HideConfig.layers.length === 0
      text: Translations.t("hdEmptyLayers")
    }

    SettingsRow {
      visible: WM.wm !== "mango"
      titleKey: "hdDetected"
      hintKey: "hdDetectedHint"
      stacked: true
      ColumnLayout {
        Layout.fillWidth: true
        spacing: 8
        SettingsBtn {
          Layout.alignment: Qt.AlignLeft
          icon: "󰍉"
          text: Translations.t(HideConfig.scanning ? "hdSearching" : "hdSearch")
          primary: true
          onClicked: HideConfig.scanLayers()
        }
        Repeater {
          model: HideConfig.detectedLayers
          delegate: DetectRow {
            required property var modelData
            title: modelData
            sub: HideConfig.isLayerOpen(modelData) ? "" : Translations.t("hdNotOpen")
            picked: HideConfig.isLayerPicked(modelData)
            onPressed: HideConfig.pickLayer(modelData)
          }
        }
        SettingsNote {
          visible: HideConfig.detectedLayers.length === 0 && !HideConfig.scanning
          text: Translations.t("hdNoLayers")
        }
      }
    }

    SettingsRow {
      stacked: true
      ColumnLayout {
        Layout.fillWidth: true
        spacing: 8
        SettingsBtn {
          visible: WM.wm !== "mango"
          Layout.alignment: Qt.AlignLeft
          icon: page.manualLayer ? "󰅃" : "󰅀"
          text: Translations.t("hdManual")
          onClicked: page.manualLayer = !page.manualLayer
        }
        ColumnLayout {
          visible: page.manualLayer || WM.wm === "mango"
          Layout.fillWidth: true
          spacing: 8
          SettingsNote { text: Translations.t("hdAddLayerHint") }
          SettingsField {
            id: layerField
            value: page.layerNs
            mono: true
            placeholder: Translations.t("hdNamespacePlaceholder")
            onSubmitted: t => page.layerNs = t
          }
          Flow {
            Layout.fillWidth: true
            spacing: 8
            SettingsBtn {
              icon: "󰐕"
              text: Translations.t("hdAdd")
              primary: true
              onClicked: {
                if (HideConfig.addLayer(layerField.input.text)) {
                  page.layerNs = ""
                  layerField.input.text = ""
                  page.layerMsg = ""
                } else {
                  page.layerMsg = Translations.t("hdInvalid")
                  msgTimer.restart()
                }
              }
            }
            SettingsBtn {
              visible: WM.wm === "mango"
              icon: "󰍉"
              text: Translations.t("hdUseLast")
              onClicked: { page.awaitLast = true; HideConfig.scanLayers() }
            }
          }
          SettingsNote {
            visible: page.layerMsg !== ""
            kind: "warn"
            text: page.layerMsg
          }
        }
      }
    }
  }
}
