# AUDIO — Panel de volumen PipeWire + OozeAudio (salidas y entradas virtuales)

- Qué es: backend único (`AudioBackend`, singleton PipeWire/wpctl) para volumen salida/entrada, mixer por app y ruteo por salida; más OozeAudio, app aparte para crear salidas virtuales `ooze_*` y entradas virtuales `ooze_in_*` (pw-loopback) y cablearlas. Este doc cubre ambos.
- Archivos:
  - `Services/Audio/AudioBackend.qml` → `pragma Singleton`: sink/source default (Pipewire + fallback `wpctl`), `sinks`/`sources` (parseo `wpctl status`), `streamNodes`/`outputTargets`, reglas por app (`appRules`), `routeStream`/`forgetRule`, OSD state, `restoreOutputs`.
  - `Services/Audio/AudioOSD.qml` → píldora flotante abajo (Overlay) que muestra `osdKind`/`osdValue`/`osdMuted` 1,6 s.
  - `Services/Audio/AppsRouting.qml` → sección "Aplicaciones" reutilizable (apps sonando + reglas guardadas de apps inactivas).
  - `Services/Audio/StreamOutputPicker.qml` → desplegable de salida por stream (usa `PwNodeLinkTracker` + `ruleSink`).
  - `Services/OozeAudio/shell.qml` → ventana flotante propia (900×700): `Header` + `ConnectionsPanel` + `EditorPanel` + `CreateDialog` + toast de error.
  - `Services/OozeAudio/data/AudioService.qml` → `pragma Singleton`: invoca `audio.sh` (`outputs/inputs/sinks/sources/streams/links/create/delete/create-input/delete-input/connect/disconnect/connect-app/disconnect-app/app-streams/input-apps/volume-set/mute-set`), estado local optimista. Expone `outputs`, `inputs`, `appStreams`, `appLinks`, `sinks`, `sources`, `destinationCandidates()` (sinks físicos) y `sourceCandidates()` (micrófonos físicos).
  - `Services/OozeAudio/backend/audio.sh` → backend bash (~2000 líneas): requiere `pw-cli pw-dump pw-link pw-loopback jq pgrep systemd-run systemctl wpctl flock`; subcomandos `status sinks sources streams outputs inputs app-streams input-apps dump create delete create-input delete-input links connect disconnect connect-app disconnect-app sync-apps volume-set mute-set restore app-rules app-forget stream-move stream-route stream-unroute state`.
  - `Services/OozeAudio/components/` → `Header`, `ConnectionsPanel`, `ConnectionCard`, `EditorPanel`, `CreateDialog` (UI de la ventana).
- IPC (Core/Ipc/AudioIpc.qml, target `audio`):

  | función | efecto |
  |---|---|
  | `toggle` | abre/cierra la sección `audio` del Dashboard |
  | `raise` / `lower` / `mute` | ±5 % volumen / mute con OSD |
  | `micToggle` / `micRaise` / `micLower` | mute / ±5 % micrófono con OSD |

  ```bash
  quickshell ipc -p .../shell.qml call -- audio toggle
  quickshell ipc -p .../shell.qml call -- audio raise
  quickshell ipc -p .../shell.qml call -- audio mute
  quickshell ipc -p .../shell.qml call -- audio micToggle
  ```
- Estado y datos: `AudioBackend` es singleton sin JSON propio; reglas de apps y salidas las guarda `audio.sh` (ver `restore`, `app-rules`, `state` en el script). OozeAudio no usa IPC: es proceso Quickshell aparte (`FloatingWindow`).
- Dependencias: `Quickshell.Services.Pipewire` (event-driven; `wpctl` solo como fallback/acciones), `COMMON` (Theme, SkinRect, AppIcon), `Services/Lang`, `Services/Brightness` (slider de brillo en pestaña Salida). OozeAudio solo depende de su `audio.sh` + `pw-*`.
- Notas: `watchers`/`menuWatch`: listas de dispositivos y streams solo se escanean con el panel abierto (timers 1 s/1,5 s). Al subir volumen se desmutea solo. Los nodos `ooze_*` se etiquetan `Ooze_…` y se excluyen del ruteo automático. No confundir `Services/Audio/` (shell integrado) con `Services/OozeAudio/` (app externa de cableado virtual). `Services/Audio/AudioMenu.qml` ya no existe: el módulo de audio de la barra y `audio toggle` abren el Dashboard en la sección Audio (`Modules/Dashboard/DashboardAudio.qml`).

## Entradas virtuales (micrófonos virtuales)

- Qué son: nodos `Audio/Source` llamados `ooze_in_<nombre>` que las apps ven como un micrófono más (Discord, OBS, grabadores). Reciben audio de los micrófonos físicos que el usuario marque. Se gestionan en Ajustes avanzados → Audio → "Enrutamiento" (ver sección al final), con la misma mecánica que las salidas virtuales (crear, volumen, silenciar, borrar y chips de conexión).
- Simetría con las salidas: una salida virtual es un sink al que apps *envían* audio y que se reenvía a sinks físicos; una entrada virtual es una fuente de la que apps *graban* y que se alimenta de fuentes físicas.

### Cómo está hecho (un `pw-loopback` por entrada)

| Pieza | Nodo PipeWire | Papel |
|---|---|---|
| Lado de captura | `capture.ooze_in_<nombre>` (`Stream/Input/Audio`, pasivo) | Recibe los enlaces desde los micrófonos físicos. Es el destino real de los chips. |
| Lado de reproducción | `ooze_in_<nombre>` (`Audio/Source`) | Es el micrófono virtual que ven las apps. Aquí se aplica volumen y mute. |

- Cada entrada corre como unidad de usuario `oozeaudio-ooze_in_<nombre>` (`systemd-run --user`, `Restart=always`), igual que las salidas.
- `normalize_name` convierte el nombre visible a minúsculas con `_`; "Mic Discord" → `ooze_in_mic_discord`.
- Los nodos `ooze_in_*` nunca se ofrecen como candidatos de conexión (`sourceCandidates()` excluye todo `ooze_*`).

### Bloques de `audio.sh` añadidos

| Bloque (cabecera en el script) | Funciones | Qué hace |
|---|---|---|
| `STATE - VIRTUAL INPUTS` | `state_add_input`, `state_remove_input`, `state_input_in_state`, `state_set_input_links`, `state_input_link_add/remove`, `state_set_input_volume/muted` | Persisten la clave `inputs` de `audio.toml`. Todas usan `(.inputs // [])`, así que un `audio.toml` antiguo sin esa clave sigue funcionando. |
| `DISCOVERY - VIRTUAL INPUTS` | `source_names`, `source_only`, `virtual_input_exists`, `current_sources_of` | Consultan `pw-dump`: fuentes presentes, si existe la entrada virtual (por nombre **y** clase `Audio/Source`) y qué fuentes están enlazadas a ella. |
| `LIST - VIRTUAL INPUTS` | `list_inputs` | Salida TSV `id, node.name, descripción, volumen, mute` (subcomando `inputs`). |
| `CREATE / DELETE - VIRTUAL INPUTS` | `spawn_input_loopback`, `wait_capture_linked`, `create_input`, `delete_input` | Lanzan/paran el `pw-loopback`. `create_input` guarda como enlaces iniciales los que PipeWire haya autoconectado (normalmente el micrófono por defecto). `delete_input` solo actúa si el nodo es realmente una fuente o está en el estado, para no tocar una salida con nombre parecido. |
| `RESTORE - VIRTUAL INPUTS` | `wait_for_hardware_source`, `adopt_live_inputs`, `restore_inputs` | Tras reiniciar: recrea las entradas guardadas, reaplica volumen/mute, quita enlaces automáticos que el usuario no eligió y enlaza los guardados cuyo micrófono esté presente. `restore` ejecuta salidas y luego entradas. |

Cambios en bloques existentes:

- `resolve_input_node_id`: si el destino es `ooze_in_*` se resuelve a `capture.ooze_in_*`.
- `list_links`: normaliza `capture.ooze_in_*` a `ooze_in_*` en el destino, para que la UI compare `micrófono → ooze_in_x`.
- `connect_nodes` / `disconnect_nodes`: además de guardar enlaces de salidas, guardan el micrófono en `inputs[].links` cuando el destino es `ooze_in_*`.
- `persist_node_volume` / `persist_node_mute`: para nombres `ooze_*` consultan la clase real del nodo y escriben en `inputs` u `outputs` según corresponda.

### Estado persistente (`~/.config/oozeshell/audio.toml`)

```toml
[[inputs]]
display = "Mic Discord"
node = "ooze_in_mic_discord"
volume = 100
muted = false
links = ["alsa_input.pci-0000_00_1f.3.analog-stereo"]
```

`links` guarda nombres de nodo de las fuentes físicas que alimentan la entrada (a diferencia de las salidas, donde guarda sinks de destino).

### Interfaz

- `Settings/pages/AudioPage.qml`: `SettingsSection` "Enrutamiento" (antes "Entradas virtuales") bajo "Salidas virtuales". `AudioRow` ahora tiene la propiedad `direction` (`"output"` | `"input"`): en `input` los chips listan `AudioService.sourceCandidates()`, el texto es "Recibir de:" y un chip activo significa `isConnected(micrófono, entrada)`.
- `Settings/AdvancedSettings.qml`: dos entradas nuevas en `searchIndex` (`advAudioInputsTitle`, `advAudioCreateInput`).
- `Services/Lang/languages/LangEs.qml` y `LangEn.qml`: claves `advAudioInputsTitle`, `advAudioInputsHint`, `advAudioNewInputPlaceholder`, `advAudioCreateInput`, `advAudioNoInputs`, `advAudioReceiveFrom`.
- `Services/Audio/AudioBackend.qml`: `scanOutputTargets` también vigila los nodos de fuente (`inputTargetsKey`); si aparece o desaparece un micrófono (p. ej. USB) lanza `reconcileTimer`, que ejecuta `restore` y re-enlaza las entradas virtuales.

### Uso desde terminal

```bash
audio.sh create-input "Mic Discord"
audio.sh inputs
audio.sh connect alsa_input.usb-xxx ooze_in_mic_discord
audio.sh disconnect alsa_input.usb-xxx ooze_in_mic_discord
audio.sh volume-set <ID> 80
audio.sh delete-input "Mic Discord"
```

### Notas

- Si una salida se llama `in_x` su nodo es `ooze_in_x`, igual que una entrada `x`. Crear la segunda falla con "already exists" y `delete-input` no toca la salida.
- Las apps eligen la entrada virtual en su propio selector de micrófono o con pavucontrol; el mixer de Aplicaciones solo enruta reproducción.

## Enrutamiento (micrófonos, salidas de sonido y aplicaciones → entrada virtual)

- Qué es: la sección "Entradas virtuales" pasó a llamarse **Enrutamiento**. Sigue siendo el mismo nodo `ooze_in_<nombre>` (las apps lo ven como un micrófono), pero ahora mezcla tres tipos de origen. Ejemplo Discord: crear "Mic Discord", marcar tu micrófono + Spotify + el navegador, y elegir "Mic Discord" en Discord. Tú sigues oyendo todo normal: se añade un enlace, no se mueve el stream.

| Origen | Qué se enlaza hacia `capture.ooze_in_<nombre>` | Se guarda en |
|---|---|---|
| Micrófono | puertos de la fuente física | `inputs[].links` |
| Salida de sonido | puertos *monitor* del sink (físico o `ooze_*`) | `inputs[].links` |
| Aplicación | puertos de cada stream de la app | `inputs[].apps` |

- Clave de app: la misma que usan las reglas por app (binario → `application.name` → `node.name`, en minúsculas). Una app con varias pestañas/streams aparece como un solo chip.
- Los streams son efímeros, así que `sync-apps` reenlaza lo guardado: `AudioBackend` lo lanza 150 ms después de cada cambio de nodos de PipeWire y `restore_inputs` lo ejecuta al final.
- Estado: `apps = ["spotify", "firefox"]` dentro de cada `[[inputs]]`; un `audio.toml` sin esa clave sigue funcionando.
- Terminal:

  ```bash
  audio.sh app-streams                       # id, clave, nombre
  audio.sh connect-app spotify ooze_in_mic_discord
  audio.sh disconnect-app spotify ooze_in_mic_discord
  audio.sh connect alsa_output.xxx ooze_in_mic_discord   # salida de sonido como fuente
  audio.sh sync-apps
  ```

### Bloques y archivos tocados

| Dónde | Cambio |
|---|---|
| `audio.sh` `DISCOVERY - APP STREAMS` | `APP_KEY_JQ`, `list_app_streams`, `list_input_apps` |
| `audio.sh` `ROUTING - APP SOURCES` | `apply_app_links`, `connect_app`, `disconnect_app`, `sync_input_apps` |
| `audio.sh` `STATE - VIRTUAL INPUTS` | `state_input_app_add/remove` |
| `AudioService.qml` | `appStreams`, `appLinks`, `appCandidates`, `monitorCandidates`, `setAppConnection`, `refreshRouting` |
| `AudioPage.qml` | componente `RouteGroup` (chips por grupo) y refresco de apps cada 3 s con la página abierta |
| `AudioBackend.qml` | `syncInputApps` + `syncAppsTimer` |

### Funciones a vigilar o modificar

- `APP_KEY_JQ` (`appkey`): duplica `streamKey` de `AudioBackend.qml`. Si una cambia y la otra no, las reglas de salida y el enrutamiento dejan de hablar de la misma app. Conviene unificarlas (que QML consuma `app-streams`).
- `link_node_ids` / `unlink_node_ids`: salieron de `link_nodes` / `unlink_nodes` y ahora son el núcleo de todo el cableado (salidas, micrófonos, apps). Tocar el emparejado de canales afecta a los tres.
- `apply_app_links`: función caliente, corre en cada cambio de nodos. Mantener un único `pw-dump` por llamada. Los 3 reintentos de 0,25 s existen porque los puertos de un stream aparecen unos ms después del nodo; subirlos retrasa el resto de enlaces.
- `sync_input_apps`: el `grep '^apps = \["'` evita lanzar Python en cada evento, pero depende del formato que escribe `ooze_toml.py`. Si cambia el serializador, el enrutamiento de apps se desactivaría sin avisar.
- `connect_nodes` / `disconnect_nodes`: ya no guardan un destino `ooze_in_*` en `outputs[].links`.
- `restore_inputs`: `present` ahora incluye sinks para restaurar las salidas de sonido guardadas.

### Límites conocidos

- Un stream nuevo se enlaza al detectarlo (~0,3–0,5 s): el arranque de un sonido corto de un navegador puede no llegar si ese stream se crea y destruye en cada clip. Con streams persistentes (Spotify, Discord, la mayoría de paneles de sonidos) no hay pérdida.
- No marcar como fuente la salida por la que suena el propio Discord: sus interlocutores se oirían a sí mismos en tu micrófono.
- Apps con el mismo binario (varios Electron/Chromium) comparten clave y se enrutan juntas.
- `sync-apps` no toma `acquire_ops_lock`: solo enlaza y es idempotente; si coincide con `restore`, lo peor es un enlace duplicado que PipeWire rechaza.

## Ventana de audio en ajustes avanzados (CoOzey)
- `Settings/pages/AudioPage.qml`: filas de dispositivo y chips usan `Theme.bg` con contorno `Theme.edge` de `Theme.bw1` en CoOzey, para contrastar con la sección (`Theme.surface`).
- `Services/Audio/AppsRouting.qml`: tarjetas de apps y reglas guardadas con la misma superficie; el control de volumen de cada app es un `PixelBar` en CoOzey y la barra suave original en OozeSoft.
- Ancho: el bloque tiene `Layout.minimumWidth: 0` y los textos largos («Reglas guardadas…») usan `fillWidth` con ajuste de línea, porque un `Text` sin límite ensanchaba la columna y recortaba la tarjeta por la derecha. El nombre de cada regla se limita al 45 % de la fila para no empujar el botón de borrar.
