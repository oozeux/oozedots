# APPEARANCE — Panel de estética del WM (gaps, bordes, blur, layout)

- Qué es: popup lateral que edita el objeto `appearance` de `shell.qml` con preview en vivo y commit al WM vía `WmAppearance`. Cubre sliders numéricos, toggles y layout.
- Archivos:
  - `Modules/Appearance/Appearance.qml` → popup `FusedWindow`/`FusedPanel`: `sliderSpecs` (gaps, bordes, rounding, opacidades, blur, sombra), `toggleSpecs`, chips de layout; emite `previewChanged`/`valueCommitted`/`toggleChanged`/`layoutChosen`.
  - `Modules/Appearance/AppearanceSlider.qml` → slider reutilizable con arrastre, nudges de teclado, edición numérica tipada y commit diferido (350 ms).
- IPC (Core/Ipc/AppearanceIpc.qml, target `appearance`):

  | Función | Efecto |
  |---|---|
  | `toggle` | abre/cierra el popup |
  | `get` | devuelve JSON del objeto `appearance` |
  | `set <key> <valor>` | `layout`/`animProfile` directos; toggles con `true/1`; resto como float |

  ```bash
  quickshell ipc -p .../shell.qml call -- appearance toggle
  quickshell ipc -p .../shell.qml call -- appearance get
  quickshell ipc -p .../shell.qml call -- appearance set rounding 14
  quickshell ipc -p .../shell.qml call -- appearance set layout dwindle
  ```
- Estado y datos: el estado vive en `shell.qml` (`property var appearance`, defaults gapsIn 3, gapsOut 6, etc.). Caché en `~/.cache/oozeshell/state.toml` vía `StateStore` (`Core/StateStore.qml`); `shell.qml` la guarda con `writeAppearanceCache()` (`StateStore.setCommon("appearance", …)`). `WmAppearance` (`COMMON/WmAppearance.qml`, singleton) genera configs del WM (hypr/niri/mango) y aplica cambios live.
- Dependencias: `COMMON` (Theme, FusedWindow, FusedPanel, PanelHeader), `Services/Lang`, y `WmAppearance` + `WM` para filtrar specs por WM (`specAllowed`: `gapsIn`/opacidades no aplican en niri; blur/sombra según `WM.has()`).
- Notas: los sliders filtrados por WM desaparecen (`visibleSliders`); los de sombra se atenúan si `shadowEnabled` es false. `animProfile` también se edita aquí aunque no es slider.

## Esquinas cuadradas (modo cuadrado)
- Qué es: un interruptor en Ajustes → Apariencia → Estilo de interfaz («Esquinas cuadradas») que quita toda esquina redondeada del shell. Es independiente del estilo (`uiStyle`: OozeSoft o CoOzey) y de la paleta: puede combinarse con cualquiera.
- Estado: `Theme.squaredPref` (persistido con la clave `squared` en las preferencias de Theme) y `Theme.squared` (solo lectura). Se cambia con `Theme.setSquared(on)`.
- IPC: `quickshell ipc call theme squared true|false`, `theme squaredToggle`, `theme squaredGet`.
- Cómo se aplica:
  - `Theme.rad(v)` devuelve `0` si el modo está activo y `v` si no. Todo `radius:` del código se escribe como `radius: Theme.rad(...)`; los tokens ya lo incluyen (`cardRadius`, `panelRadius`, `islandRadius`, `barRadius`, `tipRadius`, `tipFlare`, `flare`, `fusedFlare`, `screenCorner`, `frameCornerRadius`, y los `MdTokens.r*`).
  - Las curvas de unión (flares) valen 0, así que los paneles pegados a la barra se unen en ángulo recto; las esquinas de pantalla desaparecen.
  - `NotchRect` pone `n = 0` (sin muescas pixel) y `MdShape` usa la forma `block` (cuadrado puro de `MdShapes`).
  - `FusedPanel.cornerRadius` es 0 y no recupera radio por el hueco del marco.
  - Ventanas reales: `WmAppearance.squareRounding()` envía `rounding = 0` a hyprland/niri/mango al escribir el tema y en vivo; `shell.qml` lo reaplica al cambiar `Theme.squared`. El valor guardado de `appearance.rounding` no se pierde.
- Regla al escribir QML nuevo: nunca dejar `radius: <número>` suelto; usar `Theme.rad(<número>)` o un token de Theme/MdTokens.
