# LAUNCHER — lanzadores: Launcher (apps/ventanas/comandos), QuickBar (búsqueda/archivos) y PackageSearch (paquetes)

- Qué es: tres frontales de búsqueda/lanzamiento. `Launcher` es el lanzador completo por popup; `QuickBar` (nombre visible: **QuickSearch**) es una barra de búsqueda minimalista con host e IPC propios; `PackageSearch` es el buscador de paquetes que se abre vía el target `nixsearch`.

## Launcher (`Services/Launcher`)

- Archivos:
  - `Launcher.qml` → UI principal, modos `apps | windows | run | files | commands | tmux`, lee `DesktopEntries.applications`
  - `LauncherDetail.qml` → panel lateral del layout `detail` (carátula o icono, nombre, acciones)
  - `LauncherHistory.qml` → recientes, contador de usos y favoritos; persiste en `~/.config/oozeshell/launcher-history.json`
  - `LauncherCovers.qml` → localiza carátulas (caché de Steam y carpeta propia)
  - `LauncherCommands.qml` → comandos personalizados
  - `TmuxSessions.qml` → sesiones tmux vía `Process`
  - `LauncherParticles.qml` → fondo decorativo de partículas; pide su reparto a `Backends/python/ooze-particles.py`
  - `LauncherGlyph.qml` → icono o glifo de un resultado, compartido por `grid` y `deck`/`orbit`
  - `LauncherGrid.qml` → vista de rejilla del layout `grid`
  - `LauncherCarousel.qml` → vista de los layouts `deck` y `orbit`
- IPC (Core/Ipc/LauncherIpc.qml, target `launcher`):

  | Función | Efecto |
  |---|---|
  | `toggle` | alterna popup (modo `apps`); usa rofi si `useRofiLauncher()` |
  | `open <modo>` | abre en un modo (`apps`, `windows`, `run`, `files`, `commands`, `tmux`) |
  | `close` | cierra |

  ```sh
  quickshell ipc -p .../shell.qml call -- launcher toggle
  quickshell ipc -p .../shell.qml call -- launcher open windows
  quickshell ipc -p .../shell.qml call -- launcher close
  ```
- Dependencias: `COMMON`, `Services/Lang`, `Quickshell.Io` (`Process`, `DesktopEntries`), `QtQuick.Effects` (blur del layout `frosted`).

### Atajos de teclado

La interfaz ya no muestra la línea de atajos; esta tabla es la referencia.

| Tecla | Acción |
|---|---|
| `Tab` / `Shift+Tab` | siguiente / anterior modo |
| `Alt+1` … `Alt+3` | ir directo a un modo |
| `↑` `↓` · `Ctrl+P/K` `Ctrl+N/J` | mover selección |
| `PgUp` / `PgDn` | mover 7 filas |
| `Enter` | abrir |
| `Ctrl+Enter` | abrir en terminal (modo `run`) |
| `Ctrl+D` | añadir o quitar favorito (solo apps) |
| `Ctrl+U` | limpiar búsqueda |
| `Backspace` (vacío) | subir carpeta (modo `files`) |
| `Ctrl+H` | mostrar ocultos (modo `files`) |
| `Esc` | cerrar |
| `>` · `!` | prefijo comandos · prefijo tmux (si está activo en Ajustes) |

### Teclado y foco

- `Launcher.handleKey(key, modifiers)` concentra todos los atajos y devuelve si la tecla se consumió. Lo llaman el `TextInput` (`Keys.onPressed`) y `FusedWindow.onKeyPressed`, que recibe las teclas cuando el foco está en el `keyCatcher` y no en el buscador. Antes ese camino descartaba las flechas (solo devolvía el foco al buscador), por eso la navegación fallaba de forma intermitente, sobre todo con el ratón sobre el launcher.
- `Connections { target: panel }` → `onHoveredChanged` devuelve el foco al buscador si lo perdió al entrar o salir el puntero.
- `handleKey` → vigilar. Todo atajo nuevo va ahí; si se añade solo en el `TextInput` vuelve el fallo cuando el foco está en `keyCatcher`.
- `focusTimer` (120 ms) → mantener. Cubre el foco inicial al abrir; no sustituye a la recuperación por hover.

- `list.reveal()` mantiene visible la fila seleccionada calculando `contentY` a partir de `fitRowH + rowGap` (todas las filas miden lo mismo). Sustituye a `positionViewAtIndex(Contain)`, que depende de delegados ya creados y podía dejar la selección fuera de la vista al subir. Se llama al cambiar `selected`, `count`, el alto de la lista o `fitRowH`.
- `list.reveal()` → vigilar. Si las filas dejan de ser de alto uniforme (cabeceras, secciones), hay que volver a `positionViewAtIndex` o medir cada fila.
- Diagnóstico: `OOZESHELL_LAUNCHER_DEBUG=1 quickshell …` imprime cada tecla (`handleKey`) y cada `reveal` con `selected`, `contentY`, `count` y si el buscador tiene el foco.

### Imagen en cápsula

`Theme.launcherCapsule` (activo por defecto; cualquier layout con imagen: `split`, `frosted`, `grid`, `deck` y `orbit`) dibuja `capsuleFrame`: un marco de 10 px con el color de `Theme.panelBg` y hueco redondeado sobre el wallpaper, sin máscaras (relleno `OddEvenFill`). El marco sobresale 3 px del wallpaper (`bleed`) y `wallTop.x` se redondea: sin esto, durante la animación de apertura el borde antialiasado dejaba asomar una línea de la imagen. En `split` encapsula la imagen y en los layouts de cristal el wallpaper desenfocado de toda la tarjeta; en ambos casos no toca las aletas, por lo que se desactivan `barBlend`, `cornerBlend` y `sideBlend`. En Cristal el marco usa al menos 92 % de opacidad para que el borde sea limpio.

### Modo flotante

`Theme.launcherFloating` (Ajustes → Launcher, solo con «En la barra») separa el panel de la barra con `Theme.windowGap` y esquinas redondeadas. Es independiente de `Theme.floatWindows`: el panel flota si cualquiera de los dos está activo (`floatWin` en `Launcher.qml`), y `styleAnim` de `FusedPanel` usa también `floatWin`, por lo que el launcher flotante hereda la animación de ventanas.

### Ratón

| Acción | Efecto |
|---|---|
| Clic | abre (por defecto) |
| Clic con `Theme.launcherDoubleClick` | solo selecciona; el doble clic abre |
| Clic derecho | alterna favorito (solo apps), en lista, `grid`, `deck` y `orbit` |

En `grid`, `deck` y `orbit` los favoritos llevan una estrella en la esquina superior derecha de la tarjeta (solo el glifo, sin borde ni insignia, igual en los tres) (solo cuando `launcherRecents` está activo y en modo `apps`).

`launcherDoubleClick` se cambia en Ajustes → Launcher y se guarda en `ui.toml`. En `deck` y `orbit` el doble clic es fiable solo sobre la tarjeta activa, porque al seleccionar otra las tarjetas se desplazan.

### Layouts (`Theme.launcherLayout`)

| Valor | Descripción |
|---|---|
| `split` | wallpaper a la izquierda, lista a la derecha (diseño original). Con la barra a la izquierda y el launcher pegado a ella, se espeja: la imagen queda a la derecha (`imageRight`), opuesta a la barra, y la lista junto a ella. Sin imagen queda un fondo plano oscuro |
| `frosted` | panel de cristal con filas y buscador semitransparentes. Con imagen, el wallpaper desenfocado cubre toda la tarjeta. Sin imagen, panel liso como en `split` |
| `detail` | lista a la izquierda y panel de detalle a la derecha; sin wallpaper |
| `grid` | rejilla de iconos sobre wallpaper desenfocado; las columnas se calculan por ancho |
| `deck` | carrusel horizontal con inclinación; la carátula (Steam o carpeta propia) aparece en la tarjeta activa |
| `orbit` | anillo elíptico de apps que gira al moverte; nombre de la app activa en el centro |

En `grid`, `deck` y `orbit` se navega con flechas (`←` `→`, y `↑` `↓` en `grid`), rueda del ratón o clic; el clic en la tarjeta activa la abre.

El layout se cambia en Ajustes → Launcher → Diseño. El tamaño (compacto/normal/grande) aplica a todos.

### Efectos y animaciones

Todos requieren "Efectos extra" y respetan `Theme.effectsActive`.

| Ajuste | Valores | Efecto |
|---|---|---|
| `launcherParticlesEnabled` | on / off | Activa o apaga las partículas |
| `launcherParticleStyle` | `dust`, `stars`, `snow`, `fireflies` | Polvo que sube, estrellas fijas que parpadean, nieve que cae, luciérnagas que vagan |
| `launcherParticleDensity` | 0, 1, 2 | 12, 20 o 34 partículas (`stars` suma 10) |
| `launcherParticlePattern` | `even`, `random`, `cascade` | Reparto parejo y fijo, reparto nuevo en cada apertura u oleadas escalonadas |
| `launcherGlowEnabled` | on / off | Pulso del buscador y de la fila seleccionada, independiente de las partículas |
| `launcherImageGlow` | on / off | Resplandor de color (`orb` en `Launcher.qml`) que se desplaza sobre el wallpaper. Apagado por defecto; solo aparece en Ajustes cuando hay imagen y el layout no es `detail` |
| `launcherEnterAnim` | `slide`, `fade`, `zoom`, `none` | Cómo aparecen las filas y el título al abrir o cambiar de modo |

### Backend de partículas

`Backends/python/ooze-particles.py` genera las posiciones y tiempos y los devuelve como JSON en una línea. Requiere `python3` (solo biblioteca estándar).

```sh
python3 Backends/python/ooze-particles.py --style fireflies --count 20 --glyphs 2 --pattern cascade --seed 3
```

| Parámetro | Efecto |
|---|---|
| `--style` | `dust`, `stars`, `snow`, `fireflies` |
| `--pattern` | `even` (ruido azul, semilla fija), `random` (semilla nueva), `cascade` (oleadas con retardo por columna) |
| `--avoid x0,y0,x1,y1` | Rectángulo normalizado (el panel) donde se penalizan las partículas |
| `--seed`, `--direction` | Reproducibilidad y sentido de la cascada (`ltr`, `rtl`, `center`, `edges`) |

Si Python no responde en 700 ms, `LauncherParticles.localMotes()` genera un reparto de respaldo. El patrón `even` se guarda en caché por estilo, cantidad y zona a evitar.

### Recientes y favoritos

- Con `Theme.launcherRecents` activo, el modo `apps` sin texto muestra primero los favoritos, luego las 5 apps más recientes y después el resto en orden alfabético.
- Al buscar, favoritos y apps muy usadas reciben un bonus de puntaje (`LauncherHistory.boost`), sin saltarse la coincidencia de texto.
- Se guardan un máximo de 200 entradas; las más antiguas se descartan salvo las favoritas.

### Carátulas

El panel `detail` muestra una carátula si existe y, si no, el icono de la app. Orden de búsqueda:

1. `~/.config/oozeshell/covers/<id o nombre>.(png|jpg|jpeg|webp)`, en minúsculas y sin `.desktop`.
2. Caché de Steam (`appcache/librarycache`), en instalación nativa, `~/.steam/steam` y Flatpak. Se prefiere `library_600x900`, luego `library_capsule`, `library_header` y `header`.

El AppID de Steam se extrae del `Exec` (`steam://rungameid/<id>`) o del icono `steam_icon_<id>`. Para juegos fuera de Steam (Heroic, Lutris), copia la imagen a la carpeta propia con el nombre del `.desktop`.

### Funciones y propiedades a modificar o vigilar

| Elemento | Estado | Motivo |
|---|---|---|
| `sizes` | modificable | Define medidas por tamaño; `detailW` controla el ancho del panel de detalle. Cambiar `cardH` afecta las filas visibles |
| `syncDisplayResults()` | vigilar | Evita un crash de Qt 6.11.2 al mover filas en `ScriptModel`. Cualquier orden nuevo de resultados debe pasar por aquí |
| `ranked()` y `boost()` | modificable | Controlan el orden con y sin texto. Si cambias los pesos, ten en cuenta que `Fuzzy.match` devuelve puntajes de cientos |
| `wallProc` | modificable | Lee `~/.cache/awww/last` por script `sh`. Es el único origen del wallpaper; no sirve para imágenes por app |
| `barBlend`, `cornerBlend` y `sideBlend` | vigilar | `cornerBlend` funde solo las esquinas del wallpaper pegadas a la barra (donde están las aletas) con degradados radiales de radio `flareSize` + 14 px, sin escalón ni oscurecer el resto del borde. Degradados con `Theme.panelBg` sobre el wallpaper, sin máscaras (`MultiEffect` con máscara no funciona aquí). `barBlend` lo funde con la barra y se apaga si el panel flota (`panel.detached`, incl. Cristal y ventanas flotantes). `sideBlend` lo funde con la lista en `split`, tanto en barra como centrado; en Cristal termina al 92 % para no dejar línea. Todo fade nuevo del wallpaper debe seguir esta vía |
| `LauncherParticles.styles` | modificable | Un estilo nuevo es una entrada con glifos, balanceo, opacidad mínima y tipo de movimiento. La posición se calcula en los bindings de `x`, `y`, `opacity` y `scale` |
| `orb` (resplandor del wallpaper) | vigilar | Depende de `Theme.launcherImageGlow`, `wall.fx` y `Theme.effectsActive`. Su animación `orbMove` también se detiene al apagarlo, para no gastar GPU en un elemento invisible |
| `wallMotion` (layer de blur) | vigilar | En `frosted` usa `MultiEffect` sobre toda la tarjeta. El gif vivo se desactiva en ese layout porque repetiría el blur en cada fotograma |
| `fancyFxActive` / `Theme.effectsActive` | vigilar | Todo efecto nuevo debe depender de ellos para que el modo de rendimiento (`shellPerf`) siga apagándolo |
| `LauncherCovers.script` | modificable | Rutas de Steam y extensiones soportadas. Si Steam cambia su estructura de caché, se ajusta aquí y en `ingest()` |
| `LauncherHistory.commit()` | vigilar | Escribe a disco en cada lanzamiento o cambio de favorito. Si se llama desde un bucle, agrupa los cambios antes |
| Delegado de fila (`row`) | modificable | Candidato a extraerse a `LauncherRow.qml` si se añaden más layouts |

## QuickBar / QuickSearch (`Modules/QuickBar`)
- Nombre: en la interfaz (Ajustes avanzados, textos de ayuda) se llama **QuickSearch**. Los identificadores internos (carpeta `Modules/QuickBar/`, singleton `QuickBarConfig`, target IPC `quickbar`, archivo `quickbar.toml`) conservan el nombre original para no romper atajos ni ajustes guardados.

- Archivos:
  - `Modules/QuickBar/QuickBarHost.qml` → `Scope` con estado abierto/cerrado, `LazyPopup` y el `IpcHandler` propio (target `quickbar`); lo instancia `shell.qml` (bloque `QuickBarHost`, `shell.qml:1009`)
  - `Modules/QuickBar/QuickBar.qml` → tarjeta de búsqueda (web con bangs + archivos con prefijo `f `)
  - `Modules/QuickBar/QuickBarConfig.qml` → `pragma Singleton` con ajustes y persistencia
- IPC (Modules/QuickBar/QuickBarHost.qml, target `quickbar`):

  | Función | Efecto |
  |---|---|
  | `toggle` / `open` / `close` | alterna, abre, cierra |
  | `search <texto>` | abre con consulta inicial |
  | `files` | abre en modo archivos (`f `) |
  | `position <p>` | cambia posición vía `QuickBarConfig` |
  | `filesEnabled <bool>` | activa/desactiva búsqueda de archivos |
  | `get` | devuelve `QuickBarConfig.snapshot()` en JSON |

  ```sh
  quickshell ipc -p .../shell.qml call -- quickbar toggle
  quickshell ipc -p .../shell.qml call -- quickbar search 'nixpkgs firefox'
  quickshell ipc -p .../shell.qml call -- quickbar files
  quickshell ipc -p .../shell.qml call -- quickbar get
  ```
- Estado y datos: `QuickBarConfig` (`pragma Singleton`): `position`, `widthMode`, `browserId`, `engineId`, `bangsEnabled`, `filesEnabled`, `fileRoots`, `fileDepth`, etc. Persiste en `~/.config/oozeshell/quickbar.toml` (`dir` + `file` en `Modules/QuickBar/QuickBarConfig.qml:39-40`).
- Dependencias: `COMMON`, `Services/Lang`.

## PackageSearch (`Services/PackageSearch`)

- Archivos:
  - `Services/PackageSearch/PackageSearch.qml` → buscador unificado; backend según `WM.packageBackend`
  - `Services/PackageSearch/installed.sh` → helper para listar paquetes instalados (modo `installed`)
- IPC (Core/Ipc/NixSearchIpc.qml, target `nixsearch`):

  | Función | Efecto |
  |---|---|
  | `toggle` | alterna buscador |
  | `open [consulta]` | abre con consulta inicial |
  | `installed` | abre en modo paquetes instalados |
  | `close` | cierra |

  ```sh
  quickshell ipc -p .../shell.qml call -- nixsearch toggle
  quickshell ipc -p .../shell.qml call -- nixsearch open 'firefox'
  quickshell ipc -p .../shell.qml call -- nixsearch installed
  quickshell ipc -p .../shell.qml call -- nixsearch close
  ```
- Estado y datos: sin singleton; `backend` = `WM.packageBackend` (`COMMON/WM.qml:65-70`: `nix-search` en NixOS, si no `pkgHelperPref` o primer helper disponible, por defecto `pacman`). Requiere binario `nix-search` cuando el backend es nix (emite `__NO_NIX_SEARCH__` si falta).
- Dependencias: `COMMON` (WM), `Services/Lang`.
- Notas: el nombre del target IPC (`nixsearch`) es histórico; en Arch el backend real es pacman/AUR, no nix.

## Estilo CoOzey y título de portada
- Buscador, fila seleccionada, botones de modo, celdas del grid, caras del carrusel y botones de acción del detalle son `SkinRect`: en CoOzey dibujan contorno ink con muescas pixel (el elemento activo con `Theme.primary`), en OozeSoft conservan el relleno y borde fino.
- El título sobre la portada (`root.viewTitle`) y su subtítulo tienen ancho `imageW - 56`, con `fontSizeMode: HorizontalFit` y `elide`; el contenedor recorta (`clip`) para no invadir la lista.
- Con esquinas cuadradas activas (`Theme.squared`), `flareSize` y `cornerSize` se envuelven en `Theme.rad`, por lo que el panel se une a la barra sin curvas.
