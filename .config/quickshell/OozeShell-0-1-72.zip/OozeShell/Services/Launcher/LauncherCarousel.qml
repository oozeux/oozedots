// LauncherCarousel

import QtQuick
import "../../COMMON"

Item {
  id: root

  property var items: []
  property int selected: 0
  property string kind: "deck"
  property string mode: "apps"
  property string cover: ""
  property bool glass: false
  property bool glow: false
  property bool doubleClick: false
  property var favorites: []

  signal picked(int index)
  signal activated(int index)
  signal favorited(int index)

  readonly property bool orbit: root.kind === "orbit"
  readonly property int span: root.orbit ? 4 : 3
  readonly property int count: root.items.length
  readonly property var current: root.items[root.selected] ?? null

  property real pos: root.selected
  property real spin: 0
  property real intro: 1
  readonly property real vpos: root.pos + root.spin

  Behavior on pos {
    NumberAnimation { duration: Theme.animDuration(root.orbit ? 520 : 420); easing.type: Easing.OutCubic }
  }

  function play() {
    if (!Theme.uiAnimationsEnabled) return
    spinIn.restart()
  }

  ParallelAnimation {
    id: spinIn
    NumberAnimation { target: root; property: "spin"; from: root.orbit ? -3.2 : -2.2; to: 0; duration: Theme.animDuration(root.orbit ? 1100 : 800); easing.type: Easing.OutCubic }
    NumberAnimation { target: root; property: "intro"; from: 0; to: 1; duration: Theme.animDuration(700); easing.type: Easing.OutQuad }
  }

  onSelectedChanged: infoIn.restart()

  // ─── Tarjetas ───────────────────────────────────────────────────
  Item {
    id: stage
    anchors.fill: parent

    readonly property real cw: root.orbit ? Math.max(84, Math.min(root.width, root.height) * 0.2)
                                          : Math.max(70, Math.min(root.width * 0.26, (root.height - 78) / 1.18))
    readonly property real ch: root.orbit ? stage.cw : Math.round(stage.cw * 1.18)
    readonly property real cx: root.width / 2
    readonly property real cy: root.orbit ? root.height * 0.42 : (root.height - 66) / 2
    readonly property real ringX: root.width * 0.36
    readonly property real ringY: root.height * 0.3
    readonly property real ringStep: Math.PI * 2 / 8.0

    Repeater {
      model: root.span * 2 + 1

      delegate: Item {
        id: slot
        required property int index

        readonly property int idx: Math.round(root.pos) + slot.index - root.span
        readonly property real d: slot.idx - root.vpos
        readonly property real ad: Math.abs(slot.d)
        readonly property real sgn: slot.d < 0 ? -1 : 1
        readonly property bool valid: slot.idx >= 0 && slot.idx < root.count
        readonly property var entry: slot.valid ? root.items[slot.idx] : null
        readonly property bool isCurrent: slot.idx === root.selected
        readonly property bool fav: !!slot.entry && root.favorites.indexOf(slot.entry.id) >= 0

        readonly property real theta: slot.d * stage.ringStep
        readonly property real depth: root.orbit ? (1 + Math.cos(slot.theta)) / 2 : 0
        readonly property real edgeFade: Math.max(0, Math.min(1, root.span + 0.6 - slot.ad))
        readonly property real introK: Math.max(0, Math.min(1, root.intro * 1.8 - slot.ad * 0.18))

        visible: slot.valid && slot.edgeFade > 0.01
        width: stage.cw
        height: stage.ch

        x: root.orbit ? stage.cx + stage.ringX * Math.sin(slot.theta) - stage.cw / 2
                      : stage.cx + slot.sgn * (slot.ad < 1 ? slot.ad * stage.cw * 0.86
                                                        : stage.cw * 0.86 + (slot.ad - 1) * stage.cw * 0.4) - stage.cw / 2
        y: root.orbit ? stage.cy + stage.ringY * Math.cos(slot.theta) - stage.ch / 2
                      : stage.cy - stage.ch / 2 + Math.min(slot.ad, 3) * 6
        z: root.orbit ? Math.round(slot.depth * 100) : Math.round(100 - slot.ad * 10)
        scale: (root.orbit ? 0.46 + 0.7 * slot.depth
                           : Math.max(0.4, 1 - 0.24 * Math.min(slot.ad, 1) - 0.09 * Math.max(0, Math.min(slot.ad, 3) - 1)))
               * (0.5 + 0.5 * slot.introK)
        opacity: (root.orbit ? 0.3 + 0.7 * slot.depth : Math.max(0.25, 1 - 0.2 * slot.ad)) * slot.edgeFade * slot.introK

        transform: Rotation {
          origin.x: slot.width / 2
          origin.y: slot.height / 2
          axis { x: 0; y: 1; z: 0 }
          angle: root.orbit ? 0 : -slot.sgn * Math.min(slot.ad, 1) * 40
        }

        SkinRect {
          id: face
          anchors.fill: parent
          inkColor: slot.isCurrent ? Theme.primary : Theme.ink
          radius: Theme.rad(Theme.cardRadius + 4)
          color: slot.isCurrent ? (root.glass ? Qt.alpha(Theme.surfaceHigh, 0.82) : Theme.surfaceHigh)
                                : (root.glass ? Qt.alpha(Theme.surface, 0.6) : Theme.surface)
          border.width: Theme.cozy ? 0 : (slot.isCurrent ? 2 : 1)
          border.color: slot.isCurrent ? Theme.primary : Qt.rgba(Theme.primary.r, Theme.primary.g, Theme.primary.b, 0.18)
          clip: true
          Behavior on color { ColorAnimation { duration: Theme.animDuration(180) } }

          Image {
            anchors.fill: parent
            visible: !root.orbit && slot.isCurrent && root.cover !== ""
            source: (!root.orbit && slot.isCurrent && root.cover !== "") ? root.cover : ""
            fillMode: Image.PreserveAspectCrop
            asynchronous: true
            smooth: true
            opacity: status === Image.Ready ? 1 : 0
            Behavior on opacity { NumberAnimation { duration: Theme.animDuration(260) } }
          }

          LauncherGlyph {
            anchors.centerIn: parent
            anchors.verticalCenterOffset: root.orbit ? 0 : -Math.round(parent.height * 0.08)
            visible: !(!root.orbit && slot.isCurrent && root.cover !== "")
            item: slot.entry
            mode: root.mode
            size: Math.round(stage.cw * (root.orbit ? 0.52 : 0.42))
          }

          Text {
            anchors { left: parent.left; right: parent.right; bottom: parent.bottom; margins: 10 }
            visible: !root.orbit && !slot.isCurrent
            horizontalAlignment: Text.AlignHCenter
            elide: Text.ElideRight
            text: slot.entry ? (slot.entry.isCalc ? "= " + slot.entry.name : slot.entry.name) : ""
            color: Theme.text
            font.pixelSize: Theme.fs(12)
            font.family: Theme.fontFamily
            font.bold: slot.isCurrent
          }

          Text {
            visible: slot.fav
            anchors { top: parent.top; right: parent.right; topMargin: 6; rightMargin: 8 }
            text: "󰓎"
            color: Theme.primary
            font.pixelSize: Math.max(14, Math.round(stage.cw * 0.2))
            font.family: Theme.monoFamily
          }
        }

        Rectangle {
          anchors { fill: parent; margins: -5 }
          radius: Theme.rad(Theme.cardRadius + 9)
          color: "transparent"
          border.width: 2
          border.color: Qt.rgba(Theme.primary.r, Theme.primary.g, Theme.primary.b, 0.45)
          visible: slot.isCurrent && root.glow
          opacity: 0.2
          SequentialAnimation on opacity {
            running: slot.isCurrent && root.glow && Theme.uiAnimationsEnabled
            loops: Animation.Infinite
            NumberAnimation { from: 0.15; to: 0.75; duration: Theme.animDuration(900); easing.type: Easing.InOutSine }
            NumberAnimation { from: 0.75; to: 0.15; duration: Theme.animDuration(900); easing.type: Easing.InOutSine }
          }
        }

        MouseArea {
          anchors.fill: parent
          cursorShape: Qt.PointingHandCursor
          acceptedButtons: Qt.LeftButton | Qt.RightButton
          onClicked: mouse => {
            if (mouse.button === Qt.RightButton) {
              root.picked(slot.idx)
              root.favorited(slot.idx)
            } else if (slot.isCurrent && !root.doubleClick) root.activated(slot.idx)
            else root.picked(slot.idx)
          }
          onDoubleClicked: mouse => {
            if (mouse.button === Qt.LeftButton && root.doubleClick) root.activated(slot.idx)
          }
        }
      }
    }
  }

  // ─── Rótulo del elemento activo ─────────────────────────────────
  Column {
    id: info
    width: root.orbit ? Math.round(root.width * 0.34) : root.width - 40
    x: Math.round((root.width - info.width) / 2)
    y: root.orbit ? stage.cy - 26 : root.height - info.height - 2
    spacing: 2
    opacity: 1

    ParallelAnimation {
      id: infoIn
      NumberAnimation { target: info; property: "opacity"; from: 0; to: 1; duration: Theme.animDuration(260) }
      NumberAnimation { target: infoShift; property: "y"; from: 8; to: 0; duration: Theme.animDuration(300); easing.type: Easing.OutCubic }
    }
    transform: Translate { id: infoShift }

    Text {
      width: parent.width
      horizontalAlignment: Text.AlignHCenter
      elide: Text.ElideRight
      text: root.current ? (root.current.isCalc ? "= " + root.current.name : root.current.name) : ""
      color: Theme.text
      font.pixelSize: Theme.fs(root.orbit ? 22 : 20)
      font.family: Theme.titleFamily
      font.bold: true
    }
    Text {
      width: parent.width
      horizontalAlignment: Text.AlignHCenter
      elide: Text.ElideRight
      text: root.current ? (root.current.sub ?? "") : ""
      color: Theme.subtext
      font.pixelSize: Theme.fs(12)
      font.family: Theme.fontFamily
    }
  }

  WheelHandler {
    acceptedDevices: PointerDevice.Mouse | PointerDevice.TouchPad
    onWheel: event => {
      const step = event.angleDelta.y !== 0 ? (event.angleDelta.y < 0 ? 1 : -1) : (event.angleDelta.x < 0 ? 1 : -1)
      root.picked(Math.max(0, Math.min(root.count - 1, root.selected + step)))
    }
  }
}
