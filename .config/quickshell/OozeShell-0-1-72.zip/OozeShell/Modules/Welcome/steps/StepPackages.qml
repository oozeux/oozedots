// StepPackages — WELCOME

import QtQuick
import QtQuick.Layouts
import "../../../Settings"
import "../../../COMMON"
import "../../../Services/Lang"
import ".."

SettingsPage {
  id: page

  readonly property var missing: WelcomePackages.missing
  readonly property bool ready: WelcomePackages.checked

  readonly property string summary: !page.ready ? Translations.t("welPkgChecking")
    : page.missing.length === 0 ? Translations.t("welPkgAllOk")
    : Translations.t("welPkgMissing").replace("%1", page.missing.length)

  readonly property string managerInfo: (WM.distro === "nixos" ? "NixOS" : "Arch") + " · " + WM.packageBackend

  Component.onCompleted: WelcomePackages.refresh()

  // ─── RESUMEN ───
  SettingsSection {
    titleKey: "welPkgSummary"

    SettingsRow {
      title: page.summary
      hint: page.managerInfo
      divider: false

      SettingsIconBtn {
        spinning: WelcomePackages.busy
        onClicked: WelcomePackages.refresh()
      }
    }

    SettingsRow {
      visible: page.missing.length > 0
      stacked: true
      divider: true

      Flow {
        Layout.fillWidth: true
        spacing: 8

        SettingsBtn {
          primary: true
          icon: "󰆏"
          text: Translations.t("welPkgCopyCmd")
          onClicked: WelcomePackages.copy(WelcomePackages.installCommand(page.missing))
        }
        SettingsBtn {
          icon: "󰆏"
          text: Translations.t("welPkgCopyNames")
          onClicked: WelcomePackages.copy(WelcomePackages.packageNames(page.missing))
        }
      }
    }

    SettingsNote {
      visible: WelcomePackages.missingRequired.length > 0
      kind: "error"
      text: Translations.t("welPkgRequiredMissing")
    }

    SettingsNote {
      visible: page.missing.length > 0
      text: Translations.t("welPkgSearchHint")
    }
  }

  // ─── GRUPOS ───
  Repeater {
    model: WelcomePackages.groups

    delegate: SettingsSection {
      id: sec
      required property var modelData
      readonly property var list: WelcomePackages.groupEntries(sec.modelData.id)

      titleKey: sec.modelData.titleKey
      hintKey: sec.modelData.hintKey

      SettingsRow {
        stacked: true
        divider: false

        Flow {
          Layout.fillWidth: true
          spacing: 8

          Repeater {
            model: sec.list

            delegate: SkinRect {
              id: chip
              required property var modelData
              readonly property bool known: WelcomePackages.checked
              readonly property bool ok: WelcomePackages.isOk(chip.modelData.bin)
              readonly property bool bad: chip.known && !chip.ok

              implicitWidth: chipLabel.implicitWidth + 24
              implicitHeight: 28
              radius: Theme.rad(Theme.cozy ? 4 : 14)
              color: chipArea.containsMouse && chip.bad ? Theme.surfaceHigh : Theme.bg
              border.width: Theme.bw1
              border.color: !chip.known ? Theme.divider : (chip.ok ? Theme.primary : (sec.modelData.required ? Theme.error : "#e0b04f"))

              Text {
                id: chipLabel
                anchors.centerIn: parent
                text: (!chip.known ? "… " : (chip.ok ? "✓ " : "✗ ")) + chip.modelData.bin
                color: !chip.known ? Theme.subtext : (chip.ok ? Theme.text : (sec.modelData.required ? Theme.error : "#e0b04f"))
                font.pixelSize: Theme.sfs(11)
                font.family: Theme.monoFamily
              }

              MouseArea {
                id: chipArea
                anchors.fill: parent
                enabled: chip.bad
                hoverEnabled: true
                cursorShape: chip.bad ? Qt.PointingHandCursor : Qt.ArrowCursor
                onClicked: page.host.requestPackageSearch(WelcomePackages.searchName(chip.modelData))
              }
            }
          }
        }
      }
    }
  }
}
