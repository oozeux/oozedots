// StepKeybinds — WELCOME

import QtQuick
import QtQuick.Layouts
import "../../../Settings"
import "../../../COMMON"
import "../../../Services/Lang"

SettingsPage {
  id: page

  property int sectionIndex: 0

  readonly property var all: {
    Translations.current
    return Translations.sections().filter(s => !s.wm || s.wm.indexOf(WM.wm) >= 0)
  }
  readonly property var section: page.all[Math.min(page.sectionIndex, Math.max(0, page.all.length - 1))]

  // ─── SECCIONES ───
  SettingsSection {
    titleKey: "welKbTitle"
    hintKey: "welKbHint"

    SettingsRow {
      stacked: true
      divider: false
      SettingsChips {
        model: page.all.map((s, i) => ({ value: i, label: s.title, icon: s.icon }))
        current: page.sectionIndex
        onPicked: v => page.sectionIndex = v
      }
    }
  }

  // ─── ATAJOS ───
  SettingsSection {
    Repeater {
      model: page.section ? page.section.binds.filter(b => !b.wm || b.wm.indexOf(WM.wm) >= 0) : []

      delegate: SettingsRow {
        id: row
        required property var modelData
        title: row.modelData.desc

        Row {
          spacing: 4
          Repeater {
            model: row.modelData.keys
            delegate: Rectangle {
              required property string modelData
              implicitWidth: capText.implicitWidth + 16
              implicitHeight: Math.round(24 * Theme.settingsTextScale)
              radius: Theme.rad(Theme.cozy ? 3 : 7)
              color: Qt.rgba(Theme.primary.r, Theme.primary.g, Theme.primary.b, 0.16)

              Text {
                id: capText
                anchors.centerIn: parent
                text: modelData
                color: Theme.primary
                font.bold: true
                font.pixelSize: Theme.sfs(11)
                font.family: Theme.fontFamily
              }
            }
          }
        }
      }
    }
  }

  SettingsRow {
    stacked: true
    divider: false
    SettingsBtn {
      icon: "󰌌"
      text: Translations.t("welKbOpenPanel")
      onClicked: page.host.requestKeybinds()
    }
  }

  SettingsNote {
    text: Translations.t("welKbMore")
  }
}
