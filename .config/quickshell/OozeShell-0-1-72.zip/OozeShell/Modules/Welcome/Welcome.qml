// Welcome — WELCOME

import Quickshell
import Quickshell.Wayland
import QtQuick
import QtQuick.Layouts
import "../../COMMON"
import "../../Services/Lang"
import "../../Settings"

Item {
  id: root

  // ─── PROPIEDADES ───
  property bool open: false
  property string targetScreen: ""
  property string targetMonitor: "auto"
  property string resolvedMonitor: ""
  property bool screenCorners: false
  property int startStep: 0
  property int step: root.startStep
  property bool keyGrab: false

  signal closeRequested()
  signal finished()
  signal skipped()
  signal monitorChosen(string name)
  signal languageChosen(string code)
  signal requestCornersToggle()
  signal requestMonitorEditor()
  signal requestPackageSearch(string query)
  signal requestSettings()
  signal requestKeybinds()

  // ─── PASOS ───
  readonly property var steps: [
    { id: "language", icon: "󰗊", titleKey: "welStepLanguage", hintKey: "welStepLanguageHint", source: "steps/StepLanguage.qml" },
    { id: "bar", icon: "shape:bar", titleKey: "welStepBar", hintKey: "welStepBarHint", source: "steps/StepBar.qml" },
    { id: "screen", icon: "󰍹", titleKey: "welStepScreen", hintKey: "welStepScreenHint", source: "steps/StepScreen.qml" },
    { id: "dock", icon: "shape:dock", titleKey: "welStepDock", hintKey: "welStepDockHint", source: "steps/StepDock.qml" },
    { id: "launcher", icon: "󰀻", titleKey: "welStepLauncher", hintKey: "welStepLauncherHint", source: "steps/StepLauncher.qml" },
    { id: "quick", icon: "󰍉", titleKey: "welStepQuick", hintKey: "welStepQuickHint", source: "steps/StepQuickSearch.qml" },
    { id: "apps", icon: "󰓎", titleKey: "welStepApps", hintKey: "welStepAppsHint", source: "steps/StepApps.qml" },
    { id: "terminal", icon: "󰞷", titleKey: "welStepTerminal", hintKey: "welStepTerminalHint", source: "steps/StepTerminal.qml" },
    { id: "lock", icon: String.fromCodePoint(0xF033E), titleKey: "welStepLock", hintKey: "welStepLockHint", source: "steps/StepLock.qml" },
    { id: "folders", icon: "󰉋", titleKey: "welStepFolders", hintKey: "welStepFoldersHint", source: "steps/StepFolders.qml" },
    { id: "profile", icon: "󰀄", titleKey: "welStepProfile", hintKey: "welStepProfileHint", source: "../../Settings/pages/ProfilePage.qml" },
    { id: "ai", icon: "󰚩", titleKey: "welStepAi", hintKey: "welStepAiHint", source: "steps/StepAi.qml" },
    { id: "packages", icon: "󰏖", titleKey: "welStepPackages", hintKey: "welStepPackagesHint", source: "steps/StepPackages.qml" },
    { id: "keybinds", icon: "󰌌", titleKey: "welStepKeybinds", hintKey: "welStepKeybindsHint", source: "steps/StepKeybinds.qml" },
    { id: "thanks", icon: String.fromCodePoint(0xF02D1), titleKey: "welStepThanks", hintKey: "welStepThanksHint", source: "steps/StepThanks.qml" }
  ]

  readonly property int lastStep: root.steps.length - 1
  readonly property bool isLast: root.step >= root.lastStep
  readonly property var current: root.steps[Math.max(0, Math.min(root.step, root.lastStep))]

  function go(index) { root.step = Math.max(0, Math.min(root.lastStep, index)) }
  function next() { if (root.isLast) root.finished(); else root.go(root.step + 1) }
  function back() { root.go(root.step - 1) }

  // ─── GEOMETRÍA ───
  readonly property var screenRef: Quickshell.screens.find(s => s.name === root.targetScreen) ?? Quickshell.screens[0]
  readonly property real k: Theme.settingsTextScale
  readonly property int winW: Math.min(Math.round(880 * root.k), Math.max(480, (root.screenRef ? root.screenRef.width : 1920) - 32))
  readonly property int winH: Math.min(Math.round(680 * root.k), Math.max(380, (root.screenRef ? root.screenRef.height : 1080) - 48))
  readonly property bool compact: root.winW < 700
  readonly property int railW: root.compact ? 60 : Math.round(200 * root.k)
  readonly property int contentPad: 22

  onOpenChanged: {
    if (root.open) {
      keyCatcher.forceActiveFocus()
      root.keyGrab = true
      keyGrabTimer.restart()
    } else {
      root.keyGrab = false
    }
  }
  onStepChanged: flick.contentY = 0

  Timer { id: keyGrabTimer; interval: 250; onTriggered: root.keyGrab = false }

  // ─── VENTANA ───
  PanelWindow {
    id: win

    screen: root.screenRef
    visible: true
    color: "transparent"
    exclusiveZone: -1
    implicitWidth: root.winW
    implicitHeight: root.winH

    WlrLayershell.layer: WlrLayer.Overlay
    WlrLayershell.namespace: "oozeshell-welcome"
    WlrLayershell.keyboardFocus: !root.open ? WlrKeyboardFocus.None
      : (root.keyGrab ? WlrKeyboardFocus.Exclusive : WlrKeyboardFocus.OnDemand)

    property Region noInput: Region {}
    property Region cardInput: Region { item: card }
    mask: root.open ? win.cardInput : win.noInput

    FocusScope {
      id: keyCatcher
      anchors.fill: parent
      focus: true
      Keys.onEscapePressed: root.closeRequested()

      // ─── TARJETA ───
      SkinRect {
        id: card
        anchors.fill: parent
        anchors.bottomMargin: Theme.cozy ? 4 : 0
        radius: Theme.panelRadius
        color: Theme.bg
        border.width: Theme.cozy ? 0 : Theme.bw1
        border.color: Theme.edge
        raised: true
        clip: true

        opacity: root.open ? 1 : 0
        visible: opacity > 0
        scale: root.open ? 1.0 : 0.97
        Behavior on opacity { NumberAnimation { duration: Theme.animDuration(180) } }
        Behavior on scale { NumberAnimation { duration: Theme.animDuration(220); easing.type: Easing.OutCubic } }

        MouseArea { anchors.fill: parent }

        RowLayout {
          anchors.fill: parent
          anchors.margins: Theme.cozy ? Theme.inkWidth + 2 : 0
          spacing: 0

          // ─── RIEL DE PASOS ───
          Rectangle {
            Layout.preferredWidth: root.railW
            Layout.fillHeight: true
            color: Theme.cozy ? "transparent" : Qt.rgba(Theme.surface.r, Theme.surface.g, Theme.surface.b, 0.5)

            ColumnLayout {
              anchors { fill: parent; margins: 12 }
              spacing: 4

              RowLayout {
                Layout.fillWidth: true
                Layout.bottomMargin: 10
                Layout.leftMargin: root.compact ? 0 : 6
                spacing: 8

                Item {
                  Layout.fillWidth: root.compact
                  visible: root.compact
                }
                Text {
                  text: "󰒓"
                  color: Theme.primary
                  font.pixelSize: Theme.sfs(20)
                  font.family: Theme.monoFamily
                }
                Text {
                  visible: !root.compact
                  Layout.fillWidth: true
                  text: "OozeShell"
                  elide: Text.ElideRight
                  color: Theme.text
                  font.bold: true
                  font.pixelSize: Theme.sfs(15)
                  font.family: Theme.fontFamily
                }
                Item {
                  Layout.fillWidth: root.compact
                  visible: root.compact
                }
              }

              Repeater {
                model: root.steps

                delegate: Rectangle {
                  id: item
                  required property var modelData
                  required property int index
                  readonly property bool active: item.index === root.step
                  readonly property bool visited: item.index < root.step

                  Layout.fillWidth: true
                  Layout.preferredHeight: Math.round(34 * root.k)
                  radius: Theme.rad(Theme.cozy ? 4 : 12)
                  color: item.active ? Qt.rgba(Theme.primary.r, Theme.primary.g, Theme.primary.b, 0.16)
                       : (itemArea.containsMouse ? Theme.surface : "transparent")
                  Behavior on color { ColorAnimation { duration: Theme.animDuration(120) } }

                  RowLayout {
                    anchors { fill: parent; leftMargin: root.compact ? 0 : 12; rightMargin: 10 }
                    spacing: 10

                    Item { Layout.fillWidth: root.compact; visible: root.compact }
                    CatIcon {
                      icon: item.modelData.icon
                      size: Theme.sfs(16)
                      color: item.active ? Theme.primary : (item.visited ? Theme.text : Theme.subtext)
                    }
                    Text {
                      visible: !root.compact
                      Layout.fillWidth: true
                      text: Translations.t(item.modelData.titleKey)
                      elide: Text.ElideRight
                      color: item.active ? Theme.primary : Theme.text
                      font.bold: item.active
                      font.pixelSize: Theme.sfs(12)
                      font.family: Theme.fontFamily
                    }
                    Text {
                      visible: !root.compact && item.visited
                      text: "󰄬"
                      color: Theme.primary
                      font.pixelSize: Theme.sfs(13)
                      font.family: Theme.monoFamily
                    }
                    Item { Layout.fillWidth: root.compact; visible: root.compact }
                  }

                  MouseArea {
                    id: itemArea
                    anchors.fill: parent
                    hoverEnabled: true
                    cursorShape: Qt.PointingHandCursor
                    onClicked: root.go(item.index)
                  }
                }
              }

              Item { Layout.fillHeight: true }
            }
          }

          Rectangle { Layout.preferredWidth: 1; Layout.fillHeight: true; color: Theme.divider }

          // ─── DETALLE ───
          ColumnLayout {
            Layout.fillWidth: true
            Layout.fillHeight: true
            spacing: 0

            Rectangle {
              Layout.fillWidth: true
              Layout.preferredHeight: 3
              color: Theme.divider

              Rectangle {
                height: parent.height
                width: parent.width * (root.step + 1) / root.steps.length
                color: Theme.primary
                Behavior on width { NumberAnimation { duration: Theme.animDuration(220); easing.type: Easing.OutCubic } }
              }
            }

            Flickable {
              id: flick
              Layout.fillWidth: true
              Layout.fillHeight: true
              contentWidth: width
              contentHeight: stepCol.implicitHeight + root.contentPad * 2
              clip: true
              boundsBehavior: Flickable.StopAtBounds

              Rectangle {
                parent: flick
                z: 60
                visible: flick.contentHeight > flick.height + 1
                width: 4
                radius: Theme.rad(Theme.cozy ? 0 : 2)
                x: flick.width - width - 4
                height: Math.max(28, flick.height * flick.height / Math.max(1, flick.contentHeight))
                readonly property real pad: 8
                y: (flick.contentHeight - flick.height) > 0
                   ? pad + (flick.height - height - 2 * pad) * (flick.contentY / (flick.contentHeight - flick.height))
                   : pad
                color: Qt.rgba(Theme.primary.r, Theme.primary.g, Theme.primary.b, (flick.moving || flick.flicking) ? 0.75 : 0.30)
                Behavior on color { ColorAnimation { duration: Theme.animDuration(200) } }
              }

              ColumnLayout {
                id: stepCol
                width: Math.min(flick.width - root.contentPad * 2, Math.round(680 * root.k))
                x: Math.max(root.contentPad, Math.round((flick.width - width) / 2))
                y: root.contentPad
                spacing: 14

                RowLayout {
                  Layout.fillWidth: true
                  spacing: 12

                  SkinRect {
                    Layout.preferredWidth: 40
                    Layout.preferredHeight: 40
                    Layout.alignment: Qt.AlignTop
                    radius: Theme.rad(12)
                    color: Qt.rgba(Theme.primary.r, Theme.primary.g, Theme.primary.b, 0.16)
                    CatIcon {
                      anchors.centerIn: parent
                      icon: root.current.icon
                      size: Theme.sfs(19)
                    }
                  }

                  ColumnLayout {
                    Layout.fillWidth: true
                    Layout.minimumWidth: 0
                    spacing: 2

                    Text {
                      Layout.fillWidth: true
                      text: root.step === 0 ? Translations.t("welTitle") : Translations.t(root.current.titleKey)
                      wrapMode: Text.WordWrap
                      color: Theme.text
                      font.bold: true
                      font.pixelSize: Theme.sfs(18)
                      font.family: Theme.fontFamily
                    }
                    Text {
                      Layout.fillWidth: true
                      text: root.step === 0 ? Translations.t("welIntro") : Translations.t(root.current.hintKey)
                      wrapMode: Text.WordWrap
                      color: Theme.subtext
                      font.pixelSize: Theme.sfs(11)
                      font.family: Theme.fontFamily
                    }
                  }
                }

                Loader {
                  id: stepLoader
                  Layout.fillWidth: true
                  Layout.preferredHeight: stepLoader.item ? stepLoader.item.implicitHeight : 0
                  active: root.open || card.visible
                  source: root.current.source
                  onLoaded: {
                    stepLoader.item.host = root
                    stepLoader.item.active = Qt.binding(() => root.open)
                    stepLoader.item.showTitle = false
                  }
                }
              }
            }

            // ─── PIE ───
            Rectangle { Layout.fillWidth: true; Layout.preferredHeight: 1; color: Theme.divider }

            RowLayout {
              Layout.fillWidth: true
              Layout.preferredHeight: Math.round(56 * root.k)
              Layout.leftMargin: root.contentPad
              Layout.rightMargin: root.contentPad
              spacing: 8

              Text {
                Layout.fillWidth: true
                text: Translations.t("welStepOf").replace("%1", root.step + 1).replace("%2", root.steps.length)
                elide: Text.ElideRight
                color: Theme.subtext
                font.pixelSize: Theme.sfs(11)
                font.family: Theme.fontFamily
              }

              SettingsBtn {
                visible: !root.isLast
                icon: "󰒭"
                text: Translations.t("welSkip")
                onClicked: root.skipped()
              }
              SettingsBtn {
                visible: root.step > 0
                icon: "󰅁"
                text: Translations.t("welBack")
                onClicked: root.back()
              }
              SettingsBtn {
                primary: true
                icon: root.isLast ? "󰄬" : "󰅂"
                text: Translations.t(root.isLast ? "welFinish" : "welNext")
                onClicked: root.next()
              }
            }
          }
        }
      }
    }
  }
}
