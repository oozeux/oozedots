// ClockModule — reloj con 5 estilos y formato 12/24 h (Theme.barClockStyle, dibujados por COMMON/ClockFace.qml). Al pasar el mouse abre el calendario (BarCalendar, dibujado por CenterModules); clic derecho abre la agenda.

import QtQuick
import QtQuick.Layouts

import "../../../COMMON"
import "../../../Services/Lang"

BarFlow {
  id: mod

  property var host: null
  readonly property bool shown: true

  readonly property bool calOpen: BarCalendar.isOpen(mod.host.screenName)

  SkinRect {
    id: clockButton

    property var now: new Date()

    Layout.preferredWidth: Theme.barVertical ? 40 : Math.max(face.clockStyle === "classic" ? 70 : 44, face.implicitWidth + 22)
    Layout.preferredHeight: Theme.barVertical ? 44 : 30

    radius: Theme.cardRadius
    color: (clockMouse.containsMouse || mod.calOpen) ? mod.hoverColor : "transparent"

    Behavior on color { ColorAnimation { duration: Theme.animDuration(150) } }

    raised: Theme.cozy && (clockMouse.containsMouse || mod.calOpen)
    depth: 2
    notch: 3

    scale: Theme.cozy ? 1.0 : (clockMouse.pressed
      ? 0.90
      : clockMouse.containsMouse ? 1.04 : 1.0)

    Behavior on scale {
      NumberAnimation { duration: Theme.animDuration(160); easing.type: Easing.OutBack }
    }

    Timer {
      interval: 1000
      running: true
      repeat: true

      onTriggered: clockButton.now = new Date()
    }

    ClockFace {
      id: face

      anchors.centerIn: parent
      clockStyle: Theme.barClockStyleEffective
      localeCode: Translations.localeCode
      vertical: Theme.barVertical
      now: clockButton.now
    }

    MouseArea {
      id: clockMouse

      anchors.fill: parent
      hoverEnabled: true
      cursorShape: Qt.PointingHandCursor
      acceptedButtons: Qt.LeftButton | Qt.RightButton

      onEntered: {
        BarCalendar.clockHover = true
        if (!mod.host.agendaOpen)
          BarCalendar.show(mod.host.screenName, mod.host.side, mod.host.alongCenterOf(clockButton))
      }
      onExited: BarCalendar.clockHover = false
      onClicked: mouse => {
        if (mouse.button === Qt.RightButton) {
          BarCalendar.hide()
          mod.host.clockRightClicked()
        } else if (!mod.host.agendaOpen) {
          BarCalendar.toggle(mod.host.screenName, mod.host.side, mod.host.alongCenterOf(clockButton))
        }
      }
    }
  }
}
