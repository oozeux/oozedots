// MprisModule — canción en reproducción en la barra (clic: popup, clic derecho / rueda: siguiente / anterior). Estilos: Theme.mprisActiveBarStyle.

import QtQuick
import QtQuick.Layouts
import QtQuick.Shapes

import "../../../COMMON"
import "../../../Services/Lang"
import "../../../Services/Mpris"

BarFlow {
  id: mod

  property var host: null
  readonly property bool shown: true

  property int songMaxWidth: 260
  gap: 2

  readonly property string style: Theme.mprisActiveBarStyle
  readonly property bool hasText: !Theme.barVertical && !Theme.mprisCompact
  readonly property bool showProgress: mod.style === "progress" && mod.hasText
  readonly property bool showRing: mod.style === "ring"
  readonly property bool showControls: mod.style === "controls"
  readonly property bool miniPlay: mod.style === "progress"

  readonly property string mprisStatus:
    MprisBackend.activePlayers.length > 0 ? MprisBackend.currentStatus : ""
  readonly property string mprisArtist: MprisBackend.currentArtist
  readonly property string mprisTitle: MprisBackend.currentTitle

  readonly property string songLabel:
    (mprisArtist !== "" && mprisTitle !== "")
      ? mprisArtist + " - " + mprisTitle
      : (mprisTitle !== "" ? mprisTitle : mprisArtist)

  readonly property bool hasSong: songLabel !== ""

  readonly property string songTip: {
    if (!hasSong) return Translations.t("mprisNoPlaying")
    if (mprisTitle !== "" && mprisArtist !== "") return mprisTitle + "\n" + mprisArtist
    return songLabel
  }

  // ─── Posición: solo se sondea si el estilo muestra progreso ───
  readonly property bool wantPos: (mod.showProgress || mod.showRing) && mod.mprisStatus === "Playing"
  readonly property string wantKey: "bar-" + Math.random().toString(36).slice(2)
  onWantPosChanged: MprisBackend.setWanted(mod.wantKey, mod.wantPos)
  Component.onCompleted: MprisBackend.setWanted(mod.wantKey, mod.wantPos)
  Component.onDestruction: MprisBackend.setWanted(mod.wantKey, false)

  component CtlButton: BarPillButton {
    property string glyph: ""
    property string ctl: ""

    hoverScale: 1.08
    Layout.preferredWidth: Theme.barVertical ? 40 : 28
    Layout.preferredHeight: 30
    onClicked: MprisBackend.runCtl([ctl])

    Text {
      Layout.alignment: Qt.AlignCenter
      text: glyph
      color: Theme.text
      font.family: Theme.monoFamily
      font.pixelSize: Theme.fs(15)
    }
  }

  // ─── Botón principal: carátula (+ aro de progreso) y texto ───
  BarPillButton {
    id: mprisBtn

    hoverColor: mod.hoverColor

    active: mod.host.mprisOpen
    hoverScale: 1.03
    tip: mod.songTip

    onHoverEntered: mod.host.tipEnter(mprisBtn)
    onHoverExited: mod.host.tipLeave(mprisBtn)

    onClicked: mouse => {
      if (mouse.button === Qt.RightButton)
        MprisBackend.runCtl(["next"])
      else
        mod.host.mprisButtonClicked()
    }

    onScrolled: wheel => {
      MprisBackend.runCtl([wheel.angleDelta.y > 0 ? "previous" : "next"])
    }

    Item {
      Layout.preferredWidth: mod.showRing ? 30 : (Theme.barVertical ? 24 : 22)
      Layout.preferredHeight: mod.showRing ? 30 : (Theme.barVertical ? 24 : 22)
      Layout.alignment: Qt.AlignCenter

      Shape {
        visible: mod.showRing
        anchors.fill: parent
        layer.enabled: mod.showRing
        layer.samples: 4

        ShapePath {
          strokeColor: Theme.withAlpha(Theme.text, 0.18)
          strokeWidth: 2
          fillColor: "transparent"
          PathAngleArc { centerX: 15; centerY: 15; radiusX: 14; radiusY: 14; startAngle: 0; sweepAngle: 360 }
        }
        ShapePath {
          strokeColor: Theme.primary
          strokeWidth: 2
          capStyle: ShapePath.RoundCap
          fillColor: "transparent"
          PathAngleArc {
            centerX: 15; centerY: 15; radiusX: 14; radiusY: 14
            startAngle: -90
            sweepAngle: 360 * MprisBackend.progressRatio
          }
        }
      }

      MdCover {
        anchors.centerIn: parent
        width: mod.showRing ? 22 : parent.width
        height: width
        source: MprisBackend.currentArt
        shape: mod.showRing ? "circle" : "square"
        decodeSize: 64
        glyph: mod.mprisStatus === "Playing" ? "󰎈" : (mod.mprisStatus === "Paused" ? "󰏤" : "󰝛")
        dimmed: mod.mprisStatus !== "Playing"
      }
    }

    ColumnLayout {
      visible: mod.hasText
      Layout.maximumWidth: mod.songMaxWidth
      Layout.alignment: Qt.AlignVCenter
      spacing: 2

      Text {
        Layout.fillWidth: true
        text: mod.hasSong ? mod.songLabel : Translations.t("mprisNoPlaying")
        elide: Text.ElideRight

        color: mod.hasSong ? Theme.text : Theme.subtext
        font.family: Theme.fontFamily
        font.pixelSize: Theme.fs(12)
      }

      Rectangle {
        visible: mod.showProgress
        Layout.fillWidth: true
        Layout.preferredHeight: 3
        radius: Theme.rad(2)
        color: Theme.withAlpha(Theme.text, 0.18)

        Rectangle {
          width: parent.width * MprisBackend.progressRatio
          height: parent.height
          radius: parent.radius
          color: Theme.primary
        }
      }
    }
  }

  // ─── Controles según estilo ───
  CtlButton {
    visible: mod.showControls
    glyph: "󰒮"
    ctl: "previous"
    hoverColor: mod.hoverColor
  }
  CtlButton {
    visible: mod.showControls || mod.miniPlay
    glyph: mod.mprisStatus === "Playing" ? "󰏤" : "󰐊"
    ctl: "play-pause"
    hoverColor: mod.hoverColor
  }
  CtlButton {
    visible: mod.showControls
    glyph: "󰒭"
    ctl: "next"
    hoverColor: mod.hoverColor
  }

  BarToggle {
    id: mprisToggle

    hoverColor: mod.hoverColor
    visible: !Theme.barVertical
    collapsed: Theme.mprisCompact
    contentAfter: false
    tip: Translations.t(Theme.mprisCompact ? "barExpand" : "barCollapse")

    onToggled: Theme.setMprisCompact(!Theme.mprisCompact)
    onHoverEntered: mod.host.tipEnter(mprisToggle)
    onHoverExited: mod.host.tipLeave(mprisToggle)
  }
}
