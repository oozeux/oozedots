// AudioBgStage

import QtQuick
import QtQuick.Shapes
import "../../COMMON"

Item {
  id: stage

  // ─── Entrada ───
  property bool reversed: false
  property bool mirror: false
  property bool active: true

  // ─── Derivados ───
  readonly property string sty: AudioBgConfig.style
  readonly property var vals: stage.active ? AudioBgService.values : []
  readonly property var pks: (stage.active && AudioBgConfig.peaks) ? AudioBgService.peaks : []
  readonly property int n: stage.vals.length
  readonly property real slot: stage.n > 0 ? stage.width / stage.n : 0
  readonly property real gap: Math.min(AudioBgConfig.gap, stage.slot * 0.8)
  readonly property real rnd: AudioBgConfig.roundness / 100
  readonly property bool cellStyle: stage.sty === "blocks" || stage.sty === "dots"
  readonly property bool curveStyle: stage.sty === "wave" || stage.sty === "line"
  readonly property bool peaksOn: AudioBgConfig.peaks && stage.pks.length === stage.n && stage.n > 0

  readonly property int cells: {
    if (!stage.cellStyle || stage.n === 0) return 0
    let c = Math.max(4, Math.min(24, Math.floor(stage.height / 16)))
    c = Math.min(c, Math.max(3, Math.floor(1600 / stage.n)))
    return stage.mirror ? Math.max(4, c - (c % 2)) : c
  }
  readonly property real pitch: stage.cells > 0 ? stage.height / stage.cells : 0
  readonly property real cellW: Math.max(1, stage.slot - stage.gap)
  readonly property real cellH: Math.max(2, stage.pitch - Math.max(1, Math.min(stage.gap, stage.pitch * 0.6)))
  readonly property real dotD: Math.max(2, Math.min(stage.cellW, stage.cellH))

  // ─── Acceso a datos ───
  function dataIndex(i) { return stage.reversed ? stage.n - 1 - i : i }
  function val(i) {
    const x = stage.vals[stage.dataIndex(i)]
    return x === undefined ? 0 : x / 1000
  }
  function peak(i) {
    const x = stage.pks[stage.dataIndex(i)]
    return x === undefined ? 0 : x / 1000
  }
  function tone(i) { return AudioBgConfig.colorAt(stage.n > 1 ? stage.dataIndex(i) / (stage.n - 1) : 0) }
  function toneAt(p) { return AudioBgConfig.colorAt(stage.reversed ? 1 - p : p) }

  // ─── Barras ───
  Repeater {
    model: stage.sty === "bars" ? stage.n : 0
    delegate: Rectangle {
      id: bar
      required property int index
      readonly property real v: stage.val(bar.index)
      visible: bar.v > 0.004
      width: Math.max(1, stage.slot - stage.gap)
      x: bar.index * stage.slot + (stage.slot - bar.width) / 2
      height: Math.max(2, bar.v * stage.height)
      y: stage.mirror ? (stage.height - bar.height) / 2 : stage.height - bar.height
      radius: Theme.rad(bar.width / 2 * stage.rnd)
      color: stage.tone(bar.index)
    }
  }

  // ─── Bloques y puntos ───
  Repeater {
    model: stage.cellStyle ? stage.n * stage.cells : 0
    delegate: Rectangle {
      id: cell
      required property int index
      readonly property int band: Math.floor(cell.index / stage.cells)
      readonly property int row: cell.index % stage.cells
      readonly property real v: stage.val(cell.band)
      readonly property bool dots: stage.sty === "dots"
      visible: stage.mirror
        ? Math.abs(cell.row + 0.5 - stage.cells / 2) < cell.v * stage.cells / 2
        : cell.row < Math.ceil(cell.v * stage.cells - 0.2)
      width: cell.dots ? stage.dotD : stage.cellW
      height: cell.dots ? stage.dotD : stage.cellH
      x: cell.band * stage.slot + (stage.slot - cell.width) / 2
      y: (stage.mirror ? cell.row * stage.pitch : stage.height - (cell.row + 1) * stage.pitch) + (stage.pitch - cell.height) / 2
      radius: Theme.rad(cell.dots ? cell.width / 2 : Math.min(cell.width, cell.height) / 2 * stage.rnd)
      color: stage.tone(cell.band)
    }
  }

  // ─── Picos ───
  readonly property real capH: stage.cellStyle ? stage.cellH : Math.max(2, Math.min(4, stage.height * 0.02))
  readonly property real capW: stage.sty === "dots" ? stage.dotD : (stage.cellStyle ? stage.cellW : Math.max(1, stage.slot - stage.gap))

  function capOff(p) {
    if (!stage.cellStyle) return p * (stage.mirror ? stage.height / 2 : stage.height)
    const rows = stage.mirror ? stage.cells / 2 : stage.cells
    return Math.max(1, Math.ceil(p * rows - 0.2)) * stage.pitch
  }
  function capY(p, below) {
    const off = stage.capOff(p)
    const h = stage.capH
    if (stage.cellStyle) {
      const pad = (stage.pitch - h) / 2
      if (!stage.mirror) return stage.height - off + pad
      return below ? stage.height / 2 + off - stage.pitch + pad : stage.height / 2 - off + pad
    }
    if (!stage.mirror) return stage.height - off - h
    return below ? stage.height / 2 + off : stage.height / 2 - off - h
  }

  Repeater {
    model: (stage.sty === "bars" || stage.cellStyle) && stage.peaksOn ? stage.n : 0
    delegate: Rectangle {
      id: cap
      required property int index
      readonly property real p: stage.peak(cap.index)
      visible: cap.p > 0.02
      width: stage.capW
      height: stage.capH
      x: cap.index * stage.slot + (stage.slot - cap.width) / 2
      y: stage.capY(cap.p, false)
      radius: Theme.rad(stage.sty === "dots" ? cap.width / 2 : Math.min(cap.width, cap.height) / 2 * stage.rnd)
      color: Qt.lighter(stage.tone(cap.index), 1.25)
    }
  }
  Repeater {
    model: (stage.sty === "bars" || stage.cellStyle) && stage.peaksOn && stage.mirror ? stage.n : 0
    delegate: Rectangle {
      id: capLow
      required property int index
      readonly property real p: stage.peak(capLow.index)
      visible: capLow.p > 0.02
      width: stage.capW
      height: stage.capH
      x: capLow.index * stage.slot + (stage.slot - capLow.width) / 2
      y: stage.capY(capLow.p, true)
      radius: Theme.rad(stage.sty === "dots" ? capLow.width / 2 : Math.min(capLow.width, capLow.height) / 2 * stage.rnd)
      color: Qt.lighter(stage.tone(capLow.index), 1.25)
    }
  }

  // ─── Columnas ───
  Repeater {
    model: stage.sty === "columns" ? stage.n : 0
    delegate: Rectangle {
      id: col
      required property int index
      readonly property real v: stage.val(col.index)
      readonly property color c: stage.tone(col.index)
      visible: col.v > 0.01
      opacity: Math.min(1, col.v * 1.2)
      width: Math.max(1, stage.slot - Math.min(stage.gap, stage.slot * 0.5))
      x: col.index * stage.slot + (stage.slot - col.width) / 2
      height: stage.height
      radius: Theme.rad(col.width / 2 * stage.rnd)
      gradient: Gradient {
        GradientStop { position: 0; color: Qt.alpha(col.c, 0) }
        GradientStop { position: stage.mirror ? 0.5 : 1; color: Qt.alpha(col.c, 0.95) }
        GradientStop { position: 1; color: stage.mirror ? Qt.alpha(col.c, 0) : Qt.alpha(col.c, 0.95) }
      }
    }
  }

  // ─── Curvas ───
  readonly property var topPts: stage.curveStyle ? stage.curvePoints(false) : []
  readonly property var botPts: (stage.curveStyle && stage.mirror) ? stage.curvePoints(true) : []

  function curvePoints(bottom) {
    const m = stage.n
    const W = stage.width
    const H = stage.height
    const pts = new Array(m)
    for (let i = 0; i < m; i++) {
      const v = stage.val(i)
      const x = m > 1 ? i / (m - 1) * W : 0
      let y
      if (stage.mirror) y = bottom ? H / 2 + v * (H / 2 - 2) : H / 2 - v * (H / 2 - 2)
      else y = H - 1 - v * (H - 3)
      pts[i] = Qt.point(x, y)
    }
    return pts
  }

  function areaPoints() {
    const W = stage.width
    const H = stage.height
    if (stage.topPts.length === 0) return []
    if (stage.mirror) return stage.topPts.concat(stage.botPts.slice().reverse())
    return [Qt.point(0, H + 6)].concat(stage.topPts, [Qt.point(W, H + 6)])
  }

  function slice(arr, q, parts) {
    const last = arr.length - 1
    if (last < 1) return []
    const a = Math.floor(q * last / parts)
    const b = Math.min(last, Math.ceil((q + 1) * last / parts))
    return arr.slice(a, b + 1)
  }

  function segPaths(q, parts) {
    const t = stage.slice(stage.topPts, q, parts)
    if (!stage.mirror) return t.length > 1 ? [t] : []
    const b = stage.slice(stage.botPts, q, parts)
    return t.length > 1 ? [t, b] : []
  }

  component LineSeg: ShapePath {
    id: seg
    property var host: null
    property int q: 0
    readonly property int parts: 6
    strokeColor: seg.host ? seg.host.toneAt((seg.q + 0.5) / seg.parts) : "transparent"
    strokeWidth: (seg.host && seg.host.sty === "wave") ? 2 : 3
    capStyle: ShapePath.RoundCap
    joinStyle: ShapePath.RoundJoin
    fillColor: "transparent"
    PathMultiline { paths: seg.host ? seg.host.segPaths(seg.q, seg.parts) : [] }
  }

  Loader {
    anchors.fill: parent
    active: stage.sty === "wave"
    sourceComponent: Shape {
      ShapePath {
        strokeColor: "transparent"
        strokeWidth: 0
        fillGradient: LinearGradient {
          x1: 0; y1: 0; x2: stage.width; y2: 0
          GradientStop { position: 0; color: Qt.alpha(stage.toneAt(0), 0.34) }
          GradientStop { position: 0.25; color: Qt.alpha(stage.toneAt(0.25), 0.34) }
          GradientStop { position: 0.5; color: Qt.alpha(stage.toneAt(0.5), 0.34) }
          GradientStop { position: 0.75; color: Qt.alpha(stage.toneAt(0.75), 0.34) }
          GradientStop { position: 1; color: Qt.alpha(stage.toneAt(1), 0.34) }
        }
        PathPolyline { path: stage.areaPoints() }
      }
    }
  }

  Loader {
    anchors.fill: parent
    active: stage.curveStyle
    sourceComponent: Shape {
      preferredRendererType: Shape.CurveRenderer
      LineSeg { host: stage; q: 0 }
      LineSeg { host: stage; q: 1 }
      LineSeg { host: stage; q: 2 }
      LineSeg { host: stage; q: 3 }
      LineSeg { host: stage; q: 4 }
      LineSeg { host: stage; q: 5 }
    }
  }
}
